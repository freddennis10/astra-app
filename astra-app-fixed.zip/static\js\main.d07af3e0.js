/*! For license information please see main.d07af3e0.js.LICENSE.txt */
(()=>{var e={4:(e,t,n)=>{"use strict";var r=n(853),i=n(43),o=n(950);function a(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function s(e){return!(!e||1!==e.nodeType&&9!==e.nodeType&&11!==e.nodeType)}function l(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do{0!==(4098&(t=e).flags)&&(n=t.return),e=t.return}while(e)}return 3===t.tag?n:null}function c(e){if(13===e.tag){var t=e.memoizedState;if(null===t&&(null!==(e=e.alternate)&&(t=e.memoizedState)),null!==t)return t.dehydrated}return null}function u(e){if(l(e)!==e)throw Error(a(188))}function d(e){var t=e.tag;if(5===t||26===t||27===t||6===t)return e;for(e=e.child;null!==e;){if(null!==(t=d(e)))return t;e=e.sibling}return null}var h=Object.assign,p=Symbol.for("react.element"),m=Symbol.for("react.transitional.element"),f=Symbol.for("react.portal"),g=Symbol.for("react.fragment"),y=Symbol.for("react.strict_mode"),x=Symbol.for("react.profiler"),v=Symbol.for("react.provider"),b=Symbol.for("react.consumer"),w=Symbol.for("react.context"),k=Symbol.for("react.forward_ref"),S=Symbol.for("react.suspense"),j=Symbol.for("react.suspense_list"),$=Symbol.for("react.memo"),C=Symbol.for("react.lazy");Symbol.for("react.scope");var E=Symbol.for("react.activity");Symbol.for("react.legacy_hidden"),Symbol.for("react.tracing_marker");var T=Symbol.for("react.memo_cache_sentinel");Symbol.for("react.view_transition");var P=Symbol.iterator;function z(e){return null===e||"object"!==typeof e?null:"function"===typeof(e=P&&e[P]||e["@@iterator"])?e:null}var A=Symbol.for("react.client.reference");function R(e){if(null==e)return null;if("function"===typeof e)return e.$$typeof===A?null:e.displayName||e.name||null;if("string"===typeof e)return e;switch(e){case g:return"Fragment";case x:return"Profiler";case y:return"StrictMode";case S:return"Suspense";case j:return"SuspenseList";case E:return"Activity"}if("object"===typeof e)switch(e.$$typeof){case f:return"Portal";case w:return(e.displayName||"Context")+".Provider";case b:return(e._context.displayName||"Context")+".Consumer";case k:var t=e.render;return(e=e.displayName)||(e=""!==(e=t.displayName||t.name||"")?"ForwardRef("+e+")":"ForwardRef"),e;case $:return null!==(t=e.displayName||null)?t:R(e.type)||"Memo";case C:t=e._payload,e=e._init;try{return R(e(t))}catch(n){}}return null}var M=Array.isArray,L=i.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,D=o.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,O={pending:!1,data:null,method:null,action:null},F=[],N=-1;function _(e){return{current:e}}function I(e){0>N||(e.current=F[N],F[N]=null,N--)}function V(e,t){N++,F[N]=e.current,e.current=t}var B=_(null),W=_(null),H=_(null),U=_(null);function q(e,t){switch(V(H,t),V(W,e),V(B,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?id(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)e=od(t=id(t),e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}I(B),V(B,e)}function Y(){I(B),I(W),I(H)}function K(e){null!==e.memoizedState&&V(U,e);var t=B.current,n=od(t,e.type);t!==n&&(V(W,e),V(B,n))}function G(e){W.current===e&&(I(B),I(W)),U.current===e&&(I(U),Kd._currentValue=O)}var X=Object.prototype.hasOwnProperty,Q=r.unstable_scheduleCallback,J=r.unstable_cancelCallback,Z=r.unstable_shouldYield,ee=r.unstable_requestPaint,te=r.unstable_now,ne=r.unstable_getCurrentPriorityLevel,re=r.unstable_ImmediatePriority,ie=r.unstable_UserBlockingPriority,oe=r.unstable_NormalPriority,ae=r.unstable_LowPriority,se=r.unstable_IdlePriority,le=r.log,ce=r.unstable_setDisableYieldValue,ue=null,de=null;function he(e){if("function"===typeof le&&ce(e),de&&"function"===typeof de.setStrictMode)try{de.setStrictMode(ue,e)}catch(t){}}var pe=Math.clz32?Math.clz32:function(e){return 0===(e>>>=0)?32:31-(me(e)/fe|0)|0},me=Math.log,fe=Math.LN2;var ge=256,ye=4194304;function xe(e){var t=42&e;if(0!==t)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return 4194048&e;case 4194304:case 8388608:case 16777216:case 33554432:return 62914560&e;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function ve(e,t,n){var r=e.pendingLanes;if(0===r)return 0;var i=0,o=e.suspendedLanes,a=e.pingedLanes;e=e.warmLanes;var s=134217727&r;return 0!==s?0!==(r=s&~o)?i=xe(r):0!==(a&=s)?i=xe(a):n||0!==(n=s&~e)&&(i=xe(n)):0!==(s=r&~o)?i=xe(s):0!==a?i=xe(a):n||0!==(n=r&~e)&&(i=xe(n)),0===i?0:0!==t&&t!==i&&0===(t&o)&&((o=i&-i)>=(n=t&-t)||32===o&&0!==(4194048&n))?t:i}function be(e,t){return 0===(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)}function we(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;default:return-1}}function ke(){var e=ge;return 0===(4194048&(ge<<=1))&&(ge=256),e}function Se(){var e=ye;return 0===(62914560&(ye<<=1))&&(ye=4194304),e}function je(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function $e(e,t){e.pendingLanes|=t,268435456!==t&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function Ce(e,t,n){e.pendingLanes|=t,e.suspendedLanes&=~t;var r=31-pe(t);e.entangledLanes|=t,e.entanglements[r]=1073741824|e.entanglements[r]|4194090&n}function Ee(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-pe(n),i=1<<r;i&t|e[r]&t&&(e[r]|=t),n&=~i}}function Te(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function Pe(e){return 2<(e&=-e)?8<e?0!==(134217727&e)?32:268435456:8:2}function ze(){var e=D.p;return 0!==e?e:void 0===(e=window.event)?32:ch(e.type)}var Ae=Math.random().toString(36).slice(2),Re="__reactFiber$"+Ae,Me="__reactProps$"+Ae,Le="__reactContainer$"+Ae,De="__reactEvents$"+Ae,Oe="__reactListeners$"+Ae,Fe="__reactHandles$"+Ae,Ne="__reactResources$"+Ae,_e="__reactMarker$"+Ae;function Ie(e){delete e[Re],delete e[Me],delete e[De],delete e[Oe],delete e[Fe]}function Ve(e){var t=e[Re];if(t)return t;for(var n=e.parentNode;n;){if(t=n[Le]||n[Re]){if(n=t.alternate,null!==t.child||null!==n&&null!==n.child)for(e=vd(e);null!==e;){if(n=e[Re])return n;e=vd(e)}return t}n=(e=n).parentNode}return null}function Be(e){if(e=e[Re]||e[Le]){var t=e.tag;if(5===t||6===t||13===t||26===t||27===t||3===t)return e}return null}function We(e){var t=e.tag;if(5===t||26===t||27===t||6===t)return e.stateNode;throw Error(a(33))}function He(e){var t=e[Ne];return t||(t=e[Ne]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function Ue(e){e[_e]=!0}var qe=new Set,Ye={};function Ke(e,t){Ge(e,t),Ge(e+"Capture",t)}function Ge(e,t){for(Ye[e]=t,e=0;e<t.length;e++)qe.add(t[e])}var Xe,Qe,Je=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Ze={},et={};function tt(e,t,n){if(i=t,X.call(et,i)||!X.call(Ze,i)&&(Je.test(i)?et[i]=!0:(Ze[i]=!0,0)))if(null===n)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":return void e.removeAttribute(t);case"boolean":var r=t.toLowerCase().slice(0,5);if("data-"!==r&&"aria-"!==r)return void e.removeAttribute(t)}e.setAttribute(t,""+n)}var i}function nt(e,t,n){if(null===n)e.removeAttribute(t);else{switch(typeof n){case"undefined":case"function":case"symbol":case"boolean":return void e.removeAttribute(t)}e.setAttribute(t,""+n)}}function rt(e,t,n,r){if(null===r)e.removeAttribute(n);else{switch(typeof r){case"undefined":case"function":case"symbol":case"boolean":return void e.removeAttribute(n)}e.setAttributeNS(t,n,""+r)}}function it(e){if(void 0===Xe)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);Xe=t&&t[1]||"",Qe=-1<n.stack.indexOf("\n    at")?" (<anonymous>)":-1<n.stack.indexOf("@")?"@unknown:0:0":""}return"\n"+Xe+e+Qe}var ot=!1;function at(e,t){if(!e||ot)return"";ot=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var r={DetermineComponentFrameRoot:function(){try{if(t){var n=function(){throw Error()};if(Object.defineProperty(n.prototype,"props",{set:function(){throw Error()}}),"object"===typeof Reflect&&Reflect.construct){try{Reflect.construct(n,[])}catch(i){var r=i}Reflect.construct(e,[],n)}else{try{n.call()}catch(o){r=o}e.call(n.prototype)}}else{try{throw Error()}catch(a){r=a}(n=e())&&"function"===typeof n.catch&&n.catch(function(){})}}catch(s){if(s&&r&&"string"===typeof s.stack)return[s.stack,r.stack]}return[null,null]}};r.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var i=Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot,"name");i&&i.configurable&&Object.defineProperty(r.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var o=r.DetermineComponentFrameRoot(),a=o[0],s=o[1];if(a&&s){var l=a.split("\n"),c=s.split("\n");for(i=r=0;r<l.length&&!l[r].includes("DetermineComponentFrameRoot");)r++;for(;i<c.length&&!c[i].includes("DetermineComponentFrameRoot");)i++;if(r===l.length||i===c.length)for(r=l.length-1,i=c.length-1;1<=r&&0<=i&&l[r]!==c[i];)i--;for(;1<=r&&0<=i;r--,i--)if(l[r]!==c[i]){if(1!==r||1!==i)do{if(r--,0>--i||l[r]!==c[i]){var u="\n"+l[r].replace(" at new "," at ");return e.displayName&&u.includes("<anonymous>")&&(u=u.replace("<anonymous>",e.displayName)),u}}while(1<=r&&0<=i);break}}}finally{ot=!1,Error.prepareStackTrace=n}return(n=e?e.displayName||e.name:"")?it(n):""}function st(e){switch(e.tag){case 26:case 27:case 5:return it(e.type);case 16:return it("Lazy");case 13:return it("Suspense");case 19:return it("SuspenseList");case 0:case 15:return at(e.type,!1);case 11:return at(e.type.render,!1);case 1:return at(e.type,!0);case 31:return it("Activity");default:return""}}function lt(e){try{var t="";do{t+=st(e),e=e.return}while(e);return t}catch(n){return"\nError generating stack: "+n.message+"\n"+n.stack}}function ct(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":case"object":return e;default:return""}}function ut(e){var t=e.type;return(e=e.nodeName)&&"input"===e.toLowerCase()&&("checkbox"===t||"radio"===t)}function dt(e){e._valueTracker||(e._valueTracker=function(e){var t=ut(e)?"checked":"value",n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=""+e[t];if(!e.hasOwnProperty(t)&&"undefined"!==typeof n&&"function"===typeof n.get&&"function"===typeof n.set){var i=n.get,o=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(e){r=""+e,o.call(this,e)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(e){r=""+e},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}(e))}function ht(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r="";return e&&(r=ut(e)?e.checked?"true":"false":e.value),(e=r)!==n&&(t.setValue(e),!0)}function pt(e){if("undefined"===typeof(e=e||("undefined"!==typeof document?document:void 0)))return null;try{return e.activeElement||e.body}catch(t){return e.body}}var mt=/[\n"\\]/g;function ft(e){return e.replace(mt,function(e){return"\\"+e.charCodeAt(0).toString(16)+" "})}function gt(e,t,n,r,i,o,a,s){e.name="",null!=a&&"function"!==typeof a&&"symbol"!==typeof a&&"boolean"!==typeof a?e.type=a:e.removeAttribute("type"),null!=t?"number"===a?(0===t&&""===e.value||e.value!=t)&&(e.value=""+ct(t)):e.value!==""+ct(t)&&(e.value=""+ct(t)):"submit"!==a&&"reset"!==a||e.removeAttribute("value"),null!=t?xt(e,a,ct(t)):null!=n?xt(e,a,ct(n)):null!=r&&e.removeAttribute("value"),null==i&&null!=o&&(e.defaultChecked=!!o),null!=i&&(e.checked=i&&"function"!==typeof i&&"symbol"!==typeof i),null!=s&&"function"!==typeof s&&"symbol"!==typeof s&&"boolean"!==typeof s?e.name=""+ct(s):e.removeAttribute("name")}function yt(e,t,n,r,i,o,a,s){if(null!=o&&"function"!==typeof o&&"symbol"!==typeof o&&"boolean"!==typeof o&&(e.type=o),null!=t||null!=n){if(!("submit"!==o&&"reset"!==o||void 0!==t&&null!==t))return;n=null!=n?""+ct(n):"",t=null!=t?""+ct(t):n,s||t===e.value||(e.value=t),e.defaultValue=t}r="function"!==typeof(r=null!=r?r:i)&&"symbol"!==typeof r&&!!r,e.checked=s?e.checked:!!r,e.defaultChecked=!!r,null!=a&&"function"!==typeof a&&"symbol"!==typeof a&&"boolean"!==typeof a&&(e.name=a)}function xt(e,t,n){"number"===t&&pt(e.ownerDocument)===e||e.defaultValue===""+n||(e.defaultValue=""+n)}function vt(e,t,n,r){if(e=e.options,t){t={};for(var i=0;i<n.length;i++)t["$"+n[i]]=!0;for(n=0;n<e.length;n++)i=t.hasOwnProperty("$"+e[n].value),e[n].selected!==i&&(e[n].selected=i),i&&r&&(e[n].defaultSelected=!0)}else{for(n=""+ct(n),t=null,i=0;i<e.length;i++){if(e[i].value===n)return e[i].selected=!0,void(r&&(e[i].defaultSelected=!0));null!==t||e[i].disabled||(t=e[i])}null!==t&&(t.selected=!0)}}function bt(e,t,n){null==t||((t=""+ct(t))!==e.value&&(e.value=t),null!=n)?e.defaultValue=null!=n?""+ct(n):"":e.defaultValue!==t&&(e.defaultValue=t)}function wt(e,t,n,r){if(null==t){if(null!=r){if(null!=n)throw Error(a(92));if(M(r)){if(1<r.length)throw Error(a(93));r=r[0]}n=r}null==n&&(n=""),t=n}n=ct(t),e.defaultValue=n,(r=e.textContent)===n&&""!==r&&null!==r&&(e.value=r)}function kt(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&3===n.nodeType)return void(n.nodeValue=t)}e.textContent=t}var St=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function jt(e,t,n){var r=0===t.indexOf("--");null==n||"boolean"===typeof n||""===n?r?e.setProperty(t,""):"float"===t?e.cssFloat="":e[t]="":r?e.setProperty(t,n):"number"!==typeof n||0===n||St.has(t)?"float"===t?e.cssFloat=n:e[t]=(""+n).trim():e[t]=n+"px"}function $t(e,t,n){if(null!=t&&"object"!==typeof t)throw Error(a(62));if(e=e.style,null!=n){for(var r in n)!n.hasOwnProperty(r)||null!=t&&t.hasOwnProperty(r)||(0===r.indexOf("--")?e.setProperty(r,""):"float"===r?e.cssFloat="":e[r]="");for(var i in t)r=t[i],t.hasOwnProperty(i)&&n[i]!==r&&jt(e,i,r)}else for(var o in t)t.hasOwnProperty(o)&&jt(e,o,t[o])}function Ct(e){if(-1===e.indexOf("-"))return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Et=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Tt=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Pt(e){return Tt.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}var zt=null;function At(e){return(e=e.target||e.srcElement||window).correspondingUseElement&&(e=e.correspondingUseElement),3===e.nodeType?e.parentNode:e}var Rt=null,Mt=null;function Lt(e){var t=Be(e);if(t&&(e=t.stateNode)){var n=e[Me]||null;e:switch(e=t.stateNode,t.type){case"input":if(gt(e,n.value,n.defaultValue,n.defaultValue,n.checked,n.defaultChecked,n.type,n.name),t=n.name,"radio"===n.type&&null!=t){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll('input[name="'+ft(""+t)+'"][type="radio"]'),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var i=r[Me]||null;if(!i)throw Error(a(90));gt(r,i.value,i.defaultValue,i.defaultValue,i.checked,i.defaultChecked,i.type,i.name)}}for(t=0;t<n.length;t++)(r=n[t]).form===e.form&&ht(r)}break e;case"textarea":bt(e,n.value,n.defaultValue);break e;case"select":null!=(t=n.value)&&vt(e,!!n.multiple,t,!1)}}}var Dt=!1;function Ot(e,t,n){if(Dt)return e(t,n);Dt=!0;try{return e(t)}finally{if(Dt=!1,(null!==Rt||null!==Mt)&&(Vc(),Rt&&(t=Rt,e=Mt,Mt=Rt=null,Lt(t),e)))for(t=0;t<e.length;t++)Lt(e[t])}}function Ft(e,t){var n=e.stateNode;if(null===n)return null;var r=n[Me]||null;if(null===r)return null;n=r[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(r=!("button"===(e=e.type)||"input"===e||"select"===e||"textarea"===e)),e=!r;break e;default:e=!1}if(e)return null;if(n&&"function"!==typeof n)throw Error(a(231,t,typeof n));return n}var Nt=!("undefined"===typeof window||"undefined"===typeof window.document||"undefined"===typeof window.document.createElement),_t=!1;if(Nt)try{var It={};Object.defineProperty(It,"passive",{get:function(){_t=!0}}),window.addEventListener("test",It,It),window.removeEventListener("test",It,It)}catch(Mh){_t=!1}var Vt=null,Bt=null,Wt=null;function Ht(){if(Wt)return Wt;var e,t,n=Bt,r=n.length,i="value"in Vt?Vt.value:Vt.textContent,o=i.length;for(e=0;e<r&&n[e]===i[e];e++);var a=r-e;for(t=1;t<=a&&n[r-t]===i[o-t];t++);return Wt=i.slice(e,1<t?1-t:void 0)}function Ut(e){var t=e.keyCode;return"charCode"in e?0===(e=e.charCode)&&13===t&&(e=13):e=t,10===e&&(e=13),32<=e||13===e?e:0}function qt(){return!0}function Yt(){return!1}function Kt(e){function t(t,n,r,i,o){for(var a in this._reactName=t,this._targetInst=r,this.type=n,this.nativeEvent=i,this.target=o,this.currentTarget=null,e)e.hasOwnProperty(a)&&(t=e[a],this[a]=t?t(i):i[a]);return this.isDefaultPrevented=(null!=i.defaultPrevented?i.defaultPrevented:!1===i.returnValue)?qt:Yt,this.isPropagationStopped=Yt,this}return h(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():"unknown"!==typeof e.returnValue&&(e.returnValue=!1),this.isDefaultPrevented=qt)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():"unknown"!==typeof e.cancelBubble&&(e.cancelBubble=!0),this.isPropagationStopped=qt)},persist:function(){},isPersistent:qt}),t}var Gt,Xt,Qt,Jt={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Zt=Kt(Jt),en=h({},Jt,{view:0,detail:0}),tn=Kt(en),nn=h({},en,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:mn,button:0,buttons:0,relatedTarget:function(e){return void 0===e.relatedTarget?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==Qt&&(Qt&&"mousemove"===e.type?(Gt=e.screenX-Qt.screenX,Xt=e.screenY-Qt.screenY):Xt=Gt=0,Qt=e),Gt)},movementY:function(e){return"movementY"in e?e.movementY:Xt}}),rn=Kt(nn),on=Kt(h({},nn,{dataTransfer:0})),an=Kt(h({},en,{relatedTarget:0})),sn=Kt(h({},Jt,{animationName:0,elapsedTime:0,pseudoElement:0})),ln=Kt(h({},Jt,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}})),cn=Kt(h({},Jt,{data:0})),un={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},dn={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},hn={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function pn(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):!!(e=hn[e])&&!!t[e]}function mn(){return pn}var fn=Kt(h({},en,{key:function(e){if(e.key){var t=un[e.key]||e.key;if("Unidentified"!==t)return t}return"keypress"===e.type?13===(e=Ut(e))?"Enter":String.fromCharCode(e):"keydown"===e.type||"keyup"===e.type?dn[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:mn,charCode:function(e){return"keypress"===e.type?Ut(e):0},keyCode:function(e){return"keydown"===e.type||"keyup"===e.type?e.keyCode:0},which:function(e){return"keypress"===e.type?Ut(e):"keydown"===e.type||"keyup"===e.type?e.keyCode:0}})),gn=Kt(h({},nn,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),yn=Kt(h({},en,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:mn})),xn=Kt(h({},Jt,{propertyName:0,elapsedTime:0,pseudoElement:0})),vn=Kt(h({},nn,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0})),bn=Kt(h({},Jt,{newState:0,oldState:0})),wn=[9,13,27,32],kn=Nt&&"CompositionEvent"in window,Sn=null;Nt&&"documentMode"in document&&(Sn=document.documentMode);var jn=Nt&&"TextEvent"in window&&!Sn,$n=Nt&&(!kn||Sn&&8<Sn&&11>=Sn),Cn=String.fromCharCode(32),En=!1;function Tn(e,t){switch(e){case"keyup":return-1!==wn.indexOf(t.keyCode);case"keydown":return 229!==t.keyCode;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Pn(e){return"object"===typeof(e=e.detail)&&"data"in e?e.data:null}var zn=!1;var An={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Rn(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return"input"===t?!!An[e.type]:"textarea"===t}function Mn(e,t,n,r){Rt?Mt?Mt.push(r):Mt=[r]:Rt=r,0<(t=Hu(t,"onChange")).length&&(n=new Zt("onChange","change",null,n,r),e.push({event:n,listeners:t}))}var Ln=null,Dn=null;function On(e){Ou(e,0)}function Fn(e){if(ht(We(e)))return e}function Nn(e,t){if("change"===e)return t}var _n=!1;if(Nt){var In;if(Nt){var Vn="oninput"in document;if(!Vn){var Bn=document.createElement("div");Bn.setAttribute("oninput","return;"),Vn="function"===typeof Bn.oninput}In=Vn}else In=!1;_n=In&&(!document.documentMode||9<document.documentMode)}function Wn(){Ln&&(Ln.detachEvent("onpropertychange",Hn),Dn=Ln=null)}function Hn(e){if("value"===e.propertyName&&Fn(Dn)){var t=[];Mn(t,Dn,e,At(e)),Ot(On,t)}}function Un(e,t,n){"focusin"===e?(Wn(),Dn=n,(Ln=t).attachEvent("onpropertychange",Hn)):"focusout"===e&&Wn()}function qn(e){if("selectionchange"===e||"keyup"===e||"keydown"===e)return Fn(Dn)}function Yn(e,t){if("click"===e)return Fn(t)}function Kn(e,t){if("input"===e||"change"===e)return Fn(t)}var Gn="function"===typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e===1/t)||e!==e&&t!==t};function Xn(e,t){if(Gn(e,t))return!0;if("object"!==typeof e||null===e||"object"!==typeof t||null===t)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var i=n[r];if(!X.call(t,i)||!Gn(e[i],t[i]))return!1}return!0}function Qn(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Jn(e,t){var n,r=Qn(e);for(e=0;r;){if(3===r.nodeType){if(n=e+r.textContent.length,e<=t&&n>=t)return{node:r,offset:t-e};e=n}e:{for(;r;){if(r.nextSibling){r=r.nextSibling;break e}r=r.parentNode}r=void 0}r=Qn(r)}}function Zn(e,t){return!(!e||!t)&&(e===t||(!e||3!==e.nodeType)&&(t&&3===t.nodeType?Zn(e,t.parentNode):"contains"in e?e.contains(t):!!e.compareDocumentPosition&&!!(16&e.compareDocumentPosition(t))))}function er(e){for(var t=pt((e=null!=e&&null!=e.ownerDocument&&null!=e.ownerDocument.defaultView?e.ownerDocument.defaultView:window).document);t instanceof e.HTMLIFrameElement;){try{var n="string"===typeof t.contentWindow.location.href}catch(r){n=!1}if(!n)break;t=pt((e=t.contentWindow).document)}return t}function tr(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&("input"===t&&("text"===e.type||"search"===e.type||"tel"===e.type||"url"===e.type||"password"===e.type)||"textarea"===t||"true"===e.contentEditable)}var nr=Nt&&"documentMode"in document&&11>=document.documentMode,rr=null,ir=null,or=null,ar=!1;function sr(e,t,n){var r=n.window===n?n.document:9===n.nodeType?n:n.ownerDocument;ar||null==rr||rr!==pt(r)||("selectionStart"in(r=rr)&&tr(r)?r={start:r.selectionStart,end:r.selectionEnd}:r={anchorNode:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection()).anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset},or&&Xn(or,r)||(or=r,0<(r=Hu(ir,"onSelect")).length&&(t=new Zt("onSelect","select",null,t,n),e.push({event:t,listeners:r}),t.target=rr)))}function lr(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var cr={animationend:lr("Animation","AnimationEnd"),animationiteration:lr("Animation","AnimationIteration"),animationstart:lr("Animation","AnimationStart"),transitionrun:lr("Transition","TransitionRun"),transitionstart:lr("Transition","TransitionStart"),transitioncancel:lr("Transition","TransitionCancel"),transitionend:lr("Transition","TransitionEnd")},ur={},dr={};function hr(e){if(ur[e])return ur[e];if(!cr[e])return e;var t,n=cr[e];for(t in n)if(n.hasOwnProperty(t)&&t in dr)return ur[e]=n[t];return e}Nt&&(dr=document.createElement("div").style,"AnimationEvent"in window||(delete cr.animationend.animation,delete cr.animationiteration.animation,delete cr.animationstart.animation),"TransitionEvent"in window||delete cr.transitionend.transition);var pr=hr("animationend"),mr=hr("animationiteration"),fr=hr("animationstart"),gr=hr("transitionrun"),yr=hr("transitionstart"),xr=hr("transitioncancel"),vr=hr("transitionend"),br=new Map,wr="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function kr(e,t){br.set(e,t),Ke(t,[e])}wr.push("scrollEnd");var Sr=new WeakMap;function jr(e,t){if("object"===typeof e&&null!==e){var n=Sr.get(e);return void 0!==n?n:(t={value:e,source:t,stack:lt(t)},Sr.set(e,t),t)}return{value:e,source:t,stack:lt(t)}}var $r=[],Cr=0,Er=0;function Tr(){for(var e=Cr,t=Er=Cr=0;t<e;){var n=$r[t];$r[t++]=null;var r=$r[t];$r[t++]=null;var i=$r[t];$r[t++]=null;var o=$r[t];if($r[t++]=null,null!==r&&null!==i){var a=r.pending;null===a?i.next=i:(i.next=a.next,a.next=i),r.pending=i}0!==o&&Rr(n,i,o)}}function Pr(e,t,n,r){$r[Cr++]=e,$r[Cr++]=t,$r[Cr++]=n,$r[Cr++]=r,Er|=r,e.lanes|=r,null!==(e=e.alternate)&&(e.lanes|=r)}function zr(e,t,n,r){return Pr(e,t,n,r),Mr(e)}function Ar(e,t){return Pr(e,null,null,t),Mr(e)}function Rr(e,t,n){e.lanes|=n;var r=e.alternate;null!==r&&(r.lanes|=n);for(var i=!1,o=e.return;null!==o;)o.childLanes|=n,null!==(r=o.alternate)&&(r.childLanes|=n),22===o.tag&&(null===(e=o.stateNode)||1&e._visibility||(i=!0)),e=o,o=o.return;return 3===e.tag?(o=e.stateNode,i&&null!==t&&(i=31-pe(n),null===(r=(e=o.hiddenUpdates)[i])?e[i]=[t]:r.push(t),t.lane=536870912|n),o):null}function Mr(e){if(50<Rc)throw Rc=0,Mc=null,Error(a(185));for(var t=e.return;null!==t;)t=(e=t).return;return 3===e.tag?e.stateNode:null}var Lr={};function Dr(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Or(e,t,n,r){return new Dr(e,t,n,r)}function Fr(e){return!(!(e=e.prototype)||!e.isReactComponent)}function Nr(e,t){var n=e.alternate;return null===n?((n=Or(e.tag,t,e.key,e.mode)).elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=65011712&e.flags,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=null===t?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n.refCleanup=e.refCleanup,n}function _r(e,t){e.flags&=65011714;var n=e.alternate;return null===n?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,t=n.dependencies,e.dependencies=null===t?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function Ir(e,t,n,r,i,o){var s=0;if(r=e,"function"===typeof e)Fr(e)&&(s=1);else if("string"===typeof e)s=function(e,t,n){if(1===n||null!=t.itemProp)return!1;switch(e){case"meta":case"title":return!0;case"style":if("string"!==typeof t.precedence||"string"!==typeof t.href||""===t.href)break;return!0;case"link":if("string"!==typeof t.rel||"string"!==typeof t.href||""===t.href||t.onLoad||t.onError)break;return"stylesheet"!==t.rel||(e=t.disabled,"string"===typeof t.precedence&&null==e);case"script":if(t.async&&"function"!==typeof t.async&&"symbol"!==typeof t.async&&!t.onLoad&&!t.onError&&t.src&&"string"===typeof t.src)return!0}return!1}(e,n,B.current)?26:"html"===e||"head"===e||"body"===e?27:5;else e:switch(e){case E:return(e=Or(31,n,t,i)).elementType=E,e.lanes=o,e;case g:return Vr(n.children,i,o,t);case y:s=8,i|=24;break;case x:return(e=Or(12,n,t,2|i)).elementType=x,e.lanes=o,e;case S:return(e=Or(13,n,t,i)).elementType=S,e.lanes=o,e;case j:return(e=Or(19,n,t,i)).elementType=j,e.lanes=o,e;default:if("object"===typeof e&&null!==e)switch(e.$$typeof){case v:case w:s=10;break e;case b:s=9;break e;case k:s=11;break e;case $:s=14;break e;case C:s=16,r=null;break e}s=29,n=Error(a(130,null===e?"null":typeof e,"")),r=null}return(t=Or(s,n,t,i)).elementType=e,t.type=r,t.lanes=o,t}function Vr(e,t,n,r){return(e=Or(7,e,r,t)).lanes=n,e}function Br(e,t,n){return(e=Or(6,e,null,t)).lanes=n,e}function Wr(e,t,n){return(t=Or(4,null!==e.children?e.children:[],e.key,t)).lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var Hr=[],Ur=0,qr=null,Yr=0,Kr=[],Gr=0,Xr=null,Qr=1,Jr="";function Zr(e,t){Hr[Ur++]=Yr,Hr[Ur++]=qr,qr=e,Yr=t}function ei(e,t,n){Kr[Gr++]=Qr,Kr[Gr++]=Jr,Kr[Gr++]=Xr,Xr=e;var r=Qr;e=Jr;var i=32-pe(r)-1;r&=~(1<<i),n+=1;var o=32-pe(t)+i;if(30<o){var a=i-i%5;o=(r&(1<<a)-1).toString(32),r>>=a,i-=a,Qr=1<<32-pe(t)+i|n<<i|r,Jr=o+e}else Qr=1<<o|n<<i|r,Jr=e}function ti(e){null!==e.return&&(Zr(e,1),ei(e,1,0))}function ni(e){for(;e===qr;)qr=Hr[--Ur],Hr[Ur]=null,Yr=Hr[--Ur],Hr[Ur]=null;for(;e===Xr;)Xr=Kr[--Gr],Kr[Gr]=null,Jr=Kr[--Gr],Kr[Gr]=null,Qr=Kr[--Gr],Kr[Gr]=null}var ri=null,ii=null,oi=!1,ai=null,si=!1,li=Error(a(519));function ci(e){throw fi(jr(Error(a(418,"")),e)),li}function ui(e){var t=e.stateNode,n=e.type,r=e.memoizedProps;switch(t[Re]=e,t[Me]=r,n){case"dialog":Fu("cancel",t),Fu("close",t);break;case"iframe":case"object":case"embed":Fu("load",t);break;case"video":case"audio":for(n=0;n<Lu.length;n++)Fu(Lu[n],t);break;case"source":Fu("error",t);break;case"img":case"image":case"link":Fu("error",t),Fu("load",t);break;case"details":Fu("toggle",t);break;case"input":Fu("invalid",t),yt(t,r.value,r.defaultValue,r.checked,r.defaultChecked,r.type,r.name,!0),dt(t);break;case"select":Fu("invalid",t);break;case"textarea":Fu("invalid",t),wt(t,r.value,r.defaultValue,r.children),dt(t)}"string"!==typeof(n=r.children)&&"number"!==typeof n&&"bigint"!==typeof n||t.textContent===""+n||!0===r.suppressHydrationWarning||Xu(t.textContent,n)?(null!=r.popover&&(Fu("beforetoggle",t),Fu("toggle",t)),null!=r.onScroll&&Fu("scroll",t),null!=r.onScrollEnd&&Fu("scrollend",t),null!=r.onClick&&(t.onclick=Qu),t=!0):t=!1,t||ci(e)}function di(e){for(ri=e.return;ri;)switch(ri.tag){case 5:case 13:return void(si=!1);case 27:case 3:return void(si=!0);default:ri=ri.return}}function hi(e){if(e!==ri)return!1;if(!oi)return di(e),oi=!0,!1;var t,n=e.tag;if((t=3!==n&&27!==n)&&((t=5===n)&&(t=!("form"!==(t=e.type)&&"button"!==t)||ad(e.type,e.memoizedProps)),t=!t),t&&ii&&ci(e),di(e),13===n){if(!(e=null!==(e=e.memoizedState)?e.dehydrated:null))throw Error(a(317));e:{for(e=e.nextSibling,n=0;e;){if(8===e.nodeType)if("/$"===(t=e.data)){if(0===n){ii=yd(e.nextSibling);break e}n--}else"$"!==t&&"$!"!==t&&"$?"!==t||n++;e=e.nextSibling}ii=null}}else 27===n?(n=ii,pd(e.type)?(e=xd,xd=null,ii=e):ii=n):ii=ri?yd(e.stateNode.nextSibling):null;return!0}function pi(){ii=ri=null,oi=!1}function mi(){var e=ai;return null!==e&&(null===vc?vc=e:vc.push.apply(vc,e),ai=null),e}function fi(e){null===ai?ai=[e]:ai.push(e)}var gi=_(null),yi=null,xi=null;function vi(e,t,n){V(gi,t._currentValue),t._currentValue=n}function bi(e){e._currentValue=gi.current,I(gi)}function wi(e,t,n){for(;null!==e;){var r=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,null!==r&&(r.childLanes|=t)):null!==r&&(r.childLanes&t)!==t&&(r.childLanes|=t),e===n)break;e=e.return}}function ki(e,t,n,r){var i=e.child;for(null!==i&&(i.return=e);null!==i;){var o=i.dependencies;if(null!==o){var s=i.child;o=o.firstContext;e:for(;null!==o;){var l=o;o=i;for(var c=0;c<t.length;c++)if(l.context===t[c]){o.lanes|=n,null!==(l=o.alternate)&&(l.lanes|=n),wi(o.return,n,e),r||(s=null);break e}o=l.next}}else if(18===i.tag){if(null===(s=i.return))throw Error(a(341));s.lanes|=n,null!==(o=s.alternate)&&(o.lanes|=n),wi(s,n,e),s=null}else s=i.child;if(null!==s)s.return=i;else for(s=i;null!==s;){if(s===e){s=null;break}if(null!==(i=s.sibling)){i.return=s.return,s=i;break}s=s.return}i=s}}function Si(e,t,n,r){e=null;for(var i=t,o=!1;null!==i;){if(!o)if(0!==(524288&i.flags))o=!0;else if(0!==(262144&i.flags))break;if(10===i.tag){var s=i.alternate;if(null===s)throw Error(a(387));if(null!==(s=s.memoizedProps)){var l=i.type;Gn(i.pendingProps.value,s.value)||(null!==e?e.push(l):e=[l])}}else if(i===U.current){if(null===(s=i.alternate))throw Error(a(387));s.memoizedState.memoizedState!==i.memoizedState.memoizedState&&(null!==e?e.push(Kd):e=[Kd])}i=i.return}null!==e&&ki(t,e,n,r),t.flags|=262144}function ji(e){for(e=e.firstContext;null!==e;){if(!Gn(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function $i(e){yi=e,xi=null,null!==(e=e.dependencies)&&(e.firstContext=null)}function Ci(e){return Ti(yi,e)}function Ei(e,t){return null===yi&&$i(e),Ti(e,t)}function Ti(e,t){var n=t._currentValue;if(t={context:t,memoizedValue:n,next:null},null===xi){if(null===e)throw Error(a(308));xi=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else xi=xi.next=t;return n}var Pi="undefined"!==typeof AbortController?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(t,n){e.push(n)}};this.abort=function(){t.aborted=!0,e.forEach(function(e){return e()})}},zi=r.unstable_scheduleCallback,Ai=r.unstable_NormalPriority,Ri={$$typeof:w,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Mi(){return{controller:new Pi,data:new Map,refCount:0}}function Li(e){e.refCount--,0===e.refCount&&zi(Ai,function(){e.controller.abort()})}var Di=null,Oi=0,Fi=0,Ni=null;function _i(){if(0===--Oi&&null!==Di){null!==Ni&&(Ni.status="fulfilled");var e=Di;Di=null,Fi=0,Ni=null;for(var t=0;t<e.length;t++)(0,e[t])()}}var Ii=L.S;L.S=function(e,t){"object"===typeof t&&null!==t&&"function"===typeof t.then&&function(e,t){if(null===Di){var n=Di=[];Oi=0,Fi=Pu(),Ni={status:"pending",value:void 0,then:function(e){n.push(e)}}}Oi++,t.then(_i,_i)}(0,t),null!==Ii&&Ii(e,t)};var Vi=_(null);function Bi(){var e=Vi.current;return null!==e?e:rc.pooledCache}function Wi(e,t){V(Vi,null===t?Vi.current:t.pool)}function Hi(){var e=Bi();return null===e?null:{parent:Ri._currentValue,pool:e}}var Ui=Error(a(460)),qi=Error(a(474)),Yi=Error(a(542)),Ki={then:function(){}};function Gi(e){return"fulfilled"===(e=e.status)||"rejected"===e}function Xi(){}function Qi(e,t,n){switch(void 0===(n=e[n])?e.push(t):n!==t&&(t.then(Xi,Xi),t=n),t.status){case"fulfilled":return t.value;case"rejected":throw eo(e=t.reason),e;default:if("string"===typeof t.status)t.then(Xi,Xi);else{if(null!==(e=rc)&&100<e.shellSuspendCounter)throw Error(a(482));(e=t).status="pending",e.then(function(e){if("pending"===t.status){var n=t;n.status="fulfilled",n.value=e}},function(e){if("pending"===t.status){var n=t;n.status="rejected",n.reason=e}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw eo(e=t.reason),e}throw Ji=t,Ui}}var Ji=null;function Zi(){if(null===Ji)throw Error(a(459));var e=Ji;return Ji=null,e}function eo(e){if(e===Ui||e===Yi)throw Error(a(483))}var to=!1;function no(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function ro(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function io(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function oo(e,t,n){var r=e.updateQueue;if(null===r)return null;if(r=r.shared,0!==(2&nc)){var i=r.pending;return null===i?t.next=t:(t.next=i.next,i.next=t),r.pending=t,t=Mr(e),Rr(e,null,n),t}return Pr(e,r,t,n),Mr(e)}function ao(e,t,n){if(null!==(t=t.updateQueue)&&(t=t.shared,0!==(4194048&n))){var r=t.lanes;n|=r&=e.pendingLanes,t.lanes=n,Ee(e,n)}}function so(e,t){var n=e.updateQueue,r=e.alternate;if(null!==r&&n===(r=r.updateQueue)){var i=null,o=null;if(null!==(n=n.firstBaseUpdate)){do{var a={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};null===o?i=o=a:o=o.next=a,n=n.next}while(null!==n);null===o?i=o=t:o=o.next=t}else i=o=t;return n={baseState:r.baseState,firstBaseUpdate:i,lastBaseUpdate:o,shared:r.shared,callbacks:r.callbacks},void(e.updateQueue=n)}null===(e=n.lastBaseUpdate)?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}var lo=!1;function co(){if(lo){if(null!==Ni)throw Ni}}function uo(e,t,n,r){lo=!1;var i=e.updateQueue;to=!1;var o=i.firstBaseUpdate,a=i.lastBaseUpdate,s=i.shared.pending;if(null!==s){i.shared.pending=null;var l=s,c=l.next;l.next=null,null===a?o=c:a.next=c,a=l;var u=e.alternate;null!==u&&((s=(u=u.updateQueue).lastBaseUpdate)!==a&&(null===s?u.firstBaseUpdate=c:s.next=c,u.lastBaseUpdate=l))}if(null!==o){var d=i.baseState;for(a=0,u=c=l=null,s=o;;){var p=-536870913&s.lane,m=p!==s.lane;if(m?(oc&p)===p:(r&p)===p){0!==p&&p===Fi&&(lo=!0),null!==u&&(u=u.next={lane:0,tag:s.tag,payload:s.payload,callback:null,next:null});e:{var f=e,g=s;p=t;var y=n;switch(g.tag){case 1:if("function"===typeof(f=g.payload)){d=f.call(y,d,p);break e}d=f;break e;case 3:f.flags=-65537&f.flags|128;case 0:if(null===(p="function"===typeof(f=g.payload)?f.call(y,d,p):f)||void 0===p)break e;d=h({},d,p);break e;case 2:to=!0}}null!==(p=s.callback)&&(e.flags|=64,m&&(e.flags|=8192),null===(m=i.callbacks)?i.callbacks=[p]:m.push(p))}else m={lane:p,tag:s.tag,payload:s.payload,callback:s.callback,next:null},null===u?(c=u=m,l=d):u=u.next=m,a|=p;if(null===(s=s.next)){if(null===(s=i.shared.pending))break;s=(m=s).next,m.next=null,i.lastBaseUpdate=m,i.shared.pending=null}}null===u&&(l=d),i.baseState=l,i.firstBaseUpdate=c,i.lastBaseUpdate=u,null===o&&(i.shared.lanes=0),pc|=a,e.lanes=a,e.memoizedState=d}}function ho(e,t){if("function"!==typeof e)throw Error(a(191,e));e.call(t)}function po(e,t){var n=e.callbacks;if(null!==n)for(e.callbacks=null,e=0;e<n.length;e++)ho(n[e],t)}var mo=_(null),fo=_(0);function go(e,t){V(fo,e=dc),V(mo,t),dc=e|t.baseLanes}function yo(){V(fo,dc),V(mo,mo.current)}function xo(){dc=fo.current,I(mo),I(fo)}var vo=0,bo=null,wo=null,ko=null,So=!1,jo=!1,$o=!1,Co=0,Eo=0,To=null,Po=0;function zo(){throw Error(a(321))}function Ao(e,t){if(null===t)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!Gn(e[n],t[n]))return!1;return!0}function Ro(e,t,n,r,i,o){return vo=o,bo=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,L.H=null===e||null===e.memoizedState?qa:Ya,$o=!1,o=n(r,i),$o=!1,jo&&(o=Lo(t,n,r,i)),Mo(e),o}function Mo(e){L.H=Ua;var t=null!==wo&&null!==wo.next;if(vo=0,ko=wo=bo=null,So=!1,Eo=0,To=null,t)throw Error(a(300));null===e||Es||null!==(e=e.dependencies)&&ji(e)&&(Es=!0)}function Lo(e,t,n,r){bo=e;var i=0;do{if(jo&&(To=null),Eo=0,jo=!1,25<=i)throw Error(a(301));if(i+=1,ko=wo=null,null!=e.updateQueue){var o=e.updateQueue;o.lastEffect=null,o.events=null,o.stores=null,null!=o.memoCache&&(o.memoCache.index=0)}L.H=Ka,o=t(n,r)}while(jo);return o}function Do(){var e=L.H,t=e.useState()[0];return t="function"===typeof t.then?Vo(t):t,e=e.useState()[0],(null!==wo?wo.memoizedState:null)!==e&&(bo.flags|=1024),t}function Oo(){var e=0!==Co;return Co=0,e}function Fo(e,t,n){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n}function No(e){if(So){for(e=e.memoizedState;null!==e;){var t=e.queue;null!==t&&(t.pending=null),e=e.next}So=!1}vo=0,ko=wo=bo=null,jo=!1,Eo=Co=0,To=null}function _o(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return null===ko?bo.memoizedState=ko=e:ko=ko.next=e,ko}function Io(){if(null===wo){var e=bo.alternate;e=null!==e?e.memoizedState:null}else e=wo.next;var t=null===ko?bo.memoizedState:ko.next;if(null!==t)ko=t,wo=e;else{if(null===e){if(null===bo.alternate)throw Error(a(467));throw Error(a(310))}e={memoizedState:(wo=e).memoizedState,baseState:wo.baseState,baseQueue:wo.baseQueue,queue:wo.queue,next:null},null===ko?bo.memoizedState=ko=e:ko=ko.next=e}return ko}function Vo(e){var t=Eo;return Eo+=1,null===To&&(To=[]),e=Qi(To,e,t),t=bo,null===(null===ko?t.memoizedState:ko.next)&&(t=t.alternate,L.H=null===t||null===t.memoizedState?qa:Ya),e}function Bo(e){if(null!==e&&"object"===typeof e){if("function"===typeof e.then)return Vo(e);if(e.$$typeof===w)return Ci(e)}throw Error(a(438,String(e)))}function Wo(e){var t=null,n=bo.updateQueue;if(null!==n&&(t=n.memoCache),null==t){var r=bo.alternate;null!==r&&(null!==(r=r.updateQueue)&&(null!=(r=r.memoCache)&&(t={data:r.data.map(function(e){return e.slice()}),index:0})))}if(null==t&&(t={data:[],index:0}),null===n&&(n={lastEffect:null,events:null,stores:null,memoCache:null},bo.updateQueue=n),n.memoCache=t,void 0===(n=t.data[t.index]))for(n=t.data[t.index]=Array(e),r=0;r<e;r++)n[r]=T;return t.index++,n}function Ho(e,t){return"function"===typeof t?t(e):t}function Uo(e){return qo(Io(),wo,e)}function qo(e,t,n){var r=e.queue;if(null===r)throw Error(a(311));r.lastRenderedReducer=n;var i=e.baseQueue,o=r.pending;if(null!==o){if(null!==i){var s=i.next;i.next=o.next,o.next=s}t.baseQueue=i=o,r.pending=null}if(o=e.baseState,null===i)e.memoizedState=o;else{var l=s=null,c=null,u=t=i.next,d=!1;do{var h=-536870913&u.lane;if(h!==u.lane?(oc&h)===h:(vo&h)===h){var p=u.revertLane;if(0===p)null!==c&&(c=c.next={lane:0,revertLane:0,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),h===Fi&&(d=!0);else{if((vo&p)===p){u=u.next,p===Fi&&(d=!0);continue}h={lane:0,revertLane:u.revertLane,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},null===c?(l=c=h,s=o):c=c.next=h,bo.lanes|=p,pc|=p}h=u.action,$o&&n(o,h),o=u.hasEagerState?u.eagerState:n(o,h)}else p={lane:h,revertLane:u.revertLane,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null},null===c?(l=c=p,s=o):c=c.next=p,bo.lanes|=h,pc|=h;u=u.next}while(null!==u&&u!==t);if(null===c?s=o:c.next=l,!Gn(o,e.memoizedState)&&(Es=!0,d&&null!==(n=Ni)))throw n;e.memoizedState=o,e.baseState=s,e.baseQueue=c,r.lastRenderedState=o}return null===i&&(r.lanes=0),[e.memoizedState,r.dispatch]}function Yo(e){var t=Io(),n=t.queue;if(null===n)throw Error(a(311));n.lastRenderedReducer=e;var r=n.dispatch,i=n.pending,o=t.memoizedState;if(null!==i){n.pending=null;var s=i=i.next;do{o=e(o,s.action),s=s.next}while(s!==i);Gn(o,t.memoizedState)||(Es=!0),t.memoizedState=o,null===t.baseQueue&&(t.baseState=o),n.lastRenderedState=o}return[o,r]}function Ko(e,t,n){var r=bo,i=Io(),o=oi;if(o){if(void 0===n)throw Error(a(407));n=n()}else n=t();var s=!Gn((wo||i).memoizedState,n);if(s&&(i.memoizedState=n,Es=!0),i=i.queue,ya(2048,8,Qo.bind(null,r,i,e),[e]),i.getSnapshot!==t||s||null!==ko&&1&ko.memoizedState.tag){if(r.flags|=2048,ma(9,{destroy:void 0,resource:void 0},Xo.bind(null,r,i,n,t),null),null===rc)throw Error(a(349));o||0!==(124&vo)||Go(r,t,n)}return n}function Go(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},null===(t=bo.updateQueue)?(t={lastEffect:null,events:null,stores:null,memoCache:null},bo.updateQueue=t,t.stores=[e]):null===(n=t.stores)?t.stores=[e]:n.push(e)}function Xo(e,t,n,r){t.value=n,t.getSnapshot=r,Jo(t)&&Zo(e)}function Qo(e,t,n){return n(function(){Jo(t)&&Zo(e)})}function Jo(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!Gn(e,n)}catch(r){return!0}}function Zo(e){var t=Ar(e,2);null!==t&&Oc(t,e,2)}function ea(e){var t=_o();if("function"===typeof e){var n=e;if(e=n(),$o){he(!0);try{n()}finally{he(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ho,lastRenderedState:e},t}function ta(e,t,n,r){return e.baseState=n,qo(e,wo,"function"===typeof r?r:Ho)}function na(e,t,n,r,i){if(Ba(e))throw Error(a(485));if(null!==(e=t.action)){var o={payload:i,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(e){o.listeners.push(e)}};null!==L.T?n(!0):o.isTransition=!1,r(o),null===(n=t.pending)?(o.next=t.pending=o,ra(t,o)):(o.next=n.next,t.pending=n.next=o)}}function ra(e,t){var n=t.action,r=t.payload,i=e.state;if(t.isTransition){var o=L.T,a={};L.T=a;try{var s=n(i,r),l=L.S;null!==l&&l(a,s),ia(e,t,s)}catch(c){aa(e,t,c)}finally{L.T=o}}else try{ia(e,t,o=n(i,r))}catch(u){aa(e,t,u)}}function ia(e,t,n){null!==n&&"object"===typeof n&&"function"===typeof n.then?n.then(function(n){oa(e,t,n)},function(n){return aa(e,t,n)}):oa(e,t,n)}function oa(e,t,n){t.status="fulfilled",t.value=n,sa(t),e.state=n,null!==(t=e.pending)&&((n=t.next)===t?e.pending=null:(n=n.next,t.next=n,ra(e,n)))}function aa(e,t,n){var r=e.pending;if(e.pending=null,null!==r){r=r.next;do{t.status="rejected",t.reason=n,sa(t),t=t.next}while(t!==r)}e.action=null}function sa(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function la(e,t){return t}function ca(e,t){if(oi){var n=rc.formState;if(null!==n){e:{var r=bo;if(oi){if(ii){t:{for(var i=ii,o=si;8!==i.nodeType;){if(!o){i=null;break t}if(null===(i=yd(i.nextSibling))){i=null;break t}}i="F!"===(o=i.data)||"F"===o?i:null}if(i){ii=yd(i.nextSibling),r="F!"===i.data;break e}}ci(r)}r=!1}r&&(t=n[0])}}return(n=_o()).memoizedState=n.baseState=t,r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:la,lastRenderedState:t},n.queue=r,n=_a.bind(null,bo,r),r.dispatch=n,r=ea(!1),o=Va.bind(null,bo,!1,r.queue),i={state:t,dispatch:null,action:e,pending:null},(r=_o()).queue=i,n=na.bind(null,bo,i,o,n),i.dispatch=n,r.memoizedState=e,[t,n,!1]}function ua(e){return da(Io(),wo,e)}function da(e,t,n){if(t=qo(e,t,la)[0],e=Uo(Ho)[0],"object"===typeof t&&null!==t&&"function"===typeof t.then)try{var r=Vo(t)}catch(a){if(a===Ui)throw Yi;throw a}else r=t;var i=(t=Io()).queue,o=i.dispatch;return n!==t.memoizedState&&(bo.flags|=2048,ma(9,{destroy:void 0,resource:void 0},ha.bind(null,i,n),null)),[r,o,e]}function ha(e,t){e.action=t}function pa(e){var t=Io(),n=wo;if(null!==n)return da(t,n,e);Io(),t=t.memoizedState;var r=(n=Io()).queue.dispatch;return n.memoizedState=e,[t,r,!1]}function ma(e,t,n,r){return e={tag:e,create:n,deps:r,inst:t,next:null},null===(t=bo.updateQueue)&&(t={lastEffect:null,events:null,stores:null,memoCache:null},bo.updateQueue=t),null===(n=t.lastEffect)?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e),e}function fa(){return Io().memoizedState}function ga(e,t,n,r){var i=_o();r=void 0===r?null:r,bo.flags|=e,i.memoizedState=ma(1|t,{destroy:void 0,resource:void 0},n,r)}function ya(e,t,n,r){var i=Io();r=void 0===r?null:r;var o=i.memoizedState.inst;null!==wo&&null!==r&&Ao(r,wo.memoizedState.deps)?i.memoizedState=ma(t,o,n,r):(bo.flags|=e,i.memoizedState=ma(1|t,o,n,r))}function xa(e,t){ga(8390656,8,e,t)}function va(e,t){ya(2048,8,e,t)}function ba(e,t){return ya(4,2,e,t)}function wa(e,t){return ya(4,4,e,t)}function ka(e,t){if("function"===typeof t){e=e();var n=t(e);return function(){"function"===typeof n?n():t(null)}}if(null!==t&&void 0!==t)return e=e(),t.current=e,function(){t.current=null}}function Sa(e,t,n){n=null!==n&&void 0!==n?n.concat([e]):null,ya(4,4,ka.bind(null,t,e),n)}function ja(){}function $a(e,t){var n=Io();t=void 0===t?null:t;var r=n.memoizedState;return null!==t&&Ao(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function Ca(e,t){var n=Io();t=void 0===t?null:t;var r=n.memoizedState;if(null!==t&&Ao(t,r[1]))return r[0];if(r=e(),$o){he(!0);try{e()}finally{he(!1)}}return n.memoizedState=[r,t],r}function Ea(e,t,n){return void 0===n||0!==(1073741824&vo)?e.memoizedState=t:(e.memoizedState=n,e=Dc(),bo.lanes|=e,pc|=e,n)}function Ta(e,t,n,r){return Gn(n,t)?n:null!==mo.current?(e=Ea(e,n,r),Gn(e,t)||(Es=!0),e):0===(42&vo)?(Es=!0,e.memoizedState=n):(e=Dc(),bo.lanes|=e,pc|=e,t)}function Pa(e,t,n,r,i){var o=D.p;D.p=0!==o&&8>o?o:8;var a=L.T,s={};L.T=s,Va(e,!1,t,n);try{var l=i(),c=L.S;if(null!==c&&c(s,l),null!==l&&"object"===typeof l&&"function"===typeof l.then)Ia(e,t,function(e,t){var n=[],r={status:"pending",value:null,reason:null,then:function(e){n.push(e)}};return e.then(function(){r.status="fulfilled",r.value=t;for(var e=0;e<n.length;e++)(0,n[e])(t)},function(e){for(r.status="rejected",r.reason=e,e=0;e<n.length;e++)(0,n[e])(void 0)}),r}(l,r),Lc());else Ia(e,t,r,Lc())}catch(u){Ia(e,t,{then:function(){},status:"rejected",reason:u},Lc())}finally{D.p=o,L.T=a}}function za(){}function Aa(e,t,n,r){if(5!==e.tag)throw Error(a(476));var i=Ra(e).queue;Pa(e,i,t,O,null===n?za:function(){return Ma(e),n(r)})}function Ra(e){var t=e.memoizedState;if(null!==t)return t;var n={};return(t={memoizedState:O,baseState:O,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ho,lastRenderedState:O},next:null}).next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ho,lastRenderedState:n},next:null},e.memoizedState=t,null!==(e=e.alternate)&&(e.memoizedState=t),t}function Ma(e){Ia(e,Ra(e).next.queue,{},Lc())}function La(){return Ci(Kd)}function Da(){return Io().memoizedState}function Oa(){return Io().memoizedState}function Fa(e){for(var t=e.return;null!==t;){switch(t.tag){case 24:case 3:var n=Lc(),r=oo(t,e=io(n),n);return null!==r&&(Oc(r,t,n),ao(r,t,n)),t={cache:Mi()},void(e.payload=t)}t=t.return}}function Na(e,t,n){var r=Lc();n={lane:r,revertLane:0,action:n,hasEagerState:!1,eagerState:null,next:null},Ba(e)?Wa(t,n):null!==(n=zr(e,t,n,r))&&(Oc(n,e,r),Ha(n,t,r))}function _a(e,t,n){Ia(e,t,n,Lc())}function Ia(e,t,n,r){var i={lane:r,revertLane:0,action:n,hasEagerState:!1,eagerState:null,next:null};if(Ba(e))Wa(t,i);else{var o=e.alternate;if(0===e.lanes&&(null===o||0===o.lanes)&&null!==(o=t.lastRenderedReducer))try{var a=t.lastRenderedState,s=o(a,n);if(i.hasEagerState=!0,i.eagerState=s,Gn(s,a))return Pr(e,t,i,0),null===rc&&Tr(),!1}catch(l){}if(null!==(n=zr(e,t,i,r)))return Oc(n,e,r),Ha(n,t,r),!0}return!1}function Va(e,t,n,r){if(r={lane:2,revertLane:Pu(),action:r,hasEagerState:!1,eagerState:null,next:null},Ba(e)){if(t)throw Error(a(479))}else null!==(t=zr(e,n,r,2))&&Oc(t,e,2)}function Ba(e){var t=e.alternate;return e===bo||null!==t&&t===bo}function Wa(e,t){jo=So=!0;var n=e.pending;null===n?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function Ha(e,t,n){if(0!==(4194048&n)){var r=t.lanes;n|=r&=e.pendingLanes,t.lanes=n,Ee(e,n)}}var Ua={readContext:Ci,use:Bo,useCallback:zo,useContext:zo,useEffect:zo,useImperativeHandle:zo,useLayoutEffect:zo,useInsertionEffect:zo,useMemo:zo,useReducer:zo,useRef:zo,useState:zo,useDebugValue:zo,useDeferredValue:zo,useTransition:zo,useSyncExternalStore:zo,useId:zo,useHostTransitionStatus:zo,useFormState:zo,useActionState:zo,useOptimistic:zo,useMemoCache:zo,useCacheRefresh:zo},qa={readContext:Ci,use:Bo,useCallback:function(e,t){return _o().memoizedState=[e,void 0===t?null:t],e},useContext:Ci,useEffect:xa,useImperativeHandle:function(e,t,n){n=null!==n&&void 0!==n?n.concat([e]):null,ga(4194308,4,ka.bind(null,t,e),n)},useLayoutEffect:function(e,t){return ga(4194308,4,e,t)},useInsertionEffect:function(e,t){ga(4,2,e,t)},useMemo:function(e,t){var n=_o();t=void 0===t?null:t;var r=e();if($o){he(!0);try{e()}finally{he(!1)}}return n.memoizedState=[r,t],r},useReducer:function(e,t,n){var r=_o();if(void 0!==n){var i=n(t);if($o){he(!0);try{n(t)}finally{he(!1)}}}else i=t;return r.memoizedState=r.baseState=i,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:i},r.queue=e,e=e.dispatch=Na.bind(null,bo,e),[r.memoizedState,e]},useRef:function(e){return e={current:e},_o().memoizedState=e},useState:function(e){var t=(e=ea(e)).queue,n=_a.bind(null,bo,t);return t.dispatch=n,[e.memoizedState,n]},useDebugValue:ja,useDeferredValue:function(e,t){return Ea(_o(),e,t)},useTransition:function(){var e=ea(!1);return e=Pa.bind(null,bo,e.queue,!0,!1),_o().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,n){var r=bo,i=_o();if(oi){if(void 0===n)throw Error(a(407));n=n()}else{if(n=t(),null===rc)throw Error(a(349));0!==(124&oc)||Go(r,t,n)}i.memoizedState=n;var o={value:n,getSnapshot:t};return i.queue=o,xa(Qo.bind(null,r,o,e),[e]),r.flags|=2048,ma(9,{destroy:void 0,resource:void 0},Xo.bind(null,r,o,n,t),null),n},useId:function(){var e=_o(),t=rc.identifierPrefix;if(oi){var n=Jr;t="\xab"+t+"R"+(n=(Qr&~(1<<32-pe(Qr)-1)).toString(32)+n),0<(n=Co++)&&(t+="H"+n.toString(32)),t+="\xbb"}else t="\xab"+t+"r"+(n=Po++).toString(32)+"\xbb";return e.memoizedState=t},useHostTransitionStatus:La,useFormState:ca,useActionState:ca,useOptimistic:function(e){var t=_o();t.memoizedState=t.baseState=e;var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=n,t=Va.bind(null,bo,!0,n),n.dispatch=t,[e,t]},useMemoCache:Wo,useCacheRefresh:function(){return _o().memoizedState=Fa.bind(null,bo)}},Ya={readContext:Ci,use:Bo,useCallback:$a,useContext:Ci,useEffect:va,useImperativeHandle:Sa,useInsertionEffect:ba,useLayoutEffect:wa,useMemo:Ca,useReducer:Uo,useRef:fa,useState:function(){return Uo(Ho)},useDebugValue:ja,useDeferredValue:function(e,t){return Ta(Io(),wo.memoizedState,e,t)},useTransition:function(){var e=Uo(Ho)[0],t=Io().memoizedState;return["boolean"===typeof e?e:Vo(e),t]},useSyncExternalStore:Ko,useId:Da,useHostTransitionStatus:La,useFormState:ua,useActionState:ua,useOptimistic:function(e,t){return ta(Io(),0,e,t)},useMemoCache:Wo,useCacheRefresh:Oa},Ka={readContext:Ci,use:Bo,useCallback:$a,useContext:Ci,useEffect:va,useImperativeHandle:Sa,useInsertionEffect:ba,useLayoutEffect:wa,useMemo:Ca,useReducer:Yo,useRef:fa,useState:function(){return Yo(Ho)},useDebugValue:ja,useDeferredValue:function(e,t){var n=Io();return null===wo?Ea(n,e,t):Ta(n,wo.memoizedState,e,t)},useTransition:function(){var e=Yo(Ho)[0],t=Io().memoizedState;return["boolean"===typeof e?e:Vo(e),t]},useSyncExternalStore:Ko,useId:Da,useHostTransitionStatus:La,useFormState:pa,useActionState:pa,useOptimistic:function(e,t){var n=Io();return null!==wo?ta(n,0,e,t):(n.baseState=e,[e,n.queue.dispatch])},useMemoCache:Wo,useCacheRefresh:Oa},Ga=null,Xa=0;function Qa(e){var t=Xa;return Xa+=1,null===Ga&&(Ga=[]),Qi(Ga,e,t)}function Ja(e,t){t=t.props.ref,e.ref=void 0!==t?t:null}function Za(e,t){if(t.$$typeof===p)throw Error(a(525));throw e=Object.prototype.toString.call(t),Error(a(31,"[object Object]"===e?"object with keys {"+Object.keys(t).join(", ")+"}":e))}function es(e){return(0,e._init)(e._payload)}function ts(e){function t(t,n){if(e){var r=t.deletions;null===r?(t.deletions=[n],t.flags|=16):r.push(n)}}function n(n,r){if(!e)return null;for(;null!==r;)t(n,r),r=r.sibling;return null}function r(e){for(var t=new Map;null!==e;)null!==e.key?t.set(e.key,e):t.set(e.index,e),e=e.sibling;return t}function i(e,t){return(e=Nr(e,t)).index=0,e.sibling=null,e}function o(t,n,r){return t.index=r,e?null!==(r=t.alternate)?(r=r.index)<n?(t.flags|=67108866,n):r:(t.flags|=67108866,n):(t.flags|=1048576,n)}function s(t){return e&&null===t.alternate&&(t.flags|=67108866),t}function l(e,t,n,r){return null===t||6!==t.tag?((t=Br(n,e.mode,r)).return=e,t):((t=i(t,n)).return=e,t)}function c(e,t,n,r){var o=n.type;return o===g?d(e,t,n.props.children,r,n.key):null!==t&&(t.elementType===o||"object"===typeof o&&null!==o&&o.$$typeof===C&&es(o)===t.type)?(Ja(t=i(t,n.props),n),t.return=e,t):(Ja(t=Ir(n.type,n.key,n.props,null,e.mode,r),n),t.return=e,t)}function u(e,t,n,r){return null===t||4!==t.tag||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?((t=Wr(n,e.mode,r)).return=e,t):((t=i(t,n.children||[])).return=e,t)}function d(e,t,n,r,o){return null===t||7!==t.tag?((t=Vr(n,e.mode,r,o)).return=e,t):((t=i(t,n)).return=e,t)}function h(e,t,n){if("string"===typeof t&&""!==t||"number"===typeof t||"bigint"===typeof t)return(t=Br(""+t,e.mode,n)).return=e,t;if("object"===typeof t&&null!==t){switch(t.$$typeof){case m:return Ja(n=Ir(t.type,t.key,t.props,null,e.mode,n),t),n.return=e,n;case f:return(t=Wr(t,e.mode,n)).return=e,t;case C:return h(e,t=(0,t._init)(t._payload),n)}if(M(t)||z(t))return(t=Vr(t,e.mode,n,null)).return=e,t;if("function"===typeof t.then)return h(e,Qa(t),n);if(t.$$typeof===w)return h(e,Ei(e,t),n);Za(e,t)}return null}function p(e,t,n,r){var i=null!==t?t.key:null;if("string"===typeof n&&""!==n||"number"===typeof n||"bigint"===typeof n)return null!==i?null:l(e,t,""+n,r);if("object"===typeof n&&null!==n){switch(n.$$typeof){case m:return n.key===i?c(e,t,n,r):null;case f:return n.key===i?u(e,t,n,r):null;case C:return p(e,t,n=(i=n._init)(n._payload),r)}if(M(n)||z(n))return null!==i?null:d(e,t,n,r,null);if("function"===typeof n.then)return p(e,t,Qa(n),r);if(n.$$typeof===w)return p(e,t,Ei(e,n),r);Za(e,n)}return null}function y(e,t,n,r,i){if("string"===typeof r&&""!==r||"number"===typeof r||"bigint"===typeof r)return l(t,e=e.get(n)||null,""+r,i);if("object"===typeof r&&null!==r){switch(r.$$typeof){case m:return c(t,e=e.get(null===r.key?n:r.key)||null,r,i);case f:return u(t,e=e.get(null===r.key?n:r.key)||null,r,i);case C:return y(e,t,n,r=(0,r._init)(r._payload),i)}if(M(r)||z(r))return d(t,e=e.get(n)||null,r,i,null);if("function"===typeof r.then)return y(e,t,n,Qa(r),i);if(r.$$typeof===w)return y(e,t,n,Ei(t,r),i);Za(t,r)}return null}function x(l,c,u,d){if("object"===typeof u&&null!==u&&u.type===g&&null===u.key&&(u=u.props.children),"object"===typeof u&&null!==u){switch(u.$$typeof){case m:e:{for(var v=u.key;null!==c;){if(c.key===v){if((v=u.type)===g){if(7===c.tag){n(l,c.sibling),(d=i(c,u.props.children)).return=l,l=d;break e}}else if(c.elementType===v||"object"===typeof v&&null!==v&&v.$$typeof===C&&es(v)===c.type){n(l,c.sibling),Ja(d=i(c,u.props),u),d.return=l,l=d;break e}n(l,c);break}t(l,c),c=c.sibling}u.type===g?((d=Vr(u.props.children,l.mode,d,u.key)).return=l,l=d):(Ja(d=Ir(u.type,u.key,u.props,null,l.mode,d),u),d.return=l,l=d)}return s(l);case f:e:{for(v=u.key;null!==c;){if(c.key===v){if(4===c.tag&&c.stateNode.containerInfo===u.containerInfo&&c.stateNode.implementation===u.implementation){n(l,c.sibling),(d=i(c,u.children||[])).return=l,l=d;break e}n(l,c);break}t(l,c),c=c.sibling}(d=Wr(u,l.mode,d)).return=l,l=d}return s(l);case C:return x(l,c,u=(v=u._init)(u._payload),d)}if(M(u))return function(i,a,s,l){for(var c=null,u=null,d=a,m=a=0,f=null;null!==d&&m<s.length;m++){d.index>m?(f=d,d=null):f=d.sibling;var g=p(i,d,s[m],l);if(null===g){null===d&&(d=f);break}e&&d&&null===g.alternate&&t(i,d),a=o(g,a,m),null===u?c=g:u.sibling=g,u=g,d=f}if(m===s.length)return n(i,d),oi&&Zr(i,m),c;if(null===d){for(;m<s.length;m++)null!==(d=h(i,s[m],l))&&(a=o(d,a,m),null===u?c=d:u.sibling=d,u=d);return oi&&Zr(i,m),c}for(d=r(d);m<s.length;m++)null!==(f=y(d,i,m,s[m],l))&&(e&&null!==f.alternate&&d.delete(null===f.key?m:f.key),a=o(f,a,m),null===u?c=f:u.sibling=f,u=f);return e&&d.forEach(function(e){return t(i,e)}),oi&&Zr(i,m),c}(l,c,u,d);if(z(u)){if("function"!==typeof(v=z(u)))throw Error(a(150));return function(i,s,l,c){if(null==l)throw Error(a(151));for(var u=null,d=null,m=s,f=s=0,g=null,x=l.next();null!==m&&!x.done;f++,x=l.next()){m.index>f?(g=m,m=null):g=m.sibling;var v=p(i,m,x.value,c);if(null===v){null===m&&(m=g);break}e&&m&&null===v.alternate&&t(i,m),s=o(v,s,f),null===d?u=v:d.sibling=v,d=v,m=g}if(x.done)return n(i,m),oi&&Zr(i,f),u;if(null===m){for(;!x.done;f++,x=l.next())null!==(x=h(i,x.value,c))&&(s=o(x,s,f),null===d?u=x:d.sibling=x,d=x);return oi&&Zr(i,f),u}for(m=r(m);!x.done;f++,x=l.next())null!==(x=y(m,i,f,x.value,c))&&(e&&null!==x.alternate&&m.delete(null===x.key?f:x.key),s=o(x,s,f),null===d?u=x:d.sibling=x,d=x);return e&&m.forEach(function(e){return t(i,e)}),oi&&Zr(i,f),u}(l,c,u=v.call(u),d)}if("function"===typeof u.then)return x(l,c,Qa(u),d);if(u.$$typeof===w)return x(l,c,Ei(l,u),d);Za(l,u)}return"string"===typeof u&&""!==u||"number"===typeof u||"bigint"===typeof u?(u=""+u,null!==c&&6===c.tag?(n(l,c.sibling),(d=i(c,u)).return=l,l=d):(n(l,c),(d=Br(u,l.mode,d)).return=l,l=d),s(l)):n(l,c)}return function(e,t,n,r){try{Xa=0;var i=x(e,t,n,r);return Ga=null,i}catch(a){if(a===Ui||a===Yi)throw a;var o=Or(29,a,null,e.mode);return o.lanes=r,o.return=e,o}}}var ns=ts(!0),rs=ts(!1),is=_(null),os=null;function as(e){var t=e.alternate;V(us,1&us.current),V(is,e),null===os&&(null===t||null!==mo.current||null!==t.memoizedState)&&(os=e)}function ss(e){if(22===e.tag){if(V(us,us.current),V(is,e),null===os){var t=e.alternate;null!==t&&null!==t.memoizedState&&(os=e)}}else ls()}function ls(){V(us,us.current),V(is,is.current)}function cs(e){I(is),os===e&&(os=null),I(us)}var us=_(0);function ds(e){for(var t=e;null!==t;){if(13===t.tag){var n=t.memoizedState;if(null!==n&&(null===(n=n.dehydrated)||"$?"===n.data||gd(n)))return t}else if(19===t.tag&&void 0!==t.memoizedProps.revealOrder){if(0!==(128&t.flags))return t}else if(null!==t.child){t.child.return=t,t=t.child;continue}if(t===e)break;for(;null===t.sibling;){if(null===t.return||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}function hs(e,t,n,r){n=null===(n=n(r,t=e.memoizedState))||void 0===n?t:h({},t,n),e.memoizedState=n,0===e.lanes&&(e.updateQueue.baseState=n)}var ps={enqueueSetState:function(e,t,n){e=e._reactInternals;var r=Lc(),i=io(r);i.payload=t,void 0!==n&&null!==n&&(i.callback=n),null!==(t=oo(e,i,r))&&(Oc(t,e,r),ao(t,e,r))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=Lc(),i=io(r);i.tag=1,i.payload=t,void 0!==n&&null!==n&&(i.callback=n),null!==(t=oo(e,i,r))&&(Oc(t,e,r),ao(t,e,r))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=Lc(),r=io(n);r.tag=2,void 0!==t&&null!==t&&(r.callback=t),null!==(t=oo(e,r,n))&&(Oc(t,e,n),ao(t,e,n))}};function ms(e,t,n,r,i,o,a){return"function"===typeof(e=e.stateNode).shouldComponentUpdate?e.shouldComponentUpdate(r,o,a):!t.prototype||!t.prototype.isPureReactComponent||(!Xn(n,r)||!Xn(i,o))}function fs(e,t,n,r){e=t.state,"function"===typeof t.componentWillReceiveProps&&t.componentWillReceiveProps(n,r),"function"===typeof t.UNSAFE_componentWillReceiveProps&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&ps.enqueueReplaceState(t,t.state,null)}function gs(e,t){var n=t;if("ref"in t)for(var r in n={},t)"ref"!==r&&(n[r]=t[r]);if(e=e.defaultProps)for(var i in n===t&&(n=h({},n)),e)void 0===n[i]&&(n[i]=e[i]);return n}var ys="function"===typeof reportError?reportError:function(e){if("object"===typeof window&&"function"===typeof window.ErrorEvent){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:"object"===typeof e&&null!==e&&"string"===typeof e.message?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if("object"===typeof process&&"function"===typeof process.emit)return void process.emit("uncaughtException",e);console.error(e)};function xs(e){ys(e)}function vs(e){console.error(e)}function bs(e){ys(e)}function ws(e,t){try{(0,e.onUncaughtError)(t.value,{componentStack:t.stack})}catch(n){setTimeout(function(){throw n})}}function ks(e,t,n){try{(0,e.onCaughtError)(n.value,{componentStack:n.stack,errorBoundary:1===t.tag?t.stateNode:null})}catch(r){setTimeout(function(){throw r})}}function Ss(e,t,n){return(n=io(n)).tag=3,n.payload={element:null},n.callback=function(){ws(e,t)},n}function js(e){return(e=io(e)).tag=3,e}function $s(e,t,n,r){var i=n.type.getDerivedStateFromError;if("function"===typeof i){var o=r.value;e.payload=function(){return i(o)},e.callback=function(){ks(t,n,r)}}var a=n.stateNode;null!==a&&"function"===typeof a.componentDidCatch&&(e.callback=function(){ks(t,n,r),"function"!==typeof i&&(null===jc?jc=new Set([this]):jc.add(this));var e=r.stack;this.componentDidCatch(r.value,{componentStack:null!==e?e:""})})}var Cs=Error(a(461)),Es=!1;function Ts(e,t,n,r){t.child=null===e?rs(t,null,n,r):ns(t,e.child,n,r)}function Ps(e,t,n,r,i){n=n.render;var o=t.ref;if("ref"in r){var a={};for(var s in r)"ref"!==s&&(a[s]=r[s])}else a=r;return $i(t),r=Ro(e,t,n,a,o,i),s=Oo(),null===e||Es?(oi&&s&&ti(t),t.flags|=1,Ts(e,t,r,i),t.child):(Fo(e,t,i),Gs(e,t,i))}function zs(e,t,n,r,i){if(null===e){var o=n.type;return"function"!==typeof o||Fr(o)||void 0!==o.defaultProps||null!==n.compare?((e=Ir(n.type,null,r,t,t.mode,i)).ref=t.ref,e.return=t,t.child=e):(t.tag=15,t.type=o,As(e,t,o,r,i))}if(o=e.child,!Xs(e,i)){var a=o.memoizedProps;if((n=null!==(n=n.compare)?n:Xn)(a,r)&&e.ref===t.ref)return Gs(e,t,i)}return t.flags|=1,(e=Nr(o,r)).ref=t.ref,e.return=t,t.child=e}function As(e,t,n,r,i){if(null!==e){var o=e.memoizedProps;if(Xn(o,r)&&e.ref===t.ref){if(Es=!1,t.pendingProps=r=o,!Xs(e,i))return t.lanes=e.lanes,Gs(e,t,i);0!==(131072&e.flags)&&(Es=!0)}}return Ds(e,t,n,r,i)}function Rs(e,t,n){var r=t.pendingProps,i=r.children,o=null!==e?e.memoizedState:null;if("hidden"===r.mode){if(0!==(128&t.flags)){if(r=null!==o?o.baseLanes|n:n,null!==e){for(i=t.child=e.child,o=0;null!==i;)o=o|i.lanes|i.childLanes,i=i.sibling;t.childLanes=o&~r}else t.childLanes=0,t.child=null;return Ms(e,t,r,n)}if(0===(536870912&n))return t.lanes=t.childLanes=536870912,Ms(e,t,null!==o?o.baseLanes|n:n,n);t.memoizedState={baseLanes:0,cachePool:null},null!==e&&Wi(0,null!==o?o.cachePool:null),null!==o?go(t,o):yo(),ss(t)}else null!==o?(Wi(0,o.cachePool),go(t,o),ls(),t.memoizedState=null):(null!==e&&Wi(0,null),yo(),ls());return Ts(e,t,i,n),t.child}function Ms(e,t,n,r){var i=Bi();return i=null===i?null:{parent:Ri._currentValue,pool:i},t.memoizedState={baseLanes:n,cachePool:i},null!==e&&Wi(0,null),yo(),ss(t),null!==e&&Si(e,t,r,!0),null}function Ls(e,t){var n=t.ref;if(null===n)null!==e&&null!==e.ref&&(t.flags|=4194816);else{if("function"!==typeof n&&"object"!==typeof n)throw Error(a(284));null!==e&&e.ref===n||(t.flags|=4194816)}}function Ds(e,t,n,r,i){return $i(t),n=Ro(e,t,n,r,void 0,i),r=Oo(),null===e||Es?(oi&&r&&ti(t),t.flags|=1,Ts(e,t,n,i),t.child):(Fo(e,t,i),Gs(e,t,i))}function Os(e,t,n,r,i,o){return $i(t),t.updateQueue=null,n=Lo(t,r,n,i),Mo(e),r=Oo(),null===e||Es?(oi&&r&&ti(t),t.flags|=1,Ts(e,t,n,o),t.child):(Fo(e,t,o),Gs(e,t,o))}function Fs(e,t,n,r,i){if($i(t),null===t.stateNode){var o=Lr,a=n.contextType;"object"===typeof a&&null!==a&&(o=Ci(a)),o=new n(r,o),t.memoizedState=null!==o.state&&void 0!==o.state?o.state:null,o.updater=ps,t.stateNode=o,o._reactInternals=t,(o=t.stateNode).props=r,o.state=t.memoizedState,o.refs={},no(t),a=n.contextType,o.context="object"===typeof a&&null!==a?Ci(a):Lr,o.state=t.memoizedState,"function"===typeof(a=n.getDerivedStateFromProps)&&(hs(t,n,a,r),o.state=t.memoizedState),"function"===typeof n.getDerivedStateFromProps||"function"===typeof o.getSnapshotBeforeUpdate||"function"!==typeof o.UNSAFE_componentWillMount&&"function"!==typeof o.componentWillMount||(a=o.state,"function"===typeof o.componentWillMount&&o.componentWillMount(),"function"===typeof o.UNSAFE_componentWillMount&&o.UNSAFE_componentWillMount(),a!==o.state&&ps.enqueueReplaceState(o,o.state,null),uo(t,r,o,i),co(),o.state=t.memoizedState),"function"===typeof o.componentDidMount&&(t.flags|=4194308),r=!0}else if(null===e){o=t.stateNode;var s=t.memoizedProps,l=gs(n,s);o.props=l;var c=o.context,u=n.contextType;a=Lr,"object"===typeof u&&null!==u&&(a=Ci(u));var d=n.getDerivedStateFromProps;u="function"===typeof d||"function"===typeof o.getSnapshotBeforeUpdate,s=t.pendingProps!==s,u||"function"!==typeof o.UNSAFE_componentWillReceiveProps&&"function"!==typeof o.componentWillReceiveProps||(s||c!==a)&&fs(t,o,r,a),to=!1;var h=t.memoizedState;o.state=h,uo(t,r,o,i),co(),c=t.memoizedState,s||h!==c||to?("function"===typeof d&&(hs(t,n,d,r),c=t.memoizedState),(l=to||ms(t,n,l,r,h,c,a))?(u||"function"!==typeof o.UNSAFE_componentWillMount&&"function"!==typeof o.componentWillMount||("function"===typeof o.componentWillMount&&o.componentWillMount(),"function"===typeof o.UNSAFE_componentWillMount&&o.UNSAFE_componentWillMount()),"function"===typeof o.componentDidMount&&(t.flags|=4194308)):("function"===typeof o.componentDidMount&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=c),o.props=r,o.state=c,o.context=a,r=l):("function"===typeof o.componentDidMount&&(t.flags|=4194308),r=!1)}else{o=t.stateNode,ro(e,t),u=gs(n,a=t.memoizedProps),o.props=u,d=t.pendingProps,h=o.context,c=n.contextType,l=Lr,"object"===typeof c&&null!==c&&(l=Ci(c)),(c="function"===typeof(s=n.getDerivedStateFromProps)||"function"===typeof o.getSnapshotBeforeUpdate)||"function"!==typeof o.UNSAFE_componentWillReceiveProps&&"function"!==typeof o.componentWillReceiveProps||(a!==d||h!==l)&&fs(t,o,r,l),to=!1,h=t.memoizedState,o.state=h,uo(t,r,o,i),co();var p=t.memoizedState;a!==d||h!==p||to||null!==e&&null!==e.dependencies&&ji(e.dependencies)?("function"===typeof s&&(hs(t,n,s,r),p=t.memoizedState),(u=to||ms(t,n,u,r,h,p,l)||null!==e&&null!==e.dependencies&&ji(e.dependencies))?(c||"function"!==typeof o.UNSAFE_componentWillUpdate&&"function"!==typeof o.componentWillUpdate||("function"===typeof o.componentWillUpdate&&o.componentWillUpdate(r,p,l),"function"===typeof o.UNSAFE_componentWillUpdate&&o.UNSAFE_componentWillUpdate(r,p,l)),"function"===typeof o.componentDidUpdate&&(t.flags|=4),"function"===typeof o.getSnapshotBeforeUpdate&&(t.flags|=1024)):("function"!==typeof o.componentDidUpdate||a===e.memoizedProps&&h===e.memoizedState||(t.flags|=4),"function"!==typeof o.getSnapshotBeforeUpdate||a===e.memoizedProps&&h===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=p),o.props=r,o.state=p,o.context=l,r=u):("function"!==typeof o.componentDidUpdate||a===e.memoizedProps&&h===e.memoizedState||(t.flags|=4),"function"!==typeof o.getSnapshotBeforeUpdate||a===e.memoizedProps&&h===e.memoizedState||(t.flags|=1024),r=!1)}return o=r,Ls(e,t),r=0!==(128&t.flags),o||r?(o=t.stateNode,n=r&&"function"!==typeof n.getDerivedStateFromError?null:o.render(),t.flags|=1,null!==e&&r?(t.child=ns(t,e.child,null,i),t.child=ns(t,null,n,i)):Ts(e,t,n,i),t.memoizedState=o.state,e=t.child):e=Gs(e,t,i),e}function Ns(e,t,n,r){return pi(),t.flags|=256,Ts(e,t,n,r),t.child}var _s={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Is(e){return{baseLanes:e,cachePool:Hi()}}function Vs(e,t,n){return e=null!==e?e.childLanes&~n:0,t&&(e|=gc),e}function Bs(e,t,n){var r,i=t.pendingProps,o=!1,s=0!==(128&t.flags);if((r=s)||(r=(null===e||null!==e.memoizedState)&&0!==(2&us.current)),r&&(o=!0,t.flags&=-129),r=0!==(32&t.flags),t.flags&=-33,null===e){if(oi){if(o?as(t):ls(),oi){var l,c=ii;if(l=c){e:{for(l=c,c=si;8!==l.nodeType;){if(!c){c=null;break e}if(null===(l=yd(l.nextSibling))){c=null;break e}}c=l}null!==c?(t.memoizedState={dehydrated:c,treeContext:null!==Xr?{id:Qr,overflow:Jr}:null,retryLane:536870912,hydrationErrors:null},(l=Or(18,null,null,0)).stateNode=c,l.return=t,t.child=l,ri=t,ii=null,l=!0):l=!1}l||ci(t)}if(null!==(c=t.memoizedState)&&null!==(c=c.dehydrated))return gd(c)?t.lanes=32:t.lanes=536870912,null;cs(t)}return c=i.children,i=i.fallback,o?(ls(),c=Hs({mode:"hidden",children:c},o=t.mode),i=Vr(i,o,n,null),c.return=t,i.return=t,c.sibling=i,t.child=c,(o=t.child).memoizedState=Is(n),o.childLanes=Vs(e,r,n),t.memoizedState=_s,i):(as(t),Ws(t,c))}if(null!==(l=e.memoizedState)&&null!==(c=l.dehydrated)){if(s)256&t.flags?(as(t),t.flags&=-257,t=Us(e,t,n)):null!==t.memoizedState?(ls(),t.child=e.child,t.flags|=128,t=null):(ls(),o=i.fallback,c=t.mode,i=Hs({mode:"visible",children:i.children},c),(o=Vr(o,c,n,null)).flags|=2,i.return=t,o.return=t,i.sibling=o,t.child=i,ns(t,e.child,null,n),(i=t.child).memoizedState=Is(n),i.childLanes=Vs(e,r,n),t.memoizedState=_s,t=o);else if(as(t),gd(c)){if(r=c.nextSibling&&c.nextSibling.dataset)var u=r.dgst;r=u,(i=Error(a(419))).stack="",i.digest=r,fi({value:i,source:null,stack:null}),t=Us(e,t,n)}else if(Es||Si(e,t,n,!1),r=0!==(n&e.childLanes),Es||r){if(null!==(r=rc)&&(0!==(i=0!==((i=0!==(42&(i=n&-n))?1:Te(i))&(r.suspendedLanes|n))?0:i)&&i!==l.retryLane))throw l.retryLane=i,Ar(e,i),Oc(r,e,i),Cs;"$?"===c.data||Yc(),t=Us(e,t,n)}else"$?"===c.data?(t.flags|=192,t.child=e.child,t=null):(e=l.treeContext,ii=yd(c.nextSibling),ri=t,oi=!0,ai=null,si=!1,null!==e&&(Kr[Gr++]=Qr,Kr[Gr++]=Jr,Kr[Gr++]=Xr,Qr=e.id,Jr=e.overflow,Xr=t),(t=Ws(t,i.children)).flags|=4096);return t}return o?(ls(),o=i.fallback,c=t.mode,u=(l=e.child).sibling,(i=Nr(l,{mode:"hidden",children:i.children})).subtreeFlags=65011712&l.subtreeFlags,null!==u?o=Nr(u,o):(o=Vr(o,c,n,null)).flags|=2,o.return=t,i.return=t,i.sibling=o,t.child=i,i=o,o=t.child,null===(c=e.child.memoizedState)?c=Is(n):(null!==(l=c.cachePool)?(u=Ri._currentValue,l=l.parent!==u?{parent:u,pool:u}:l):l=Hi(),c={baseLanes:c.baseLanes|n,cachePool:l}),o.memoizedState=c,o.childLanes=Vs(e,r,n),t.memoizedState=_s,i):(as(t),e=(n=e.child).sibling,(n=Nr(n,{mode:"visible",children:i.children})).return=t,n.sibling=null,null!==e&&(null===(r=t.deletions)?(t.deletions=[e],t.flags|=16):r.push(e)),t.child=n,t.memoizedState=null,n)}function Ws(e,t){return(t=Hs({mode:"visible",children:t},e.mode)).return=e,e.child=t}function Hs(e,t){return(e=Or(22,e,null,t)).lanes=0,e.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null},e}function Us(e,t,n){return ns(t,e.child,null,n),(e=Ws(t,t.pendingProps.children)).flags|=2,t.memoizedState=null,e}function qs(e,t,n){e.lanes|=t;var r=e.alternate;null!==r&&(r.lanes|=t),wi(e.return,t,n)}function Ys(e,t,n,r,i){var o=e.memoizedState;null===o?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:i}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=r,o.tail=n,o.tailMode=i)}function Ks(e,t,n){var r=t.pendingProps,i=r.revealOrder,o=r.tail;if(Ts(e,t,r.children,n),0!==(2&(r=us.current)))r=1&r|2,t.flags|=128;else{if(null!==e&&0!==(128&e.flags))e:for(e=t.child;null!==e;){if(13===e.tag)null!==e.memoizedState&&qs(e,n,t);else if(19===e.tag)qs(e,n,t);else if(null!==e.child){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;null===e.sibling;){if(null===e.return||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}switch(V(us,r),i){case"forwards":for(n=t.child,i=null;null!==n;)null!==(e=n.alternate)&&null===ds(e)&&(i=n),n=n.sibling;null===(n=i)?(i=t.child,t.child=null):(i=n.sibling,n.sibling=null),Ys(t,!1,i,n,o);break;case"backwards":for(n=null,i=t.child,t.child=null;null!==i;){if(null!==(e=i.alternate)&&null===ds(e)){t.child=i;break}e=i.sibling,i.sibling=n,n=i,i=e}Ys(t,!0,n,null,o);break;case"together":Ys(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function Gs(e,t,n){if(null!==e&&(t.dependencies=e.dependencies),pc|=t.lanes,0===(n&t.childLanes)){if(null===e)return null;if(Si(e,t,n,!1),0===(n&t.childLanes))return null}if(null!==e&&t.child!==e.child)throw Error(a(153));if(null!==t.child){for(n=Nr(e=t.child,e.pendingProps),t.child=n,n.return=t;null!==e.sibling;)e=e.sibling,(n=n.sibling=Nr(e,e.pendingProps)).return=t;n.sibling=null}return t.child}function Xs(e,t){return 0!==(e.lanes&t)||!(null===(e=e.dependencies)||!ji(e))}function Qs(e,t,n){if(null!==e)if(e.memoizedProps!==t.pendingProps)Es=!0;else{if(!Xs(e,n)&&0===(128&t.flags))return Es=!1,function(e,t,n){switch(t.tag){case 3:q(t,t.stateNode.containerInfo),vi(0,Ri,e.memoizedState.cache),pi();break;case 27:case 5:K(t);break;case 4:q(t,t.stateNode.containerInfo);break;case 10:vi(0,t.type,t.memoizedProps.value);break;case 13:var r=t.memoizedState;if(null!==r)return null!==r.dehydrated?(as(t),t.flags|=128,null):0!==(n&t.child.childLanes)?Bs(e,t,n):(as(t),null!==(e=Gs(e,t,n))?e.sibling:null);as(t);break;case 19:var i=0!==(128&e.flags);if((r=0!==(n&t.childLanes))||(Si(e,t,n,!1),r=0!==(n&t.childLanes)),i){if(r)return Ks(e,t,n);t.flags|=128}if(null!==(i=t.memoizedState)&&(i.rendering=null,i.tail=null,i.lastEffect=null),V(us,us.current),r)break;return null;case 22:case 23:return t.lanes=0,Rs(e,t,n);case 24:vi(0,Ri,e.memoizedState.cache)}return Gs(e,t,n)}(e,t,n);Es=0!==(131072&e.flags)}else Es=!1,oi&&0!==(1048576&t.flags)&&ei(t,Yr,t.index);switch(t.lanes=0,t.tag){case 16:e:{e=t.pendingProps;var r=t.elementType,i=r._init;if(r=i(r._payload),t.type=r,"function"!==typeof r){if(void 0!==r&&null!==r){if((i=r.$$typeof)===k){t.tag=11,t=Ps(null,t,r,e,n);break e}if(i===$){t.tag=14,t=zs(null,t,r,e,n);break e}}throw t=R(r)||r,Error(a(306,t,""))}Fr(r)?(e=gs(r,e),t.tag=1,t=Fs(null,t,r,e,n)):(t.tag=0,t=Ds(null,t,r,e,n))}return t;case 0:return Ds(e,t,t.type,t.pendingProps,n);case 1:return Fs(e,t,r=t.type,i=gs(r,t.pendingProps),n);case 3:e:{if(q(t,t.stateNode.containerInfo),null===e)throw Error(a(387));r=t.pendingProps;var o=t.memoizedState;i=o.element,ro(e,t),uo(t,r,null,n);var s=t.memoizedState;if(r=s.cache,vi(0,Ri,r),r!==o.cache&&ki(t,[Ri],n,!0),co(),r=s.element,o.isDehydrated){if(o={element:r,isDehydrated:!1,cache:s.cache},t.updateQueue.baseState=o,t.memoizedState=o,256&t.flags){t=Ns(e,t,r,n);break e}if(r!==i){fi(i=jr(Error(a(424)),t)),t=Ns(e,t,r,n);break e}if(9===(e=t.stateNode.containerInfo).nodeType)e=e.body;else e="HTML"===e.nodeName?e.ownerDocument.body:e;for(ii=yd(e.firstChild),ri=t,oi=!0,ai=null,si=!0,n=rs(t,null,r,n),t.child=n;n;)n.flags=-3&n.flags|4096,n=n.sibling}else{if(pi(),r===i){t=Gs(e,t,n);break e}Ts(e,t,r,n)}t=t.child}return t;case 26:return Ls(e,t),null===e?(n=Td(t.type,null,t.pendingProps,null))?t.memoizedState=n:oi||(n=t.type,e=t.pendingProps,(r=rd(H.current).createElement(n))[Re]=t,r[Me]=e,ed(r,n,e),Ue(r),t.stateNode=r):t.memoizedState=Td(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return K(t),null===e&&oi&&(r=t.stateNode=bd(t.type,t.pendingProps,H.current),ri=t,si=!0,i=ii,pd(t.type)?(xd=i,ii=yd(r.firstChild)):ii=i),Ts(e,t,t.pendingProps.children,n),Ls(e,t),null===e&&(t.flags|=4194304),t.child;case 5:return null===e&&oi&&((i=r=ii)&&(null!==(r=function(e,t,n,r){for(;1===e.nodeType;){var i=n;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!r&&("INPUT"!==e.nodeName||"hidden"!==e.type))break}else if(r){if(!e[_e])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if("stylesheet"===(o=e.getAttribute("rel"))&&e.hasAttribute("data-precedence"))break;if(o!==i.rel||e.getAttribute("href")!==(null==i.href||""===i.href?null:i.href)||e.getAttribute("crossorigin")!==(null==i.crossOrigin?null:i.crossOrigin)||e.getAttribute("title")!==(null==i.title?null:i.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(((o=e.getAttribute("src"))!==(null==i.src?null:i.src)||e.getAttribute("type")!==(null==i.type?null:i.type)||e.getAttribute("crossorigin")!==(null==i.crossOrigin?null:i.crossOrigin))&&o&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else{if("input"!==t||"hidden"!==e.type)return e;var o=null==i.name?null:""+i.name;if("hidden"===i.type&&e.getAttribute("name")===o)return e}if(null===(e=yd(e.nextSibling)))break}return null}(r,t.type,t.pendingProps,si))?(t.stateNode=r,ri=t,ii=yd(r.firstChild),si=!1,i=!0):i=!1),i||ci(t)),K(t),i=t.type,o=t.pendingProps,s=null!==e?e.memoizedProps:null,r=o.children,ad(i,o)?r=null:null!==s&&ad(i,s)&&(t.flags|=32),null!==t.memoizedState&&(i=Ro(e,t,Do,null,null,n),Kd._currentValue=i),Ls(e,t),Ts(e,t,r,n),t.child;case 6:return null===e&&oi&&((e=n=ii)&&(null!==(n=function(e,t,n){if(""===t)return null;for(;3!==e.nodeType;){if((1!==e.nodeType||"INPUT"!==e.nodeName||"hidden"!==e.type)&&!n)return null;if(null===(e=yd(e.nextSibling)))return null}return e}(n,t.pendingProps,si))?(t.stateNode=n,ri=t,ii=null,e=!0):e=!1),e||ci(t)),null;case 13:return Bs(e,t,n);case 4:return q(t,t.stateNode.containerInfo),r=t.pendingProps,null===e?t.child=ns(t,null,r,n):Ts(e,t,r,n),t.child;case 11:return Ps(e,t,t.type,t.pendingProps,n);case 7:return Ts(e,t,t.pendingProps,n),t.child;case 8:case 12:return Ts(e,t,t.pendingProps.children,n),t.child;case 10:return r=t.pendingProps,vi(0,t.type,r.value),Ts(e,t,r.children,n),t.child;case 9:return i=t.type._context,r=t.pendingProps.children,$i(t),r=r(i=Ci(i)),t.flags|=1,Ts(e,t,r,n),t.child;case 14:return zs(e,t,t.type,t.pendingProps,n);case 15:return As(e,t,t.type,t.pendingProps,n);case 19:return Ks(e,t,n);case 31:return r=t.pendingProps,n=t.mode,r={mode:r.mode,children:r.children},null===e?((n=Hs(r,n)).ref=t.ref,t.child=n,n.return=t,t=n):((n=Nr(e.child,r)).ref=t.ref,t.child=n,n.return=t,t=n),t;case 22:return Rs(e,t,n);case 24:return $i(t),r=Ci(Ri),null===e?(null===(i=Bi())&&(i=rc,o=Mi(),i.pooledCache=o,o.refCount++,null!==o&&(i.pooledCacheLanes|=n),i=o),t.memoizedState={parent:r,cache:i},no(t),vi(0,Ri,i)):(0!==(e.lanes&n)&&(ro(e,t),uo(t,null,null,n),co()),i=e.memoizedState,o=t.memoizedState,i.parent!==r?(i={parent:r,cache:r},t.memoizedState=i,0===t.lanes&&(t.memoizedState=t.updateQueue.baseState=i),vi(0,Ri,r)):(r=o.cache,vi(0,Ri,r),r!==i.cache&&ki(t,[Ri],n,!0))),Ts(e,t,t.pendingProps.children,n),t.child;case 29:throw t.pendingProps}throw Error(a(156,t.tag))}function Js(e){e.flags|=4}function Zs(e,t){if("stylesheet"!==t.type||0!==(4&t.state.loading))e.flags&=-16777217;else if(e.flags|=16777216,!Vd(t)){if(null!==(t=is.current)&&((4194048&oc)===oc?null!==os:(62914560&oc)!==oc&&0===(536870912&oc)||t!==os))throw Ji=Ki,qi;e.flags|=8192}}function el(e,t){null!==t&&(e.flags|=4),16384&e.flags&&(t=22!==e.tag?Se():536870912,e.lanes|=t,yc|=t)}function tl(e,t){if(!oi)switch(e.tailMode){case"hidden":t=e.tail;for(var n=null;null!==t;)null!==t.alternate&&(n=t),t=t.sibling;null===n?e.tail=null:n.sibling=null;break;case"collapsed":n=e.tail;for(var r=null;null!==n;)null!==n.alternate&&(r=n),n=n.sibling;null===r?t||null===e.tail?e.tail=null:e.tail.sibling=null:r.sibling=null}}function nl(e){var t=null!==e.alternate&&e.alternate.child===e.child,n=0,r=0;if(t)for(var i=e.child;null!==i;)n|=i.lanes|i.childLanes,r|=65011712&i.subtreeFlags,r|=65011712&i.flags,i.return=e,i=i.sibling;else for(i=e.child;null!==i;)n|=i.lanes|i.childLanes,r|=i.subtreeFlags,r|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function rl(e,t,n){var r=t.pendingProps;switch(ni(t),t.tag){case 31:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:case 1:return nl(t),null;case 3:return n=t.stateNode,r=null,null!==e&&(r=e.memoizedState.cache),t.memoizedState.cache!==r&&(t.flags|=2048),bi(Ri),Y(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),null!==e&&null!==e.child||(hi(t)?Js(t):null===e||e.memoizedState.isDehydrated&&0===(256&t.flags)||(t.flags|=1024,mi())),nl(t),null;case 26:return n=t.memoizedState,null===e?(Js(t),null!==n?(nl(t),Zs(t,n)):(nl(t),t.flags&=-16777217)):n?n!==e.memoizedState?(Js(t),nl(t),Zs(t,n)):(nl(t),t.flags&=-16777217):(e.memoizedProps!==r&&Js(t),nl(t),t.flags&=-16777217),null;case 27:G(t),n=H.current;var i=t.type;if(null!==e&&null!=t.stateNode)e.memoizedProps!==r&&Js(t);else{if(!r){if(null===t.stateNode)throw Error(a(166));return nl(t),null}e=B.current,hi(t)?ui(t):(e=bd(i,r,n),t.stateNode=e,Js(t))}return nl(t),null;case 5:if(G(t),n=t.type,null!==e&&null!=t.stateNode)e.memoizedProps!==r&&Js(t);else{if(!r){if(null===t.stateNode)throw Error(a(166));return nl(t),null}if(e=B.current,hi(t))ui(t);else{switch(i=rd(H.current),e){case 1:e=i.createElementNS("http://www.w3.org/2000/svg",n);break;case 2:e=i.createElementNS("http://www.w3.org/1998/Math/MathML",n);break;default:switch(n){case"svg":e=i.createElementNS("http://www.w3.org/2000/svg",n);break;case"math":e=i.createElementNS("http://www.w3.org/1998/Math/MathML",n);break;case"script":(e=i.createElement("div")).innerHTML="<script><\/script>",e=e.removeChild(e.firstChild);break;case"select":e="string"===typeof r.is?i.createElement("select",{is:r.is}):i.createElement("select"),r.multiple?e.multiple=!0:r.size&&(e.size=r.size);break;default:e="string"===typeof r.is?i.createElement(n,{is:r.is}):i.createElement(n)}}e[Re]=t,e[Me]=r;e:for(i=t.child;null!==i;){if(5===i.tag||6===i.tag)e.appendChild(i.stateNode);else if(4!==i.tag&&27!==i.tag&&null!==i.child){i.child.return=i,i=i.child;continue}if(i===t)break e;for(;null===i.sibling;){if(null===i.return||i.return===t)break e;i=i.return}i.sibling.return=i.return,i=i.sibling}t.stateNode=e;e:switch(ed(e,n,r),n){case"button":case"input":case"select":case"textarea":e=!!r.autoFocus;break e;case"img":e=!0;break e;default:e=!1}e&&Js(t)}}return nl(t),t.flags&=-16777217,null;case 6:if(e&&null!=t.stateNode)e.memoizedProps!==r&&Js(t);else{if("string"!==typeof r&&null===t.stateNode)throw Error(a(166));if(e=H.current,hi(t)){if(e=t.stateNode,n=t.memoizedProps,r=null,null!==(i=ri))switch(i.tag){case 27:case 5:r=i.memoizedProps}e[Re]=t,(e=!!(e.nodeValue===n||null!==r&&!0===r.suppressHydrationWarning||Xu(e.nodeValue,n)))||ci(t)}else(e=rd(e).createTextNode(r))[Re]=t,t.stateNode=e}return nl(t),null;case 13:if(r=t.memoizedState,null===e||null!==e.memoizedState&&null!==e.memoizedState.dehydrated){if(i=hi(t),null!==r&&null!==r.dehydrated){if(null===e){if(!i)throw Error(a(318));if(!(i=null!==(i=t.memoizedState)?i.dehydrated:null))throw Error(a(317));i[Re]=t}else pi(),0===(128&t.flags)&&(t.memoizedState=null),t.flags|=4;nl(t),i=!1}else i=mi(),null!==e&&null!==e.memoizedState&&(e.memoizedState.hydrationErrors=i),i=!0;if(!i)return 256&t.flags?(cs(t),t):(cs(t),null)}if(cs(t),0!==(128&t.flags))return t.lanes=n,t;if(n=null!==r,e=null!==e&&null!==e.memoizedState,n){i=null,null!==(r=t.child).alternate&&null!==r.alternate.memoizedState&&null!==r.alternate.memoizedState.cachePool&&(i=r.alternate.memoizedState.cachePool.pool);var o=null;null!==r.memoizedState&&null!==r.memoizedState.cachePool&&(o=r.memoizedState.cachePool.pool),o!==i&&(r.flags|=2048)}return n!==e&&n&&(t.child.flags|=8192),el(t,t.updateQueue),nl(t),null;case 4:return Y(),null===e&&Iu(t.stateNode.containerInfo),nl(t),null;case 10:return bi(t.type),nl(t),null;case 19:if(I(us),null===(i=t.memoizedState))return nl(t),null;if(r=0!==(128&t.flags),null===(o=i.rendering))if(r)tl(i,!1);else{if(0!==hc||null!==e&&0!==(128&e.flags))for(e=t.child;null!==e;){if(null!==(o=ds(e))){for(t.flags|=128,tl(i,!1),e=o.updateQueue,t.updateQueue=e,el(t,e),t.subtreeFlags=0,e=n,n=t.child;null!==n;)_r(n,e),n=n.sibling;return V(us,1&us.current|2),t.child}e=e.sibling}null!==i.tail&&te()>kc&&(t.flags|=128,r=!0,tl(i,!1),t.lanes=4194304)}else{if(!r)if(null!==(e=ds(o))){if(t.flags|=128,r=!0,e=e.updateQueue,t.updateQueue=e,el(t,e),tl(i,!0),null===i.tail&&"hidden"===i.tailMode&&!o.alternate&&!oi)return nl(t),null}else 2*te()-i.renderingStartTime>kc&&536870912!==n&&(t.flags|=128,r=!0,tl(i,!1),t.lanes=4194304);i.isBackwards?(o.sibling=t.child,t.child=o):(null!==(e=i.last)?e.sibling=o:t.child=o,i.last=o)}return null!==i.tail?(t=i.tail,i.rendering=t,i.tail=t.sibling,i.renderingStartTime=te(),t.sibling=null,e=us.current,V(us,r?1&e|2:1&e),t):(nl(t),null);case 22:case 23:return cs(t),xo(),r=null!==t.memoizedState,null!==e?null!==e.memoizedState!==r&&(t.flags|=8192):r&&(t.flags|=8192),r?0!==(536870912&n)&&0===(128&t.flags)&&(nl(t),6&t.subtreeFlags&&(t.flags|=8192)):nl(t),null!==(n=t.updateQueue)&&el(t,n.retryQueue),n=null,null!==e&&null!==e.memoizedState&&null!==e.memoizedState.cachePool&&(n=e.memoizedState.cachePool.pool),r=null,null!==t.memoizedState&&null!==t.memoizedState.cachePool&&(r=t.memoizedState.cachePool.pool),r!==n&&(t.flags|=2048),null!==e&&I(Vi),null;case 24:return n=null,null!==e&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),bi(Ri),nl(t),null;case 25:case 30:return null}throw Error(a(156,t.tag))}function il(e,t){switch(ni(t),t.tag){case 1:return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 3:return bi(Ri),Y(),0!==(65536&(e=t.flags))&&0===(128&e)?(t.flags=-65537&e|128,t):null;case 26:case 27:case 5:return G(t),null;case 13:if(cs(t),null!==(e=t.memoizedState)&&null!==e.dehydrated){if(null===t.alternate)throw Error(a(340));pi()}return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 19:return I(us),null;case 4:return Y(),null;case 10:return bi(t.type),null;case 22:case 23:return cs(t),xo(),null!==e&&I(Vi),65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;case 24:return bi(Ri),null;default:return null}}function ol(e,t){switch(ni(t),t.tag){case 3:bi(Ri),Y();break;case 26:case 27:case 5:G(t);break;case 4:Y();break;case 13:cs(t);break;case 19:I(us);break;case 10:bi(t.type);break;case 22:case 23:cs(t),xo(),null!==e&&I(Vi);break;case 24:bi(Ri)}}function al(e,t){try{var n=t.updateQueue,r=null!==n?n.lastEffect:null;if(null!==r){var i=r.next;n=i;do{if((n.tag&e)===e){r=void 0;var o=n.create,a=n.inst;r=o(),a.destroy=r}n=n.next}while(n!==i)}}catch(s){uu(t,t.return,s)}}function sl(e,t,n){try{var r=t.updateQueue,i=null!==r?r.lastEffect:null;if(null!==i){var o=i.next;r=o;do{if((r.tag&e)===e){var a=r.inst,s=a.destroy;if(void 0!==s){a.destroy=void 0,i=t;var l=n,c=s;try{c()}catch(u){uu(i,l,u)}}}r=r.next}while(r!==o)}}catch(u){uu(t,t.return,u)}}function ll(e){var t=e.updateQueue;if(null!==t){var n=e.stateNode;try{po(t,n)}catch(r){uu(e,e.return,r)}}}function cl(e,t,n){n.props=gs(e.type,e.memoizedProps),n.state=e.memoizedState;try{n.componentWillUnmount()}catch(r){uu(e,t,r)}}function ul(e,t){try{var n=e.ref;if(null!==n){switch(e.tag){case 26:case 27:case 5:var r=e.stateNode;break;default:r=e.stateNode}"function"===typeof n?e.refCleanup=n(r):n.current=r}}catch(i){uu(e,t,i)}}function dl(e,t){var n=e.ref,r=e.refCleanup;if(null!==n)if("function"===typeof r)try{r()}catch(i){uu(e,t,i)}finally{e.refCleanup=null,null!=(e=e.alternate)&&(e.refCleanup=null)}else if("function"===typeof n)try{n(null)}catch(o){uu(e,t,o)}else n.current=null}function hl(e){var t=e.type,n=e.memoizedProps,r=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":n.autoFocus&&r.focus();break e;case"img":n.src?r.src=n.src:n.srcSet&&(r.srcset=n.srcSet)}}catch(i){uu(e,e.return,i)}}function pl(e,t,n){try{var r=e.stateNode;!function(e,t,n,r){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var i=null,o=null,s=null,l=null,c=null,u=null,d=null;for(m in n){var h=n[m];if(n.hasOwnProperty(m)&&null!=h)switch(m){case"checked":case"value":break;case"defaultValue":c=h;default:r.hasOwnProperty(m)||Ju(e,t,m,null,r,h)}}for(var p in r){var m=r[p];if(h=n[p],r.hasOwnProperty(p)&&(null!=m||null!=h))switch(p){case"type":o=m;break;case"name":i=m;break;case"checked":u=m;break;case"defaultChecked":d=m;break;case"value":s=m;break;case"defaultValue":l=m;break;case"children":case"dangerouslySetInnerHTML":if(null!=m)throw Error(a(137,t));break;default:m!==h&&Ju(e,t,p,m,r,h)}}return void gt(e,s,l,c,u,d,o,i);case"select":for(o in m=s=l=p=null,n)if(c=n[o],n.hasOwnProperty(o)&&null!=c)switch(o){case"value":break;case"multiple":m=c;default:r.hasOwnProperty(o)||Ju(e,t,o,null,r,c)}for(i in r)if(o=r[i],c=n[i],r.hasOwnProperty(i)&&(null!=o||null!=c))switch(i){case"value":p=o;break;case"defaultValue":l=o;break;case"multiple":s=o;default:o!==c&&Ju(e,t,i,o,r,c)}return t=l,n=s,r=m,void(null!=p?vt(e,!!n,p,!1):!!r!==!!n&&(null!=t?vt(e,!!n,t,!0):vt(e,!!n,n?[]:"",!1)));case"textarea":for(l in m=p=null,n)if(i=n[l],n.hasOwnProperty(l)&&null!=i&&!r.hasOwnProperty(l))switch(l){case"value":case"children":break;default:Ju(e,t,l,null,r,i)}for(s in r)if(i=r[s],o=n[s],r.hasOwnProperty(s)&&(null!=i||null!=o))switch(s){case"value":p=i;break;case"defaultValue":m=i;break;case"children":break;case"dangerouslySetInnerHTML":if(null!=i)throw Error(a(91));break;default:i!==o&&Ju(e,t,s,i,r,o)}return void bt(e,p,m);case"option":for(var f in n)if(p=n[f],n.hasOwnProperty(f)&&null!=p&&!r.hasOwnProperty(f))if("selected"===f)e.selected=!1;else Ju(e,t,f,null,r,p);for(c in r)if(p=r[c],m=n[c],r.hasOwnProperty(c)&&p!==m&&(null!=p||null!=m))if("selected"===c)e.selected=p&&"function"!==typeof p&&"symbol"!==typeof p;else Ju(e,t,c,p,r,m);return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var g in n)p=n[g],n.hasOwnProperty(g)&&null!=p&&!r.hasOwnProperty(g)&&Ju(e,t,g,null,r,p);for(u in r)if(p=r[u],m=n[u],r.hasOwnProperty(u)&&p!==m&&(null!=p||null!=m))switch(u){case"children":case"dangerouslySetInnerHTML":if(null!=p)throw Error(a(137,t));break;default:Ju(e,t,u,p,r,m)}return;default:if(Ct(t)){for(var y in n)p=n[y],n.hasOwnProperty(y)&&void 0!==p&&!r.hasOwnProperty(y)&&Zu(e,t,y,void 0,r,p);for(d in r)p=r[d],m=n[d],!r.hasOwnProperty(d)||p===m||void 0===p&&void 0===m||Zu(e,t,d,p,r,m);return}}for(var x in n)p=n[x],n.hasOwnProperty(x)&&null!=p&&!r.hasOwnProperty(x)&&Ju(e,t,x,null,r,p);for(h in r)p=r[h],m=n[h],!r.hasOwnProperty(h)||p===m||null==p&&null==m||Ju(e,t,h,p,r,m)}(r,e.type,n,t),r[Me]=t}catch(i){uu(e,e.return,i)}}function ml(e){return 5===e.tag||3===e.tag||26===e.tag||27===e.tag&&pd(e.type)||4===e.tag}function fl(e){e:for(;;){for(;null===e.sibling;){if(null===e.return||ml(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;5!==e.tag&&6!==e.tag&&18!==e.tag;){if(27===e.tag&&pd(e.type))continue e;if(2&e.flags)continue e;if(null===e.child||4===e.tag)continue e;e.child.return=e,e=e.child}if(!(2&e.flags))return e.stateNode}}function gl(e,t,n){var r=e.tag;if(5===r||6===r)e=e.stateNode,t?(9===n.nodeType?n.body:"HTML"===n.nodeName?n.ownerDocument.body:n).insertBefore(e,t):((t=9===n.nodeType?n.body:"HTML"===n.nodeName?n.ownerDocument.body:n).appendChild(e),null!==(n=n._reactRootContainer)&&void 0!==n||null!==t.onclick||(t.onclick=Qu));else if(4!==r&&(27===r&&pd(e.type)&&(n=e.stateNode,t=null),null!==(e=e.child)))for(gl(e,t,n),e=e.sibling;null!==e;)gl(e,t,n),e=e.sibling}function yl(e,t,n){var r=e.tag;if(5===r||6===r)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(4!==r&&(27===r&&pd(e.type)&&(n=e.stateNode),null!==(e=e.child)))for(yl(e,t,n),e=e.sibling;null!==e;)yl(e,t,n),e=e.sibling}function xl(e){var t=e.stateNode,n=e.memoizedProps;try{for(var r=e.type,i=t.attributes;i.length;)t.removeAttributeNode(i[0]);ed(t,r,n),t[Re]=e,t[Me]=n}catch(o){uu(e,e.return,o)}}var vl=!1,bl=!1,wl=!1,kl="function"===typeof WeakSet?WeakSet:Set,Sl=null;function jl(e,t,n){var r=n.flags;switch(n.tag){case 0:case 11:case 15:Fl(e,n),4&r&&al(5,n);break;case 1:if(Fl(e,n),4&r)if(e=n.stateNode,null===t)try{e.componentDidMount()}catch(a){uu(n,n.return,a)}else{var i=gs(n.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(i,t,e.__reactInternalSnapshotBeforeUpdate)}catch(s){uu(n,n.return,s)}}64&r&&ll(n),512&r&&ul(n,n.return);break;case 3:if(Fl(e,n),64&r&&null!==(e=n.updateQueue)){if(t=null,null!==n.child)switch(n.child.tag){case 27:case 5:case 1:t=n.child.stateNode}try{po(e,t)}catch(a){uu(n,n.return,a)}}break;case 27:null===t&&4&r&&xl(n);case 26:case 5:Fl(e,n),null===t&&4&r&&hl(n),512&r&&ul(n,n.return);break;case 12:Fl(e,n);break;case 13:Fl(e,n),4&r&&zl(e,n),64&r&&(null!==(e=n.memoizedState)&&(null!==(e=e.dehydrated)&&function(e,t){var n=e.ownerDocument;if("$?"!==e.data||"complete"===n.readyState)t();else{var r=function(){t(),n.removeEventListener("DOMContentLoaded",r)};n.addEventListener("DOMContentLoaded",r),e._reactRetry=r}}(e,n=mu.bind(null,n))));break;case 22:if(!(r=null!==n.memoizedState||vl)){t=null!==t&&null!==t.memoizedState||bl,i=vl;var o=bl;vl=r,(bl=t)&&!o?_l(e,n,0!==(8772&n.subtreeFlags)):Fl(e,n),vl=i,bl=o}break;case 30:break;default:Fl(e,n)}}function $l(e){var t=e.alternate;null!==t&&(e.alternate=null,$l(t)),e.child=null,e.deletions=null,e.sibling=null,5===e.tag&&(null!==(t=e.stateNode)&&Ie(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var Cl=null,El=!1;function Tl(e,t,n){for(n=n.child;null!==n;)Pl(e,t,n),n=n.sibling}function Pl(e,t,n){if(de&&"function"===typeof de.onCommitFiberUnmount)try{de.onCommitFiberUnmount(ue,n)}catch(o){}switch(n.tag){case 26:bl||dl(n,t),Tl(e,t,n),n.memoizedState?n.memoizedState.count--:n.stateNode&&(n=n.stateNode).parentNode.removeChild(n);break;case 27:bl||dl(n,t);var r=Cl,i=El;pd(n.type)&&(Cl=n.stateNode,El=!1),Tl(e,t,n),wd(n.stateNode),Cl=r,El=i;break;case 5:bl||dl(n,t);case 6:if(r=Cl,i=El,Cl=null,Tl(e,t,n),El=i,null!==(Cl=r))if(El)try{(9===Cl.nodeType?Cl.body:"HTML"===Cl.nodeName?Cl.ownerDocument.body:Cl).removeChild(n.stateNode)}catch(a){uu(n,t,a)}else try{Cl.removeChild(n.stateNode)}catch(a){uu(n,t,a)}break;case 18:null!==Cl&&(El?(md(9===(e=Cl).nodeType?e.body:"HTML"===e.nodeName?e.ownerDocument.body:e,n.stateNode),Eh(e)):md(Cl,n.stateNode));break;case 4:r=Cl,i=El,Cl=n.stateNode.containerInfo,El=!0,Tl(e,t,n),Cl=r,El=i;break;case 0:case 11:case 14:case 15:bl||sl(2,n,t),bl||sl(4,n,t),Tl(e,t,n);break;case 1:bl||(dl(n,t),"function"===typeof(r=n.stateNode).componentWillUnmount&&cl(n,t,r)),Tl(e,t,n);break;case 21:Tl(e,t,n);break;case 22:bl=(r=bl)||null!==n.memoizedState,Tl(e,t,n),bl=r;break;default:Tl(e,t,n)}}function zl(e,t){if(null===t.memoizedState&&(null!==(e=t.alternate)&&(null!==(e=e.memoizedState)&&null!==(e=e.dehydrated))))try{Eh(e)}catch(n){uu(t,t.return,n)}}function Al(e,t){var n=function(e){switch(e.tag){case 13:case 19:var t=e.stateNode;return null===t&&(t=e.stateNode=new kl),t;case 22:return null===(t=(e=e.stateNode)._retryCache)&&(t=e._retryCache=new kl),t;default:throw Error(a(435,e.tag))}}(e);t.forEach(function(t){var r=fu.bind(null,e,t);n.has(t)||(n.add(t),t.then(r,r))})}function Rl(e,t){var n=t.deletions;if(null!==n)for(var r=0;r<n.length;r++){var i=n[r],o=e,s=t,l=s;e:for(;null!==l;){switch(l.tag){case 27:if(pd(l.type)){Cl=l.stateNode,El=!1;break e}break;case 5:Cl=l.stateNode,El=!1;break e;case 3:case 4:Cl=l.stateNode.containerInfo,El=!0;break e}l=l.return}if(null===Cl)throw Error(a(160));Pl(o,s,i),Cl=null,El=!1,null!==(o=i.alternate)&&(o.return=null),i.return=null}if(13878&t.subtreeFlags)for(t=t.child;null!==t;)Ll(t,e),t=t.sibling}var Ml=null;function Ll(e,t){var n=e.alternate,r=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:Rl(t,e),Dl(e),4&r&&(sl(3,e,e.return),al(3,e),sl(5,e,e.return));break;case 1:Rl(t,e),Dl(e),512&r&&(bl||null===n||dl(n,n.return)),64&r&&vl&&(null!==(e=e.updateQueue)&&(null!==(r=e.callbacks)&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=null===n?r:n.concat(r))));break;case 26:var i=Ml;if(Rl(t,e),Dl(e),512&r&&(bl||null===n||dl(n,n.return)),4&r){var o=null!==n?n.memoizedState:null;if(r=e.memoizedState,null===n)if(null===r)if(null===e.stateNode){e:{r=e.type,n=e.memoizedProps,i=i.ownerDocument||i;t:switch(r){case"title":(!(o=i.getElementsByTagName("title")[0])||o[_e]||o[Re]||"http://www.w3.org/2000/svg"===o.namespaceURI||o.hasAttribute("itemprop"))&&(o=i.createElement(r),i.head.insertBefore(o,i.querySelector("head > title"))),ed(o,r,n),o[Re]=e,Ue(o),r=o;break e;case"link":var s=_d("link","href",i).get(r+(n.href||""));if(s)for(var l=0;l<s.length;l++)if((o=s[l]).getAttribute("href")===(null==n.href||""===n.href?null:n.href)&&o.getAttribute("rel")===(null==n.rel?null:n.rel)&&o.getAttribute("title")===(null==n.title?null:n.title)&&o.getAttribute("crossorigin")===(null==n.crossOrigin?null:n.crossOrigin)){s.splice(l,1);break t}ed(o=i.createElement(r),r,n),i.head.appendChild(o);break;case"meta":if(s=_d("meta","content",i).get(r+(n.content||"")))for(l=0;l<s.length;l++)if((o=s[l]).getAttribute("content")===(null==n.content?null:""+n.content)&&o.getAttribute("name")===(null==n.name?null:n.name)&&o.getAttribute("property")===(null==n.property?null:n.property)&&o.getAttribute("http-equiv")===(null==n.httpEquiv?null:n.httpEquiv)&&o.getAttribute("charset")===(null==n.charSet?null:n.charSet)){s.splice(l,1);break t}ed(o=i.createElement(r),r,n),i.head.appendChild(o);break;default:throw Error(a(468,r))}o[Re]=e,Ue(o),r=o}e.stateNode=r}else Id(i,e.type,e.stateNode);else e.stateNode=Ld(i,r,e.memoizedProps);else o!==r?(null===o?null!==n.stateNode&&(n=n.stateNode).parentNode.removeChild(n):o.count--,null===r?Id(i,e.type,e.stateNode):Ld(i,r,e.memoizedProps)):null===r&&null!==e.stateNode&&pl(e,e.memoizedProps,n.memoizedProps)}break;case 27:Rl(t,e),Dl(e),512&r&&(bl||null===n||dl(n,n.return)),null!==n&&4&r&&pl(e,e.memoizedProps,n.memoizedProps);break;case 5:if(Rl(t,e),Dl(e),512&r&&(bl||null===n||dl(n,n.return)),32&e.flags){i=e.stateNode;try{kt(i,"")}catch(m){uu(e,e.return,m)}}4&r&&null!=e.stateNode&&pl(e,i=e.memoizedProps,null!==n?n.memoizedProps:i),1024&r&&(wl=!0);break;case 6:if(Rl(t,e),Dl(e),4&r){if(null===e.stateNode)throw Error(a(162));r=e.memoizedProps,n=e.stateNode;try{n.nodeValue=r}catch(m){uu(e,e.return,m)}}break;case 3:if(Nd=null,i=Ml,Ml=jd(t.containerInfo),Rl(t,e),Ml=i,Dl(e),4&r&&null!==n&&n.memoizedState.isDehydrated)try{Eh(t.containerInfo)}catch(m){uu(e,e.return,m)}wl&&(wl=!1,Ol(e));break;case 4:r=Ml,Ml=jd(e.stateNode.containerInfo),Rl(t,e),Dl(e),Ml=r;break;case 12:default:Rl(t,e),Dl(e);break;case 13:Rl(t,e),Dl(e),8192&e.child.flags&&null!==e.memoizedState!==(null!==n&&null!==n.memoizedState)&&(wc=te()),4&r&&(null!==(r=e.updateQueue)&&(e.updateQueue=null,Al(e,r)));break;case 22:i=null!==e.memoizedState;var c=null!==n&&null!==n.memoizedState,u=vl,d=bl;if(vl=u||i,bl=d||c,Rl(t,e),bl=d,vl=u,Dl(e),8192&r)e:for(t=e.stateNode,t._visibility=i?-2&t._visibility:1|t._visibility,i&&(null===n||c||vl||bl||Nl(e)),n=null,t=e;;){if(5===t.tag||26===t.tag){if(null===n){c=n=t;try{if(o=c.stateNode,i)"function"===typeof(s=o.style).setProperty?s.setProperty("display","none","important"):s.display="none";else{l=c.stateNode;var h=c.memoizedProps.style,p=void 0!==h&&null!==h&&h.hasOwnProperty("display")?h.display:null;l.style.display=null==p||"boolean"===typeof p?"":(""+p).trim()}}catch(m){uu(c,c.return,m)}}}else if(6===t.tag){if(null===n){c=t;try{c.stateNode.nodeValue=i?"":c.memoizedProps}catch(m){uu(c,c.return,m)}}}else if((22!==t.tag&&23!==t.tag||null===t.memoizedState||t===e)&&null!==t.child){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;null===t.sibling;){if(null===t.return||t.return===e)break e;n===t&&(n=null),t=t.return}n===t&&(n=null),t.sibling.return=t.return,t=t.sibling}4&r&&(null!==(r=e.updateQueue)&&(null!==(n=r.retryQueue)&&(r.retryQueue=null,Al(e,n))));break;case 19:Rl(t,e),Dl(e),4&r&&(null!==(r=e.updateQueue)&&(e.updateQueue=null,Al(e,r)));case 30:case 21:}}function Dl(e){var t=e.flags;if(2&t){try{for(var n,r=e.return;null!==r;){if(ml(r)){n=r;break}r=r.return}if(null==n)throw Error(a(160));switch(n.tag){case 27:var i=n.stateNode;yl(e,fl(e),i);break;case 5:var o=n.stateNode;32&n.flags&&(kt(o,""),n.flags&=-33),yl(e,fl(e),o);break;case 3:case 4:var s=n.stateNode.containerInfo;gl(e,fl(e),s);break;default:throw Error(a(161))}}catch(l){uu(e,e.return,l)}e.flags&=-3}4096&t&&(e.flags&=-4097)}function Ol(e){if(1024&e.subtreeFlags)for(e=e.child;null!==e;){var t=e;Ol(t),5===t.tag&&1024&t.flags&&t.stateNode.reset(),e=e.sibling}}function Fl(e,t){if(8772&t.subtreeFlags)for(t=t.child;null!==t;)jl(e,t.alternate,t),t=t.sibling}function Nl(e){for(e=e.child;null!==e;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:sl(4,t,t.return),Nl(t);break;case 1:dl(t,t.return);var n=t.stateNode;"function"===typeof n.componentWillUnmount&&cl(t,t.return,n),Nl(t);break;case 27:wd(t.stateNode);case 26:case 5:dl(t,t.return),Nl(t);break;case 22:null===t.memoizedState&&Nl(t);break;default:Nl(t)}e=e.sibling}}function _l(e,t,n){for(n=n&&0!==(8772&t.subtreeFlags),t=t.child;null!==t;){var r=t.alternate,i=e,o=t,a=o.flags;switch(o.tag){case 0:case 11:case 15:_l(i,o,n),al(4,o);break;case 1:if(_l(i,o,n),"function"===typeof(i=(r=o).stateNode).componentDidMount)try{i.componentDidMount()}catch(c){uu(r,r.return,c)}if(null!==(i=(r=o).updateQueue)){var s=r.stateNode;try{var l=i.shared.hiddenCallbacks;if(null!==l)for(i.shared.hiddenCallbacks=null,i=0;i<l.length;i++)ho(l[i],s)}catch(c){uu(r,r.return,c)}}n&&64&a&&ll(o),ul(o,o.return);break;case 27:xl(o);case 26:case 5:_l(i,o,n),n&&null===r&&4&a&&hl(o),ul(o,o.return);break;case 12:_l(i,o,n);break;case 13:_l(i,o,n),n&&4&a&&zl(i,o);break;case 22:null===o.memoizedState&&_l(i,o,n),ul(o,o.return);break;case 30:break;default:_l(i,o,n)}t=t.sibling}}function Il(e,t){var n=null;null!==e&&null!==e.memoizedState&&null!==e.memoizedState.cachePool&&(n=e.memoizedState.cachePool.pool),e=null,null!==t.memoizedState&&null!==t.memoizedState.cachePool&&(e=t.memoizedState.cachePool.pool),e!==n&&(null!=e&&e.refCount++,null!=n&&Li(n))}function Vl(e,t){e=null,null!==t.alternate&&(e=t.alternate.memoizedState.cache),(t=t.memoizedState.cache)!==e&&(t.refCount++,null!=e&&Li(e))}function Bl(e,t,n,r){if(10256&t.subtreeFlags)for(t=t.child;null!==t;)Wl(e,t,n,r),t=t.sibling}function Wl(e,t,n,r){var i=t.flags;switch(t.tag){case 0:case 11:case 15:Bl(e,t,n,r),2048&i&&al(9,t);break;case 1:case 13:default:Bl(e,t,n,r);break;case 3:Bl(e,t,n,r),2048&i&&(e=null,null!==t.alternate&&(e=t.alternate.memoizedState.cache),(t=t.memoizedState.cache)!==e&&(t.refCount++,null!=e&&Li(e)));break;case 12:if(2048&i){Bl(e,t,n,r),e=t.stateNode;try{var o=t.memoizedProps,a=o.id,s=o.onPostCommit;"function"===typeof s&&s(a,null===t.alternate?"mount":"update",e.passiveEffectDuration,-0)}catch(l){uu(t,t.return,l)}}else Bl(e,t,n,r);break;case 23:break;case 22:o=t.stateNode,a=t.alternate,null!==t.memoizedState?2&o._visibility?Bl(e,t,n,r):Ul(e,t):2&o._visibility?Bl(e,t,n,r):(o._visibility|=2,Hl(e,t,n,r,0!==(10256&t.subtreeFlags))),2048&i&&Il(a,t);break;case 24:Bl(e,t,n,r),2048&i&&Vl(t.alternate,t)}}function Hl(e,t,n,r,i){for(i=i&&0!==(10256&t.subtreeFlags),t=t.child;null!==t;){var o=e,a=t,s=n,l=r,c=a.flags;switch(a.tag){case 0:case 11:case 15:Hl(o,a,s,l,i),al(8,a);break;case 23:break;case 22:var u=a.stateNode;null!==a.memoizedState?2&u._visibility?Hl(o,a,s,l,i):Ul(o,a):(u._visibility|=2,Hl(o,a,s,l,i)),i&&2048&c&&Il(a.alternate,a);break;case 24:Hl(o,a,s,l,i),i&&2048&c&&Vl(a.alternate,a);break;default:Hl(o,a,s,l,i)}t=t.sibling}}function Ul(e,t){if(10256&t.subtreeFlags)for(t=t.child;null!==t;){var n=e,r=t,i=r.flags;switch(r.tag){case 22:Ul(n,r),2048&i&&Il(r.alternate,r);break;case 24:Ul(n,r),2048&i&&Vl(r.alternate,r);break;default:Ul(n,r)}t=t.sibling}}var ql=8192;function Yl(e){if(e.subtreeFlags&ql)for(e=e.child;null!==e;)Kl(e),e=e.sibling}function Kl(e){switch(e.tag){case 26:Yl(e),e.flags&ql&&null!==e.memoizedState&&function(e,t,n){if(null===Bd)throw Error(a(475));var r=Bd;if("stylesheet"===t.type&&("string"!==typeof n.media||!1!==matchMedia(n.media).matches)&&0===(4&t.state.loading)){if(null===t.instance){var i=Pd(n.href),o=e.querySelector(zd(i));if(o)return null!==(e=o._p)&&"object"===typeof e&&"function"===typeof e.then&&(r.count++,r=Hd.bind(r),e.then(r,r)),t.state.loading|=4,t.instance=o,void Ue(o);o=e.ownerDocument||e,n=Ad(n),(i=kd.get(i))&&Od(n,i),Ue(o=o.createElement("link"));var s=o;s._p=new Promise(function(e,t){s.onload=e,s.onerror=t}),ed(o,"link",n),t.instance=o}null===r.stylesheets&&(r.stylesheets=new Map),r.stylesheets.set(t,e),(e=t.state.preload)&&0===(3&t.state.loading)&&(r.count++,t=Hd.bind(r),e.addEventListener("load",t),e.addEventListener("error",t))}}(Ml,e.memoizedState,e.memoizedProps);break;case 5:default:Yl(e);break;case 3:case 4:var t=Ml;Ml=jd(e.stateNode.containerInfo),Yl(e),Ml=t;break;case 22:null===e.memoizedState&&(null!==(t=e.alternate)&&null!==t.memoizedState?(t=ql,ql=16777216,Yl(e),ql=t):Yl(e))}}function Gl(e){var t=e.alternate;if(null!==t&&null!==(e=t.child)){t.child=null;do{t=e.sibling,e.sibling=null,e=t}while(null!==e)}}function Xl(e){var t=e.deletions;if(0!==(16&e.flags)){if(null!==t)for(var n=0;n<t.length;n++){var r=t[n];Sl=r,Zl(r,e)}Gl(e)}if(10256&e.subtreeFlags)for(e=e.child;null!==e;)Ql(e),e=e.sibling}function Ql(e){switch(e.tag){case 0:case 11:case 15:Xl(e),2048&e.flags&&sl(9,e,e.return);break;case 3:case 12:default:Xl(e);break;case 22:var t=e.stateNode;null!==e.memoizedState&&2&t._visibility&&(null===e.return||13!==e.return.tag)?(t._visibility&=-3,Jl(e)):Xl(e)}}function Jl(e){var t=e.deletions;if(0!==(16&e.flags)){if(null!==t)for(var n=0;n<t.length;n++){var r=t[n];Sl=r,Zl(r,e)}Gl(e)}for(e=e.child;null!==e;){switch((t=e).tag){case 0:case 11:case 15:sl(8,t,t.return),Jl(t);break;case 22:2&(n=t.stateNode)._visibility&&(n._visibility&=-3,Jl(t));break;default:Jl(t)}e=e.sibling}}function Zl(e,t){for(;null!==Sl;){var n=Sl;switch(n.tag){case 0:case 11:case 15:sl(8,n,t);break;case 23:case 22:if(null!==n.memoizedState&&null!==n.memoizedState.cachePool){var r=n.memoizedState.cachePool.pool;null!=r&&r.refCount++}break;case 24:Li(n.memoizedState.cache)}if(null!==(r=n.child))r.return=n,Sl=r;else e:for(n=e;null!==Sl;){var i=(r=Sl).sibling,o=r.return;if($l(r),r===n){Sl=null;break e}if(null!==i){i.return=o,Sl=i;break e}Sl=o}}}var ec={getCacheForType:function(e){var t=Ci(Ri),n=t.data.get(e);return void 0===n&&(n=e(),t.data.set(e,n)),n}},tc="function"===typeof WeakMap?WeakMap:Map,nc=0,rc=null,ic=null,oc=0,ac=0,sc=null,lc=!1,cc=!1,uc=!1,dc=0,hc=0,pc=0,mc=0,fc=0,gc=0,yc=0,xc=null,vc=null,bc=!1,wc=0,kc=1/0,Sc=null,jc=null,$c=0,Cc=null,Ec=null,Tc=0,Pc=0,zc=null,Ac=null,Rc=0,Mc=null;function Lc(){if(0!==(2&nc)&&0!==oc)return oc&-oc;if(null!==L.T){return 0!==Fi?Fi:Pu()}return ze()}function Dc(){0===gc&&(gc=0===(536870912&oc)||oi?ke():536870912);var e=is.current;return null!==e&&(e.flags|=32),gc}function Oc(e,t,n){(e!==rc||2!==ac&&9!==ac)&&null===e.cancelPendingCommit||(Wc(e,0),Ic(e,oc,gc,!1)),$e(e,n),0!==(2&nc)&&e===rc||(e===rc&&(0===(2&nc)&&(mc|=n),4===hc&&Ic(e,oc,gc,!1)),ku(e))}function Fc(e,t,n){if(0!==(6&nc))throw Error(a(327));for(var r=!n&&0===(124&t)&&0===(t&e.expiredLanes)||be(e,t),i=r?function(e,t){var n=nc;nc|=2;var r=Uc(),i=qc();rc!==e||oc!==t?(Sc=null,kc=te()+500,Wc(e,t)):cc=be(e,t);e:for(;;)try{if(0!==ac&&null!==ic){t=ic;var o=sc;t:switch(ac){case 1:ac=0,sc=null,Zc(e,t,o,1);break;case 2:case 9:if(Gi(o)){ac=0,sc=null,Jc(t);break}t=function(){2!==ac&&9!==ac||rc!==e||(ac=7),ku(e)},o.then(t,t);break e;case 3:ac=7;break e;case 4:ac=5;break e;case 7:Gi(o)?(ac=0,sc=null,Jc(t)):(ac=0,sc=null,Zc(e,t,o,7));break;case 5:var s=null;switch(ic.tag){case 26:s=ic.memoizedState;case 5:case 27:var l=ic;if(!s||Vd(s)){ac=0,sc=null;var c=l.sibling;if(null!==c)ic=c;else{var u=l.return;null!==u?(ic=u,eu(u)):ic=null}break t}}ac=0,sc=null,Zc(e,t,o,5);break;case 6:ac=0,sc=null,Zc(e,t,o,6);break;case 8:Bc(),hc=6;break e;default:throw Error(a(462))}}Xc();break}catch(d){Hc(e,d)}return xi=yi=null,L.H=r,L.A=i,nc=n,null!==ic?0:(rc=null,oc=0,Tr(),hc)}(e,t):Kc(e,t,!0),o=r;;){if(0===i){cc&&!r&&Ic(e,t,0,!1);break}if(n=e.current.alternate,!o||_c(n)){if(2===i){if(o=t,e.errorRecoveryDisabledLanes&o)var s=0;else s=0!==(s=-536870913&e.pendingLanes)?s:536870912&s?536870912:0;if(0!==s){t=s;e:{var l=e;i=xc;var c=l.current.memoizedState.isDehydrated;if(c&&(Wc(l,s).flags|=256),2!==(s=Kc(l,s,!1))){if(uc&&!c){l.errorRecoveryDisabledLanes|=o,mc|=o,i=4;break e}o=vc,vc=i,null!==o&&(null===vc?vc=o:vc.push.apply(vc,o))}i=s}if(o=!1,2!==i)continue}}if(1===i){Wc(e,0),Ic(e,t,0,!0);break}e:{switch(r=e,o=i){case 0:case 1:throw Error(a(345));case 4:if((4194048&t)!==t)break;case 6:Ic(r,t,gc,!lc);break e;case 2:vc=null;break;case 3:case 5:break;default:throw Error(a(329))}if((62914560&t)===t&&10<(i=wc+300-te())){if(Ic(r,t,gc,!lc),0!==ve(r,0,!0))break e;r.timeoutHandle=ld(Nc.bind(null,r,n,vc,Sc,bc,t,gc,mc,yc,lc,o,2,-0,0),i)}else Nc(r,n,vc,Sc,bc,t,gc,mc,yc,lc,o,0,-0,0)}break}i=Kc(e,t,!1),o=!1}ku(e)}function Nc(e,t,n,r,i,o,s,l,c,u,d,h,p,m){if(e.timeoutHandle=-1,(8192&(h=t.subtreeFlags)||16785408===(16785408&h))&&(Bd={stylesheets:null,count:0,unsuspend:Wd},Kl(t),null!==(h=function(){if(null===Bd)throw Error(a(475));var e=Bd;return e.stylesheets&&0===e.count&&qd(e,e.stylesheets),0<e.count?function(t){var n=setTimeout(function(){if(e.stylesheets&&qd(e,e.stylesheets),e.unsuspend){var t=e.unsuspend;e.unsuspend=null,t()}},6e4);return e.unsuspend=t,function(){e.unsuspend=null,clearTimeout(n)}}:null}())))return e.cancelPendingCommit=h(nu.bind(null,e,t,o,n,r,i,s,l,c,d,1,p,m)),void Ic(e,o,s,!u);nu(e,t,o,n,r,i,s,l,c)}function _c(e){for(var t=e;;){var n=t.tag;if((0===n||11===n||15===n)&&16384&t.flags&&(null!==(n=t.updateQueue)&&null!==(n=n.stores)))for(var r=0;r<n.length;r++){var i=n[r],o=i.getSnapshot;i=i.value;try{if(!Gn(o(),i))return!1}catch(a){return!1}}if(n=t.child,16384&t.subtreeFlags&&null!==n)n.return=t,t=n;else{if(t===e)break;for(;null===t.sibling;){if(null===t.return||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function Ic(e,t,n,r){t&=~fc,t&=~mc,e.suspendedLanes|=t,e.pingedLanes&=~t,r&&(e.warmLanes|=t),r=e.expirationTimes;for(var i=t;0<i;){var o=31-pe(i),a=1<<o;r[o]=-1,i&=~a}0!==n&&Ce(e,n,t)}function Vc(){return 0!==(6&nc)||(Su(0,!1),!1)}function Bc(){if(null!==ic){if(0===ac)var e=ic.return;else xi=yi=null,No(e=ic),Ga=null,Xa=0,e=ic;for(;null!==e;)ol(e.alternate,e),e=e.return;ic=null}}function Wc(e,t){var n=e.timeoutHandle;-1!==n&&(e.timeoutHandle=-1,cd(n)),null!==(n=e.cancelPendingCommit)&&(e.cancelPendingCommit=null,n()),Bc(),rc=e,ic=n=Nr(e.current,null),oc=t,ac=0,sc=null,lc=!1,cc=be(e,t),uc=!1,yc=gc=fc=mc=pc=hc=0,vc=xc=null,bc=!1,0!==(8&t)&&(t|=32&t);var r=e.entangledLanes;if(0!==r)for(e=e.entanglements,r&=t;0<r;){var i=31-pe(r),o=1<<i;t|=e[i],r&=~o}return dc=t,Tr(),n}function Hc(e,t){bo=null,L.H=Ua,t===Ui||t===Yi?(t=Zi(),ac=3):t===qi?(t=Zi(),ac=4):ac=t===Cs?8:null!==t&&"object"===typeof t&&"function"===typeof t.then?6:1,sc=t,null===ic&&(hc=1,ws(e,jr(t,e.current)))}function Uc(){var e=L.H;return L.H=Ua,null===e?Ua:e}function qc(){var e=L.A;return L.A=ec,e}function Yc(){hc=4,lc||(4194048&oc)!==oc&&null!==is.current||(cc=!0),0===(134217727&pc)&&0===(134217727&mc)||null===rc||Ic(rc,oc,gc,!1)}function Kc(e,t,n){var r=nc;nc|=2;var i=Uc(),o=qc();rc===e&&oc===t||(Sc=null,Wc(e,t)),t=!1;var a=hc;e:for(;;)try{if(0!==ac&&null!==ic){var s=ic,l=sc;switch(ac){case 8:Bc(),a=6;break e;case 3:case 2:case 9:case 6:null===is.current&&(t=!0);var c=ac;if(ac=0,sc=null,Zc(e,s,l,c),n&&cc){a=0;break e}break;default:c=ac,ac=0,sc=null,Zc(e,s,l,c)}}Gc(),a=hc;break}catch(u){Hc(e,u)}return t&&e.shellSuspendCounter++,xi=yi=null,nc=r,L.H=i,L.A=o,null===ic&&(rc=null,oc=0,Tr()),a}function Gc(){for(;null!==ic;)Qc(ic)}function Xc(){for(;null!==ic&&!Z();)Qc(ic)}function Qc(e){var t=Qs(e.alternate,e,dc);e.memoizedProps=e.pendingProps,null===t?eu(e):ic=t}function Jc(e){var t=e,n=t.alternate;switch(t.tag){case 15:case 0:t=Os(n,t,t.pendingProps,t.type,void 0,oc);break;case 11:t=Os(n,t,t.pendingProps,t.type.render,t.ref,oc);break;case 5:No(t);default:ol(n,t),t=Qs(n,t=ic=_r(t,dc),dc)}e.memoizedProps=e.pendingProps,null===t?eu(e):ic=t}function Zc(e,t,n,r){xi=yi=null,No(t),Ga=null,Xa=0;var i=t.return;try{if(function(e,t,n,r,i){if(n.flags|=32768,null!==r&&"object"===typeof r&&"function"===typeof r.then){if(null!==(t=n.alternate)&&Si(t,n,i,!0),null!==(n=is.current)){switch(n.tag){case 13:return null===os?Yc():null===n.alternate&&0===hc&&(hc=3),n.flags&=-257,n.flags|=65536,n.lanes=i,r===Ki?n.flags|=16384:(null===(t=n.updateQueue)?n.updateQueue=new Set([r]):t.add(r),du(e,r,i)),!1;case 22:return n.flags|=65536,r===Ki?n.flags|=16384:(null===(t=n.updateQueue)?(t={transitions:null,markerInstances:null,retryQueue:new Set([r])},n.updateQueue=t):null===(n=t.retryQueue)?t.retryQueue=new Set([r]):n.add(r),du(e,r,i)),!1}throw Error(a(435,n.tag))}return du(e,r,i),Yc(),!1}if(oi)return null!==(t=is.current)?(0===(65536&t.flags)&&(t.flags|=256),t.flags|=65536,t.lanes=i,r!==li&&fi(jr(e=Error(a(422),{cause:r}),n))):(r!==li&&fi(jr(t=Error(a(423),{cause:r}),n)),(e=e.current.alternate).flags|=65536,i&=-i,e.lanes|=i,r=jr(r,n),so(e,i=Ss(e.stateNode,r,i)),4!==hc&&(hc=2)),!1;var o=Error(a(520),{cause:r});if(o=jr(o,n),null===xc?xc=[o]:xc.push(o),4!==hc&&(hc=2),null===t)return!0;r=jr(r,n),n=t;do{switch(n.tag){case 3:return n.flags|=65536,e=i&-i,n.lanes|=e,so(n,e=Ss(n.stateNode,r,e)),!1;case 1:if(t=n.type,o=n.stateNode,0===(128&n.flags)&&("function"===typeof t.getDerivedStateFromError||null!==o&&"function"===typeof o.componentDidCatch&&(null===jc||!jc.has(o))))return n.flags|=65536,i&=-i,n.lanes|=i,$s(i=js(i),e,n,r),so(n,i),!1}n=n.return}while(null!==n);return!1}(e,i,t,n,oc))return hc=1,ws(e,jr(n,e.current)),void(ic=null)}catch(o){if(null!==i)throw ic=i,o;return hc=1,ws(e,jr(n,e.current)),void(ic=null)}32768&t.flags?(oi||1===r?e=!0:cc||0!==(536870912&oc)?e=!1:(lc=e=!0,(2===r||9===r||3===r||6===r)&&(null!==(r=is.current)&&13===r.tag&&(r.flags|=16384))),tu(t,e)):eu(t)}function eu(e){var t=e;do{if(0!==(32768&t.flags))return void tu(t,lc);e=t.return;var n=rl(t.alternate,t,dc);if(null!==n)return void(ic=n);if(null!==(t=t.sibling))return void(ic=t);ic=t=e}while(null!==t);0===hc&&(hc=5)}function tu(e,t){do{var n=il(e.alternate,e);if(null!==n)return n.flags&=32767,void(ic=n);if(null!==(n=e.return)&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&null!==(e=e.sibling))return void(ic=e);ic=e=n}while(null!==e);hc=6,ic=null}function nu(e,t,n,r,i,o,s,l,c){e.cancelPendingCommit=null;do{su()}while(0!==$c);if(0!==(6&nc))throw Error(a(327));if(null!==t){if(t===e.current)throw Error(a(177));if(o=t.lanes|t.childLanes,function(e,t,n,r,i,o){var a=e.pendingLanes;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;var s=e.entanglements,l=e.expirationTimes,c=e.hiddenUpdates;for(n=a&~n;0<n;){var u=31-pe(n),d=1<<u;s[u]=0,l[u]=-1;var h=c[u];if(null!==h)for(c[u]=null,u=0;u<h.length;u++){var p=h[u];null!==p&&(p.lane&=-536870913)}n&=~d}0!==r&&Ce(e,r,0),0!==o&&0===i&&0!==e.tag&&(e.suspendedLanes|=o&~(a&~t))}(e,n,o|=Er,s,l,c),e===rc&&(ic=rc=null,oc=0),Ec=t,Cc=e,Tc=n,Pc=o,zc=i,Ac=r,0!==(10256&t.subtreeFlags)||0!==(10256&t.flags)?(e.callbackNode=null,e.callbackPriority=0,Q(oe,function(){return lu(),null})):(e.callbackNode=null,e.callbackPriority=0),r=0!==(13878&t.flags),0!==(13878&t.subtreeFlags)||r){r=L.T,L.T=null,i=D.p,D.p=2,s=nc,nc|=4;try{!function(e,t){if(e=e.containerInfo,td=nh,tr(e=er(e))){if("selectionStart"in e)var n={start:e.selectionStart,end:e.selectionEnd};else e:{var r=(n=(n=e.ownerDocument)&&n.defaultView||window).getSelection&&n.getSelection();if(r&&0!==r.rangeCount){n=r.anchorNode;var i=r.anchorOffset,o=r.focusNode;r=r.focusOffset;try{n.nodeType,o.nodeType}catch(g){n=null;break e}var s=0,l=-1,c=-1,u=0,d=0,h=e,p=null;t:for(;;){for(var m;h!==n||0!==i&&3!==h.nodeType||(l=s+i),h!==o||0!==r&&3!==h.nodeType||(c=s+r),3===h.nodeType&&(s+=h.nodeValue.length),null!==(m=h.firstChild);)p=h,h=m;for(;;){if(h===e)break t;if(p===n&&++u===i&&(l=s),p===o&&++d===r&&(c=s),null!==(m=h.nextSibling))break;p=(h=p).parentNode}h=m}n=-1===l||-1===c?null:{start:l,end:c}}else n=null}n=n||{start:0,end:0}}else n=null;for(nd={focusedElem:e,selectionRange:n},nh=!1,Sl=t;null!==Sl;)if(e=(t=Sl).child,0!==(1024&t.subtreeFlags)&&null!==e)e.return=t,Sl=e;else for(;null!==Sl;){switch(o=(t=Sl).alternate,e=t.flags,t.tag){case 0:case 11:case 15:case 5:case 26:case 27:case 6:case 4:case 17:break;case 1:if(0!==(1024&e)&&null!==o){e=void 0,n=t,i=o.memoizedProps,o=o.memoizedState,r=n.stateNode;try{var f=gs(n.type,i,(n.elementType,n.type));e=r.getSnapshotBeforeUpdate(f,o),r.__reactInternalSnapshotBeforeUpdate=e}catch(y){uu(n,n.return,y)}}break;case 3:if(0!==(1024&e))if(9===(n=(e=t.stateNode.containerInfo).nodeType))fd(e);else if(1===n)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":fd(e);break;default:e.textContent=""}break;default:if(0!==(1024&e))throw Error(a(163))}if(null!==(e=t.sibling)){e.return=t.return,Sl=e;break}Sl=t.return}}(e,t)}finally{nc=s,D.p=i,L.T=r}}$c=1,ru(),iu(),ou()}}function ru(){if(1===$c){$c=0;var e=Cc,t=Ec,n=0!==(13878&t.flags);if(0!==(13878&t.subtreeFlags)||n){n=L.T,L.T=null;var r=D.p;D.p=2;var i=nc;nc|=4;try{Ll(t,e);var o=nd,a=er(e.containerInfo),s=o.focusedElem,l=o.selectionRange;if(a!==s&&s&&s.ownerDocument&&Zn(s.ownerDocument.documentElement,s)){if(null!==l&&tr(s)){var c=l.start,u=l.end;if(void 0===u&&(u=c),"selectionStart"in s)s.selectionStart=c,s.selectionEnd=Math.min(u,s.value.length);else{var d=s.ownerDocument||document,h=d&&d.defaultView||window;if(h.getSelection){var p=h.getSelection(),m=s.textContent.length,f=Math.min(l.start,m),g=void 0===l.end?f:Math.min(l.end,m);!p.extend&&f>g&&(a=g,g=f,f=a);var y=Jn(s,f),x=Jn(s,g);if(y&&x&&(1!==p.rangeCount||p.anchorNode!==y.node||p.anchorOffset!==y.offset||p.focusNode!==x.node||p.focusOffset!==x.offset)){var v=d.createRange();v.setStart(y.node,y.offset),p.removeAllRanges(),f>g?(p.addRange(v),p.extend(x.node,x.offset)):(v.setEnd(x.node,x.offset),p.addRange(v))}}}}for(d=[],p=s;p=p.parentNode;)1===p.nodeType&&d.push({element:p,left:p.scrollLeft,top:p.scrollTop});for("function"===typeof s.focus&&s.focus(),s=0;s<d.length;s++){var b=d[s];b.element.scrollLeft=b.left,b.element.scrollTop=b.top}}nh=!!td,nd=td=null}finally{nc=i,D.p=r,L.T=n}}e.current=t,$c=2}}function iu(){if(2===$c){$c=0;var e=Cc,t=Ec,n=0!==(8772&t.flags);if(0!==(8772&t.subtreeFlags)||n){n=L.T,L.T=null;var r=D.p;D.p=2;var i=nc;nc|=4;try{jl(e,t.alternate,t)}finally{nc=i,D.p=r,L.T=n}}$c=3}}function ou(){if(4===$c||3===$c){$c=0,ee();var e=Cc,t=Ec,n=Tc,r=Ac;0!==(10256&t.subtreeFlags)||0!==(10256&t.flags)?$c=5:($c=0,Ec=Cc=null,au(e,e.pendingLanes));var i=e.pendingLanes;if(0===i&&(jc=null),Pe(n),t=t.stateNode,de&&"function"===typeof de.onCommitFiberRoot)try{de.onCommitFiberRoot(ue,t,void 0,128===(128&t.current.flags))}catch(l){}if(null!==r){t=L.T,i=D.p,D.p=2,L.T=null;try{for(var o=e.onRecoverableError,a=0;a<r.length;a++){var s=r[a];o(s.value,{componentStack:s.stack})}}finally{L.T=t,D.p=i}}0!==(3&Tc)&&su(),ku(e),i=e.pendingLanes,0!==(4194090&n)&&0!==(42&i)?e===Mc?Rc++:(Rc=0,Mc=e):Rc=0,Su(0,!1)}}function au(e,t){0===(e.pooledCacheLanes&=t)&&(null!=(t=e.pooledCache)&&(e.pooledCache=null,Li(t)))}function su(e){return ru(),iu(),ou(),lu()}function lu(){if(5!==$c)return!1;var e=Cc,t=Pc;Pc=0;var n=Pe(Tc),r=L.T,i=D.p;try{D.p=32>n?32:n,L.T=null,n=zc,zc=null;var o=Cc,s=Tc;if($c=0,Ec=Cc=null,Tc=0,0!==(6&nc))throw Error(a(331));var l=nc;if(nc|=4,Ql(o.current),Wl(o,o.current,s,n),nc=l,Su(0,!1),de&&"function"===typeof de.onPostCommitFiberRoot)try{de.onPostCommitFiberRoot(ue,o)}catch(c){}return!0}finally{D.p=i,L.T=r,au(e,t)}}function cu(e,t,n){t=jr(n,t),null!==(e=oo(e,t=Ss(e.stateNode,t,2),2))&&($e(e,2),ku(e))}function uu(e,t,n){if(3===e.tag)cu(e,e,n);else for(;null!==t;){if(3===t.tag){cu(t,e,n);break}if(1===t.tag){var r=t.stateNode;if("function"===typeof t.type.getDerivedStateFromError||"function"===typeof r.componentDidCatch&&(null===jc||!jc.has(r))){e=jr(n,e),null!==(r=oo(t,n=js(2),2))&&($s(n,r,t,e),$e(r,2),ku(r));break}}t=t.return}}function du(e,t,n){var r=e.pingCache;if(null===r){r=e.pingCache=new tc;var i=new Set;r.set(t,i)}else void 0===(i=r.get(t))&&(i=new Set,r.set(t,i));i.has(n)||(uc=!0,i.add(n),e=hu.bind(null,e,t,n),t.then(e,e))}function hu(e,t,n){var r=e.pingCache;null!==r&&r.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,rc===e&&(oc&n)===n&&(4===hc||3===hc&&(62914560&oc)===oc&&300>te()-wc?0===(2&nc)&&Wc(e,0):fc|=n,yc===oc&&(yc=0)),ku(e)}function pu(e,t){0===t&&(t=Se()),null!==(e=Ar(e,t))&&($e(e,t),ku(e))}function mu(e){var t=e.memoizedState,n=0;null!==t&&(n=t.retryLane),pu(e,n)}function fu(e,t){var n=0;switch(e.tag){case 13:var r=e.stateNode,i=e.memoizedState;null!==i&&(n=i.retryLane);break;case 19:r=e.stateNode;break;case 22:r=e.stateNode._retryCache;break;default:throw Error(a(314))}null!==r&&r.delete(t),pu(e,n)}var gu=null,yu=null,xu=!1,vu=!1,bu=!1,wu=0;function ku(e){e!==yu&&null===e.next&&(null===yu?gu=yu=e:yu=yu.next=e),vu=!0,xu||(xu=!0,dd(function(){0!==(6&nc)?Q(re,ju):$u()}))}function Su(e,t){if(!bu&&vu){bu=!0;do{for(var n=!1,r=gu;null!==r;){if(!t)if(0!==e){var i=r.pendingLanes;if(0===i)var o=0;else{var a=r.suspendedLanes,s=r.pingedLanes;o=(1<<31-pe(42|e)+1)-1,o=201326741&(o&=i&~(a&~s))?201326741&o|1:o?2|o:0}0!==o&&(n=!0,Tu(r,o))}else o=oc,0===(3&(o=ve(r,r===rc?o:0,null!==r.cancelPendingCommit||-1!==r.timeoutHandle)))||be(r,o)||(n=!0,Tu(r,o));r=r.next}}while(n);bu=!1}}function ju(){$u()}function $u(){vu=xu=!1;var e=0;0!==wu&&(function(){var e=window.event;if(e&&"popstate"===e.type)return e!==sd&&(sd=e,!0);return sd=null,!1}()&&(e=wu),wu=0);for(var t=te(),n=null,r=gu;null!==r;){var i=r.next,o=Cu(r,t);0===o?(r.next=null,null===n?gu=i:n.next=i,null===i&&(yu=n)):(n=r,(0!==e||0!==(3&o))&&(vu=!0)),r=i}Su(e,!1)}function Cu(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,i=e.expirationTimes,o=-62914561&e.pendingLanes;0<o;){var a=31-pe(o),s=1<<a,l=i[a];-1===l?0!==(s&n)&&0===(s&r)||(i[a]=we(s,t)):l<=t&&(e.expiredLanes|=s),o&=~s}if(n=oc,n=ve(e,e===(t=rc)?n:0,null!==e.cancelPendingCommit||-1!==e.timeoutHandle),r=e.callbackNode,0===n||e===t&&(2===ac||9===ac)||null!==e.cancelPendingCommit)return null!==r&&null!==r&&J(r),e.callbackNode=null,e.callbackPriority=0;if(0===(3&n)||be(e,n)){if((t=n&-n)===e.callbackPriority)return t;switch(null!==r&&J(r),Pe(n)){case 2:case 8:n=ie;break;case 32:default:n=oe;break;case 268435456:n=se}return r=Eu.bind(null,e),n=Q(n,r),e.callbackPriority=t,e.callbackNode=n,t}return null!==r&&null!==r&&J(r),e.callbackPriority=2,e.callbackNode=null,2}function Eu(e,t){if(0!==$c&&5!==$c)return e.callbackNode=null,e.callbackPriority=0,null;var n=e.callbackNode;if(su()&&e.callbackNode!==n)return null;var r=oc;return 0===(r=ve(e,e===rc?r:0,null!==e.cancelPendingCommit||-1!==e.timeoutHandle))?null:(Fc(e,r,t),Cu(e,te()),null!=e.callbackNode&&e.callbackNode===n?Eu.bind(null,e):null)}function Tu(e,t){if(su())return null;Fc(e,t,!0)}function Pu(){return 0===wu&&(wu=ke()),wu}function zu(e){return null==e||"symbol"===typeof e||"boolean"===typeof e?null:"function"===typeof e?e:Pt(""+e)}function Au(e,t){var n=t.ownerDocument.createElement("input");return n.name=t.name,n.value=t.value,e.id&&n.setAttribute("form",e.id),t.parentNode.insertBefore(n,t),e=new FormData(e),n.parentNode.removeChild(n),e}for(var Ru=0;Ru<wr.length;Ru++){var Mu=wr[Ru];kr(Mu.toLowerCase(),"on"+(Mu[0].toUpperCase()+Mu.slice(1)))}kr(pr,"onAnimationEnd"),kr(mr,"onAnimationIteration"),kr(fr,"onAnimationStart"),kr("dblclick","onDoubleClick"),kr("focusin","onFocus"),kr("focusout","onBlur"),kr(gr,"onTransitionRun"),kr(yr,"onTransitionStart"),kr(xr,"onTransitionCancel"),kr(vr,"onTransitionEnd"),Ge("onMouseEnter",["mouseout","mouseover"]),Ge("onMouseLeave",["mouseout","mouseover"]),Ge("onPointerEnter",["pointerout","pointerover"]),Ge("onPointerLeave",["pointerout","pointerover"]),Ke("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),Ke("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),Ke("onBeforeInput",["compositionend","keypress","textInput","paste"]),Ke("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),Ke("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),Ke("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Lu="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Du=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Lu));function Ou(e,t){t=0!==(4&t);for(var n=0;n<e.length;n++){var r=e[n],i=r.event;r=r.listeners;e:{var o=void 0;if(t)for(var a=r.length-1;0<=a;a--){var s=r[a],l=s.instance,c=s.currentTarget;if(s=s.listener,l!==o&&i.isPropagationStopped())break e;o=s,i.currentTarget=c;try{o(i)}catch(u){ys(u)}i.currentTarget=null,o=l}else for(a=0;a<r.length;a++){if(l=(s=r[a]).instance,c=s.currentTarget,s=s.listener,l!==o&&i.isPropagationStopped())break e;o=s,i.currentTarget=c;try{o(i)}catch(u){ys(u)}i.currentTarget=null,o=l}}}}function Fu(e,t){var n=t[De];void 0===n&&(n=t[De]=new Set);var r=e+"__bubble";n.has(r)||(Vu(t,e,2,!1),n.add(r))}function Nu(e,t,n){var r=0;t&&(r|=4),Vu(n,e,r,t)}var _u="_reactListening"+Math.random().toString(36).slice(2);function Iu(e){if(!e[_u]){e[_u]=!0,qe.forEach(function(t){"selectionchange"!==t&&(Du.has(t)||Nu(t,!1,e),Nu(t,!0,e))});var t=9===e.nodeType?e:e.ownerDocument;null===t||t[_u]||(t[_u]=!0,Nu("selectionchange",!1,t))}}function Vu(e,t,n,r){switch(ch(t)){case 2:var i=rh;break;case 8:i=ih;break;default:i=oh}n=i.bind(null,t,n,e),i=void 0,!_t||"touchstart"!==t&&"touchmove"!==t&&"wheel"!==t||(i=!0),r?void 0!==i?e.addEventListener(t,n,{capture:!0,passive:i}):e.addEventListener(t,n,!0):void 0!==i?e.addEventListener(t,n,{passive:i}):e.addEventListener(t,n,!1)}function Bu(e,t,n,r,i){var o=r;if(0===(1&t)&&0===(2&t)&&null!==r)e:for(;;){if(null===r)return;var a=r.tag;if(3===a||4===a){var s=r.stateNode.containerInfo;if(s===i)break;if(4===a)for(a=r.return;null!==a;){var c=a.tag;if((3===c||4===c)&&a.stateNode.containerInfo===i)return;a=a.return}for(;null!==s;){if(null===(a=Ve(s)))return;if(5===(c=a.tag)||6===c||26===c||27===c){r=o=a;continue e}s=s.parentNode}}r=r.return}Ot(function(){var r=o,i=At(n),a=[];e:{var s=br.get(e);if(void 0!==s){var c=Zt,u=e;switch(e){case"keypress":if(0===Ut(n))break e;case"keydown":case"keyup":c=fn;break;case"focusin":u="focus",c=an;break;case"focusout":u="blur",c=an;break;case"beforeblur":case"afterblur":c=an;break;case"click":if(2===n.button)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":c=rn;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":c=on;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":c=yn;break;case pr:case mr:case fr:c=sn;break;case vr:c=xn;break;case"scroll":case"scrollend":c=tn;break;case"wheel":c=vn;break;case"copy":case"cut":case"paste":c=ln;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":c=gn;break;case"toggle":case"beforetoggle":c=bn}var d=0!==(4&t),h=!d&&("scroll"===e||"scrollend"===e),p=d?null!==s?s+"Capture":null:s;d=[];for(var m,f=r;null!==f;){var g=f;if(m=g.stateNode,5!==(g=g.tag)&&26!==g&&27!==g||null===m||null===p||null!=(g=Ft(f,p))&&d.push(Wu(f,g,m)),h)break;f=f.return}0<d.length&&(s=new c(s,u,null,n,i),a.push({event:s,listeners:d}))}}if(0===(7&t)){if(c="mouseout"===e||"pointerout"===e,(!(s="mouseover"===e||"pointerover"===e)||n===zt||!(u=n.relatedTarget||n.fromElement)||!Ve(u)&&!u[Le])&&(c||s)&&(s=i.window===i?i:(s=i.ownerDocument)?s.defaultView||s.parentWindow:window,c?(c=r,null!==(u=(u=n.relatedTarget||n.toElement)?Ve(u):null)&&(h=l(u),d=u.tag,u!==h||5!==d&&27!==d&&6!==d)&&(u=null)):(c=null,u=r),c!==u)){if(d=rn,g="onMouseLeave",p="onMouseEnter",f="mouse","pointerout"!==e&&"pointerover"!==e||(d=gn,g="onPointerLeave",p="onPointerEnter",f="pointer"),h=null==c?s:We(c),m=null==u?s:We(u),(s=new d(g,f+"leave",c,n,i)).target=h,s.relatedTarget=m,g=null,Ve(i)===r&&((d=new d(p,f+"enter",u,n,i)).target=m,d.relatedTarget=h,g=d),h=g,c&&u)e:{for(p=u,f=0,m=d=c;m;m=Uu(m))f++;for(m=0,g=p;g;g=Uu(g))m++;for(;0<f-m;)d=Uu(d),f--;for(;0<m-f;)p=Uu(p),m--;for(;f--;){if(d===p||null!==p&&d===p.alternate)break e;d=Uu(d),p=Uu(p)}d=null}else d=null;null!==c&&qu(a,s,c,d,!1),null!==u&&null!==h&&qu(a,h,u,d,!0)}if("select"===(c=(s=r?We(r):window).nodeName&&s.nodeName.toLowerCase())||"input"===c&&"file"===s.type)var y=Nn;else if(Rn(s))if(_n)y=Kn;else{y=qn;var x=Un}else!(c=s.nodeName)||"input"!==c.toLowerCase()||"checkbox"!==s.type&&"radio"!==s.type?r&&Ct(r.elementType)&&(y=Nn):y=Yn;switch(y&&(y=y(e,r))?Mn(a,y,n,i):(x&&x(e,s,r),"focusout"===e&&r&&"number"===s.type&&null!=r.memoizedProps.value&&xt(s,"number",s.value)),x=r?We(r):window,e){case"focusin":(Rn(x)||"true"===x.contentEditable)&&(rr=x,ir=r,or=null);break;case"focusout":or=ir=rr=null;break;case"mousedown":ar=!0;break;case"contextmenu":case"mouseup":case"dragend":ar=!1,sr(a,n,i);break;case"selectionchange":if(nr)break;case"keydown":case"keyup":sr(a,n,i)}var v;if(kn)e:{switch(e){case"compositionstart":var b="onCompositionStart";break e;case"compositionend":b="onCompositionEnd";break e;case"compositionupdate":b="onCompositionUpdate";break e}b=void 0}else zn?Tn(e,n)&&(b="onCompositionEnd"):"keydown"===e&&229===n.keyCode&&(b="onCompositionStart");b&&($n&&"ko"!==n.locale&&(zn||"onCompositionStart"!==b?"onCompositionEnd"===b&&zn&&(v=Ht()):(Bt="value"in(Vt=i)?Vt.value:Vt.textContent,zn=!0)),0<(x=Hu(r,b)).length&&(b=new cn(b,e,null,n,i),a.push({event:b,listeners:x}),v?b.data=v:null!==(v=Pn(n))&&(b.data=v))),(v=jn?function(e,t){switch(e){case"compositionend":return Pn(t);case"keypress":return 32!==t.which?null:(En=!0,Cn);case"textInput":return(e=t.data)===Cn&&En?null:e;default:return null}}(e,n):function(e,t){if(zn)return"compositionend"===e||!kn&&Tn(e,t)?(e=Ht(),Wt=Bt=Vt=null,zn=!1,e):null;switch(e){case"paste":default:return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return $n&&"ko"!==t.locale?null:t.data}}(e,n))&&(0<(b=Hu(r,"onBeforeInput")).length&&(x=new cn("onBeforeInput","beforeinput",null,n,i),a.push({event:x,listeners:b}),x.data=v)),function(e,t,n,r,i){if("submit"===t&&n&&n.stateNode===i){var o=zu((i[Me]||null).action),a=r.submitter;a&&null!==(t=(t=a[Me]||null)?zu(t.formAction):a.getAttribute("formAction"))&&(o=t,a=null);var s=new Zt("action","action",null,r,i);e.push({event:s,listeners:[{instance:null,listener:function(){if(r.defaultPrevented){if(0!==wu){var e=a?Au(i,a):new FormData(i);Aa(n,{pending:!0,data:e,method:i.method,action:o},null,e)}}else"function"===typeof o&&(s.preventDefault(),e=a?Au(i,a):new FormData(i),Aa(n,{pending:!0,data:e,method:i.method,action:o},o,e))},currentTarget:i}]})}}(a,e,r,n,i)}Ou(a,t)})}function Wu(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Hu(e,t){for(var n=t+"Capture",r=[];null!==e;){var i=e,o=i.stateNode;if(5!==(i=i.tag)&&26!==i&&27!==i||null===o||(null!=(i=Ft(e,n))&&r.unshift(Wu(e,i,o)),null!=(i=Ft(e,t))&&r.push(Wu(e,i,o))),3===e.tag)return r;e=e.return}return[]}function Uu(e){if(null===e)return null;do{e=e.return}while(e&&5!==e.tag&&27!==e.tag);return e||null}function qu(e,t,n,r,i){for(var o=t._reactName,a=[];null!==n&&n!==r;){var s=n,l=s.alternate,c=s.stateNode;if(s=s.tag,null!==l&&l===r)break;5!==s&&26!==s&&27!==s||null===c||(l=c,i?null!=(c=Ft(n,o))&&a.unshift(Wu(n,c,l)):i||null!=(c=Ft(n,o))&&a.push(Wu(n,c,l))),n=n.return}0!==a.length&&e.push({event:t,listeners:a})}var Yu=/\r\n?/g,Ku=/\u0000|\uFFFD/g;function Gu(e){return("string"===typeof e?e:""+e).replace(Yu,"\n").replace(Ku,"")}function Xu(e,t){return t=Gu(t),Gu(e)===t}function Qu(){}function Ju(e,t,n,r,i,o){switch(n){case"children":"string"===typeof r?"body"===t||"textarea"===t&&""===r||kt(e,r):("number"===typeof r||"bigint"===typeof r)&&"body"!==t&&kt(e,""+r);break;case"className":nt(e,"class",r);break;case"tabIndex":nt(e,"tabindex",r);break;case"dir":case"role":case"viewBox":case"width":case"height":nt(e,n,r);break;case"style":$t(e,r,o);break;case"data":if("object"!==t){nt(e,"data",r);break}case"src":case"href":if(""===r&&("a"!==t||"href"!==n)){e.removeAttribute(n);break}if(null==r||"function"===typeof r||"symbol"===typeof r||"boolean"===typeof r){e.removeAttribute(n);break}r=Pt(""+r),e.setAttribute(n,r);break;case"action":case"formAction":if("function"===typeof r){e.setAttribute(n,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}if("function"===typeof o&&("formAction"===n?("input"!==t&&Ju(e,t,"name",i.name,i,null),Ju(e,t,"formEncType",i.formEncType,i,null),Ju(e,t,"formMethod",i.formMethod,i,null),Ju(e,t,"formTarget",i.formTarget,i,null)):(Ju(e,t,"encType",i.encType,i,null),Ju(e,t,"method",i.method,i,null),Ju(e,t,"target",i.target,i,null))),null==r||"symbol"===typeof r||"boolean"===typeof r){e.removeAttribute(n);break}r=Pt(""+r),e.setAttribute(n,r);break;case"onClick":null!=r&&(e.onclick=Qu);break;case"onScroll":null!=r&&Fu("scroll",e);break;case"onScrollEnd":null!=r&&Fu("scrollend",e);break;case"dangerouslySetInnerHTML":if(null!=r){if("object"!==typeof r||!("__html"in r))throw Error(a(61));if(null!=(n=r.__html)){if(null!=i.children)throw Error(a(60));e.innerHTML=n}}break;case"multiple":e.multiple=r&&"function"!==typeof r&&"symbol"!==typeof r;break;case"muted":e.muted=r&&"function"!==typeof r&&"symbol"!==typeof r;break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":case"autoFocus":break;case"xlinkHref":if(null==r||"function"===typeof r||"boolean"===typeof r||"symbol"===typeof r){e.removeAttribute("xlink:href");break}n=Pt(""+r),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",n);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":null!=r&&"function"!==typeof r&&"symbol"!==typeof r?e.setAttribute(n,""+r):e.removeAttribute(n);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":r&&"function"!==typeof r&&"symbol"!==typeof r?e.setAttribute(n,""):e.removeAttribute(n);break;case"capture":case"download":!0===r?e.setAttribute(n,""):!1!==r&&null!=r&&"function"!==typeof r&&"symbol"!==typeof r?e.setAttribute(n,r):e.removeAttribute(n);break;case"cols":case"rows":case"size":case"span":null!=r&&"function"!==typeof r&&"symbol"!==typeof r&&!isNaN(r)&&1<=r?e.setAttribute(n,r):e.removeAttribute(n);break;case"rowSpan":case"start":null==r||"function"===typeof r||"symbol"===typeof r||isNaN(r)?e.removeAttribute(n):e.setAttribute(n,r);break;case"popover":Fu("beforetoggle",e),Fu("toggle",e),tt(e,"popover",r);break;case"xlinkActuate":rt(e,"http://www.w3.org/1999/xlink","xlink:actuate",r);break;case"xlinkArcrole":rt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",r);break;case"xlinkRole":rt(e,"http://www.w3.org/1999/xlink","xlink:role",r);break;case"xlinkShow":rt(e,"http://www.w3.org/1999/xlink","xlink:show",r);break;case"xlinkTitle":rt(e,"http://www.w3.org/1999/xlink","xlink:title",r);break;case"xlinkType":rt(e,"http://www.w3.org/1999/xlink","xlink:type",r);break;case"xmlBase":rt(e,"http://www.w3.org/XML/1998/namespace","xml:base",r);break;case"xmlLang":rt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",r);break;case"xmlSpace":rt(e,"http://www.w3.org/XML/1998/namespace","xml:space",r);break;case"is":tt(e,"is",r);break;case"innerText":case"textContent":break;default:(!(2<n.length)||"o"!==n[0]&&"O"!==n[0]||"n"!==n[1]&&"N"!==n[1])&&tt(e,n=Et.get(n)||n,r)}}function Zu(e,t,n,r,i,o){switch(n){case"style":$t(e,r,o);break;case"dangerouslySetInnerHTML":if(null!=r){if("object"!==typeof r||!("__html"in r))throw Error(a(61));if(null!=(n=r.__html)){if(null!=i.children)throw Error(a(60));e.innerHTML=n}}break;case"children":"string"===typeof r?kt(e,r):("number"===typeof r||"bigint"===typeof r)&&kt(e,""+r);break;case"onScroll":null!=r&&Fu("scroll",e);break;case"onScrollEnd":null!=r&&Fu("scrollend",e);break;case"onClick":null!=r&&(e.onclick=Qu);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":case"innerText":case"textContent":break;default:Ye.hasOwnProperty(n)||("o"!==n[0]||"n"!==n[1]||(i=n.endsWith("Capture"),t=n.slice(2,i?n.length-7:void 0),"function"===typeof(o=null!=(o=e[Me]||null)?o[n]:null)&&e.removeEventListener(t,o,i),"function"!==typeof r)?n in e?e[n]=r:!0===r?e.setAttribute(n,""):tt(e,n,r):("function"!==typeof o&&null!==o&&(n in e?e[n]=null:e.hasAttribute(n)&&e.removeAttribute(n)),e.addEventListener(t,r,i)))}}function ed(e,t,n){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Fu("error",e),Fu("load",e);var r,i=!1,o=!1;for(r in n)if(n.hasOwnProperty(r)){var s=n[r];if(null!=s)switch(r){case"src":i=!0;break;case"srcSet":o=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(a(137,t));default:Ju(e,t,r,s,n,null)}}return o&&Ju(e,t,"srcSet",n.srcSet,n,null),void(i&&Ju(e,t,"src",n.src,n,null));case"input":Fu("invalid",e);var l=r=s=o=null,c=null,u=null;for(i in n)if(n.hasOwnProperty(i)){var d=n[i];if(null!=d)switch(i){case"name":o=d;break;case"type":s=d;break;case"checked":c=d;break;case"defaultChecked":u=d;break;case"value":r=d;break;case"defaultValue":l=d;break;case"children":case"dangerouslySetInnerHTML":if(null!=d)throw Error(a(137,t));break;default:Ju(e,t,i,d,n,null)}}return yt(e,r,l,c,u,s,o,!1),void dt(e);case"select":for(o in Fu("invalid",e),i=s=r=null,n)if(n.hasOwnProperty(o)&&null!=(l=n[o]))switch(o){case"value":r=l;break;case"defaultValue":s=l;break;case"multiple":i=l;default:Ju(e,t,o,l,n,null)}return t=r,n=s,e.multiple=!!i,void(null!=t?vt(e,!!i,t,!1):null!=n&&vt(e,!!i,n,!0));case"textarea":for(s in Fu("invalid",e),r=o=i=null,n)if(n.hasOwnProperty(s)&&null!=(l=n[s]))switch(s){case"value":i=l;break;case"defaultValue":o=l;break;case"children":r=l;break;case"dangerouslySetInnerHTML":if(null!=l)throw Error(a(91));break;default:Ju(e,t,s,l,n,null)}return wt(e,i,o,r),void dt(e);case"option":for(c in n)if(n.hasOwnProperty(c)&&null!=(i=n[c]))if("selected"===c)e.selected=i&&"function"!==typeof i&&"symbol"!==typeof i;else Ju(e,t,c,i,n,null);return;case"dialog":Fu("beforetoggle",e),Fu("toggle",e),Fu("cancel",e),Fu("close",e);break;case"iframe":case"object":Fu("load",e);break;case"video":case"audio":for(i=0;i<Lu.length;i++)Fu(Lu[i],e);break;case"image":Fu("error",e),Fu("load",e);break;case"details":Fu("toggle",e);break;case"embed":case"source":case"link":Fu("error",e),Fu("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(u in n)if(n.hasOwnProperty(u)&&null!=(i=n[u]))switch(u){case"children":case"dangerouslySetInnerHTML":throw Error(a(137,t));default:Ju(e,t,u,i,n,null)}return;default:if(Ct(t)){for(d in n)n.hasOwnProperty(d)&&(void 0!==(i=n[d])&&Zu(e,t,d,i,n,void 0));return}}for(l in n)n.hasOwnProperty(l)&&(null!=(i=n[l])&&Ju(e,t,l,i,n,null))}var td=null,nd=null;function rd(e){return 9===e.nodeType?e:e.ownerDocument}function id(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function od(e,t){if(0===e)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return 1===e&&"foreignObject"===t?0:e}function ad(e,t){return"textarea"===e||"noscript"===e||"string"===typeof t.children||"number"===typeof t.children||"bigint"===typeof t.children||"object"===typeof t.dangerouslySetInnerHTML&&null!==t.dangerouslySetInnerHTML&&null!=t.dangerouslySetInnerHTML.__html}var sd=null;var ld="function"===typeof setTimeout?setTimeout:void 0,cd="function"===typeof clearTimeout?clearTimeout:void 0,ud="function"===typeof Promise?Promise:void 0,dd="function"===typeof queueMicrotask?queueMicrotask:"undefined"!==typeof ud?function(e){return ud.resolve(null).then(e).catch(hd)}:ld;function hd(e){setTimeout(function(){throw e})}function pd(e){return"head"===e}function md(e,t){var n=t,r=0,i=0;do{var o=n.nextSibling;if(e.removeChild(n),o&&8===o.nodeType)if("/$"===(n=o.data)){if(0<r&&8>r){n=r;var a=e.ownerDocument;if(1&n&&wd(a.documentElement),2&n&&wd(a.body),4&n)for(wd(n=a.head),a=n.firstChild;a;){var s=a.nextSibling,l=a.nodeName;a[_e]||"SCRIPT"===l||"STYLE"===l||"LINK"===l&&"stylesheet"===a.rel.toLowerCase()||n.removeChild(a),a=s}}if(0===i)return e.removeChild(o),void Eh(t);i--}else"$"===n||"$?"===n||"$!"===n?i++:r=n.charCodeAt(0)-48;else r=0;n=o}while(n);Eh(t)}function fd(e){var t=e.firstChild;for(t&&10===t.nodeType&&(t=t.nextSibling);t;){var n=t;switch(t=t.nextSibling,n.nodeName){case"HTML":case"HEAD":case"BODY":fd(n),Ie(n);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if("stylesheet"===n.rel.toLowerCase())continue}e.removeChild(n)}}function gd(e){return"$!"===e.data||"$?"===e.data&&"complete"===e.ownerDocument.readyState}function yd(e){for(;null!=e;e=e.nextSibling){var t=e.nodeType;if(1===t||3===t)break;if(8===t){if("$"===(t=e.data)||"$!"===t||"$?"===t||"F!"===t||"F"===t)break;if("/$"===t)return null}}return e}var xd=null;function vd(e){e=e.previousSibling;for(var t=0;e;){if(8===e.nodeType){var n=e.data;if("$"===n||"$!"===n||"$?"===n){if(0===t)return e;t--}else"/$"===n&&t++}e=e.previousSibling}return null}function bd(e,t,n){switch(t=rd(n),e){case"html":if(!(e=t.documentElement))throw Error(a(452));return e;case"head":if(!(e=t.head))throw Error(a(453));return e;case"body":if(!(e=t.body))throw Error(a(454));return e;default:throw Error(a(451))}}function wd(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);Ie(e)}var kd=new Map,Sd=new Set;function jd(e){return"function"===typeof e.getRootNode?e.getRootNode():9===e.nodeType?e:e.ownerDocument}var $d=D.d;D.d={f:function(){var e=$d.f(),t=Vc();return e||t},r:function(e){var t=Be(e);null!==t&&5===t.tag&&"form"===t.type?Ma(t):$d.r(e)},D:function(e){$d.D(e),Ed("dns-prefetch",e,null)},C:function(e,t){$d.C(e,t),Ed("preconnect",e,t)},L:function(e,t,n){$d.L(e,t,n);var r=Cd;if(r&&e&&t){var i='link[rel="preload"][as="'+ft(t)+'"]';"image"===t&&n&&n.imageSrcSet?(i+='[imagesrcset="'+ft(n.imageSrcSet)+'"]',"string"===typeof n.imageSizes&&(i+='[imagesizes="'+ft(n.imageSizes)+'"]')):i+='[href="'+ft(e)+'"]';var o=i;switch(t){case"style":o=Pd(e);break;case"script":o=Rd(e)}kd.has(o)||(e=h({rel:"preload",href:"image"===t&&n&&n.imageSrcSet?void 0:e,as:t},n),kd.set(o,e),null!==r.querySelector(i)||"style"===t&&r.querySelector(zd(o))||"script"===t&&r.querySelector(Md(o))||(ed(t=r.createElement("link"),"link",e),Ue(t),r.head.appendChild(t)))}},m:function(e,t){$d.m(e,t);var n=Cd;if(n&&e){var r=t&&"string"===typeof t.as?t.as:"script",i='link[rel="modulepreload"][as="'+ft(r)+'"][href="'+ft(e)+'"]',o=i;switch(r){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":o=Rd(e)}if(!kd.has(o)&&(e=h({rel:"modulepreload",href:e},t),kd.set(o,e),null===n.querySelector(i))){switch(r){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(n.querySelector(Md(o)))return}ed(r=n.createElement("link"),"link",e),Ue(r),n.head.appendChild(r)}}},X:function(e,t){$d.X(e,t);var n=Cd;if(n&&e){var r=He(n).hoistableScripts,i=Rd(e),o=r.get(i);o||((o=n.querySelector(Md(i)))||(e=h({src:e,async:!0},t),(t=kd.get(i))&&Fd(e,t),Ue(o=n.createElement("script")),ed(o,"link",e),n.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},r.set(i,o))}},S:function(e,t,n){$d.S(e,t,n);var r=Cd;if(r&&e){var i=He(r).hoistableStyles,o=Pd(e);t=t||"default";var a=i.get(o);if(!a){var s={loading:0,preload:null};if(a=r.querySelector(zd(o)))s.loading=5;else{e=h({rel:"stylesheet",href:e,"data-precedence":t},n),(n=kd.get(o))&&Od(e,n);var l=a=r.createElement("link");Ue(l),ed(l,"link",e),l._p=new Promise(function(e,t){l.onload=e,l.onerror=t}),l.addEventListener("load",function(){s.loading|=1}),l.addEventListener("error",function(){s.loading|=2}),s.loading|=4,Dd(a,t,r)}a={type:"stylesheet",instance:a,count:1,state:s},i.set(o,a)}}},M:function(e,t){$d.M(e,t);var n=Cd;if(n&&e){var r=He(n).hoistableScripts,i=Rd(e),o=r.get(i);o||((o=n.querySelector(Md(i)))||(e=h({src:e,async:!0,type:"module"},t),(t=kd.get(i))&&Fd(e,t),Ue(o=n.createElement("script")),ed(o,"link",e),n.head.appendChild(o)),o={type:"script",instance:o,count:1,state:null},r.set(i,o))}}};var Cd="undefined"===typeof document?null:document;function Ed(e,t,n){var r=Cd;if(r&&"string"===typeof t&&t){var i=ft(t);i='link[rel="'+e+'"][href="'+i+'"]',"string"===typeof n&&(i+='[crossorigin="'+n+'"]'),Sd.has(i)||(Sd.add(i),e={rel:e,crossOrigin:n,href:t},null===r.querySelector(i)&&(ed(t=r.createElement("link"),"link",e),Ue(t),r.head.appendChild(t)))}}function Td(e,t,n,r){var i,o,s,l,c=(c=H.current)?jd(c):null;if(!c)throw Error(a(446));switch(e){case"meta":case"title":return null;case"style":return"string"===typeof n.precedence&&"string"===typeof n.href?(t=Pd(n.href),(r=(n=He(c).hoistableStyles).get(t))||(r={type:"style",instance:null,count:0,state:null},n.set(t,r)),r):{type:"void",instance:null,count:0,state:null};case"link":if("stylesheet"===n.rel&&"string"===typeof n.href&&"string"===typeof n.precedence){e=Pd(n.href);var u=He(c).hoistableStyles,d=u.get(e);if(d||(c=c.ownerDocument||c,d={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},u.set(e,d),(u=c.querySelector(zd(e)))&&!u._p&&(d.instance=u,d.state.loading=5),kd.has(e)||(n={rel:"preload",as:"style",href:n.href,crossOrigin:n.crossOrigin,integrity:n.integrity,media:n.media,hrefLang:n.hrefLang,referrerPolicy:n.referrerPolicy},kd.set(e,n),u||(i=c,o=e,s=n,l=d.state,i.querySelector('link[rel="preload"][as="style"]['+o+"]")?l.loading=1:(o=i.createElement("link"),l.preload=o,o.addEventListener("load",function(){return l.loading|=1}),o.addEventListener("error",function(){return l.loading|=2}),ed(o,"link",s),Ue(o),i.head.appendChild(o))))),t&&null===r)throw Error(a(528,""));return d}if(t&&null!==r)throw Error(a(529,""));return null;case"script":return t=n.async,"string"===typeof(n=n.src)&&t&&"function"!==typeof t&&"symbol"!==typeof t?(t=Rd(n),(r=(n=He(c).hoistableScripts).get(t))||(r={type:"script",instance:null,count:0,state:null},n.set(t,r)),r):{type:"void",instance:null,count:0,state:null};default:throw Error(a(444,e))}}function Pd(e){return'href="'+ft(e)+'"'}function zd(e){return'link[rel="stylesheet"]['+e+"]"}function Ad(e){return h({},e,{"data-precedence":e.precedence,precedence:null})}function Rd(e){return'[src="'+ft(e)+'"]'}function Md(e){return"script[async]"+e}function Ld(e,t,n){if(t.count++,null===t.instance)switch(t.type){case"style":var r=e.querySelector('style[data-href~="'+ft(n.href)+'"]');if(r)return t.instance=r,Ue(r),r;var i=h({},n,{"data-href":n.href,"data-precedence":n.precedence,href:null,precedence:null});return Ue(r=(e.ownerDocument||e).createElement("style")),ed(r,"style",i),Dd(r,n.precedence,e),t.instance=r;case"stylesheet":i=Pd(n.href);var o=e.querySelector(zd(i));if(o)return t.state.loading|=4,t.instance=o,Ue(o),o;r=Ad(n),(i=kd.get(i))&&Od(r,i),Ue(o=(e.ownerDocument||e).createElement("link"));var s=o;return s._p=new Promise(function(e,t){s.onload=e,s.onerror=t}),ed(o,"link",r),t.state.loading|=4,Dd(o,n.precedence,e),t.instance=o;case"script":return o=Rd(n.src),(i=e.querySelector(Md(o)))?(t.instance=i,Ue(i),i):(r=n,(i=kd.get(o))&&Fd(r=h({},n),i),Ue(i=(e=e.ownerDocument||e).createElement("script")),ed(i,"link",r),e.head.appendChild(i),t.instance=i);case"void":return null;default:throw Error(a(443,t.type))}else"stylesheet"===t.type&&0===(4&t.state.loading)&&(r=t.instance,t.state.loading|=4,Dd(r,n.precedence,e));return t.instance}function Dd(e,t,n){for(var r=n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),i=r.length?r[r.length-1]:null,o=i,a=0;a<r.length;a++){var s=r[a];if(s.dataset.precedence===t)o=s;else if(o!==i)break}o?o.parentNode.insertBefore(e,o.nextSibling):(t=9===n.nodeType?n.head:n).insertBefore(e,t.firstChild)}function Od(e,t){null==e.crossOrigin&&(e.crossOrigin=t.crossOrigin),null==e.referrerPolicy&&(e.referrerPolicy=t.referrerPolicy),null==e.title&&(e.title=t.title)}function Fd(e,t){null==e.crossOrigin&&(e.crossOrigin=t.crossOrigin),null==e.referrerPolicy&&(e.referrerPolicy=t.referrerPolicy),null==e.integrity&&(e.integrity=t.integrity)}var Nd=null;function _d(e,t,n){if(null===Nd){var r=new Map,i=Nd=new Map;i.set(n,r)}else(r=(i=Nd).get(n))||(r=new Map,i.set(n,r));if(r.has(e))return r;for(r.set(e,null),n=n.getElementsByTagName(e),i=0;i<n.length;i++){var o=n[i];if(!(o[_e]||o[Re]||"link"===e&&"stylesheet"===o.getAttribute("rel"))&&"http://www.w3.org/2000/svg"!==o.namespaceURI){var a=o.getAttribute(t)||"";a=e+a;var s=r.get(a);s?s.push(o):r.set(a,[o])}}return r}function Id(e,t,n){(e=e.ownerDocument||e).head.insertBefore(n,"title"===t?e.querySelector("head > title"):null)}function Vd(e){return"stylesheet"!==e.type||0!==(3&e.state.loading)}var Bd=null;function Wd(){}function Hd(){if(this.count--,0===this.count)if(this.stylesheets)qd(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}var Ud=null;function qd(e,t){e.stylesheets=null,null!==e.unsuspend&&(e.count++,Ud=new Map,t.forEach(Yd,e),Ud=null,Hd.call(e))}function Yd(e,t){if(!(4&t.state.loading)){var n=Ud.get(e);if(n)var r=n.get(null);else{n=new Map,Ud.set(e,n);for(var i=e.querySelectorAll("link[data-precedence],style[data-precedence]"),o=0;o<i.length;o++){var a=i[o];"LINK"!==a.nodeName&&"not all"===a.getAttribute("media")||(n.set(a.dataset.precedence,a),r=a)}r&&n.set(null,r)}a=(i=t.instance).getAttribute("data-precedence"),(o=n.get(a)||r)===r&&n.set(null,i),n.set(a,i),this.count++,r=Hd.bind(this),i.addEventListener("load",r),i.addEventListener("error",r),o?o.parentNode.insertBefore(i,o.nextSibling):(e=9===e.nodeType?e.head:e).insertBefore(i,e.firstChild),t.state.loading|=4}}var Kd={$$typeof:w,Provider:null,Consumer:null,_currentValue:O,_currentValue2:O,_threadCount:0};function Gd(e,t,n,r,i,o,a,s){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=je(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=je(0),this.hiddenUpdates=je(null),this.identifierPrefix=r,this.onUncaughtError=i,this.onCaughtError=o,this.onRecoverableError=a,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=s,this.incompleteTransitions=new Map}function Xd(e,t,n,r,i,o,a,s,l,c,u,d){return e=new Gd(e,t,n,a,s,l,c,d),t=1,!0===o&&(t|=24),o=Or(3,null,null,t),e.current=o,o.stateNode=e,(t=Mi()).refCount++,e.pooledCache=t,t.refCount++,o.memoizedState={element:r,isDehydrated:n,cache:t},no(o),e}function Qd(e){return e?e=Lr:Lr}function Jd(e,t,n,r,i,o){i=Qd(i),null===r.context?r.context=i:r.pendingContext=i,(r=io(t)).payload={element:n},null!==(o=void 0===o?null:o)&&(r.callback=o),null!==(n=oo(e,r,t))&&(Oc(n,0,t),ao(n,e,t))}function Zd(e,t){if(null!==(e=e.memoizedState)&&null!==e.dehydrated){var n=e.retryLane;e.retryLane=0!==n&&n<t?n:t}}function eh(e,t){Zd(e,t),(e=e.alternate)&&Zd(e,t)}function th(e){if(13===e.tag){var t=Ar(e,67108864);null!==t&&Oc(t,0,67108864),eh(e,67108864)}}var nh=!0;function rh(e,t,n,r){var i=L.T;L.T=null;var o=D.p;try{D.p=2,oh(e,t,n,r)}finally{D.p=o,L.T=i}}function ih(e,t,n,r){var i=L.T;L.T=null;var o=D.p;try{D.p=8,oh(e,t,n,r)}finally{D.p=o,L.T=i}}function oh(e,t,n,r){if(nh){var i=ah(r);if(null===i)Bu(e,t,r,sh,n),xh(e,r);else if(function(e,t,n,r,i){switch(t){case"focusin":return dh=vh(dh,e,t,n,r,i),!0;case"dragenter":return hh=vh(hh,e,t,n,r,i),!0;case"mouseover":return ph=vh(ph,e,t,n,r,i),!0;case"pointerover":var o=i.pointerId;return mh.set(o,vh(mh.get(o)||null,e,t,n,r,i)),!0;case"gotpointercapture":return o=i.pointerId,fh.set(o,vh(fh.get(o)||null,e,t,n,r,i)),!0}return!1}(i,e,t,n,r))r.stopPropagation();else if(xh(e,r),4&t&&-1<yh.indexOf(e)){for(;null!==i;){var o=Be(i);if(null!==o)switch(o.tag){case 3:if((o=o.stateNode).current.memoizedState.isDehydrated){var a=xe(o.pendingLanes);if(0!==a){var s=o;for(s.pendingLanes|=2,s.entangledLanes|=2;a;){var l=1<<31-pe(a);s.entanglements[1]|=l,a&=~l}ku(o),0===(6&nc)&&(kc=te()+500,Su(0,!1))}}break;case 13:null!==(s=Ar(o,2))&&Oc(s,0,2),Vc(),eh(o,2)}if(null===(o=ah(r))&&Bu(e,t,r,sh,n),o===i)break;i=o}null!==i&&r.stopPropagation()}else Bu(e,t,r,null,n)}}function ah(e){return lh(e=At(e))}var sh=null;function lh(e){if(sh=null,null!==(e=Ve(e))){var t=l(e);if(null===t)e=null;else{var n=t.tag;if(13===n){if(null!==(e=c(t)))return e;e=null}else if(3===n){if(t.stateNode.current.memoizedState.isDehydrated)return 3===t.tag?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return sh=e,null}function ch(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(ne()){case re:return 2;case ie:return 8;case oe:case ae:return 32;case se:return 268435456;default:return 32}default:return 32}}var uh=!1,dh=null,hh=null,ph=null,mh=new Map,fh=new Map,gh=[],yh="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function xh(e,t){switch(e){case"focusin":case"focusout":dh=null;break;case"dragenter":case"dragleave":hh=null;break;case"mouseover":case"mouseout":ph=null;break;case"pointerover":case"pointerout":mh.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":fh.delete(t.pointerId)}}function vh(e,t,n,r,i,o){return null===e||e.nativeEvent!==o?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:o,targetContainers:[i]},null!==t&&(null!==(t=Be(t))&&th(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,null!==i&&-1===t.indexOf(i)&&t.push(i),e)}function bh(e){var t=Ve(e.target);if(null!==t){var n=l(t);if(null!==n)if(13===(t=n.tag)){if(null!==(t=c(n)))return e.blockedOn=t,void function(e,t){var n=D.p;try{return D.p=e,t()}finally{D.p=n}}(e.priority,function(){if(13===n.tag){var e=Lc();e=Te(e);var t=Ar(n,e);null!==t&&Oc(t,0,e),eh(n,e)}})}else if(3===t&&n.stateNode.current.memoizedState.isDehydrated)return void(e.blockedOn=3===n.tag?n.stateNode.containerInfo:null)}e.blockedOn=null}function wh(e){if(null!==e.blockedOn)return!1;for(var t=e.targetContainers;0<t.length;){var n=ah(e.nativeEvent);if(null!==n)return null!==(t=Be(n))&&th(t),e.blockedOn=n,!1;var r=new(n=e.nativeEvent).constructor(n.type,n);zt=r,n.target.dispatchEvent(r),zt=null,t.shift()}return!0}function kh(e,t,n){wh(e)&&n.delete(t)}function Sh(){uh=!1,null!==dh&&wh(dh)&&(dh=null),null!==hh&&wh(hh)&&(hh=null),null!==ph&&wh(ph)&&(ph=null),mh.forEach(kh),fh.forEach(kh)}function jh(e,t){e.blockedOn===t&&(e.blockedOn=null,uh||(uh=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,Sh)))}var $h=null;function Ch(e){$h!==e&&($h=e,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){$h===e&&($h=null);for(var t=0;t<e.length;t+=3){var n=e[t],r=e[t+1],i=e[t+2];if("function"!==typeof r){if(null===lh(r||n))continue;break}var o=Be(n);null!==o&&(e.splice(t,3),t-=3,Aa(o,{pending:!0,data:i,method:n.method,action:r},r,i))}}))}function Eh(e){function t(t){return jh(t,e)}null!==dh&&jh(dh,e),null!==hh&&jh(hh,e),null!==ph&&jh(ph,e),mh.forEach(t),fh.forEach(t);for(var n=0;n<gh.length;n++){var r=gh[n];r.blockedOn===e&&(r.blockedOn=null)}for(;0<gh.length&&null===(n=gh[0]).blockedOn;)bh(n),null===n.blockedOn&&gh.shift();if(null!=(n=(e.ownerDocument||e).$$reactFormReplay))for(r=0;r<n.length;r+=3){var i=n[r],o=n[r+1],a=i[Me]||null;if("function"===typeof o)a||Ch(n);else if(a){var s=null;if(o&&o.hasAttribute("formAction")){if(i=o,a=o[Me]||null)s=a.formAction;else if(null!==lh(i))continue}else s=a.action;"function"===typeof s?n[r+1]=s:(n.splice(r,3),r-=3),Ch(n)}}}function Th(e){this._internalRoot=e}function Ph(e){this._internalRoot=e}Ph.prototype.render=Th.prototype.render=function(e){var t=this._internalRoot;if(null===t)throw Error(a(409));Jd(t.current,Lc(),e,t,null,null)},Ph.prototype.unmount=Th.prototype.unmount=function(){var e=this._internalRoot;if(null!==e){this._internalRoot=null;var t=e.containerInfo;Jd(e.current,2,null,e,null,null),Vc(),t[Le]=null}},Ph.prototype.unstable_scheduleHydration=function(e){if(e){var t=ze();e={blockedOn:null,target:e,priority:t};for(var n=0;n<gh.length&&0!==t&&t<gh[n].priority;n++);gh.splice(n,0,e),0===n&&bh(e)}};var zh=i.version;if("19.1.0"!==zh)throw Error(a(527,zh,"19.1.0"));D.findDOMNode=function(e){var t=e._reactInternals;if(void 0===t){if("function"===typeof e.render)throw Error(a(188));throw e=Object.keys(e).join(","),Error(a(268,e))}return e=function(e){var t=e.alternate;if(!t){if(null===(t=l(e)))throw Error(a(188));return t!==e?null:e}for(var n=e,r=t;;){var i=n.return;if(null===i)break;var o=i.alternate;if(null===o){if(null!==(r=i.return)){n=r;continue}break}if(i.child===o.child){for(o=i.child;o;){if(o===n)return u(i),e;if(o===r)return u(i),t;o=o.sibling}throw Error(a(188))}if(n.return!==r.return)n=i,r=o;else{for(var s=!1,c=i.child;c;){if(c===n){s=!0,n=i,r=o;break}if(c===r){s=!0,r=i,n=o;break}c=c.sibling}if(!s){for(c=o.child;c;){if(c===n){s=!0,n=o,r=i;break}if(c===r){s=!0,r=o,n=i;break}c=c.sibling}if(!s)throw Error(a(189))}}if(n.alternate!==r)throw Error(a(190))}if(3!==n.tag)throw Error(a(188));return n.stateNode.current===n?e:t}(t),e=null===(e=null!==e?d(e):null)?null:e.stateNode};var Ah={bundleType:0,version:"19.1.0",rendererPackageName:"react-dom",currentDispatcherRef:L,reconcilerVersion:"19.1.0"};if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var Rh=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Rh.isDisabled&&Rh.supportsFiber)try{ue=Rh.inject(Ah),de=Rh}catch(Lh){}}t.createRoot=function(e,t){if(!s(e))throw Error(a(299));var n=!1,r="",i=xs,o=vs,l=bs;return null!==t&&void 0!==t&&(!0===t.unstable_strictMode&&(n=!0),void 0!==t.identifierPrefix&&(r=t.identifierPrefix),void 0!==t.onUncaughtError&&(i=t.onUncaughtError),void 0!==t.onCaughtError&&(o=t.onCaughtError),void 0!==t.onRecoverableError&&(l=t.onRecoverableError),void 0!==t.unstable_transitionCallbacks&&t.unstable_transitionCallbacks),t=Xd(e,1,!1,null,0,n,r,i,o,l,0,null),e[Le]=t.current,Iu(e),new Th(t)},t.hydrateRoot=function(e,t,n){if(!s(e))throw Error(a(299));var r=!1,i="",o=xs,l=vs,c=bs,u=null;return null!==n&&void 0!==n&&(!0===n.unstable_strictMode&&(r=!0),void 0!==n.identifierPrefix&&(i=n.identifierPrefix),void 0!==n.onUncaughtError&&(o=n.onUncaughtError),void 0!==n.onCaughtError&&(l=n.onCaughtError),void 0!==n.onRecoverableError&&(c=n.onRecoverableError),void 0!==n.unstable_transitionCallbacks&&n.unstable_transitionCallbacks,void 0!==n.formState&&(u=n.formState)),(t=Xd(e,1,!0,t,0,r,i,o,l,c,0,u)).context=Qd(null),n=t.current,(i=io(r=Te(r=Lc()))).callback=null,oo(n,i,r),n=r,t.current.lanes=n,$e(t,n),ku(t),e[Le]=t.current,Iu(e),new Ph(t)},t.version="19.1.0"},43:(e,t,n)=>{"use strict";e.exports=n(288)},288:(e,t)=>{"use strict";var n=Symbol.for("react.transitional.element"),r=Symbol.for("react.portal"),i=Symbol.for("react.fragment"),o=Symbol.for("react.strict_mode"),a=Symbol.for("react.profiler"),s=Symbol.for("react.consumer"),l=Symbol.for("react.context"),c=Symbol.for("react.forward_ref"),u=Symbol.for("react.suspense"),d=Symbol.for("react.memo"),h=Symbol.for("react.lazy"),p=Symbol.iterator;var m={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},f=Object.assign,g={};function y(e,t,n){this.props=e,this.context=t,this.refs=g,this.updater=n||m}function x(){}function v(e,t,n){this.props=e,this.context=t,this.refs=g,this.updater=n||m}y.prototype.isReactComponent={},y.prototype.setState=function(e,t){if("object"!==typeof e&&"function"!==typeof e&&null!=e)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")},y.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")},x.prototype=y.prototype;var b=v.prototype=new x;b.constructor=v,f(b,y.prototype),b.isPureReactComponent=!0;var w=Array.isArray,k={H:null,A:null,T:null,S:null,V:null},S=Object.prototype.hasOwnProperty;function j(e,t,r,i,o,a){return r=a.ref,{$$typeof:n,type:e,key:t,ref:void 0!==r?r:null,props:a}}function $(e){return"object"===typeof e&&null!==e&&e.$$typeof===n}var C=/\/+/g;function E(e,t){return"object"===typeof e&&null!==e&&null!=e.key?function(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(e){return t[e]})}(""+e.key):t.toString(36)}function T(){}function P(e,t,i,o,a){var s=typeof e;"undefined"!==s&&"boolean"!==s||(e=null);var l,c,u=!1;if(null===e)u=!0;else switch(s){case"bigint":case"string":case"number":u=!0;break;case"object":switch(e.$$typeof){case n:case r:u=!0;break;case h:return P((u=e._init)(e._payload),t,i,o,a)}}if(u)return a=a(e),u=""===o?"."+E(e,0):o,w(a)?(i="",null!=u&&(i=u.replace(C,"$&/")+"/"),P(a,t,i,"",function(e){return e})):null!=a&&($(a)&&(l=a,c=i+(null==a.key||e&&e.key===a.key?"":(""+a.key).replace(C,"$&/")+"/")+u,a=j(l.type,c,void 0,0,0,l.props)),t.push(a)),1;u=0;var d,m=""===o?".":o+":";if(w(e))for(var f=0;f<e.length;f++)u+=P(o=e[f],t,i,s=m+E(o,f),a);else if("function"===typeof(f=null===(d=e)||"object"!==typeof d?null:"function"===typeof(d=p&&d[p]||d["@@iterator"])?d:null))for(e=f.call(e),f=0;!(o=e.next()).done;)u+=P(o=o.value,t,i,s=m+E(o,f++),a);else if("object"===s){if("function"===typeof e.then)return P(function(e){switch(e.status){case"fulfilled":return e.value;case"rejected":throw e.reason;default:switch("string"===typeof e.status?e.then(T,T):(e.status="pending",e.then(function(t){"pending"===e.status&&(e.status="fulfilled",e.value=t)},function(t){"pending"===e.status&&(e.status="rejected",e.reason=t)})),e.status){case"fulfilled":return e.value;case"rejected":throw e.reason}}throw e}(e),t,i,o,a);throw t=String(e),Error("Objects are not valid as a React child (found: "+("[object Object]"===t?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.")}return u}function z(e,t,n){if(null==e)return e;var r=[],i=0;return P(e,r,"","",function(e){return t.call(n,e,i++)}),r}function A(e){if(-1===e._status){var t=e._result;(t=t()).then(function(t){0!==e._status&&-1!==e._status||(e._status=1,e._result=t)},function(t){0!==e._status&&-1!==e._status||(e._status=2,e._result=t)}),-1===e._status&&(e._status=0,e._result=t)}if(1===e._status)return e._result.default;throw e._result}var R="function"===typeof reportError?reportError:function(e){if("object"===typeof window&&"function"===typeof window.ErrorEvent){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:"object"===typeof e&&null!==e&&"string"===typeof e.message?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if("object"===typeof process&&"function"===typeof process.emit)return void process.emit("uncaughtException",e);console.error(e)};function M(){}t.Children={map:z,forEach:function(e,t,n){z(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return z(e,function(){t++}),t},toArray:function(e){return z(e,function(e){return e})||[]},only:function(e){if(!$(e))throw Error("React.Children.only expected to receive a single React element child.");return e}},t.Component=y,t.Fragment=i,t.Profiler=a,t.PureComponent=v,t.StrictMode=o,t.Suspense=u,t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=k,t.__COMPILER_RUNTIME={__proto__:null,c:function(e){return k.H.useMemoCache(e)}},t.cache=function(e){return function(){return e.apply(null,arguments)}},t.cloneElement=function(e,t,n){if(null===e||void 0===e)throw Error("The argument must be a React element, but you passed "+e+".");var r=f({},e.props),i=e.key;if(null!=t)for(o in void 0!==t.ref&&void 0,void 0!==t.key&&(i=""+t.key),t)!S.call(t,o)||"key"===o||"__self"===o||"__source"===o||"ref"===o&&void 0===t.ref||(r[o]=t[o]);var o=arguments.length-2;if(1===o)r.children=n;else if(1<o){for(var a=Array(o),s=0;s<o;s++)a[s]=arguments[s+2];r.children=a}return j(e.type,i,void 0,0,0,r)},t.createContext=function(e){return(e={$$typeof:l,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null}).Provider=e,e.Consumer={$$typeof:s,_context:e},e},t.createElement=function(e,t,n){var r,i={},o=null;if(null!=t)for(r in void 0!==t.key&&(o=""+t.key),t)S.call(t,r)&&"key"!==r&&"__self"!==r&&"__source"!==r&&(i[r]=t[r]);var a=arguments.length-2;if(1===a)i.children=n;else if(1<a){for(var s=Array(a),l=0;l<a;l++)s[l]=arguments[l+2];i.children=s}if(e&&e.defaultProps)for(r in a=e.defaultProps)void 0===i[r]&&(i[r]=a[r]);return j(e,o,void 0,0,0,i)},t.createRef=function(){return{current:null}},t.forwardRef=function(e){return{$$typeof:c,render:e}},t.isValidElement=$,t.lazy=function(e){return{$$typeof:h,_payload:{_status:-1,_result:e},_init:A}},t.memo=function(e,t){return{$$typeof:d,type:e,compare:void 0===t?null:t}},t.startTransition=function(e){var t=k.T,n={};k.T=n;try{var r=e(),i=k.S;null!==i&&i(n,r),"object"===typeof r&&null!==r&&"function"===typeof r.then&&r.then(M,R)}catch(o){R(o)}finally{k.T=t}},t.unstable_useCacheRefresh=function(){return k.H.useCacheRefresh()},t.use=function(e){return k.H.use(e)},t.useActionState=function(e,t,n){return k.H.useActionState(e,t,n)},t.useCallback=function(e,t){return k.H.useCallback(e,t)},t.useContext=function(e){return k.H.useContext(e)},t.useDebugValue=function(){},t.useDeferredValue=function(e,t){return k.H.useDeferredValue(e,t)},t.useEffect=function(e,t,n){var r=k.H;if("function"===typeof n)throw Error("useEffect CRUD overload is not enabled in this build of React.");return r.useEffect(e,t)},t.useId=function(){return k.H.useId()},t.useImperativeHandle=function(e,t,n){return k.H.useImperativeHandle(e,t,n)},t.useInsertionEffect=function(e,t){return k.H.useInsertionEffect(e,t)},t.useLayoutEffect=function(e,t){return k.H.useLayoutEffect(e,t)},t.useMemo=function(e,t){return k.H.useMemo(e,t)},t.useOptimistic=function(e,t){return k.H.useOptimistic(e,t)},t.useReducer=function(e,t,n){return k.H.useReducer(e,t,n)},t.useRef=function(e){return k.H.useRef(e)},t.useState=function(e){return k.H.useState(e)},t.useSyncExternalStore=function(e,t,n){return k.H.useSyncExternalStore(e,t,n)},t.useTransition=function(){return k.H.useTransition()},t.version="19.1.0"},324:e=>{e.exports=function(e,t,n,r){var i=n?n.call(r,e,t):void 0;if(void 0!==i)return!!i;if(e===t)return!0;if("object"!==typeof e||!e||"object"!==typeof t||!t)return!1;var o=Object.keys(e),a=Object.keys(t);if(o.length!==a.length)return!1;for(var s=Object.prototype.hasOwnProperty.bind(t),l=0;l<o.length;l++){var c=o[l];if(!s(c))return!1;var u=e[c],d=t[c];if(!1===(i=n?n.call(r,u,d,c):void 0)||void 0===i&&u!==d)return!1}return!0}},358:(e,t)=>{"use strict";const n=/^[\u0021-\u003A\u003C\u003E-\u007E]+$/,r=/^[\u0021-\u003A\u003C-\u007E]*$/,i=/^([.]?[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)([.][a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/i,o=/^[\u0020-\u003A\u003D-\u007E]*$/,a=Object.prototype.toString,s=(()=>{const e=function(){};return e.prototype=Object.create(null),e})();function l(e,t,n){do{const n=e.charCodeAt(t);if(32!==n&&9!==n)return t}while(++t<n);return n}function c(e,t,n){for(;t>n;){const n=e.charCodeAt(--t);if(32!==n&&9!==n)return t+1}return n}function u(e){if(-1===e.indexOf("%"))return e;try{return decodeURIComponent(e)}catch(t){return e}}},391:(e,t,n)=>{"use strict";!function e(){if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__&&"function"===typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(t){console.error(t)}}(),e.exports=n(4)},579:(e,t,n)=>{"use strict";e.exports=n(799)},672:(e,t,n)=>{"use strict";var r=n(43);function i(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var n=2;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function o(){}var a={d:{f:o,r:function(){throw Error(i(522))},D:o,C:o,L:o,m:o,X:o,S:o,M:o},p:0,findDOMNode:null},s=Symbol.for("react.portal");var l=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function c(e,t){return"font"===e?"":"string"===typeof t?"use-credentials"===t?t:"":void 0}t.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=a,t.createPortal=function(e,t){var n=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!t||1!==t.nodeType&&9!==t.nodeType&&11!==t.nodeType)throw Error(i(299));return function(e,t,n){var r=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:s,key:null==r?null:""+r,children:e,containerInfo:t,implementation:n}}(e,t,null,n)},t.flushSync=function(e){var t=l.T,n=a.p;try{if(l.T=null,a.p=2,e)return e()}finally{l.T=t,a.p=n,a.d.f()}},t.preconnect=function(e,t){"string"===typeof e&&(t?t="string"===typeof(t=t.crossOrigin)?"use-credentials"===t?t:"":void 0:t=null,a.d.C(e,t))},t.prefetchDNS=function(e){"string"===typeof e&&a.d.D(e)},t.preinit=function(e,t){if("string"===typeof e&&t&&"string"===typeof t.as){var n=t.as,r=c(n,t.crossOrigin),i="string"===typeof t.integrity?t.integrity:void 0,o="string"===typeof t.fetchPriority?t.fetchPriority:void 0;"style"===n?a.d.S(e,"string"===typeof t.precedence?t.precedence:void 0,{crossOrigin:r,integrity:i,fetchPriority:o}):"script"===n&&a.d.X(e,{crossOrigin:r,integrity:i,fetchPriority:o,nonce:"string"===typeof t.nonce?t.nonce:void 0})}},t.preinitModule=function(e,t){if("string"===typeof e)if("object"===typeof t&&null!==t){if(null==t.as||"script"===t.as){var n=c(t.as,t.crossOrigin);a.d.M(e,{crossOrigin:n,integrity:"string"===typeof t.integrity?t.integrity:void 0,nonce:"string"===typeof t.nonce?t.nonce:void 0})}}else null==t&&a.d.M(e)},t.preload=function(e,t){if("string"===typeof e&&"object"===typeof t&&null!==t&&"string"===typeof t.as){var n=t.as,r=c(n,t.crossOrigin);a.d.L(e,n,{crossOrigin:r,integrity:"string"===typeof t.integrity?t.integrity:void 0,nonce:"string"===typeof t.nonce?t.nonce:void 0,type:"string"===typeof t.type?t.type:void 0,fetchPriority:"string"===typeof t.fetchPriority?t.fetchPriority:void 0,referrerPolicy:"string"===typeof t.referrerPolicy?t.referrerPolicy:void 0,imageSrcSet:"string"===typeof t.imageSrcSet?t.imageSrcSet:void 0,imageSizes:"string"===typeof t.imageSizes?t.imageSizes:void 0,media:"string"===typeof t.media?t.media:void 0})}},t.preloadModule=function(e,t){if("string"===typeof e)if(t){var n=c(t.as,t.crossOrigin);a.d.m(e,{as:"string"===typeof t.as&&"script"!==t.as?t.as:void 0,crossOrigin:n,integrity:"string"===typeof t.integrity?t.integrity:void 0})}else a.d.m(e)},t.requestFormReset=function(e){a.d.r(e)},t.unstable_batchedUpdates=function(e,t){return e(t)},t.useFormState=function(e,t,n){return l.H.useFormState(e,t,n)},t.useFormStatus=function(){return l.H.useHostTransitionStatus()},t.version="19.1.0"},799:(e,t)=>{"use strict";var n=Symbol.for("react.transitional.element"),r=Symbol.for("react.fragment");function i(e,t,r){var i=null;if(void 0!==r&&(i=""+r),void 0!==t.key&&(i=""+t.key),"key"in t)for(var o in r={},t)"key"!==o&&(r[o]=t[o]);else r=t;return t=r.ref,{$$typeof:n,type:e,key:i,ref:void 0!==t?t:null,props:r}}t.Fragment=r,t.jsx=i,t.jsxs=i},853:(e,t,n)=>{"use strict";e.exports=n(896)},896:(e,t)=>{"use strict";function n(e,t){var n=e.length;e.push(t);e:for(;0<n;){var r=n-1>>>1,i=e[r];if(!(0<o(i,t)))break e;e[r]=t,e[n]=i,n=r}}function r(e){return 0===e.length?null:e[0]}function i(e){if(0===e.length)return null;var t=e[0],n=e.pop();if(n!==t){e[0]=n;e:for(var r=0,i=e.length,a=i>>>1;r<a;){var s=2*(r+1)-1,l=e[s],c=s+1,u=e[c];if(0>o(l,n))c<i&&0>o(u,l)?(e[r]=u,e[c]=n,r=c):(e[r]=l,e[s]=n,r=s);else{if(!(c<i&&0>o(u,n)))break e;e[r]=u,e[c]=n,r=c}}}return t}function o(e,t){var n=e.sortIndex-t.sortIndex;return 0!==n?n:e.id-t.id}if(t.unstable_now=void 0,"object"===typeof performance&&"function"===typeof performance.now){var a=performance;t.unstable_now=function(){return a.now()}}else{var s=Date,l=s.now();t.unstable_now=function(){return s.now()-l}}var c=[],u=[],d=1,h=null,p=3,m=!1,f=!1,g=!1,y=!1,x="function"===typeof setTimeout?setTimeout:null,v="function"===typeof clearTimeout?clearTimeout:null,b="undefined"!==typeof setImmediate?setImmediate:null;function w(e){for(var t=r(u);null!==t;){if(null===t.callback)i(u);else{if(!(t.startTime<=e))break;i(u),t.sortIndex=t.expirationTime,n(c,t)}t=r(u)}}function k(e){if(g=!1,w(e),!f)if(null!==r(c))f=!0,j||(j=!0,S());else{var t=r(u);null!==t&&R(k,t.startTime-e)}}var S,j=!1,$=-1,C=5,E=-1;function T(){return!!y||!(t.unstable_now()-E<C)}function P(){if(y=!1,j){var e=t.unstable_now();E=e;var n=!0;try{e:{f=!1,g&&(g=!1,v($),$=-1),m=!0;var o=p;try{t:{for(w(e),h=r(c);null!==h&&!(h.expirationTime>e&&T());){var a=h.callback;if("function"===typeof a){h.callback=null,p=h.priorityLevel;var s=a(h.expirationTime<=e);if(e=t.unstable_now(),"function"===typeof s){h.callback=s,w(e),n=!0;break t}h===r(c)&&i(c),w(e)}else i(c);h=r(c)}if(null!==h)n=!0;else{var l=r(u);null!==l&&R(k,l.startTime-e),n=!1}}break e}finally{h=null,p=o,m=!1}n=void 0}}finally{n?S():j=!1}}}if("function"===typeof b)S=function(){b(P)};else if("undefined"!==typeof MessageChannel){var z=new MessageChannel,A=z.port2;z.port1.onmessage=P,S=function(){A.postMessage(null)}}else S=function(){x(P,0)};function R(e,n){$=x(function(){e(t.unstable_now())},n)}t.unstable_IdlePriority=5,t.unstable_ImmediatePriority=1,t.unstable_LowPriority=4,t.unstable_NormalPriority=3,t.unstable_Profiling=null,t.unstable_UserBlockingPriority=2,t.unstable_cancelCallback=function(e){e.callback=null},t.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):C=0<e?Math.floor(1e3/e):5},t.unstable_getCurrentPriorityLevel=function(){return p},t.unstable_next=function(e){switch(p){case 1:case 2:case 3:var t=3;break;default:t=p}var n=p;p=t;try{return e()}finally{p=n}},t.unstable_requestPaint=function(){y=!0},t.unstable_runWithPriority=function(e,t){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var n=p;p=e;try{return t()}finally{p=n}},t.unstable_scheduleCallback=function(e,i,o){var a=t.unstable_now();switch("object"===typeof o&&null!==o?o="number"===typeof(o=o.delay)&&0<o?a+o:a:o=a,e){case 1:var s=-1;break;case 2:s=250;break;case 5:s=1073741823;break;case 4:s=1e4;break;default:s=5e3}return e={id:d++,callback:i,priorityLevel:e,startTime:o,expirationTime:s=o+s,sortIndex:-1},o>a?(e.sortIndex=o,n(u,e),null===r(c)&&e===r(u)&&(g?(v($),$=-1):g=!0,R(k,o-a))):(e.sortIndex=s,n(c,e),f||m||(f=!0,j||(j=!0,S()))),e},t.unstable_shouldYield=T,t.unstable_wrapCallback=function(e){var t=p;return function(){var n=p;p=t;try{return e.apply(this,arguments)}finally{p=n}}}},950:(e,t,n)=>{"use strict";!function e(){if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__&&"function"===typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(t){console.error(t)}}(),e.exports=n(672)}},t={};function n(r){var i=t[r];if(void 0!==i)return i.exports;var o=t[r]={exports:{}};return e[r](o,o.exports,n),o.exports}n.m=e,n.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return n.d(t,{a:t}),t},n.d=(e,t)=>{for(var r in t)n.o(t,r)&&!n.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},n.f={},n.e=e=>Promise.all(Object.keys(n.f).reduce((t,r)=>(n.f[r](e,t),t),[])),n.u=e=>"static/js/"+e+".7e32e43c.chunk.js",n.miniCssF=e=>{},n.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),(()=>{var e={},t="astra-app:";n.l=(r,i,o,a)=>{if(e[r])e[r].push(i);else{var s,l;if(void 0!==o)for(var c=document.getElementsByTagName("script"),u=0;u<c.length;u++){var d=c[u];if(d.getAttribute("src")==r||d.getAttribute("data-webpack")==t+o){s=d;break}}s||(l=!0,(s=document.createElement("script")).charset="utf-8",s.timeout=120,n.nc&&s.setAttribute("nonce",n.nc),s.setAttribute("data-webpack",t+o),s.src=r),e[r]=[i];var h=(t,n)=>{s.onerror=s.onload=null,clearTimeout(p);var i=e[r];if(delete e[r],s.parentNode&&s.parentNode.removeChild(s),i&&i.forEach(e=>e(n)),t)return t(n)},p=setTimeout(h.bind(null,void 0,{type:"timeout",target:s}),12e4);s.onerror=h.bind(null,s.onerror),s.onload=h.bind(null,s.onload),l&&document.head.appendChild(s)}}})(),n.r=e=>{"undefined"!==typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.p="/",(()=>{var e={792:0};n.f.j=(t,r)=>{var i=n.o(e,t)?e[t]:void 0;if(0!==i)if(i)r.push(i[2]);else{var o=new Promise((n,r)=>i=e[t]=[n,r]);r.push(i[2]=o);var a=n.p+n.u(t),s=new Error;n.l(a,r=>{if(n.o(e,t)&&(0!==(i=e[t])&&(e[t]=void 0),i)){var o=r&&("load"===r.type?"missing":r.type),a=r&&r.target&&r.target.src;s.message="Loading chunk "+t+" failed.\n("+o+": "+a+")",s.name="ChunkLoadError",s.type=o,s.request=a,i[1](s)}},"chunk-"+t,t)}};var t=(t,r)=>{var i,o,a=r[0],s=r[1],l=r[2],c=0;if(a.some(t=>0!==e[t])){for(i in s)n.o(s,i)&&(n.m[i]=s[i]);if(l)l(n)}for(t&&t(r);c<a.length;c++)o=a[c],n.o(e,o)&&e[o]&&e[o][0](),e[o]=0},r=self.webpackChunkastra_app=self.webpackChunkastra_app||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})(),n.nc=void 0,(()=>{"use strict";var e=n(43),t=n(391),r=(n(358),"popstate");function i(){return d(function(e,t){let{pathname:n,search:r,hash:i}=e.location;return l("",{pathname:n,search:r,hash:i},t.state&&t.state.usr||null,t.state&&t.state.key||"default")},function(e,t){return"string"===typeof t?t:c(t)},null,arguments.length>0&&void 0!==arguments[0]?arguments[0]:{})}function o(e,t){if(!1===e||null===e||"undefined"===typeof e)throw new Error(t)}function a(e,t){if(!e){"undefined"!==typeof console&&console.warn(t);try{throw new Error(t)}catch(n){}}}function s(e,t){return{usr:e.state,key:e.key,idx:t}}function l(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,r=arguments.length>3?arguments[3]:void 0;return{pathname:"string"===typeof e?e:e.pathname,search:"",hash:"",..."string"===typeof t?u(t):t,state:n,key:t&&t.key||r||Math.random().toString(36).substring(2,10)}}function c(e){let{pathname:t="/",search:n="",hash:r=""}=e;return n&&"?"!==n&&(t+="?"===n.charAt(0)?n:"?"+n),r&&"#"!==r&&(t+="#"===r.charAt(0)?r:"#"+r),t}function u(e){let t={};if(e){let n=e.indexOf("#");n>=0&&(t.hash=e.substring(n),e=e.substring(0,n));let r=e.indexOf("?");r>=0&&(t.search=e.substring(r),e=e.substring(0,r)),e&&(t.pathname=e)}return t}function d(e,t,n){let i=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{},{window:o=document.defaultView,v5Compat:a=!1}=i,c=o.history,u="POP",d=null,p=m();function m(){return(c.state||{idx:null}).idx}function f(){u="POP";let e=m(),t=null==e?null:e-p;p=e,d&&d({action:u,location:y.location,delta:t})}function g(e){return h(e)}null==p&&(p=0,c.replaceState({...c.state,idx:p},""));let y={get action(){return u},get location(){return e(o,c)},listen(e){if(d)throw new Error("A history only accepts one active listener");return o.addEventListener(r,f),d=e,()=>{o.removeEventListener(r,f),d=null}},createHref:e=>t(o,e),createURL:g,encodeLocation(e){let t=g(e);return{pathname:t.pathname,search:t.search,hash:t.hash}},push:function(e,t){u="PUSH";let r=l(y.location,e,t);n&&n(r,e),p=m()+1;let i=s(r,p),h=y.createHref(r);try{c.pushState(i,"",h)}catch(f){if(f instanceof DOMException&&"DataCloneError"===f.name)throw f;o.location.assign(h)}a&&d&&d({action:u,location:y.location,delta:1})},replace:function(e,t){u="REPLACE";let r=l(y.location,e,t);n&&n(r,e),p=m();let i=s(r,p),o=y.createHref(r);c.replaceState(i,"",o),a&&d&&d({action:u,location:y.location,delta:0})},go:e=>c.go(e)};return y}function h(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n="http://localhost";"undefined"!==typeof window&&(n="null"!==window.location.origin?window.location.origin:window.location.href),o(n,"No window.location.(origin|href) available to create URL");let r="string"===typeof e?e:c(e);return r=r.replace(/ $/,"%20"),!t&&r.startsWith("//")&&(r=n+r),new URL(r,n)}new WeakMap;function p(e,t){return m(e,t,arguments.length>2&&void 0!==arguments[2]?arguments[2]:"/",!1)}function m(e,t,n,r){let i=P(("string"===typeof t?u(t):t).pathname||"/",n);if(null==i)return null;let o=f(e);!function(e){e.sort((e,t)=>e.score!==t.score?t.score-e.score:function(e,t){let n=e.length===t.length&&e.slice(0,-1).every((e,n)=>e===t[n]);return n?e[e.length-1]-t[t.length-1]:0}(e.routesMeta.map(e=>e.childrenIndex),t.routesMeta.map(e=>e.childrenIndex)))}(o);let a=null;for(let s=0;null==a&&s<o.length;++s){let e=T(i);a=$(o[s],e,r)}return a}function f(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:[],n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[],r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"",i=(e,i,a)=>{let s={relativePath:void 0===a?e.path||"":a,caseSensitive:!0===e.caseSensitive,childrenIndex:i,route:e};s.relativePath.startsWith("/")&&(o(s.relativePath.startsWith(r),`Absolute route path "${s.relativePath}" nested under path "${r}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),s.relativePath=s.relativePath.slice(r.length));let l=L([r,s.relativePath]),c=n.concat(s);e.children&&e.children.length>0&&(o(!0!==e.index,`Index routes must not have child routes. Please remove all child routes from route path "${l}".`),f(e.children,t,c,l)),(null!=e.path||e.index)&&t.push({path:l,score:j(l,e.index),routesMeta:c})};return e.forEach((e,t)=>{if(""!==e.path&&e.path?.includes("?"))for(let n of g(e.path))i(e,t,n);else i(e,t)}),t}function g(e){let t=e.split("/");if(0===t.length)return[];let[n,...r]=t,i=n.endsWith("?"),o=n.replace(/\?$/,"");if(0===r.length)return i?[o,""]:[o];let a=g(r.join("/")),s=[];return s.push(...a.map(e=>""===e?o:[o,e].join("/"))),i&&s.push(...a),s.map(t=>e.startsWith("/")&&""===t?"/":t)}var y=/^:[\w-]+$/,x=3,v=2,b=1,w=10,k=-2,S=e=>"*"===e;function j(e,t){let n=e.split("/"),r=n.length;return n.some(S)&&(r+=k),t&&(r+=v),n.filter(e=>!S(e)).reduce((e,t)=>e+(y.test(t)?x:""===t?b:w),r)}function $(e,t){let n=arguments.length>2&&void 0!==arguments[2]&&arguments[2],{routesMeta:r}=e,i={},o="/",a=[];for(let s=0;s<r.length;++s){let e=r[s],l=s===r.length-1,c="/"===o?t:t.slice(o.length)||"/",u=C({path:e.relativePath,caseSensitive:e.caseSensitive,end:l},c),d=e.route;if(!u&&l&&n&&!r[r.length-1].route.index&&(u=C({path:e.relativePath,caseSensitive:e.caseSensitive,end:!1},c)),!u)return null;Object.assign(i,u.params),a.push({params:i,pathname:L([o,u.pathname]),pathnameBase:D(L([o,u.pathnameBase])),route:d}),"/"!==u.pathnameBase&&(o=L([o,u.pathnameBase]))}return a}function C(e,t){"string"===typeof e&&(e={path:e,caseSensitive:!1,end:!0});let[n,r]=E(e.path,e.caseSensitive,e.end),i=t.match(n);if(!i)return null;let o=i[0],a=o.replace(/(.)\/+$/,"$1"),s=i.slice(1);return{params:r.reduce((e,t,n)=>{let{paramName:r,isOptional:i}=t;if("*"===r){let e=s[n]||"";a=o.slice(0,o.length-e.length).replace(/(.)\/+$/,"$1")}const l=s[n];return e[r]=i&&!l?void 0:(l||"").replace(/%2F/g,"/"),e},{}),pathname:o,pathnameBase:a,pattern:e}}function E(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n=!(arguments.length>2&&void 0!==arguments[2])||arguments[2];a("*"===e||!e.endsWith("*")||e.endsWith("/*"),`Route path "${e}" will be treated as if it were "${e.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${e.replace(/\*$/,"/*")}".`);let r=[],i="^"+e.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(e,t,n)=>(r.push({paramName:t,isOptional:null!=n}),n?"/?([^\\/]+)?":"/([^\\/]+)"));return e.endsWith("*")?(r.push({paramName:"*"}),i+="*"===e||"/*"===e?"(.*)$":"(?:\\/(.+)|\\/*)$"):n?i+="\\/*$":""!==e&&"/"!==e&&(i+="(?:(?=\\/|$))"),[new RegExp(i,t?void 0:"i"),r]}function T(e){try{return e.split("/").map(e=>decodeURIComponent(e).replace(/\//g,"%2F")).join("/")}catch(t){return a(!1,`The URL path "${e}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${t}).`),e}}function P(e,t){if("/"===t)return e;if(!e.toLowerCase().startsWith(t.toLowerCase()))return null;let n=t.endsWith("/")?t.length-1:t.length,r=e.charAt(n);return r&&"/"!==r?null:e.slice(n)||"/"}function z(e,t,n,r){return`Cannot include a '${e}' character in a manually specified \`to.${t}\` field [${JSON.stringify(r)}].  Please separate it out to the \`to.${n}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function A(e){return e.filter((e,t)=>0===t||e.route.path&&e.route.path.length>0)}function R(e){let t=A(e);return t.map((e,n)=>n===t.length-1?e.pathname:e.pathnameBase)}function M(e,t,n){let r,i=arguments.length>3&&void 0!==arguments[3]&&arguments[3];"string"===typeof e?r=u(e):(r={...e},o(!r.pathname||!r.pathname.includes("?"),z("?","pathname","search",r)),o(!r.pathname||!r.pathname.includes("#"),z("#","pathname","hash",r)),o(!r.search||!r.search.includes("#"),z("#","search","hash",r)));let a,s=""===e||""===r.pathname,l=s?"/":r.pathname;if(null==l)a=n;else{let e=t.length-1;if(!i&&l.startsWith("..")){let t=l.split("/");for(;".."===t[0];)t.shift(),e-=1;r.pathname=t.join("/")}a=e>=0?t[e]:"/"}let c=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"/",{pathname:n,search:r="",hash:i=""}="string"===typeof e?u(e):e,o=n?n.startsWith("/")?n:function(e,t){let n=t.replace(/\/+$/,"").split("/");return e.split("/").forEach(e=>{".."===e?n.length>1&&n.pop():"."!==e&&n.push(e)}),n.length>1?n.join("/"):"/"}(n,t):t;return{pathname:o,search:O(r),hash:F(i)}}(r,a),d=l&&"/"!==l&&l.endsWith("/"),h=(s||"."===l)&&n.endsWith("/");return c.pathname.endsWith("/")||!d&&!h||(c.pathname+="/"),c}var L=e=>e.join("/").replace(/\/\/+/g,"/"),D=e=>e.replace(/\/+$/,"").replace(/^\/*/,"/"),O=e=>e&&"?"!==e?e.startsWith("?")?e:"?"+e:"",F=e=>e&&"#"!==e?e.startsWith("#")?e:"#"+e:"";function N(e){return null!=e&&"number"===typeof e.status&&"string"===typeof e.statusText&&"boolean"===typeof e.internal&&"data"in e}var _=["POST","PUT","PATCH","DELETE"],I=(new Set(_),["GET",..._]);new Set(I),Symbol("ResetLoaderData");var V=e.createContext(null);V.displayName="DataRouter";var B=e.createContext(null);B.displayName="DataRouterState";var W=e.createContext({isTransitioning:!1});W.displayName="ViewTransition";var H=e.createContext(new Map);H.displayName="Fetchers";var U=e.createContext(null);U.displayName="Await";var q=e.createContext(null);q.displayName="Navigation";var Y=e.createContext(null);Y.displayName="Location";var K=e.createContext({outlet:null,matches:[],isDataRoute:!1});K.displayName="Route";var G=e.createContext(null);G.displayName="RouteError";function X(){return null!=e.useContext(Y)}function Q(){return o(X(),"useLocation() may be used only in the context of a <Router> component."),e.useContext(Y).location}var J="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function Z(t){e.useContext(q).static||e.useLayoutEffect(t)}function ee(){let{isDataRoute:t}=e.useContext(K);return t?function(){let{router:t}=ce("useNavigate"),n=de("useNavigate"),r=e.useRef(!1);Z(()=>{r.current=!0});let i=e.useCallback(async function(e){let i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};a(r.current,J),r.current&&("number"===typeof e?t.navigate(e):await t.navigate(e,{fromRouteId:n,...i}))},[t,n]);return i}():function(){o(X(),"useNavigate() may be used only in the context of a <Router> component.");let t=e.useContext(V),{basename:n,navigator:r}=e.useContext(q),{matches:i}=e.useContext(K),{pathname:s}=Q(),l=JSON.stringify(R(i)),c=e.useRef(!1);Z(()=>{c.current=!0});let u=e.useCallback(function(e){let i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};if(a(c.current,J),!c.current)return;if("number"===typeof e)return void r.go(e);let o=M(e,JSON.parse(l),s,"path"===i.relative);null==t&&"/"!==n&&(o.pathname="/"===o.pathname?n:L([n,o.pathname])),(i.replace?r.replace:r.push)(o,i.state,i)},[n,r,l,s,t]);return u}()}e.createContext(null);function te(t){let{relative:n}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},{matches:r}=e.useContext(K),{pathname:i}=Q(),o=JSON.stringify(R(r));return e.useMemo(()=>M(t,JSON.parse(o),i,"path"===n),[t,o,i,n])}function ne(t,n,r,i){o(X(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:s}=e.useContext(q),{matches:l}=e.useContext(K),c=l[l.length-1],d=c?c.params:{},h=c?c.pathname:"/",m=c?c.pathnameBase:"/",f=c&&c.route;{let e=f&&f.path||"";me(h,!f||e.endsWith("*")||e.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${h}" (under <Route path="${e}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.\n\nPlease change the parent <Route path="${e}"> to <Route path="${"/"===e?"*":`${e}/*`}">.`)}let g,y=Q();if(n){let e="string"===typeof n?u(n):n;o("/"===m||e.pathname?.startsWith(m),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${m}" but pathname "${e.pathname}" was given in the \`location\` prop.`),g=e}else g=y;let x=g.pathname||"/",v=x;if("/"!==m){let e=m.replace(/^\//,"").split("/");v="/"+x.replace(/^\//,"").split("/").slice(e.length).join("/")}let b=p(t,{pathname:v});a(f||null!=b,`No routes matched location "${g.pathname}${g.search}${g.hash}" `),a(null==b||void 0!==b[b.length-1].route.element||void 0!==b[b.length-1].route.Component||void 0!==b[b.length-1].route.lazy,`Matched leaf route at location "${g.pathname}${g.search}${g.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let w=se(b&&b.map(e=>Object.assign({},e,{params:Object.assign({},d,e.params),pathname:L([m,s.encodeLocation?s.encodeLocation(e.pathname).pathname:e.pathname]),pathnameBase:"/"===e.pathnameBase?m:L([m,s.encodeLocation?s.encodeLocation(e.pathnameBase).pathname:e.pathnameBase])})),l,r,i);return n&&w?e.createElement(Y.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",...g},navigationType:"POP"}},w):w}function re(){let t=he(),n=N(t)?`${t.status} ${t.statusText}`:t instanceof Error?t.message:JSON.stringify(t),r=t instanceof Error?t.stack:null,i="rgba(200,200,200, 0.5)",o={padding:"0.5rem",backgroundColor:i},a={padding:"2px 4px",backgroundColor:i},s=null;return console.error("Error handled by React Router default ErrorBoundary:",t),s=e.createElement(e.Fragment,null,e.createElement("p",null,"\ud83d\udcbf Hey developer \ud83d\udc4b"),e.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",e.createElement("code",{style:a},"ErrorBoundary")," or"," ",e.createElement("code",{style:a},"errorElement")," prop on your route.")),e.createElement(e.Fragment,null,e.createElement("h2",null,"Unexpected Application Error!"),e.createElement("h3",{style:{fontStyle:"italic"}},n),r?e.createElement("pre",{style:o},r):null,s)}var ie=e.createElement(re,null),oe=class extends e.Component{constructor(e){super(e),this.state={location:e.location,revalidation:e.revalidation,error:e.error}}static getDerivedStateFromError(e){return{error:e}}static getDerivedStateFromProps(e,t){return t.location!==e.location||"idle"!==t.revalidation&&"idle"===e.revalidation?{error:e.error,location:e.location,revalidation:e.revalidation}:{error:void 0!==e.error?e.error:t.error,location:t.location,revalidation:e.revalidation||t.revalidation}}componentDidCatch(e,t){console.error("React Router caught the following error during render",e,t)}render(){return void 0!==this.state.error?e.createElement(K.Provider,{value:this.props.routeContext},e.createElement(G.Provider,{value:this.state.error,children:this.props.component})):this.props.children}};function ae(t){let{routeContext:n,match:r,children:i}=t,o=e.useContext(V);return o&&o.static&&o.staticContext&&(r.route.errorElement||r.route.ErrorBoundary)&&(o.staticContext._deepestRenderedBoundaryId=r.route.id),e.createElement(K.Provider,{value:n},i)}function se(t){let n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:[],r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null;if(null==t){if(!r)return null;if(r.errors)t=r.matches;else{if(0!==n.length||r.initialized||!(r.matches.length>0))return null;t=r.matches}}let i=t,a=r?.errors;if(null!=a){let e=i.findIndex(e=>e.route.id&&void 0!==a?.[e.route.id]);o(e>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(a).join(",")}`),i=i.slice(0,Math.min(i.length,e+1))}let s=!1,l=-1;if(r)for(let e=0;e<i.length;e++){let t=i[e];if((t.route.HydrateFallback||t.route.hydrateFallbackElement)&&(l=e),t.route.id){let{loaderData:e,errors:n}=r,o=t.route.loader&&!e.hasOwnProperty(t.route.id)&&(!n||void 0===n[t.route.id]);if(t.route.lazy||o){s=!0,i=l>=0?i.slice(0,l+1):[i[0]];break}}}return i.reduceRight((t,o,c)=>{let u,d=!1,h=null,p=null;r&&(u=a&&o.route.id?a[o.route.id]:void 0,h=o.route.errorElement||ie,s&&(l<0&&0===c?(me("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),d=!0,p=null):l===c&&(d=!0,p=o.route.hydrateFallbackElement||null)));let m=n.concat(i.slice(0,c+1)),f=()=>{let n;return n=u?h:d?p:o.route.Component?e.createElement(o.route.Component,null):o.route.element?o.route.element:t,e.createElement(ae,{match:o,routeContext:{outlet:t,matches:m,isDataRoute:null!=r},children:n})};return r&&(o.route.ErrorBoundary||o.route.errorElement||0===c)?e.createElement(oe,{location:r.location,revalidation:r.revalidation,component:h,error:u,children:f(),routeContext:{outlet:null,matches:m,isDataRoute:!0}}):f()},null)}function le(e){return`${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function ce(t){let n=e.useContext(V);return o(n,le(t)),n}function ue(t){let n=e.useContext(B);return o(n,le(t)),n}function de(t){let n=function(t){let n=e.useContext(K);return o(n,le(t)),n}(t),r=n.matches[n.matches.length-1];return o(r.route.id,`${t} can only be used on routes that contain a unique "id"`),r.route.id}function he(){let t=e.useContext(G),n=ue("useRouteError"),r=de("useRouteError");return void 0!==t?t:n.errors?.[r]}var pe={};function me(e,t,n){t||pe[e]||(pe[e]=!0,a(!1,n))}e.memo(function(e){let{routes:t,future:n,state:r}=e;return ne(t,void 0,r,n)});function fe(e){o(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function ge(t){let{basename:n="/",children:r=null,location:i,navigationType:s="POP",navigator:l,static:c=!1}=t;o(!X(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let d=n.replace(/^\/*/,"/"),h=e.useMemo(()=>({basename:d,navigator:l,static:c,future:{}}),[d,l,c]);"string"===typeof i&&(i=u(i));let{pathname:p="/",search:m="",hash:f="",state:g=null,key:y="default"}=i,x=e.useMemo(()=>{let e=P(p,d);return null==e?null:{location:{pathname:e,search:m,hash:f,state:g,key:y},navigationType:s}},[d,p,m,f,g,y,s]);return a(null!=x,`<Router basename="${d}"> is not able to match the URL "${p}${m}${f}" because it does not start with the basename, so the <Router> won't render anything.`),null==x?null:e.createElement(q.Provider,{value:h},e.createElement(Y.Provider,{children:r,value:x}))}function ye(e){let{children:t,location:n}=e;return ne(xe(t),n)}e.Component;function xe(t){let n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:[],r=[];return e.Children.forEach(t,(t,i)=>{if(!e.isValidElement(t))return;let a=[...n,i];if(t.type===e.Fragment)return void r.push.apply(r,xe(t.props.children,a));o(t.type===fe,`[${"string"===typeof t.type?t.type:t.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),o(!t.props.index||!t.props.children,"An index route cannot have child routes.");let s={id:t.props.id||a.join("-"),caseSensitive:t.props.caseSensitive,element:t.props.element,Component:t.props.Component,index:t.props.index,path:t.props.path,loader:t.props.loader,action:t.props.action,hydrateFallbackElement:t.props.hydrateFallbackElement,HydrateFallback:t.props.HydrateFallback,errorElement:t.props.errorElement,ErrorBoundary:t.props.ErrorBoundary,hasErrorBoundary:!0===t.props.hasErrorBoundary||null!=t.props.ErrorBoundary||null!=t.props.errorElement,shouldRevalidate:t.props.shouldRevalidate,handle:t.props.handle,lazy:t.props.lazy};t.props.children&&(s.children=xe(t.props.children,a)),r.push(s)}),r}var ve="get",be="application/x-www-form-urlencoded";function we(e){return null!=e&&"string"===typeof e.tagName}var ke=null;var Se=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function je(e){return null==e||Se.has(e)?e:(a(!1,`"${e}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${be}"`),null)}function $e(e,t){let n,r,i,o,a;if(we(s=e)&&"form"===s.tagName.toLowerCase()){let a=e.getAttribute("action");r=a?P(a,t):null,n=e.getAttribute("method")||ve,i=je(e.getAttribute("enctype"))||be,o=new FormData(e)}else if(function(e){return we(e)&&"button"===e.tagName.toLowerCase()}(e)||function(e){return we(e)&&"input"===e.tagName.toLowerCase()}(e)&&("submit"===e.type||"image"===e.type)){let a=e.form;if(null==a)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let s=e.getAttribute("formaction")||a.getAttribute("action");if(r=s?P(s,t):null,n=e.getAttribute("formmethod")||a.getAttribute("method")||ve,i=je(e.getAttribute("formenctype"))||je(a.getAttribute("enctype"))||be,o=new FormData(a,e),!function(){if(null===ke)try{new FormData(document.createElement("form"),0),ke=!1}catch(e){ke=!0}return ke}()){let{name:t,type:n,value:r}=e;if("image"===n){let e=t?`${t}.`:"";o.append(`${e}x`,"0"),o.append(`${e}y`,"0")}else t&&o.append(t,r)}}else{if(we(e))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');n=ve,r=null,i=be,a=e}var s;return o&&"text/plain"===i&&(a=o,o=void 0),{action:r,method:n.toLowerCase(),encType:i,formData:o,body:a}}function Ce(e,t){if(!1===e||null===e||"undefined"===typeof e)throw new Error(t)}async function Ee(e,t){if(e.id in t)return t[e.id];try{let n=await import(e.module);return t[e.id]=n,n}catch(n){return console.error(`Error loading route module \`${e.module}\`, reloading page...`),console.error(n),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function Te(e){return null!=e&&"string"===typeof e.page}function Pe(e){return null!=e&&(null==e.href?"preload"===e.rel&&"string"===typeof e.imageSrcSet&&"string"===typeof e.imageSizes:"string"===typeof e.rel&&"string"===typeof e.href)}function ze(e,t,n,r,i,o){let a=(e,t)=>!n[t]||e.route.id!==n[t].route.id,s=(e,t)=>n[t].pathname!==e.pathname||n[t].route.path?.endsWith("*")&&n[t].params["*"]!==e.params["*"];return"assets"===o?t.filter((e,t)=>a(e,t)||s(e,t)):"data"===o?t.filter((t,o)=>{let l=r.routes[t.route.id];if(!l||!l.hasLoader)return!1;if(a(t,o)||s(t,o))return!0;if(t.route.shouldRevalidate){let r=t.route.shouldRevalidate({currentUrl:new URL(i.pathname+i.search+i.hash,window.origin),currentParams:n[0]?.params||{},nextUrl:new URL(e,window.origin),nextParams:t.params,defaultShouldRevalidate:!0});if("boolean"===typeof r)return r}return!0}):[]}function Ae(e,t){let{includeHydrateFallback:n}=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};return r=e.map(e=>{let r=t.routes[e.route.id];if(!r)return[];let i=[r.module];return r.clientActionModule&&(i=i.concat(r.clientActionModule)),r.clientLoaderModule&&(i=i.concat(r.clientLoaderModule)),n&&r.hydrateFallbackModule&&(i=i.concat(r.hydrateFallbackModule)),r.imports&&(i=i.concat(r.imports)),i}).flat(1),[...new Set(r)];var r}function Re(e,t){let n=new Set,r=new Set(t);return e.reduce((e,i)=>{if(t&&!Te(i)&&"script"===i.as&&i.href&&r.has(i.href))return e;let o=JSON.stringify(function(e){let t={},n=Object.keys(e).sort();for(let r of n)t[r]=e[r];return t}(i));return n.has(o)||(n.add(o),e.push({key:o,link:i})),e},[])}function Me(e){return{__html:e}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");"undefined"!==typeof window?window:"undefined"!==typeof globalThis&&globalThis;Symbol("SingleFetchRedirect");var Le=new Set([100,101,204,205]);function De(e,t){let n="string"===typeof e?new URL(e,"undefined"===typeof window?"server://singlefetch/":window.location.origin):e;return"/"===n.pathname?n.pathname="_root.data":t&&"/"===P(n.pathname,t)?n.pathname=`${t.replace(/\/$/,"")}/_root.data`:n.pathname=`${n.pathname.replace(/\/$/,"")}.data`,n}e.Component;function Oe(t){let{error:n,isOutsideRemixApp:r}=t;console.error(n);let i,o=e.createElement("script",{dangerouslySetInnerHTML:{__html:'\n        console.log(\n          "\ud83d\udcbf Hey developer \ud83d\udc4b. You can provide a way better UX than this when your app throws errors. Check out https://reactrouter.com/how-to/error-boundary for more information."\n        );\n      '}});if(N(n))return e.createElement(Fe,{title:"Unhandled Thrown Response!"},e.createElement("h1",{style:{fontSize:"24px"}},n.status," ",n.statusText),o);if(n instanceof Error)0;else{let e=null==n?"Unknown Error":"object"===typeof n&&"toString"in n?n.toString():JSON.stringify(n);new Error(e)}return e.createElement(Fe,{title:"Application Error!",isOutsideRemixApp:r},e.createElement("h1",{style:{fontSize:"24px"}},"Application Error"),e.createElement("pre",{style:{padding:"2rem",background:"hsla(10, 50%, 50%, 0.1)",color:"red",overflow:"auto"}},i.stack),o)}function Fe(t){let{title:n,renderScripts:r,isOutsideRemixApp:i,children:o}=t,{routeModules:a}=Be();return a.root?.Layout&&!i?o:e.createElement("html",{lang:"en"},e.createElement("head",null,e.createElement("meta",{charSet:"utf-8"}),e.createElement("meta",{name:"viewport",content:"width=device-width,initial-scale=1,viewport-fit=cover"}),e.createElement("title",null,n)),e.createElement("body",null,e.createElement("main",{style:{fontFamily:"system-ui, sans-serif",padding:"2rem"}},o,r?e.createElement(Ge,null):null)))}function Ne(e,t){return"lazy"===e.mode&&!0===t}function _e(){let t=e.useContext(V);return Ce(t,"You must render this element inside a <DataRouterContext.Provider> element"),t}function Ie(){let t=e.useContext(B);return Ce(t,"You must render this element inside a <DataRouterStateContext.Provider> element"),t}var Ve=e.createContext(void 0);function Be(){let t=e.useContext(Ve);return Ce(t,"You must render this element inside a <HydratedRouter> element"),t}function We(e,t){return n=>{e&&e(n),n.defaultPrevented||t(n)}}function He(e,t,n){if(n&&!Ke)return[e[0]];if(t){let n=e.findIndex(e=>void 0!==t[e.route.id]);return e.slice(0,n+1)}return e}function Ue(t){let{page:n,...r}=t,{router:i}=_e(),o=e.useMemo(()=>p(i.routes,n,i.basename),[i.routes,n,i.basename]);return o?e.createElement(Ye,{page:n,matches:o,...r}):null}function qe(t){let{manifest:n,routeModules:r}=Be(),[i,o]=e.useState([]);return e.useEffect(()=>{let e=!1;return async function(e,t,n){let r=await Promise.all(e.map(async e=>{let r=t.routes[e.route.id];if(r){let e=await Ee(r,n);return e.links?e.links():[]}return[]}));return Re(r.flat(1).filter(Pe).filter(e=>"stylesheet"===e.rel||"preload"===e.rel).map(e=>"stylesheet"===e.rel?{...e,rel:"prefetch",as:"style"}:{...e,rel:"prefetch"}))}(t,n,r).then(t=>{e||o(t)}),()=>{e=!0}},[t,n,r]),i}function Ye(t){let{page:n,matches:r,...i}=t,o=Q(),{manifest:a,routeModules:s}=Be(),{basename:l}=_e(),{loaderData:c,matches:u}=Ie(),d=e.useMemo(()=>ze(n,r,u,a,o,"data"),[n,r,u,a,o]),h=e.useMemo(()=>ze(n,r,u,a,o,"assets"),[n,r,u,a,o]),p=e.useMemo(()=>{if(n===o.pathname+o.search+o.hash)return[];let e=new Set,t=!1;if(r.forEach(n=>{let r=a.routes[n.route.id];r&&r.hasLoader&&(!d.some(e=>e.route.id===n.route.id)&&n.route.id in c&&s[n.route.id]?.shouldRevalidate||r.hasClientLoader?t=!0:e.add(n.route.id))}),0===e.size)return[];let i=De(n,l);return t&&e.size>0&&i.searchParams.set("_routes",r.filter(t=>e.has(t.route.id)).map(e=>e.route.id).join(",")),[i.pathname+i.search]},[l,c,o,a,d,r,n,s]),m=e.useMemo(()=>Ae(h,a),[h,a]),f=qe(h);return e.createElement(e.Fragment,null,p.map(t=>e.createElement("link",{key:t,rel:"prefetch",as:"fetch",href:t,...i})),m.map(t=>e.createElement("link",{key:t,rel:"modulepreload",href:t,...i})),f.map(t=>{let{key:n,link:r}=t;return e.createElement("link",{key:n,...r})}))}Ve.displayName="FrameworkContext";var Ke=!1;function Ge(t){let{manifest:n,serverHandoffString:r,isSpaMode:i,renderMeta:o,routeDiscovery:a,ssr:s}=Be(),{router:l,static:c,staticContext:u}=_e(),{matches:d}=Ie(),h=Ne(a,s);o&&(o.didRenderScripts=!0);let m=He(d,null,i);e.useEffect(()=>{0},[]);let f=e.useMemo(()=>{let i=u?`window.__reactRouterContext = ${r};window.__reactRouterContext.stream = new ReadableStream({start(controller){window.__reactRouterContext.streamController = controller;}}).pipeThrough(new TextEncoderStream());`:" ",o=c?`${n.hmr?.runtime?`import ${JSON.stringify(n.hmr.runtime)};`:""}${h?"":`import ${JSON.stringify(n.url)}`};\n${m.map((e,t)=>{let r=`route${t}`,i=n.routes[e.route.id];Ce(i,`Route ${e.route.id} not found in manifest`);let{clientActionModule:o,clientLoaderModule:a,clientMiddlewareModule:s,hydrateFallbackModule:l,module:c}=i,u=[...o?[{module:o,varName:`${r}_clientAction`}]:[],...a?[{module:a,varName:`${r}_clientLoader`}]:[],...s?[{module:s,varName:`${r}_clientMiddleware`}]:[],...l?[{module:l,varName:`${r}_HydrateFallback`}]:[],{module:c,varName:`${r}_main`}];return 1===u.length?`import * as ${r} from ${JSON.stringify(c)};`:[u.map(e=>`import * as ${e.varName} from "${e.module}";`).join("\n"),`const ${r} = {${u.map(e=>`...${e.varName}`).join(",")}};`].join("\n")}).join("\n")}\n  ${h?`window.__reactRouterManifest = ${JSON.stringify(function(e,t){let{sri:n,...r}=e,i=new Set(t.state.matches.map(e=>e.route.id)),o=t.state.location.pathname.split("/").filter(Boolean),a=["/"];for(o.pop();o.length>0;)a.push(`/${o.join("/")}`),o.pop();a.forEach(e=>{let n=p(t.routes,e,t.basename);n&&n.forEach(e=>i.add(e.route.id))});let s=[...i].reduce((e,t)=>Object.assign(e,{[t]:r.routes[t]}),{});return{...r,routes:s,sri:!!n||void 0}}(n,l),null,2)};`:""}\n  window.__reactRouterRouteModules = {${m.map((e,t)=>`${JSON.stringify(e.route.id)}:route${t}`).join(",")}};\n\nimport(${JSON.stringify(n.entry.module)});`:" ";return e.createElement(e.Fragment,null,e.createElement("script",{...t,suppressHydrationWarning:!0,dangerouslySetInnerHTML:Me(i),type:void 0}),e.createElement("script",{...t,suppressHydrationWarning:!0,dangerouslySetInnerHTML:Me(o),type:"module",async:!0}))},[]),g=Ke?[]:(n.entry.imports.concat(Ae(m,n,{includeHydrateFallback:!0})),[...new Set(y)]);var y;let x="object"===typeof n.sri?n.sri:{};return Ke?null:e.createElement(e.Fragment,null,"object"===typeof n.sri?e.createElement("script",{"rr-importmap":"",type:"importmap",suppressHydrationWarning:!0,dangerouslySetInnerHTML:{__html:JSON.stringify({integrity:x})}}):null,h?null:e.createElement("link",{rel:"modulepreload",href:n.url,crossOrigin:t.crossOrigin,integrity:x[n.url],suppressHydrationWarning:!0}),e.createElement("link",{rel:"modulepreload",href:n.entry.module,crossOrigin:t.crossOrigin,integrity:x[n.entry.module],suppressHydrationWarning:!0}),g.map(n=>e.createElement("link",{key:n,rel:"modulepreload",href:n,crossOrigin:t.crossOrigin,integrity:x[n],suppressHydrationWarning:!0})),f)}function Xe(){for(var e=arguments.length,t=new Array(e),n=0;n<e;n++)t[n]=arguments[n];return e=>{t.forEach(t=>{"function"===typeof t?t(e):null!=t&&(t.current=e)})}}var Qe="undefined"!==typeof window&&"undefined"!==typeof window.document&&"undefined"!==typeof window.document.createElement;try{Qe&&(window.__reactRouterVersion="7.6.3")}catch(w$){}function Je(t){let{basename:n,children:r,window:o}=t,a=e.useRef();null==a.current&&(a.current=i({window:o,v5Compat:!0}));let s=a.current,[l,c]=e.useState({action:s.action,location:s.location}),u=e.useCallback(t=>{e.startTransition(()=>c(t))},[c]);return e.useLayoutEffect(()=>s.listen(u),[s,u]),e.createElement(ge,{basename:n,children:r,location:l.location,navigationType:l.action,navigator:s})}var Ze=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,et=e.forwardRef(function(t,n){let r,{onClick:i,discover:s="render",prefetch:l="none",relative:u,reloadDocument:d,replace:h,state:p,target:m,to:f,preventScrollReset:g,viewTransition:y,...x}=t,{basename:v}=e.useContext(q),b="string"===typeof f&&Ze.test(f),w=!1;if("string"===typeof f&&b&&(r=f,Qe))try{let e=new URL(window.location.href),t=f.startsWith("//")?new URL(e.protocol+f):new URL(f),n=P(t.pathname,v);t.origin===e.origin&&null!=n?f=n+t.search+t.hash:w=!0}catch(w$){a(!1,`<Link to="${f}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}let k=function(t){let{relative:n}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};o(X(),"useHref() may be used only in the context of a <Router> component.");let{basename:r,navigator:i}=e.useContext(q),{hash:a,pathname:s,search:l}=te(t,{relative:n}),c=s;return"/"!==r&&(c="/"===s?r:L([r,s])),i.createHref({pathname:c,search:l,hash:a})}(f,{relative:u}),[S,j,$]=function(t,n){let r=e.useContext(Ve),[i,o]=e.useState(!1),[a,s]=e.useState(!1),{onFocus:l,onBlur:c,onMouseEnter:u,onMouseLeave:d,onTouchStart:h}=n,p=e.useRef(null);e.useEffect(()=>{if("render"===t&&s(!0),"viewport"===t){let e=new IntersectionObserver(e=>{e.forEach(e=>{s(e.isIntersecting)})},{threshold:.5});return p.current&&e.observe(p.current),()=>{e.disconnect()}}},[t]),e.useEffect(()=>{if(i){let e=setTimeout(()=>{s(!0)},100);return()=>{clearTimeout(e)}}},[i]);let m=()=>{o(!0)},f=()=>{o(!1),s(!1)};return r?"intent"!==t?[a,p,{}]:[a,p,{onFocus:We(l,m),onBlur:We(c,f),onMouseEnter:We(u,m),onMouseLeave:We(d,f),onTouchStart:We(h,m)}]:[!1,p,{}]}(l,x),C=function(t){let{target:n,replace:r,state:i,preventScrollReset:o,relative:a,viewTransition:s}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},l=ee(),u=Q(),d=te(t,{relative:a});return e.useCallback(e=>{if(function(e,t){return 0===e.button&&(!t||"_self"===t)&&!function(e){return!!(e.metaKey||e.altKey||e.ctrlKey||e.shiftKey)}(e)}(e,n)){e.preventDefault();let n=void 0!==r?r:c(u)===c(d);l(t,{replace:n,state:i,preventScrollReset:o,relative:a,viewTransition:s})}},[u,l,d,r,i,n,t,o,a,s])}(f,{replace:h,state:p,target:m,preventScrollReset:g,relative:u,viewTransition:y});let E=e.createElement("a",{...x,...$,href:r||k,onClick:w||d?i:function(e){i&&i(e),e.defaultPrevented||C(e)},ref:Xe(n,j),target:m,"data-discover":b||"render"!==s?void 0:"true"});return S&&!b?e.createElement(e.Fragment,null,E,e.createElement(Ue,{page:k})):E});et.displayName="Link";var tt=e.forwardRef(function(t,n){let{"aria-current":r="page",caseSensitive:i=!1,className:a="",end:s=!1,style:l,to:c,viewTransition:u,children:d,...h}=t,p=te(c,{relative:h.relative}),m=Q(),f=e.useContext(B),{navigator:g,basename:y}=e.useContext(q),x=null!=f&&function(t){let n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},r=e.useContext(W);o(null!=r,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:i}=it("useViewTransitionState"),a=te(t,{relative:n.relative});if(!r.isTransitioning)return!1;let s=P(r.currentLocation.pathname,i)||r.currentLocation.pathname,l=P(r.nextLocation.pathname,i)||r.nextLocation.pathname;return null!=C(a.pathname,l)||null!=C(a.pathname,s)}(p)&&!0===u,v=g.encodeLocation?g.encodeLocation(p).pathname:p.pathname,b=m.pathname,w=f&&f.navigation&&f.navigation.location?f.navigation.location.pathname:null;i||(b=b.toLowerCase(),w=w?w.toLowerCase():null,v=v.toLowerCase()),w&&y&&(w=P(w,y)||w);const k="/"!==v&&v.endsWith("/")?v.length-1:v.length;let S,j=b===v||!s&&b.startsWith(v)&&"/"===b.charAt(k),$=null!=w&&(w===v||!s&&w.startsWith(v)&&"/"===w.charAt(v.length)),E={isActive:j,isPending:$,isTransitioning:x},T=j?r:void 0;S="function"===typeof a?a(E):[a,j?"active":null,$?"pending":null,x?"transitioning":null].filter(Boolean).join(" ");let z="function"===typeof l?l(E):l;return e.createElement(et,{...h,"aria-current":T,className:S,ref:n,style:z,to:c,viewTransition:u},"function"===typeof d?d(E):d)});tt.displayName="NavLink";var nt=e.forwardRef((t,n)=>{let{discover:r="render",fetcherKey:i,navigate:a,reloadDocument:s,replace:l,state:u,method:d=ve,action:h,onSubmit:p,relative:m,preventScrollReset:f,viewTransition:g,...y}=t,x=st(),v=function(t){let{relative:n}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},{basename:r}=e.useContext(q),i=e.useContext(K);o(i,"useFormAction must be used inside a RouteContext");let[a]=i.matches.slice(-1),s={...te(t||".",{relative:n})},l=Q();if(null==t){s.search=l.search;let e=new URLSearchParams(s.search),t=e.getAll("index"),n=t.some(e=>""===e);if(n){e.delete("index"),t.filter(e=>e).forEach(t=>e.append("index",t));let n=e.toString();s.search=n?`?${n}`:""}}t&&"."!==t||!a.route.index||(s.search=s.search?s.search.replace(/^\?/,"?index&"):"?index");"/"!==r&&(s.pathname="/"===s.pathname?r:L([r,s.pathname]));return c(s)}(h,{relative:m}),b="get"===d.toLowerCase()?"get":"post",w="string"===typeof h&&Ze.test(h);return e.createElement("form",{ref:n,method:b,action:v,onSubmit:s?p:e=>{if(p&&p(e),e.defaultPrevented)return;e.preventDefault();let t=e.nativeEvent.submitter,n=t?.getAttribute("formmethod")||d;x(t||e.currentTarget,{fetcherKey:i,method:n,navigate:a,replace:l,state:u,relative:m,preventScrollReset:f,viewTransition:g})},...y,"data-discover":w||"render"!==r?void 0:"true"})});function rt(e){return`${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function it(t){let n=e.useContext(V);return o(n,rt(t)),n}nt.displayName="Form";var ot=0,at=()=>`__${String(++ot)}__`;function st(){let{router:t}=it("useSubmit"),{basename:n}=e.useContext(q),r=de("useRouteId");return e.useCallback(async function(e){let i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},{action:o,method:a,encType:s,formData:l,body:c}=$e(e,n);if(!1===i.navigate){let e=i.fetcherKey||at();await t.fetch(e,r,i.action||o,{preventScrollReset:i.preventScrollReset,formData:l,body:c,formMethod:i.method||a,formEncType:i.encType||s,flushSync:i.flushSync})}else await t.navigate(i.action||o,{preventScrollReset:i.preventScrollReset,formData:l,body:c,formMethod:i.method||a,formEncType:i.encType||s,replace:i.replace,state:i.state,fromRouteId:r,flushSync:i.flushSync,viewTransition:i.viewTransition})},[t,n,r])}var lt=function(){return lt=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e},lt.apply(this,arguments)};Object.create;function ct(e,t,n){if(n||2===arguments.length)for(var r,i=0,o=t.length;i<o;i++)!r&&i in t||(r||(r=Array.prototype.slice.call(t,0,i)),r[i]=t[i]);return e.concat(r||Array.prototype.slice.call(t))}Object.create;"function"===typeof SuppressedError&&SuppressedError;var ut=n(324),dt=n.n(ut),ht="-ms-",pt="-moz-",mt="-webkit-",ft="comm",gt="rule",yt="decl",xt="@keyframes",vt=Math.abs,bt=String.fromCharCode,wt=Object.assign;function kt(e){return e.trim()}function St(e,t){return(e=t.exec(e))?e[0]:e}function jt(e,t,n){return e.replace(t,n)}function $t(e,t,n){return e.indexOf(t,n)}function Ct(e,t){return 0|e.charCodeAt(t)}function Et(e,t,n){return e.slice(t,n)}function Tt(e){return e.length}function Pt(e){return e.length}function zt(e,t){return t.push(e),e}function At(e,t){return e.filter(function(e){return!St(e,t)})}var Rt=1,Mt=1,Lt=0,Dt=0,Ot=0,Ft="";function Nt(e,t,n,r,i,o,a,s){return{value:e,root:t,parent:n,type:r,props:i,children:o,line:Rt,column:Mt,length:a,return:"",siblings:s}}function _t(e,t){return wt(Nt("",null,null,"",null,null,0,e.siblings),e,{length:-e.length},t)}function It(e){for(;e.root;)e=_t(e.root,{children:[e]});zt(e,e.siblings)}function Vt(){return Ot=Dt>0?Ct(Ft,--Dt):0,Mt--,10===Ot&&(Mt=1,Rt--),Ot}function Bt(){return Ot=Dt<Lt?Ct(Ft,Dt++):0,Mt++,10===Ot&&(Mt=1,Rt++),Ot}function Wt(){return Ct(Ft,Dt)}function Ht(){return Dt}function Ut(e,t){return Et(Ft,e,t)}function qt(e){switch(e){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function Yt(e){return Rt=Mt=1,Lt=Tt(Ft=e),Dt=0,[]}function Kt(e){return Ft="",e}function Gt(e){return kt(Ut(Dt-1,Jt(91===e?e+2:40===e?e+1:e)))}function Xt(e){for(;(Ot=Wt())&&Ot<33;)Bt();return qt(e)>2||qt(Ot)>3?"":" "}function Qt(e,t){for(;--t&&Bt()&&!(Ot<48||Ot>102||Ot>57&&Ot<65||Ot>70&&Ot<97););return Ut(e,Ht()+(t<6&&32==Wt()&&32==Bt()))}function Jt(e){for(;Bt();)switch(Ot){case e:return Dt;case 34:case 39:34!==e&&39!==e&&Jt(Ot);break;case 40:41===e&&Jt(e);break;case 92:Bt()}return Dt}function Zt(e,t){for(;Bt()&&e+Ot!==57&&(e+Ot!==84||47!==Wt()););return"/*"+Ut(t,Dt-1)+"*"+bt(47===e?e:Bt())}function en(e){for(;!qt(Wt());)Bt();return Ut(e,Dt)}function tn(e,t){for(var n="",r=0;r<e.length;r++)n+=t(e[r],r,e,t)||"";return n}function nn(e,t,n,r){switch(e.type){case"@layer":if(e.children.length)break;case"@import":case yt:return e.return=e.return||e.value;case ft:return"";case xt:return e.return=e.value+"{"+tn(e.children,r)+"}";case gt:if(!Tt(e.value=e.props.join(",")))return""}return Tt(n=tn(e.children,r))?e.return=e.value+"{"+n+"}":""}function rn(e,t,n){switch(function(e,t){return 45^Ct(e,0)?(((t<<2^Ct(e,0))<<2^Ct(e,1))<<2^Ct(e,2))<<2^Ct(e,3):0}(e,t)){case 5103:return mt+"print-"+e+e;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 6391:case 5879:case 5623:case 6135:case 4599:case 4855:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:return mt+e+e;case 4789:return pt+e+e;case 5349:case 4246:case 4810:case 6968:case 2756:return mt+e+pt+e+ht+e+e;case 5936:switch(Ct(e,t+11)){case 114:return mt+e+ht+jt(e,/[svh]\w+-[tblr]{2}/,"tb")+e;case 108:return mt+e+ht+jt(e,/[svh]\w+-[tblr]{2}/,"tb-rl")+e;case 45:return mt+e+ht+jt(e,/[svh]\w+-[tblr]{2}/,"lr")+e}case 6828:case 4268:case 2903:return mt+e+ht+e+e;case 6165:return mt+e+ht+"flex-"+e+e;case 5187:return mt+e+jt(e,/(\w+).+(:[^]+)/,mt+"box-$1$2"+ht+"flex-$1$2")+e;case 5443:return mt+e+ht+"flex-item-"+jt(e,/flex-|-self/g,"")+(St(e,/flex-|baseline/)?"":ht+"grid-row-"+jt(e,/flex-|-self/g,""))+e;case 4675:return mt+e+ht+"flex-line-pack"+jt(e,/align-content|flex-|-self/g,"")+e;case 5548:return mt+e+ht+jt(e,"shrink","negative")+e;case 5292:return mt+e+ht+jt(e,"basis","preferred-size")+e;case 6060:return mt+"box-"+jt(e,"-grow","")+mt+e+ht+jt(e,"grow","positive")+e;case 4554:return mt+jt(e,/([^-])(transform)/g,"$1"+mt+"$2")+e;case 6187:return jt(jt(jt(e,/(zoom-|grab)/,mt+"$1"),/(image-set)/,mt+"$1"),e,"")+e;case 5495:case 3959:return jt(e,/(image-set\([^]*)/,mt+"$1$`$1");case 4968:return jt(jt(e,/(.+:)(flex-)?(.*)/,mt+"box-pack:$3"+ht+"flex-pack:$3"),/s.+-b[^;]+/,"justify")+mt+e+e;case 4200:if(!St(e,/flex-|baseline/))return ht+"grid-column-align"+Et(e,t)+e;break;case 2592:case 3360:return ht+jt(e,"template-","")+e;case 4384:case 3616:return n&&n.some(function(e,n){return t=n,St(e.props,/grid-\w+-end/)})?~$t(e+(n=n[t].value),"span",0)?e:ht+jt(e,"-start","")+e+ht+"grid-row-span:"+(~$t(n,"span",0)?St(n,/\d+/):+St(n,/\d+/)-+St(e,/\d+/))+";":ht+jt(e,"-start","")+e;case 4896:case 4128:return n&&n.some(function(e){return St(e.props,/grid-\w+-start/)})?e:ht+jt(jt(e,"-end","-span"),"span ","")+e;case 4095:case 3583:case 4068:case 2532:return jt(e,/(.+)-inline(.+)/,mt+"$1$2")+e;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(Tt(e)-1-t>6)switch(Ct(e,t+1)){case 109:if(45!==Ct(e,t+4))break;case 102:return jt(e,/(.+:)(.+)-([^]+)/,"$1"+mt+"$2-$3$1"+pt+(108==Ct(e,t+3)?"$3":"$2-$3"))+e;case 115:return~$t(e,"stretch",0)?rn(jt(e,"stretch","fill-available"),t,n)+e:e}break;case 5152:case 5920:return jt(e,/(.+?):(\d+)(\s*\/\s*(span)?\s*(\d+))?(.*)/,function(t,n,r,i,o,a,s){return ht+n+":"+r+s+(i?ht+n+"-span:"+(o?a:+a-+r)+s:"")+e});case 4949:if(121===Ct(e,t+6))return jt(e,":",":"+mt)+e;break;case 6444:switch(Ct(e,45===Ct(e,14)?18:11)){case 120:return jt(e,/(.+:)([^;\s!]+)(;|(\s+)?!.+)?/,"$1"+mt+(45===Ct(e,14)?"inline-":"")+"box$3$1"+mt+"$2$3$1"+ht+"$2box$3")+e;case 100:return jt(e,":",":"+ht)+e}break;case 5719:case 2647:case 2135:case 3927:case 2391:return jt(e,"scroll-","scroll-snap-")+e}return e}function on(e,t,n,r){if(e.length>-1&&!e.return)switch(e.type){case yt:return void(e.return=rn(e.value,e.length,n));case xt:return tn([_t(e,{value:jt(e.value,"@","@"+mt)})],r);case gt:if(e.length)return function(e,t){return e.map(t).join("")}(n=e.props,function(t){switch(St(t,r=/(::plac\w+|:read-\w+)/)){case":read-only":case":read-write":It(_t(e,{props:[jt(t,/:(read-\w+)/,":-moz-$1")]})),It(_t(e,{props:[t]})),wt(e,{props:At(n,r)});break;case"::placeholder":It(_t(e,{props:[jt(t,/:(plac\w+)/,":"+mt+"input-$1")]})),It(_t(e,{props:[jt(t,/:(plac\w+)/,":-moz-$1")]})),It(_t(e,{props:[jt(t,/:(plac\w+)/,ht+"input-$1")]})),It(_t(e,{props:[t]})),wt(e,{props:At(n,r)})}return""})}}function an(e){return Kt(sn("",null,null,null,[""],e=Yt(e),0,[0],e))}function sn(e,t,n,r,i,o,a,s,l){for(var c=0,u=0,d=a,h=0,p=0,m=0,f=1,g=1,y=1,x=0,v="",b=i,w=o,k=r,S=v;g;)switch(m=x,x=Bt()){case 40:if(108!=m&&58==Ct(S,d-1)){-1!=$t(S+=jt(Gt(x),"&","&\f"),"&\f",vt(c?s[c-1]:0))&&(y=-1);break}case 34:case 39:case 91:S+=Gt(x);break;case 9:case 10:case 13:case 32:S+=Xt(m);break;case 92:S+=Qt(Ht()-1,7);continue;case 47:switch(Wt()){case 42:case 47:zt(cn(Zt(Bt(),Ht()),t,n,l),l);break;default:S+="/"}break;case 123*f:s[c++]=Tt(S)*y;case 125*f:case 59:case 0:switch(x){case 0:case 125:g=0;case 59+u:-1==y&&(S=jt(S,/\f/g,"")),p>0&&Tt(S)-d&&zt(p>32?un(S+";",r,n,d-1,l):un(jt(S," ","")+";",r,n,d-2,l),l);break;case 59:S+=";";default:if(zt(k=ln(S,t,n,c,u,i,s,v,b=[],w=[],d,o),o),123===x)if(0===u)sn(S,t,k,k,b,o,d,s,w);else switch(99===h&&110===Ct(S,3)?100:h){case 100:case 108:case 109:case 115:sn(e,k,k,r&&zt(ln(e,k,k,0,0,i,s,v,i,b=[],d,w),w),i,w,d,s,r?b:w);break;default:sn(S,k,k,k,[""],w,0,s,w)}}c=u=p=0,f=y=1,v=S="",d=a;break;case 58:d=1+Tt(S),p=m;default:if(f<1)if(123==x)--f;else if(125==x&&0==f++&&125==Vt())continue;switch(S+=bt(x),x*f){case 38:y=u>0?1:(S+="\f",-1);break;case 44:s[c++]=(Tt(S)-1)*y,y=1;break;case 64:45===Wt()&&(S+=Gt(Bt())),h=Wt(),u=d=Tt(v=S+=en(Ht())),x++;break;case 45:45===m&&2==Tt(S)&&(f=0)}}return o}function ln(e,t,n,r,i,o,a,s,l,c,u,d){for(var h=i-1,p=0===i?o:[""],m=Pt(p),f=0,g=0,y=0;f<r;++f)for(var x=0,v=Et(e,h+1,h=vt(g=a[f])),b=e;x<m;++x)(b=kt(g>0?p[x]+" "+v:jt(v,/&\f/g,p[x])))&&(l[y++]=b);return Nt(e,t,n,0===i?gt:s,l,c,u,d)}function cn(e,t,n,r){return Nt(e,t,n,ft,bt(Ot),Et(e,2,-2),0,r)}function un(e,t,n,r,i){return Nt(e,t,n,yt,Et(e,0,r),Et(e,r+1,-1),r,i)}var dn={animationIterationCount:1,aspectRatio:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1},hn="undefined"!=typeof process&&void 0!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}&&({NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}.REACT_APP_SC_ATTR||{NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}.SC_ATTR)||"data-styled",pn="active",mn="data-styled-version",fn="6.1.19",gn="/*!sc*/\n",yn="undefined"!=typeof window&&"undefined"!=typeof document,xn=Boolean("boolean"==typeof SC_DISABLE_SPEEDY?SC_DISABLE_SPEEDY:"undefined"!=typeof process&&void 0!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}&&void 0!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}.REACT_APP_SC_DISABLE_SPEEDY&&""!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}.REACT_APP_SC_DISABLE_SPEEDY?"false"!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}.REACT_APP_SC_DISABLE_SPEEDY&&{NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}.REACT_APP_SC_DISABLE_SPEEDY:"undefined"!=typeof process&&void 0!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}&&void 0!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}.SC_DISABLE_SPEEDY&&""!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}.SC_DISABLE_SPEEDY&&("false"!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}.SC_DISABLE_SPEEDY&&{NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0}.SC_DISABLE_SPEEDY)),vn={},bn=(new Set,Object.freeze([])),wn=Object.freeze({});function kn(e,t,n){return void 0===n&&(n=wn),e.theme!==n.theme&&e.theme||t||n.theme}var Sn=new Set(["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","tr","track","u","ul","use","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","tspan"]),jn=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,$n=/(^-|-$)/g;function Cn(e){return e.replace(jn,"-").replace($n,"")}var En=/(a)(d)/gi,Tn=function(e){return String.fromCharCode(e+(e>25?39:97))};function Pn(e){var t,n="";for(t=Math.abs(e);t>52;t=t/52|0)n=Tn(t%52)+n;return(Tn(t%52)+n).replace(En,"$1-$2")}var zn,An=function(e,t){for(var n=t.length;n;)e=33*e^t.charCodeAt(--n);return e},Rn=function(e){return An(5381,e)};function Mn(e){return Pn(Rn(e)>>>0)}function Ln(e){return e.displayName||e.name||"Component"}function Dn(e){return"string"==typeof e&&!0}var On="function"==typeof Symbol&&Symbol.for,Fn=On?Symbol.for("react.memo"):60115,Nn=On?Symbol.for("react.forward_ref"):60112,_n={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},In={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},Vn={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},Bn=((zn={})[Nn]={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},zn[Fn]=Vn,zn);function Wn(e){return("type"in(t=e)&&t.type.$$typeof)===Fn?Vn:"$$typeof"in e?Bn[e.$$typeof]:_n;var t}var Hn=Object.defineProperty,Un=Object.getOwnPropertyNames,qn=Object.getOwnPropertySymbols,Yn=Object.getOwnPropertyDescriptor,Kn=Object.getPrototypeOf,Gn=Object.prototype;function Xn(e,t,n){if("string"!=typeof t){if(Gn){var r=Kn(t);r&&r!==Gn&&Xn(e,r,n)}var i=Un(t);qn&&(i=i.concat(qn(t)));for(var o=Wn(e),a=Wn(t),s=0;s<i.length;++s){var l=i[s];if(!(l in In||n&&n[l]||a&&l in a||o&&l in o)){var c=Yn(t,l);try{Hn(e,l,c)}catch(e){}}}}return e}function Qn(e){return"function"==typeof e}function Jn(e){return"object"==typeof e&&"styledComponentId"in e}function Zn(e,t){return e&&t?"".concat(e," ").concat(t):e||t||""}function er(e,t){if(0===e.length)return"";for(var n=e[0],r=1;r<e.length;r++)n+=t?t+e[r]:e[r];return n}function tr(e){return null!==e&&"object"==typeof e&&e.constructor.name===Object.name&&!("props"in e&&e.$$typeof)}function nr(e,t,n){if(void 0===n&&(n=!1),!n&&!tr(e)&&!Array.isArray(e))return t;if(Array.isArray(t))for(var r=0;r<t.length;r++)e[r]=nr(e[r],t[r]);else if(tr(t))for(var r in t)e[r]=nr(e[r],t[r]);return e}function rr(e,t){Object.defineProperty(e,"toString",{value:t})}function ir(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];return new Error("An error occurred. See https://github.com/styled-components/styled-components/blob/main/packages/styled-components/src/utils/errors.md#".concat(e," for more information.").concat(t.length>0?" Args: ".concat(t.join(", ")):""))}var or=function(){function e(e){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=e}return e.prototype.indexOfGroup=function(e){for(var t=0,n=0;n<e;n++)t+=this.groupSizes[n];return t},e.prototype.insertRules=function(e,t){if(e>=this.groupSizes.length){for(var n=this.groupSizes,r=n.length,i=r;e>=i;)if((i<<=1)<0)throw ir(16,"".concat(e));this.groupSizes=new Uint32Array(i),this.groupSizes.set(n),this.length=i;for(var o=r;o<i;o++)this.groupSizes[o]=0}for(var a=this.indexOfGroup(e+1),s=(o=0,t.length);o<s;o++)this.tag.insertRule(a,t[o])&&(this.groupSizes[e]++,a++)},e.prototype.clearGroup=function(e){if(e<this.length){var t=this.groupSizes[e],n=this.indexOfGroup(e),r=n+t;this.groupSizes[e]=0;for(var i=n;i<r;i++)this.tag.deleteRule(n)}},e.prototype.getGroup=function(e){var t="";if(e>=this.length||0===this.groupSizes[e])return t;for(var n=this.groupSizes[e],r=this.indexOfGroup(e),i=r+n,o=r;o<i;o++)t+="".concat(this.tag.getRule(o)).concat(gn);return t},e}(),ar=new Map,sr=new Map,lr=1,cr=function(e){if(ar.has(e))return ar.get(e);for(;sr.has(lr);)lr++;var t=lr++;return ar.set(e,t),sr.set(t,e),t},ur=function(e,t){lr=t+1,ar.set(e,t),sr.set(t,e)},dr="style[".concat(hn,"][").concat(mn,'="').concat(fn,'"]'),hr=new RegExp("^".concat(hn,'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)')),pr=function(e,t,n){for(var r,i=n.split(","),o=0,a=i.length;o<a;o++)(r=i[o])&&e.registerName(t,r)},mr=function(e,t){for(var n,r=(null!==(n=t.textContent)&&void 0!==n?n:"").split(gn),i=[],o=0,a=r.length;o<a;o++){var s=r[o].trim();if(s){var l=s.match(hr);if(l){var c=0|parseInt(l[1],10),u=l[2];0!==c&&(ur(u,c),pr(e,u,l[3]),e.getTag().insertRules(c,i)),i.length=0}else i.push(s)}}},fr=function(e){for(var t=document.querySelectorAll(dr),n=0,r=t.length;n<r;n++){var i=t[n];i&&i.getAttribute(hn)!==pn&&(mr(e,i),i.parentNode&&i.parentNode.removeChild(i))}};function gr(){return n.nc}var yr=function(e){var t=document.head,n=e||t,r=document.createElement("style"),i=function(e){var t=Array.from(e.querySelectorAll("style[".concat(hn,"]")));return t[t.length-1]}(n),o=void 0!==i?i.nextSibling:null;r.setAttribute(hn,pn),r.setAttribute(mn,fn);var a=gr();return a&&r.setAttribute("nonce",a),n.insertBefore(r,o),r},xr=function(){function e(e){this.element=yr(e),this.element.appendChild(document.createTextNode("")),this.sheet=function(e){if(e.sheet)return e.sheet;for(var t=document.styleSheets,n=0,r=t.length;n<r;n++){var i=t[n];if(i.ownerNode===e)return i}throw ir(17)}(this.element),this.length=0}return e.prototype.insertRule=function(e,t){try{return this.sheet.insertRule(t,e),this.length++,!0}catch(e){return!1}},e.prototype.deleteRule=function(e){this.sheet.deleteRule(e),this.length--},e.prototype.getRule=function(e){var t=this.sheet.cssRules[e];return t&&t.cssText?t.cssText:""},e}(),vr=function(){function e(e){this.element=yr(e),this.nodes=this.element.childNodes,this.length=0}return e.prototype.insertRule=function(e,t){if(e<=this.length&&e>=0){var n=document.createTextNode(t);return this.element.insertBefore(n,this.nodes[e]||null),this.length++,!0}return!1},e.prototype.deleteRule=function(e){this.element.removeChild(this.nodes[e]),this.length--},e.prototype.getRule=function(e){return e<this.length?this.nodes[e].textContent:""},e}(),br=function(){function e(e){this.rules=[],this.length=0}return e.prototype.insertRule=function(e,t){return e<=this.length&&(this.rules.splice(e,0,t),this.length++,!0)},e.prototype.deleteRule=function(e){this.rules.splice(e,1),this.length--},e.prototype.getRule=function(e){return e<this.length?this.rules[e]:""},e}(),wr=yn,kr={isServer:!yn,useCSSOMInjection:!xn},Sr=function(){function e(e,t,n){void 0===e&&(e=wn),void 0===t&&(t={});var r=this;this.options=lt(lt({},kr),e),this.gs=t,this.names=new Map(n),this.server=!!e.isServer,!this.server&&yn&&wr&&(wr=!1,fr(this)),rr(this,function(){return function(e){for(var t=e.getTag(),n=t.length,r="",i=function(n){var i=function(e){return sr.get(e)}(n);if(void 0===i)return"continue";var o=e.names.get(i),a=t.getGroup(n);if(void 0===o||!o.size||0===a.length)return"continue";var s="".concat(hn,".g").concat(n,'[id="').concat(i,'"]'),l="";void 0!==o&&o.forEach(function(e){e.length>0&&(l+="".concat(e,","))}),r+="".concat(a).concat(s,'{content:"').concat(l,'"}').concat(gn)},o=0;o<n;o++)i(o);return r}(r)})}return e.registerId=function(e){return cr(e)},e.prototype.rehydrate=function(){!this.server&&yn&&fr(this)},e.prototype.reconstructWithOptions=function(t,n){return void 0===n&&(n=!0),new e(lt(lt({},this.options),t),this.gs,n&&this.names||void 0)},e.prototype.allocateGSInstance=function(e){return this.gs[e]=(this.gs[e]||0)+1},e.prototype.getTag=function(){return this.tag||(this.tag=(e=function(e){var t=e.useCSSOMInjection,n=e.target;return e.isServer?new br(n):t?new xr(n):new vr(n)}(this.options),new or(e)));var e},e.prototype.hasNameForId=function(e,t){return this.names.has(e)&&this.names.get(e).has(t)},e.prototype.registerName=function(e,t){if(cr(e),this.names.has(e))this.names.get(e).add(t);else{var n=new Set;n.add(t),this.names.set(e,n)}},e.prototype.insertRules=function(e,t,n){this.registerName(e,t),this.getTag().insertRules(cr(e),n)},e.prototype.clearNames=function(e){this.names.has(e)&&this.names.get(e).clear()},e.prototype.clearRules=function(e){this.getTag().clearGroup(cr(e)),this.clearNames(e)},e.prototype.clearTag=function(){this.tag=void 0},e}(),jr=/&/g,$r=/^\s*\/\/.*$/gm;function Cr(e,t){return e.map(function(e){return"rule"===e.type&&(e.value="".concat(t," ").concat(e.value),e.value=e.value.replaceAll(",",",".concat(t," ")),e.props=e.props.map(function(e){return"".concat(t," ").concat(e)})),Array.isArray(e.children)&&"@keyframes"!==e.type&&(e.children=Cr(e.children,t)),e})}function Er(e){var t,n,r,i=void 0===e?wn:e,o=i.options,a=void 0===o?wn:o,s=i.plugins,l=void 0===s?bn:s,c=function(e,r,i){return i.startsWith(n)&&i.endsWith(n)&&i.replaceAll(n,"").length>0?".".concat(t):e},u=l.slice();u.push(function(e){e.type===gt&&e.value.includes("&")&&(e.props[0]=e.props[0].replace(jr,n).replace(r,c))}),a.prefix&&u.push(on),u.push(nn);var d=function(e,i,o,s){void 0===i&&(i=""),void 0===o&&(o=""),void 0===s&&(s="&"),t=s,n=i,r=new RegExp("\\".concat(n,"\\b"),"g");var l=e.replace($r,""),c=an(o||i?"".concat(o," ").concat(i," { ").concat(l," }"):l);a.namespace&&(c=Cr(c,a.namespace));var d,h=[];return tn(c,function(e){var t=Pt(e);return function(n,r,i,o){for(var a="",s=0;s<t;s++)a+=e[s](n,r,i,o)||"";return a}}(u.concat((d=function(e){return h.push(e)},function(e){e.root||(e=e.return)&&d(e)})))),h};return d.hash=l.length?l.reduce(function(e,t){return t.name||ir(15),An(e,t.name)},5381).toString():"",d}var Tr=new Sr,Pr=Er(),zr=e.createContext({shouldForwardProp:void 0,styleSheet:Tr,stylis:Pr}),Ar=(zr.Consumer,e.createContext(void 0));function Rr(){return(0,e.useContext)(zr)}function Mr(t){var n=(0,e.useState)(t.stylisPlugins),r=n[0],i=n[1],o=Rr().styleSheet,a=(0,e.useMemo)(function(){var e=o;return t.sheet?e=t.sheet:t.target&&(e=e.reconstructWithOptions({target:t.target},!1)),t.disableCSSOMInjection&&(e=e.reconstructWithOptions({useCSSOMInjection:!1})),e},[t.disableCSSOMInjection,t.sheet,t.target,o]),s=(0,e.useMemo)(function(){return Er({options:{namespace:t.namespace,prefix:t.enableVendorPrefixes},plugins:r})},[t.enableVendorPrefixes,t.namespace,r]);(0,e.useEffect)(function(){dt()(r,t.stylisPlugins)||i(t.stylisPlugins)},[t.stylisPlugins]);var l=(0,e.useMemo)(function(){return{shouldForwardProp:t.shouldForwardProp,styleSheet:a,stylis:s}},[t.shouldForwardProp,a,s]);return e.createElement(zr.Provider,{value:l},e.createElement(Ar.Provider,{value:s},t.children))}var Lr=function(){function e(e,t){var n=this;this.inject=function(e,t){void 0===t&&(t=Pr);var r=n.name+t.hash;e.hasNameForId(n.id,r)||e.insertRules(n.id,r,t(n.rules,r,"@keyframes"))},this.name=e,this.id="sc-keyframes-".concat(e),this.rules=t,rr(this,function(){throw ir(12,String(n.name))})}return e.prototype.getName=function(e){return void 0===e&&(e=Pr),this.name+e.hash},e}(),Dr=function(e){return e>="A"&&e<="Z"};function Or(e){for(var t="",n=0;n<e.length;n++){var r=e[n];if(1===n&&"-"===r&&"-"===e[0])return e;Dr(r)?t+="-"+r.toLowerCase():t+=r}return t.startsWith("ms-")?"-"+t:t}var Fr=function(e){return null==e||!1===e||""===e},Nr=function(e){var t,n,r=[];for(var i in e){var o=e[i];e.hasOwnProperty(i)&&!Fr(o)&&(Array.isArray(o)&&o.isCss||Qn(o)?r.push("".concat(Or(i),":"),o,";"):tr(o)?r.push.apply(r,ct(ct(["".concat(i," {")],Nr(o),!1),["}"],!1)):r.push("".concat(Or(i),": ").concat((t=i,null==(n=o)||"boolean"==typeof n||""===n?"":"number"!=typeof n||0===n||t in dn||t.startsWith("--")?String(n).trim():"".concat(n,"px")),";")))}return r};function _r(e,t,n,r){return Fr(e)?[]:Jn(e)?[".".concat(e.styledComponentId)]:Qn(e)?!Qn(i=e)||i.prototype&&i.prototype.isReactComponent||!t?[e]:_r(e(t),t,n,r):e instanceof Lr?n?(e.inject(n,r),[e.getName(r)]):[e]:tr(e)?Nr(e):Array.isArray(e)?Array.prototype.concat.apply(bn,e.map(function(e){return _r(e,t,n,r)})):[e.toString()];var i}function Ir(e){for(var t=0;t<e.length;t+=1){var n=e[t];if(Qn(n)&&!Jn(n))return!1}return!0}var Vr=Rn(fn),Br=function(){function e(e,t,n){this.rules=e,this.staticRulesId="",this.isStatic=(void 0===n||n.isStatic)&&Ir(e),this.componentId=t,this.baseHash=An(Vr,t),this.baseStyle=n,Sr.registerId(t)}return e.prototype.generateAndInjectStyles=function(e,t,n){var r=this.baseStyle?this.baseStyle.generateAndInjectStyles(e,t,n):"";if(this.isStatic&&!n.hash)if(this.staticRulesId&&t.hasNameForId(this.componentId,this.staticRulesId))r=Zn(r,this.staticRulesId);else{var i=er(_r(this.rules,e,t,n)),o=Pn(An(this.baseHash,i)>>>0);if(!t.hasNameForId(this.componentId,o)){var a=n(i,".".concat(o),void 0,this.componentId);t.insertRules(this.componentId,o,a)}r=Zn(r,o),this.staticRulesId=o}else{for(var s=An(this.baseHash,n.hash),l="",c=0;c<this.rules.length;c++){var u=this.rules[c];if("string"==typeof u)l+=u;else if(u){var d=er(_r(u,e,t,n));s=An(s,d+c),l+=d}}if(l){var h=Pn(s>>>0);t.hasNameForId(this.componentId,h)||t.insertRules(this.componentId,h,n(l,".".concat(h),void 0,this.componentId)),r=Zn(r,h)}}return r},e}(),Wr=e.createContext(void 0);Wr.Consumer;function Hr(t){var n=e.useContext(Wr),r=(0,e.useMemo)(function(){return function(e,t){if(!e)throw ir(14);if(Qn(e))return e(t);if(Array.isArray(e)||"object"!=typeof e)throw ir(8);return t?lt(lt({},t),e):e}(t.theme,n)},[t.theme,n]);return t.children?e.createElement(Wr.Provider,{value:r},t.children):null}var Ur={};new Set;function qr(t,n,r){var i=Jn(t),o=t,a=!Dn(t),s=n.attrs,l=void 0===s?bn:s,c=n.componentId,u=void 0===c?function(e,t){var n="string"!=typeof e?"sc":Cn(e);Ur[n]=(Ur[n]||0)+1;var r="".concat(n,"-").concat(Mn(fn+n+Ur[n]));return t?"".concat(t,"-").concat(r):r}(n.displayName,n.parentComponentId):c,d=n.displayName,h=void 0===d?function(e){return Dn(e)?"styled.".concat(e):"Styled(".concat(Ln(e),")")}(t):d,p=n.displayName&&n.componentId?"".concat(Cn(n.displayName),"-").concat(n.componentId):n.componentId||u,m=i&&o.attrs?o.attrs.concat(l).filter(Boolean):l,f=n.shouldForwardProp;if(i&&o.shouldForwardProp){var g=o.shouldForwardProp;if(n.shouldForwardProp){var y=n.shouldForwardProp;f=function(e,t){return g(e,t)&&y(e,t)}}else f=g}var x=new Br(r,p,i?o.componentStyle:void 0);function v(t,n){return function(t,n,r){var i=t.attrs,o=t.componentStyle,a=t.defaultProps,s=t.foldedComponentIds,l=t.styledComponentId,c=t.target,u=e.useContext(Wr),d=Rr(),h=t.shouldForwardProp||d.shouldForwardProp,p=kn(n,u,a)||wn,m=function(e,t,n){for(var r,i=lt(lt({},t),{className:void 0,theme:n}),o=0;o<e.length;o+=1){var a=Qn(r=e[o])?r(i):r;for(var s in a)i[s]="className"===s?Zn(i[s],a[s]):"style"===s?lt(lt({},i[s]),a[s]):a[s]}return t.className&&(i.className=Zn(i.className,t.className)),i}(i,n,p),f=m.as||c,g={};for(var y in m)void 0===m[y]||"$"===y[0]||"as"===y||"theme"===y&&m.theme===p||("forwardedAs"===y?g.as=m.forwardedAs:h&&!h(y,f)||(g[y]=m[y]));var x=function(e,t){var n=Rr();return e.generateAndInjectStyles(t,n.styleSheet,n.stylis)}(o,m),v=Zn(s,l);return x&&(v+=" "+x),m.className&&(v+=" "+m.className),g[Dn(f)&&!Sn.has(f)?"class":"className"]=v,r&&(g.ref=r),(0,e.createElement)(f,g)}(b,t,n)}v.displayName=h;var b=e.forwardRef(v);return b.attrs=m,b.componentStyle=x,b.displayName=h,b.shouldForwardProp=f,b.foldedComponentIds=i?Zn(o.foldedComponentIds,o.styledComponentId):"",b.styledComponentId=p,b.target=i?o.target:t,Object.defineProperty(b,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(e){this._foldedDefaultProps=i?function(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];for(var r=0,i=t;r<i.length;r++)nr(e,i[r],!0);return e}({},o.defaultProps,e):e}}),rr(b,function(){return".".concat(b.styledComponentId)}),a&&Xn(b,t,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0}),b}function Yr(e,t){for(var n=[e[0]],r=0,i=t.length;r<i;r+=1)n.push(t[r],e[r+1]);return n}var Kr=function(e){return Object.assign(e,{isCss:!0})};function Gr(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];if(Qn(e)||tr(e))return Kr(_r(Yr(bn,ct([e],t,!0))));var r=e;return 0===t.length&&1===r.length&&"string"==typeof r[0]?_r(r):Kr(_r(Yr(r,t)))}function Xr(e,t,n){if(void 0===n&&(n=wn),!t)throw ir(1,t);var r=function(r){for(var i=[],o=1;o<arguments.length;o++)i[o-1]=arguments[o];return e(t,n,Gr.apply(void 0,ct([r],i,!1)))};return r.attrs=function(r){return Xr(e,t,lt(lt({},n),{attrs:Array.prototype.concat(n.attrs,r).filter(Boolean)}))},r.withConfig=function(r){return Xr(e,t,lt(lt({},n),r))},r}var Qr=function(e){return Xr(qr,e)},Jr=Qr;Sn.forEach(function(e){Jr[e]=Qr(e)});var Zr=function(){function e(e,t){this.rules=e,this.componentId=t,this.isStatic=Ir(e),Sr.registerId(this.componentId+1)}return e.prototype.createStyles=function(e,t,n,r){var i=r(er(_r(this.rules,t,n,r)),""),o=this.componentId+e;n.insertRules(o,o,i)},e.prototype.removeStyles=function(e,t){t.clearRules(this.componentId+e)},e.prototype.renderStyles=function(e,t,n,r){e>2&&Sr.registerId(this.componentId+e),this.removeStyles(e,n),this.createStyles(e,t,n,r)},e}();function ei(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];var r=er(Gr.apply(void 0,ct([e],t,!1))),i=Mn(r);return new Lr(i,r)}(function(){function t(){var t=this;this._emitSheetCSS=function(){var e=t.instance.toString();if(!e)return"";var n=gr(),r=er([n&&'nonce="'.concat(n,'"'),"".concat(hn,'="true"'),"".concat(mn,'="').concat(fn,'"')].filter(Boolean)," ");return"<style ".concat(r,">").concat(e,"</style>")},this.getStyleTags=function(){if(t.sealed)throw ir(2);return t._emitSheetCSS()},this.getStyleElement=function(){var n;if(t.sealed)throw ir(2);var r=t.instance.toString();if(!r)return[];var i=((n={})[hn]="",n[mn]=fn,n.dangerouslySetInnerHTML={__html:r},n),o=gr();return o&&(i.nonce=o),[e.createElement("style",lt({},i,{key:"sc-0-0"}))]},this.seal=function(){t.sealed=!0},this.instance=new Sr({isServer:!0}),this.sealed=!1}t.prototype.collectStyles=function(t){if(this.sealed)throw ir(2);return e.createElement(Mr,{sheet:this.instance},t)},t.prototype.interleaveWithNodeStream=function(e){throw ir(3)}})(),"__sc-".concat(hn,"__");var ti=n(579);const ni=(0,e.createContext)({});function ri(t){const n=(0,e.useRef)(null);return null===n.current&&(n.current=t()),n.current}const ii="undefined"!==typeof window,oi=ii?e.useLayoutEffect:e.useEffect,ai=(0,e.createContext)(null);function si(e){return"object"===typeof e&&null!==e}function li(e){return si(e)&&"offsetHeight"in e}const ci=(0,e.createContext)({transformPagePoint:e=>e,isStatic:!1,reducedMotion:"never"});class ui extends e.Component{getSnapshotBeforeUpdate(e){const t=this.props.childRef.current;if(t&&e.isPresent&&!this.props.isPresent){const e=t.offsetParent,n=li(e)&&e.offsetWidth||0,r=this.props.sizeRef.current;r.height=t.offsetHeight||0,r.width=t.offsetWidth||0,r.top=t.offsetTop,r.left=t.offsetLeft,r.right=n-r.width-r.left}return null}componentDidUpdate(){}render(){return this.props.children}}function di(t){let{children:n,isPresent:r,anchorX:i,root:o}=t;const a=(0,e.useId)(),s=(0,e.useRef)(null),l=(0,e.useRef)({width:0,height:0,top:0,left:0,right:0}),{nonce:c}=(0,e.useContext)(ci);return(0,e.useInsertionEffect)(()=>{const{width:e,height:t,top:n,left:u,right:d}=l.current;if(r||!s.current||!e||!t)return;const h="left"===i?`left: ${u}`:`right: ${d}`;s.current.dataset.motionPopId=a;const p=document.createElement("style");c&&(p.nonce=c);const m=o??document.head;return m.appendChild(p),p.sheet&&p.sheet.insertRule(`\n          [data-motion-pop-id="${a}"] {\n            position: absolute !important;\n            width: ${e}px !important;\n            height: ${t}px !important;\n            ${h}px !important;\n            top: ${n}px !important;\n          }\n        `),()=>{m.removeChild(p),m.contains(p)&&m.removeChild(p)}},[r]),(0,ti.jsx)(ui,{isPresent:r,childRef:s,sizeRef:l,children:e.cloneElement(n,{ref:s})})}const hi=t=>{let{children:n,initial:r,isPresent:i,onExitComplete:o,custom:a,presenceAffectsLayout:s,mode:l,anchorX:c,root:u}=t;const d=ri(pi),h=(0,e.useId)();let p=!0,m=(0,e.useMemo)(()=>(p=!1,{id:h,initial:r,isPresent:i,custom:a,onExitComplete:e=>{d.set(e,!0);for(const t of d.values())if(!t)return;o&&o()},register:e=>(d.set(e,!1),()=>d.delete(e))}),[i,d,o]);return s&&p&&(m={...m}),(0,e.useMemo)(()=>{d.forEach((e,t)=>d.set(t,!1))},[i]),e.useEffect(()=>{!i&&!d.size&&o&&o()},[i]),"popLayout"===l&&(n=(0,ti.jsx)(di,{isPresent:i,anchorX:c,root:u,children:n})),(0,ti.jsx)(ai.Provider,{value:m,children:n})};function pi(){return new Map}function mi(){let t=!(arguments.length>0&&void 0!==arguments[0])||arguments[0];const n=(0,e.useContext)(ai);if(null===n)return[!0,null];const{isPresent:r,onExitComplete:i,register:o}=n,a=(0,e.useId)();(0,e.useEffect)(()=>{if(t)return o(a)},[t]);const s=(0,e.useCallback)(()=>t&&i&&i(a),[a,i,t]);return!r&&i?[!1,s]:[!0]}const fi=e=>e.key||"";function gi(t){const n=[];return e.Children.forEach(t,t=>{(0,e.isValidElement)(t)&&n.push(t)}),n}const yi=t=>{let{children:n,custom:r,initial:i=!0,onExitComplete:o,presenceAffectsLayout:a=!0,mode:s="sync",propagate:l=!1,anchorX:c="left",root:u}=t;const[d,h]=mi(l),p=(0,e.useMemo)(()=>gi(n),[n]),m=l&&!d?[]:p.map(fi),f=(0,e.useRef)(!0),g=(0,e.useRef)(p),y=ri(()=>new Map),[x,v]=(0,e.useState)(p),[b,w]=(0,e.useState)(p);oi(()=>{f.current=!1,g.current=p;for(let e=0;e<b.length;e++){const t=fi(b[e]);m.includes(t)?y.delete(t):!0!==y.get(t)&&y.set(t,!1)}},[b,m.length,m.join("-")]);const k=[];if(p!==x){let e=[...p];for(let t=0;t<b.length;t++){const n=b[t],r=fi(n);m.includes(r)||(e.splice(t,0,n),k.push(n))}return"wait"===s&&k.length&&(e=k),w(gi(e)),v(p),null}const{forceRender:S}=(0,e.useContext)(ni);return(0,ti.jsx)(ti.Fragment,{children:b.map(e=>{const t=fi(e),n=!(l&&!d)&&(p===b||m.includes(t));return(0,ti.jsx)(hi,{isPresent:n,initial:!(f.current&&!i)&&void 0,custom:r,presenceAffectsLayout:a,mode:s,root:u,onExitComplete:n?void 0:()=>{if(!y.has(t))return;y.set(t,!0);let e=!0;y.forEach(t=>{t||(e=!1)}),e&&(S?.(),w(g.current),l&&h?.(),o&&o())},anchorX:c,children:e},t)})})},xi=e=>{const t=(e=>e.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,t,n)=>n?n.toUpperCase():t.toLowerCase()))(e);return t.charAt(0).toUpperCase()+t.slice(1)},vi=function(){for(var e=arguments.length,t=new Array(e),n=0;n<e;n++)t[n]=arguments[n];return t.filter((e,t,n)=>Boolean(e)&&""!==e.trim()&&n.indexOf(e)===t).join(" ").trim()},bi=e=>{for(const t in e)if(t.startsWith("aria-")||"role"===t||"title"===t)return!0};var wi={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};const ki=(0,e.forwardRef)((t,n)=>{let{color:r="currentColor",size:i=24,strokeWidth:o=2,absoluteStrokeWidth:a,className:s="",children:l,iconNode:c,...u}=t;return(0,e.createElement)("svg",{ref:n,...wi,width:i,height:i,stroke:r,strokeWidth:a?24*Number(o)/Number(i):o,className:vi("lucide",s),...!l&&!bi(u)&&{"aria-hidden":"true"},...u},[...c.map(t=>{let[n,r]=t;return(0,e.createElement)(n,r)}),...Array.isArray(l)?l:[l]])}),Si=(t,n)=>{const r=(0,e.forwardRef)((r,i)=>{let{className:o,...a}=r;return(0,e.createElement)(ki,{ref:i,iconNode:n,className:vi(`lucide-${s=xi(t),s.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`,`lucide-${t}`,o),...a});var s});return r.displayName=xi(t),r},ji=Si("search",[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]),$i=Si("users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]),Ci=Si("message-circle",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]]),Ei=Si("bell",[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]]),Ti=Si("log-out",[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]]),Pi=["transformPerspective","x","y","z","translateX","translateY","translateZ","scale","scaleX","scaleY","rotate","rotateX","rotateY","rotateZ","skew","skewX","skewY"],zi=(()=>new Set(Pi))(),Ai=e=>180*e/Math.PI,Ri=e=>{const t=Ai(Math.atan2(e[1],e[0]));return Li(t)},Mi={x:4,y:5,translateX:4,translateY:5,scaleX:0,scaleY:3,scale:e=>(Math.abs(e[0])+Math.abs(e[3]))/2,rotate:Ri,rotateZ:Ri,skewX:e=>Ai(Math.atan(e[1])),skewY:e=>Ai(Math.atan(e[2])),skew:e=>(Math.abs(e[1])+Math.abs(e[2]))/2},Li=e=>((e%=360)<0&&(e+=360),e),Di=e=>Math.sqrt(e[0]*e[0]+e[1]*e[1]),Oi=e=>Math.sqrt(e[4]*e[4]+e[5]*e[5]),Fi={x:12,y:13,z:14,translateX:12,translateY:13,translateZ:14,scaleX:Di,scaleY:Oi,scale:e=>(Di(e)+Oi(e))/2,rotateX:e=>Li(Ai(Math.atan2(e[6],e[5]))),rotateY:e=>Li(Ai(Math.atan2(-e[2],e[0]))),rotateZ:Ri,rotate:Ri,skewX:e=>Ai(Math.atan(e[4])),skewY:e=>Ai(Math.atan(e[1])),skew:e=>(Math.abs(e[1])+Math.abs(e[4]))/2};function Ni(e){return e.includes("scale")?1:0}function _i(e,t){if(!e||"none"===e)return Ni(t);const n=e.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);let r,i;if(n)r=Fi,i=n;else{const t=e.match(/^matrix\(([-\d.e\s,]+)\)$/u);r=Mi,i=t}if(!i)return Ni(t);const o=r[t],a=i[1].split(",").map(Ii);return"function"===typeof o?o(a):a[o]}function Ii(e){return parseFloat(e.trim())}const Vi=e=>t=>"string"===typeof t&&t.startsWith(e),Bi=Vi("--"),Wi=Vi("var(--"),Hi=e=>!!Wi(e)&&Ui.test(e.split("/*")[0].trim()),Ui=/var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;function qi(e){let{top:t,left:n,right:r,bottom:i}=e;return{x:{min:n,max:r},y:{min:t,max:i}}}const Yi=(e,t,n)=>e+(t-e)*n;function Ki(e){return void 0===e||1===e}function Gi(e){let{scale:t,scaleX:n,scaleY:r}=e;return!Ki(t)||!Ki(n)||!Ki(r)}function Xi(e){return Gi(e)||Qi(e)||e.z||e.rotate||e.rotateX||e.rotateY||e.skewX||e.skewY}function Qi(e){return Ji(e.x)||Ji(e.y)}function Ji(e){return e&&"0%"!==e}function Zi(e,t,n){return n+t*(e-n)}function eo(e,t,n,r,i){return void 0!==i&&(e=Zi(e,i,r)),Zi(e,n,r)+t}function to(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0,n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:1,r=arguments.length>3?arguments[3]:void 0,i=arguments.length>4?arguments[4]:void 0;e.min=eo(e.min,t,n,r,i),e.max=eo(e.max,t,n,r,i)}function no(e,t){let{x:n,y:r}=t;to(e.x,n.translate,n.scale,n.originPoint),to(e.y,r.translate,r.scale,r.originPoint)}const ro=.999999999999,io=1.0000000000001;function oo(e,t){e.min=e.min+t,e.max=e.max+t}function ao(e,t,n,r){let i=arguments.length>4&&void 0!==arguments[4]?arguments[4]:.5;to(e,t,n,Yi(e.min,e.max,i),r)}function so(e,t){ao(e.x,t.x,t.scaleX,t.scale,t.originX),ao(e.y,t.y,t.scaleY,t.scale,t.originY)}function lo(e,t){return qi(function(e,t){if(!t)return e;const n=t({x:e.left,y:e.top}),r=t({x:e.right,y:e.bottom});return{top:n.y,left:n.x,bottom:r.y,right:r.x}}(e.getBoundingClientRect(),t))}const co=new Set(["width","height","top","left","right","bottom",...Pi]),uo=(e,t,n)=>n>t?t:n<e?e:n,ho={test:e=>"number"===typeof e,parse:parseFloat,transform:e=>e},po={...ho,transform:e=>uo(0,1,e)},mo={...ho,default:1},fo=e=>({test:t=>"string"===typeof t&&t.endsWith(e)&&1===t.split(" ").length,parse:parseFloat,transform:t=>`${t}${e}`}),go=fo("deg"),yo=fo("%"),xo=fo("px"),vo=fo("vh"),bo=fo("vw"),wo=(()=>({...yo,parse:e=>yo.parse(e)/100,transform:e=>yo.transform(100*e)}))(),ko=e=>t=>t.test(e),So=[ho,xo,yo,go,bo,vo,{test:e=>"auto"===e,parse:e=>e}],jo=e=>So.find(ko(e));const $o=e=>/^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e),Co=/^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;function Eo(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:1;const[r,i]=function(e){const t=Co.exec(e);if(!t)return[,];const[,n,r,i]=t;return[`--${n??r}`,i]}(e);if(!r)return;const o=window.getComputedStyle(t).getPropertyValue(r);if(o){const e=o.trim();return $o(e)?parseFloat(e):e}return Hi(i)?Eo(i,t,n+1):i}const To=e=>e===ho||e===xo,Po=new Set(["x","y","z"]),zo=Pi.filter(e=>!Po.has(e));const Ao={width:(e,t)=>{let{x:n}=e,{paddingLeft:r="0",paddingRight:i="0"}=t;return n.max-n.min-parseFloat(r)-parseFloat(i)},height:(e,t)=>{let{y:n}=e,{paddingTop:r="0",paddingBottom:i="0"}=t;return n.max-n.min-parseFloat(r)-parseFloat(i)},top:(e,t)=>{let{top:n}=t;return parseFloat(n)},left:(e,t)=>{let{left:n}=t;return parseFloat(n)},bottom:(e,t)=>{let{y:n}=e,{top:r}=t;return parseFloat(r)+(n.max-n.min)},right:(e,t)=>{let{x:n}=e,{left:r}=t;return parseFloat(r)+(n.max-n.min)},x:(e,t)=>{let{transform:n}=t;return _i(n,"x")},y:(e,t)=>{let{transform:n}=t;return _i(n,"y")}};Ao.translateX=Ao.x,Ao.translateY=Ao.y;const Ro=e=>e,Mo={},Lo=["setup","read","resolveKeyframes","preUpdate","update","preRender","render","postRender"],Do={value:null,addProjectionMetrics:null};function Oo(e,t){let n=!1,r=!0;const i={delta:0,timestamp:0,isProcessing:!1},o=()=>n=!0,a=Lo.reduce((e,n)=>(e[n]=function(e,t){let n=new Set,r=new Set,i=!1,o=!1;const a=new WeakSet;let s={delta:0,timestamp:0,isProcessing:!1},l=0;function c(t){a.has(t)&&(u.schedule(t),e()),l++,t(s)}const u={schedule:function(e){const t=arguments.length>2&&void 0!==arguments[2]&&arguments[2]&&i?n:r;return arguments.length>1&&void 0!==arguments[1]&&arguments[1]&&a.add(e),t.has(e)||t.add(e),e},cancel:e=>{r.delete(e),a.delete(e)},process:e=>{s=e,i?o=!0:(i=!0,[n,r]=[r,n],n.forEach(c),t&&Do.value&&Do.value.frameloop[t].push(l),l=0,n.clear(),i=!1,o&&(o=!1,u.process(e)))}};return u}(o,t?n:void 0),e),{}),{setup:s,read:l,resolveKeyframes:c,preUpdate:u,update:d,preRender:h,render:p,postRender:m}=a,f=()=>{const o=Mo.useManualTiming?i.timestamp:performance.now();n=!1,Mo.useManualTiming||(i.delta=r?1e3/60:Math.max(Math.min(o-i.timestamp,40),1)),i.timestamp=o,i.isProcessing=!0,s.process(i),l.process(i),c.process(i),u.process(i),d.process(i),h.process(i),p.process(i),m.process(i),i.isProcessing=!1,n&&t&&(r=!1,e(f))},g=Lo.reduce((t,o)=>{const s=a[o];return t[o]=function(t){let o=arguments.length>1&&void 0!==arguments[1]&&arguments[1],a=arguments.length>2&&void 0!==arguments[2]&&arguments[2];return n||(n=!0,r=!0,i.isProcessing||e(f)),s.schedule(t,o,a)},t},{});return{schedule:g,cancel:e=>{for(let t=0;t<Lo.length;t++)a[Lo[t]].cancel(e)},state:i,steps:a}}const{schedule:Fo,cancel:No,state:_o,steps:Io}=Oo("undefined"!==typeof requestAnimationFrame?requestAnimationFrame:Ro,!0),Vo=new Set;let Bo=!1,Wo=!1,Ho=!1;function Uo(){if(Wo){const e=Array.from(Vo).filter(e=>e.needsMeasurement),t=new Set(e.map(e=>e.element)),n=new Map;t.forEach(e=>{const t=function(e){const t=[];return zo.forEach(n=>{const r=e.getValue(n);void 0!==r&&(t.push([n,r.get()]),r.set(n.startsWith("scale")?1:0))}),t}(e);t.length&&(n.set(e,t),e.render())}),e.forEach(e=>e.measureInitialState()),t.forEach(e=>{e.render();const t=n.get(e);t&&t.forEach(t=>{let[n,r]=t;e.getValue(n)?.set(r)})}),e.forEach(e=>e.measureEndState()),e.forEach(e=>{void 0!==e.suspendedScrollY&&window.scrollTo(0,e.suspendedScrollY)})}Wo=!1,Bo=!1,Vo.forEach(e=>e.complete(Ho)),Vo.clear()}function qo(){Vo.forEach(e=>{e.readKeyframes(),e.needsMeasurement&&(Wo=!0)})}class Yo{constructor(e,t,n,r,i){let o=arguments.length>5&&void 0!==arguments[5]&&arguments[5];this.state="pending",this.isAsync=!1,this.needsMeasurement=!1,this.unresolvedKeyframes=[...e],this.onComplete=t,this.name=n,this.motionValue=r,this.element=i,this.isAsync=o}scheduleResolve(){this.state="scheduled",this.isAsync?(Vo.add(this),Bo||(Bo=!0,Fo.read(qo),Fo.resolveKeyframes(Uo))):(this.readKeyframes(),this.complete())}readKeyframes(){const{unresolvedKeyframes:e,name:t,element:n,motionValue:r}=this;if(null===e[0]){const i=r?.get(),o=e[e.length-1];if(void 0!==i)e[0]=i;else if(n&&t){const r=n.readValue(t,o);void 0!==r&&null!==r&&(e[0]=r)}void 0===e[0]&&(e[0]=o),r&&void 0===i&&r.set(e[0])}!function(e){for(let t=1;t<e.length;t++)e[t]??(e[t]=e[t-1])}(e)}setFinalKeyframe(){}measureInitialState(){}renderEndStyles(){}measureEndState(){}complete(){let e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];this.state="complete",this.onComplete(this.unresolvedKeyframes,this.finalKeyframe,e),Vo.delete(this)}cancel(){"scheduled"===this.state&&(Vo.delete(this),this.state="pending")}resume(){"pending"===this.state&&this.scheduleResolve()}}const Ko=e=>/^0[^.\s]+$/u.test(e);function Go(e){return"number"===typeof e?0===e:null===e||("none"===e||"0"===e||Ko(e))}const Xo=e=>Math.round(1e5*e)/1e5,Qo=/-?(?:\d+(?:\.\d+)?|\.\d+)/gu;const Jo=/^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,Zo=(e,t)=>n=>Boolean("string"===typeof n&&Jo.test(n)&&n.startsWith(e)||t&&!function(e){return null==e}(n)&&Object.prototype.hasOwnProperty.call(n,t)),ea=(e,t,n)=>r=>{if("string"!==typeof r)return r;const[i,o,a,s]=r.match(Qo);return{[e]:parseFloat(i),[t]:parseFloat(o),[n]:parseFloat(a),alpha:void 0!==s?parseFloat(s):1}},ta={...ho,transform:e=>Math.round((e=>uo(0,255,e))(e))},na={test:Zo("rgb","red"),parse:ea("red","green","blue"),transform:e=>{let{red:t,green:n,blue:r,alpha:i=1}=e;return"rgba("+ta.transform(t)+", "+ta.transform(n)+", "+ta.transform(r)+", "+Xo(po.transform(i))+")"}};const ra={test:Zo("#"),parse:function(e){let t="",n="",r="",i="";return e.length>5?(t=e.substring(1,3),n=e.substring(3,5),r=e.substring(5,7),i=e.substring(7,9)):(t=e.substring(1,2),n=e.substring(2,3),r=e.substring(3,4),i=e.substring(4,5),t+=t,n+=n,r+=r,i+=i),{red:parseInt(t,16),green:parseInt(n,16),blue:parseInt(r,16),alpha:i?parseInt(i,16)/255:1}},transform:na.transform},ia={test:Zo("hsl","hue"),parse:ea("hue","saturation","lightness"),transform:e=>{let{hue:t,saturation:n,lightness:r,alpha:i=1}=e;return"hsla("+Math.round(t)+", "+yo.transform(Xo(n))+", "+yo.transform(Xo(r))+", "+Xo(po.transform(i))+")"}},oa={test:e=>na.test(e)||ra.test(e)||ia.test(e),parse:e=>na.test(e)?na.parse(e):ia.test(e)?ia.parse(e):ra.parse(e),transform:e=>"string"===typeof e?e:e.hasOwnProperty("red")?na.transform(e):ia.transform(e),getAnimatableNone:e=>{const t=oa.parse(e);return t.alpha=0,oa.transform(t)}},aa=/(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;const sa="number",la="color",ca=/var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;function ua(e){const t=e.toString(),n=[],r={color:[],number:[],var:[]},i=[];let o=0;const a=t.replace(ca,e=>(oa.test(e)?(r.color.push(o),i.push(la),n.push(oa.parse(e))):e.startsWith("var(")?(r.var.push(o),i.push("var"),n.push(e)):(r.number.push(o),i.push(sa),n.push(parseFloat(e))),++o,"${}")).split("${}");return{values:n,split:a,indexes:r,types:i}}function da(e){return ua(e).values}function ha(e){const{split:t,types:n}=ua(e),r=t.length;return e=>{let i="";for(let o=0;o<r;o++)if(i+=t[o],void 0!==e[o]){const t=n[o];i+=t===sa?Xo(e[o]):t===la?oa.transform(e[o]):e[o]}return i}}const pa=e=>"number"===typeof e?0:oa.test(e)?oa.getAnimatableNone(e):e;const ma={test:function(e){return isNaN(e)&&"string"===typeof e&&(e.match(Qo)?.length||0)+(e.match(aa)?.length||0)>0},parse:da,createTransformer:ha,getAnimatableNone:function(e){const t=da(e);return ha(e)(t.map(pa))}},fa=new Set(["brightness","contrast","saturate","opacity"]);function ga(e){const[t,n]=e.slice(0,-1).split("(");if("drop-shadow"===t)return e;const[r]=n.match(Qo)||[];if(!r)return e;const i=n.replace(r,"");let o=fa.has(t)?1:0;return r!==n&&(o*=100),t+"("+o+i+")"}const ya=/\b([a-z-]*)\(.*?\)/gu,xa={...ma,getAnimatableNone:e=>{const t=e.match(ya);return t?t.map(ga).join(" "):e}},va={...ho,transform:Math.round},ba={borderWidth:xo,borderTopWidth:xo,borderRightWidth:xo,borderBottomWidth:xo,borderLeftWidth:xo,borderRadius:xo,radius:xo,borderTopLeftRadius:xo,borderTopRightRadius:xo,borderBottomRightRadius:xo,borderBottomLeftRadius:xo,width:xo,maxWidth:xo,height:xo,maxHeight:xo,top:xo,right:xo,bottom:xo,left:xo,padding:xo,paddingTop:xo,paddingRight:xo,paddingBottom:xo,paddingLeft:xo,margin:xo,marginTop:xo,marginRight:xo,marginBottom:xo,marginLeft:xo,backgroundPositionX:xo,backgroundPositionY:xo,...{rotate:go,rotateX:go,rotateY:go,rotateZ:go,scale:mo,scaleX:mo,scaleY:mo,scaleZ:mo,skew:go,skewX:go,skewY:go,distance:xo,translateX:xo,translateY:xo,translateZ:xo,x:xo,y:xo,z:xo,perspective:xo,transformPerspective:xo,opacity:po,originX:wo,originY:wo,originZ:xo},zIndex:va,fillOpacity:po,strokeOpacity:po,numOctaves:va},wa={...ba,color:oa,backgroundColor:oa,outlineColor:oa,fill:oa,stroke:oa,borderColor:oa,borderTopColor:oa,borderRightColor:oa,borderBottomColor:oa,borderLeftColor:oa,filter:xa,WebkitFilter:xa},ka=e=>wa[e];function Sa(e,t){let n=ka(e);return n!==xa&&(n=ma),n.getAnimatableNone?n.getAnimatableNone(t):void 0}const ja=new Set(["auto","none","0"]);class $a extends Yo{constructor(e,t,n,r,i){super(e,t,n,r,i,!0)}readKeyframes(){const{unresolvedKeyframes:e,element:t,name:n}=this;if(!t||!t.current)return;super.readKeyframes();for(let s=0;s<e.length;s++){let n=e[s];if("string"===typeof n&&(n=n.trim(),Hi(n))){const r=Eo(n,t.current);void 0!==r&&(e[s]=r),s===e.length-1&&(this.finalKeyframe=n)}}if(this.resolveNoneKeyframes(),!co.has(n)||2!==e.length)return;const[r,i]=e,o=jo(r),a=jo(i);if(o!==a)if(To(o)&&To(a))for(let s=0;s<e.length;s++){const t=e[s];"string"===typeof t&&(e[s]=parseFloat(t))}else Ao[n]&&(this.needsMeasurement=!0)}resolveNoneKeyframes(){const{unresolvedKeyframes:e,name:t}=this,n=[];for(let r=0;r<e.length;r++)(null===e[r]||Go(e[r]))&&n.push(r);n.length&&function(e,t,n){let r,i=0;for(;i<e.length&&!r;){const t=e[i];"string"===typeof t&&!ja.has(t)&&ua(t).values.length&&(r=e[i]),i++}if(r&&n)for(const o of t)e[o]=Sa(n,r)}(e,n,t)}measureInitialState(){const{element:e,unresolvedKeyframes:t,name:n}=this;if(!e||!e.current)return;"height"===n&&(this.suspendedScrollY=window.pageYOffset),this.measuredOrigin=Ao[n](e.measureViewportBox(),window.getComputedStyle(e.current)),t[0]=this.measuredOrigin;const r=t[t.length-1];void 0!==r&&e.getValue(n,r).jump(r,!1)}measureEndState(){const{element:e,name:t,unresolvedKeyframes:n}=this;if(!e||!e.current)return;const r=e.getValue(t);r&&r.jump(this.measuredOrigin,!1);const i=n.length-1,o=n[i];n[i]=Ao[t](e.measureViewportBox(),window.getComputedStyle(e.current)),null!==o&&void 0===this.finalKeyframe&&(this.finalKeyframe=o),this.removedTransforms?.length&&this.removedTransforms.forEach(t=>{let[n,r]=t;e.getValue(n).set(r)}),this.resolveNoneKeyframes()}}const Ca=e=>Boolean(e&&e.getVelocity);let Ea;function Ta(){Ea=void 0}const Pa={now:()=>(void 0===Ea&&Pa.set(_o.isProcessing||Mo.useManualTiming?_o.timestamp:performance.now()),Ea),set:e=>{Ea=e,queueMicrotask(Ta)}};function za(e,t){-1===e.indexOf(t)&&e.push(t)}function Aa(e,t){const n=e.indexOf(t);n>-1&&e.splice(n,1)}class Ra{constructor(){this.subscriptions=[]}add(e){return za(this.subscriptions,e),()=>Aa(this.subscriptions,e)}notify(e,t,n){const r=this.subscriptions.length;if(r)if(1===r)this.subscriptions[0](e,t,n);else for(let i=0;i<r;i++){const r=this.subscriptions[i];r&&r(e,t,n)}}getSize(){return this.subscriptions.length}clear(){this.subscriptions.length=0}}function Ma(e,t){return t?e*(1e3/t):0}const La={current:void 0};class Da{constructor(e){var t=this;let n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};this.canTrackVelocity=null,this.events={},this.updateAndNotify=function(e){let n=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];const r=Pa.now();if(t.updatedAt!==r&&t.setPrevFrameValue(),t.prev=t.current,t.setCurrent(e),t.current!==t.prev&&(t.events.change?.notify(t.current),t.dependents))for(const i of t.dependents)i.dirty();n&&t.events.renderRequest?.notify(t.current)},this.hasAnimated=!1,this.setCurrent(e),this.owner=n.owner}setCurrent(e){var t;this.current=e,this.updatedAt=Pa.now(),null===this.canTrackVelocity&&void 0!==e&&(this.canTrackVelocity=(t=this.current,!isNaN(parseFloat(t))))}setPrevFrameValue(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:this.current;this.prevFrameValue=e,this.prevUpdatedAt=this.updatedAt}onChange(e){return this.on("change",e)}on(e,t){this.events[e]||(this.events[e]=new Ra);const n=this.events[e].add(t);return"change"===e?()=>{n(),Fo.read(()=>{this.events.change.getSize()||this.stop()})}:n}clearListeners(){for(const e in this.events)this.events[e].clear()}attach(e,t){this.passiveEffect=e,this.stopPassiveEffect=t}set(e){let t=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];t&&this.passiveEffect?this.passiveEffect(e,this.updateAndNotify):this.updateAndNotify(e,t)}setWithVelocity(e,t,n){this.set(t),this.prev=void 0,this.prevFrameValue=e,this.prevUpdatedAt=this.updatedAt-n}jump(e){let t=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];this.updateAndNotify(e),this.prev=e,this.prevUpdatedAt=this.prevFrameValue=void 0,t&&this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()}dirty(){this.events.change?.notify(this.current)}addDependent(e){this.dependents||(this.dependents=new Set),this.dependents.add(e)}removeDependent(e){this.dependents&&this.dependents.delete(e)}get(){return La.current&&La.current.push(this),this.current}getPrevious(){return this.prev}getVelocity(){const e=Pa.now();if(!this.canTrackVelocity||void 0===this.prevFrameValue||e-this.updatedAt>30)return 0;const t=Math.min(this.updatedAt-this.prevUpdatedAt,30);return Ma(parseFloat(this.current)-parseFloat(this.prevFrameValue),t)}start(e){return this.stop(),new Promise(t=>{this.hasAnimated=!0,this.animation=e(t),this.events.animationStart&&this.events.animationStart.notify()}).then(()=>{this.events.animationComplete&&this.events.animationComplete.notify(),this.clearAnimation()})}stop(){this.animation&&(this.animation.stop(),this.events.animationCancel&&this.events.animationCancel.notify()),this.clearAnimation()}isAnimating(){return!!this.animation}clearAnimation(){delete this.animation}destroy(){this.dependents?.clear(),this.events.destroy?.notify(),this.clearListeners(),this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()}}function Oa(e,t){return new Da(e,t)}const Fa=[...So,oa,ma],{schedule:Na,cancel:_a}=Oo(queueMicrotask,!1),Ia={animation:["animate","variants","whileHover","whileTap","exit","whileInView","whileFocus","whileDrag"],exit:["exit"],drag:["drag","dragControls"],focus:["whileFocus"],hover:["whileHover","onHoverStart","onHoverEnd"],tap:["whileTap","onTap","onTapStart","onTapCancel"],pan:["onPan","onPanStart","onPanSessionStart","onPanEnd"],inView:["whileInView","onViewportEnter","onViewportLeave"],layout:["layout","layoutId"]},Va={};for(const n in Ia)Va[n]={isEnabled:e=>Ia[n].some(t=>!!e[t])};const Ba=()=>({x:{min:0,max:0},y:{min:0,max:0}}),Wa={current:null},Ha={current:!1};const Ua=new WeakMap;function qa(e){return null!==e&&"object"===typeof e&&"function"===typeof e.start}function Ya(e){return"string"===typeof e||Array.isArray(e)}const Ka=["animate","whileInView","whileFocus","whileHover","whileTap","whileDrag","exit"],Ga=["initial",...Ka];function Xa(e){return qa(e.animate)||Ga.some(t=>Ya(e[t]))}function Qa(e){return Boolean(Xa(e)||e.variants)}function Ja(e){const t=[{},{}];return e?.values.forEach((e,n)=>{t[0][n]=e.get(),t[1][n]=e.getVelocity()}),t}function Za(e,t,n,r){if("function"===typeof t){const[i,o]=Ja(r);t=t(void 0!==n?n:e.custom,i,o)}if("string"===typeof t&&(t=e.variants&&e.variants[t]),"function"===typeof t){const[i,o]=Ja(r);t=t(void 0!==n?n:e.custom,i,o)}return t}const es=["AnimationStart","AnimationComplete","Update","BeforeLayoutMeasure","LayoutMeasure","LayoutAnimationStart","LayoutAnimationComplete"];class ts{scrapeMotionValuesFromProps(e,t,n){return{}}constructor(e){let{parent:t,props:n,presenceContext:r,reducedMotionConfig:i,blockInitialAnimation:o,visualState:a}=e,s=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};this.current=null,this.children=new Set,this.isVariantNode=!1,this.isControllingVariants=!1,this.shouldReduceMotion=null,this.values=new Map,this.KeyframeResolver=Yo,this.features={},this.valueSubscriptions=new Map,this.prevMotionValues={},this.events={},this.propEventSubscriptions={},this.notifyUpdate=()=>this.notify("Update",this.latestValues),this.render=()=>{this.current&&(this.triggerBuild(),this.renderInstance(this.current,this.renderState,this.props.style,this.projection))},this.renderScheduledAt=0,this.scheduleRender=()=>{const e=Pa.now();this.renderScheduledAt<e&&(this.renderScheduledAt=e,Fo.render(this.render,!1,!0))};const{latestValues:l,renderState:c}=a;this.latestValues=l,this.baseTarget={...l},this.initialValues=n.initial?{...l}:{},this.renderState=c,this.parent=t,this.props=n,this.presenceContext=r,this.depth=t?t.depth+1:0,this.reducedMotionConfig=i,this.options=s,this.blockInitialAnimation=Boolean(o),this.isControllingVariants=Xa(n),this.isVariantNode=Qa(n),this.isVariantNode&&(this.variantChildren=new Set),this.manuallyAnimateOnMount=Boolean(t&&t.current);const{willChange:u,...d}=this.scrapeMotionValuesFromProps(n,{},this);for(const h in d){const e=d[h];void 0!==l[h]&&Ca(e)&&e.set(l[h],!1)}}mount(e){this.current=e,Ua.set(e,this),this.projection&&!this.projection.instance&&this.projection.mount(e),this.parent&&this.isVariantNode&&!this.isControllingVariants&&(this.removeFromVariantTree=this.parent.addVariantChild(this)),this.values.forEach((e,t)=>this.bindToMotionValue(t,e)),Ha.current||function(){if(Ha.current=!0,ii)if(window.matchMedia){const e=window.matchMedia("(prefers-reduced-motion)"),t=()=>Wa.current=e.matches;e.addEventListener("change",t),t()}else Wa.current=!1}(),this.shouldReduceMotion="never"!==this.reducedMotionConfig&&("always"===this.reducedMotionConfig||Wa.current),this.parent&&this.parent.children.add(this),this.update(this.props,this.presenceContext)}unmount(){this.projection&&this.projection.unmount(),No(this.notifyUpdate),No(this.render),this.valueSubscriptions.forEach(e=>e()),this.valueSubscriptions.clear(),this.removeFromVariantTree&&this.removeFromVariantTree(),this.parent&&this.parent.children.delete(this);for(const e in this.events)this.events[e].clear();for(const e in this.features){const t=this.features[e];t&&(t.unmount(),t.isMounted=!1)}this.current=null}bindToMotionValue(e,t){this.valueSubscriptions.has(e)&&this.valueSubscriptions.get(e)();const n=zi.has(e);n&&this.onBindTransform&&this.onBindTransform();const r=t.on("change",t=>{this.latestValues[e]=t,this.props.onUpdate&&Fo.preRender(this.notifyUpdate),n&&this.projection&&(this.projection.isTransformDirty=!0)}),i=t.on("renderRequest",this.scheduleRender);let o;window.MotionCheckAppearSync&&(o=window.MotionCheckAppearSync(this,e,t)),this.valueSubscriptions.set(e,()=>{r(),i(),o&&o(),t.owner&&t.stop()})}sortNodePosition(e){return this.current&&this.sortInstanceNodePosition&&this.type===e.type?this.sortInstanceNodePosition(this.current,e.current):0}updateFeatures(){let e="animation";for(e in Va){const t=Va[e];if(!t)continue;const{isEnabled:n,Feature:r}=t;if(!this.features[e]&&r&&n(this.props)&&(this.features[e]=new r(this)),this.features[e]){const t=this.features[e];t.isMounted?t.update():(t.mount(),t.isMounted=!0)}}}triggerBuild(){this.build(this.renderState,this.latestValues,this.props)}measureViewportBox(){return this.current?this.measureInstanceViewportBox(this.current,this.props):{x:{min:0,max:0},y:{min:0,max:0}}}getStaticValue(e){return this.latestValues[e]}setStaticValue(e,t){this.latestValues[e]=t}update(e,t){(e.transformTemplate||this.props.transformTemplate)&&this.scheduleRender(),this.prevProps=this.props,this.props=e,this.prevPresenceContext=this.presenceContext,this.presenceContext=t;for(let n=0;n<es.length;n++){const t=es[n];this.propEventSubscriptions[t]&&(this.propEventSubscriptions[t](),delete this.propEventSubscriptions[t]);const r=e["on"+t];r&&(this.propEventSubscriptions[t]=this.on(t,r))}this.prevMotionValues=function(e,t,n){for(const r in t){const i=t[r],o=n[r];if(Ca(i))e.addValue(r,i);else if(Ca(o))e.addValue(r,Oa(i,{owner:e}));else if(o!==i)if(e.hasValue(r)){const t=e.getValue(r);!0===t.liveStyle?t.jump(i):t.hasAnimated||t.set(i)}else{const t=e.getStaticValue(r);e.addValue(r,Oa(void 0!==t?t:i,{owner:e}))}}for(const r in n)void 0===t[r]&&e.removeValue(r);return t}(this,this.scrapeMotionValuesFromProps(e,this.prevProps,this),this.prevMotionValues),this.handleChildMotionValue&&this.handleChildMotionValue()}getProps(){return this.props}getVariant(e){return this.props.variants?this.props.variants[e]:void 0}getDefaultTransition(){return this.props.transition}getTransformPagePoint(){return this.props.transformPagePoint}getClosestVariantNode(){return this.isVariantNode?this:this.parent?this.parent.getClosestVariantNode():void 0}addVariantChild(e){const t=this.getClosestVariantNode();if(t)return t.variantChildren&&t.variantChildren.add(e),()=>t.variantChildren.delete(e)}addValue(e,t){const n=this.values.get(e);t!==n&&(n&&this.removeValue(e),this.bindToMotionValue(e,t),this.values.set(e,t),this.latestValues[e]=t.get())}removeValue(e){this.values.delete(e);const t=this.valueSubscriptions.get(e);t&&(t(),this.valueSubscriptions.delete(e)),delete this.latestValues[e],this.removeValueFromRenderState(e,this.renderState)}hasValue(e){return this.values.has(e)}getValue(e,t){if(this.props.values&&this.props.values[e])return this.props.values[e];let n=this.values.get(e);return void 0===n&&void 0!==t&&(n=Oa(null===t?void 0:t,{owner:this}),this.addValue(e,n)),n}readValue(e,t){let n=void 0===this.latestValues[e]&&this.current?this.getBaseTargetFromProps(this.props,e)??this.readValueFromInstance(this.current,e,this.options):this.latestValues[e];return void 0!==n&&null!==n&&("string"===typeof n&&($o(n)||Ko(n))?n=parseFloat(n):!(e=>Fa.find(ko(e)))(n)&&ma.test(t)&&(n=Sa(e,t)),this.setBaseTarget(e,Ca(n)?n.get():n)),Ca(n)?n.get():n}setBaseTarget(e,t){this.baseTarget[e]=t}getBaseTarget(e){const{initial:t}=this.props;let n;if("string"===typeof t||"object"===typeof t){const r=Za(this.props,t,this.presenceContext?.custom);r&&(n=r[e])}if(t&&void 0!==n)return n;const r=this.getBaseTargetFromProps(this.props,e);return void 0===r||Ca(r)?void 0!==this.initialValues[e]&&void 0===n?void 0:this.baseTarget[e]:r}on(e,t){return this.events[e]||(this.events[e]=new Ra),this.events[e].add(t)}notify(e){if(this.events[e]){for(var t=arguments.length,n=new Array(t>1?t-1:0),r=1;r<t;r++)n[r-1]=arguments[r];this.events[e].notify(...n)}}scheduleRenderMicrotask(){Na.render(this.render)}}class ns extends ts{constructor(){super(...arguments),this.KeyframeResolver=$a}sortInstanceNodePosition(e,t){return 2&e.compareDocumentPosition(t)?1:-1}getBaseTargetFromProps(e,t){return e.style?e.style[t]:void 0}removeValueFromRenderState(e,t){let{vars:n,style:r}=t;delete n[e],delete r[e]}handleChildMotionValue(){this.childSubscription&&(this.childSubscription(),delete this.childSubscription);const{children:e}=this.props;Ca(e)&&(this.childSubscription=e.on("change",e=>{this.current&&(this.current.textContent=`${e}`)}))}}const rs=(e,t)=>t&&"number"===typeof e?t.transform(e):e,is={x:"translateX",y:"translateY",z:"translateZ",transformPerspective:"perspective"},os=Pi.length;function as(e,t,n){const{style:r,vars:i,transformOrigin:o}=e;let a=!1,s=!1;for(const l in t){const e=t[l];if(zi.has(l))a=!0;else if(Bi(l))i[l]=e;else{const t=rs(e,ba[l]);l.startsWith("origin")?(s=!0,o[l]=t):r[l]=t}}if(t.transform||(a||n?r.transform=function(e,t,n){let r="",i=!0;for(let o=0;o<os;o++){const a=Pi[o],s=e[a];if(void 0===s)continue;let l=!0;if(l="number"===typeof s?s===(a.startsWith("scale")?1:0):0===parseFloat(s),!l||n){const e=rs(s,ba[a]);l||(i=!1,r+=`${is[a]||a}(${e}) `),n&&(t[a]=e)}}return r=r.trim(),n?r=n(t,i?"":r):i&&(r="none"),r}(t,e.transform,n):r.transform&&(r.transform="none")),s){const{originX:e="50%",originY:t="50%",originZ:n=0}=o;r.transformOrigin=`${e} ${t} ${n}`}}function ss(e,t,n,r){let{style:i,vars:o}=t;const a=e.style;let s;for(s in i)a[s]=i[s];for(s in r?.applyProjectionStyles(a,n),o)a.setProperty(s,o[s])}const ls={};function cs(e,t){let{layout:n,layoutId:r}=t;return zi.has(e)||e.startsWith("origin")||(n||void 0!==r)&&(!!ls[e]||"opacity"===e)}function us(e,t,n){const{style:r}=e,i={};for(const o in r)(Ca(r[o])||t.style&&Ca(t.style[o])||cs(o,e)||void 0!==n?.getValue(o)?.liveStyle)&&(i[o]=r[o]);return i}class ds extends ns{constructor(){super(...arguments),this.type="html",this.renderInstance=ss}readValueFromInstance(e,t){if(zi.has(t))return this.projection?.isProjecting?Ni(t):((e,t)=>{const{transform:n="none"}=getComputedStyle(e);return _i(n,t)})(e,t);{const r=(n=e,window.getComputedStyle(n)),i=(Bi(t)?r.getPropertyValue(t):r[t])||0;return"string"===typeof i?i.trim():i}var n}measureInstanceViewportBox(e,t){let{transformPagePoint:n}=t;return lo(e,n)}build(e,t,n){as(e,t,n.transformTemplate)}scrapeMotionValuesFromProps(e,t,n){return us(e,t,n)}}const hs=e=>e.replace(/([a-z])([A-Z])/gu,"$1-$2").toLowerCase(),ps={offset:"stroke-dashoffset",array:"stroke-dasharray"},ms={offset:"strokeDashoffset",array:"strokeDasharray"};function fs(e,t,n,r,i){let{attrX:o,attrY:a,attrScale:s,pathLength:l,pathSpacing:c=1,pathOffset:u=0,...d}=t;if(as(e,d,r),n)return void(e.style.viewBox&&(e.attrs.viewBox=e.style.viewBox));e.attrs=e.style,e.style={};const{attrs:h,style:p}=e;h.transform&&(p.transform=h.transform,delete h.transform),(p.transform||h.transformOrigin)&&(p.transformOrigin=h.transformOrigin??"50% 50%",delete h.transformOrigin),p.transform&&(p.transformBox=i?.transformBox??"fill-box",delete h.transformBox),void 0!==o&&(h.x=o),void 0!==a&&(h.y=a),void 0!==s&&(h.scale=s),void 0!==l&&function(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:1,r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:0,i=!(arguments.length>4&&void 0!==arguments[4])||arguments[4];e.pathLength=1;const o=i?ps:ms;e[o.offset]=xo.transform(-r);const a=xo.transform(t),s=xo.transform(n);e[o.array]=`${a} ${s}`}(h,l,c,u,!1)}const gs=new Set(["baseFrequency","diffuseConstant","kernelMatrix","kernelUnitLength","keySplines","keyTimes","limitingConeAngle","markerHeight","markerWidth","numOctaves","targetX","targetY","surfaceScale","specularConstant","specularExponent","stdDeviation","tableValues","viewBox","gradientTransform","pathLength","startOffset","textLength","lengthAdjust"]),ys=e=>"string"===typeof e&&"svg"===e.toLowerCase();function xs(e,t,n){const r=us(e,t,n);for(const i in e)if(Ca(e[i])||Ca(t[i])){r[-1!==Pi.indexOf(i)?"attr"+i.charAt(0).toUpperCase()+i.substring(1):i]=e[i]}return r}class vs extends ns{constructor(){super(...arguments),this.type="svg",this.isSVGTag=!1,this.measureInstanceViewportBox=Ba}getBaseTargetFromProps(e,t){return e[t]}readValueFromInstance(e,t){if(zi.has(t)){const e=ka(t);return e&&e.default||0}return t=gs.has(t)?t:hs(t),e.getAttribute(t)}scrapeMotionValuesFromProps(e,t,n){return xs(e,t,n)}build(e,t,n){fs(e,t,this.isSVGTag,n.transformTemplate,n.style)}renderInstance(e,t,n,r){!function(e,t,n,r){ss(e,t,void 0,r);for(const i in t.attrs)e.setAttribute(gs.has(i)?i:hs(i),t.attrs[i])}(e,t,0,r)}mount(e){this.isSVGTag=ys(e.tagName),super.mount(e)}}const bs=["animate","circle","defs","desc","ellipse","g","image","line","filter","marker","mask","metadata","path","pattern","polygon","polyline","rect","stop","switch","symbol","svg","text","tspan","use","view"];function ws(e){return"string"===typeof e&&!e.includes("-")&&!!(bs.indexOf(e)>-1||/[A-Z]/u.test(e))}const ks=(t,n)=>ws(t)?new vs(n):new ds(n,{allowProjection:t!==e.Fragment}),Ss=(0,e.createContext)({strict:!1}),js=(0,e.createContext)({});function $s(t){const{initial:n,animate:r}=function(e,t){if(Xa(e)){const{initial:t,animate:n}=e;return{initial:!1===t||Ya(t)?t:void 0,animate:Ya(n)?n:void 0}}return!1!==e.inherit?t:{}}(t,(0,e.useContext)(js));return(0,e.useMemo)(()=>({initial:n,animate:r}),[Cs(n),Cs(r)])}function Cs(e){return Array.isArray(e)?e.join(" "):e}const Es=()=>({style:{},transform:{},transformOrigin:{},vars:{}});function Ts(e,t,n){for(const r in t)Ca(t[r])||cs(r,n)||(e[r]=t[r])}function Ps(t,n){const r={};return Ts(r,t.style||{},t),Object.assign(r,function(t,n){let{transformTemplate:r}=t;return(0,e.useMemo)(()=>{const e={style:{},transform:{},transformOrigin:{},vars:{}};return as(e,n,r),Object.assign({},e.vars,e.style)},[n])}(t,n)),r}function zs(e,t){const n={},r=Ps(e,t);return e.drag&&!1!==e.dragListener&&(n.draggable=!1,r.userSelect=r.WebkitUserSelect=r.WebkitTouchCallout="none",r.touchAction=!0===e.drag?"none":"pan-"+("x"===e.drag?"y":"x")),void 0===e.tabIndex&&(e.onTap||e.onTapStart||e.whileTap)&&(n.tabIndex=0),n.style=r,n}const As=()=>({style:{},transform:{},transformOrigin:{},vars:{},attrs:{}});function Rs(t,n,r,i){const o=(0,e.useMemo)(()=>{const e={style:{},transform:{},transformOrigin:{},vars:{},attrs:{}};return fs(e,n,ys(i),t.transformTemplate,t.style),{...e.attrs,style:{...e.style}}},[n]);if(t.style){const e={};Ts(e,t.style,t),o.style={...e,...o.style}}return o}const Ms=new Set(["animate","exit","variants","initial","style","values","variants","transition","transformTemplate","custom","inherit","onBeforeLayoutMeasure","onAnimationStart","onAnimationComplete","onUpdate","onDragStart","onDrag","onDragEnd","onMeasureDragConstraints","onDirectionLock","onDragTransitionEnd","_dragX","_dragY","onHoverStart","onHoverEnd","onViewportEnter","onViewportLeave","globalTapTarget","ignoreStrict","viewport"]);function Ls(e){return e.startsWith("while")||e.startsWith("drag")&&"draggable"!==e||e.startsWith("layout")||e.startsWith("onTap")||e.startsWith("onPan")||e.startsWith("onLayout")||Ms.has(e)}let Ds=e=>!Ls(e);try{"function"===typeof(Os=require("@emotion/is-prop-valid").default)&&(Ds=e=>e.startsWith("on")?!Ls(e):Os(e))}catch{}var Os;function Fs(t,n,r,i,o){let{latestValues:a}=i,s=arguments.length>5&&void 0!==arguments[5]&&arguments[5];const l=(ws(t)?Rs:zs)(n,a,o,t),c=function(e,t,n){const r={};for(const i in e)"values"===i&&"object"===typeof e.values||(Ds(i)||!0===n&&Ls(i)||!t&&!Ls(i)||e.draggable&&i.startsWith("onDrag"))&&(r[i]=e[i]);return r}(n,"string"===typeof t,s),u=t!==e.Fragment?{...c,...l,ref:r}:{},{children:d}=n,h=(0,e.useMemo)(()=>Ca(d)?d.get():d,[d]);return(0,e.createElement)(t,{...u,children:h})}function Ns(e){return Ca(e)?e.get():e}function _s(e,t,n,r){const i={},o=r(e,{});for(const h in o)i[h]=Ns(o[h]);let{initial:a,animate:s}=e;const l=Xa(e),c=Qa(e);t&&c&&!l&&!1!==e.inherit&&(void 0===a&&(a=t.initial),void 0===s&&(s=t.animate));let u=!!n&&!1===n.initial;u=u||!1===a;const d=u?s:a;if(d&&"boolean"!==typeof d&&!qa(d)){const t=Array.isArray(d)?d:[d];for(let n=0;n<t.length;n++){const r=Za(e,t[n]);if(r){const{transitionEnd:e,transition:t,...n}=r;for(const r in n){let e=n[r];if(Array.isArray(e)){e=e[u?e.length-1:0]}null!==e&&(i[r]=e)}for(const r in e)i[r]=e[r]}}}return i}const Is=t=>(n,r)=>{const i=(0,e.useContext)(js),o=(0,e.useContext)(ai),a=()=>function(e,t,n,r){let{scrapeMotionValuesFromProps:i,createRenderState:o}=e;return{latestValues:_s(t,n,r,i),renderState:o()}}(t,n,i,o);return r?a():ri(a)},Vs=Is({scrapeMotionValuesFromProps:us,createRenderState:Es}),Bs=Is({scrapeMotionValuesFromProps:xs,createRenderState:As});const Ws=Symbol.for("motionComponentSymbol");function Hs(e){return e&&"object"===typeof e&&Object.prototype.hasOwnProperty.call(e,"current")}function Us(t,n,r){return(0,e.useCallback)(e=>{e&&t.onMount&&t.onMount(e),n&&(e?n.mount(e):n.unmount()),r&&("function"===typeof r?r(e):Hs(r)&&(r.current=e))},[n])}const qs="data-"+hs("framerAppearId"),Ys=(0,e.createContext)({});function Ks(t,n,r,i,o){const{visualElement:a}=(0,e.useContext)(js),s=(0,e.useContext)(Ss),l=(0,e.useContext)(ai),c=(0,e.useContext)(ci).reducedMotion,u=(0,e.useRef)(null);i=i||s.renderer,!u.current&&i&&(u.current=i(t,{visualState:n,parent:a,props:r,presenceContext:l,blockInitialAnimation:!!l&&!1===l.initial,reducedMotionConfig:c}));const d=u.current,h=(0,e.useContext)(Ys);!d||d.projection||!o||"html"!==d.type&&"svg"!==d.type||function(e,t,n,r){const{layoutId:i,layout:o,drag:a,dragConstraints:s,layoutScroll:l,layoutRoot:c,layoutCrossfade:u}=t;e.projection=new n(e.latestValues,t["data-framer-portal-id"]?void 0:Gs(e.parent)),e.projection.setOptions({layoutId:i,layout:o,alwaysMeasureLayout:Boolean(a)||s&&Hs(s),visualElement:e,animationType:"string"===typeof o?o:"both",initialPromotionConfig:r,crossfade:u,layoutScroll:l,layoutRoot:c})}(u.current,r,o,h);const p=(0,e.useRef)(!1);(0,e.useInsertionEffect)(()=>{d&&p.current&&d.update(r,l)});const m=r[qs],f=(0,e.useRef)(Boolean(m)&&!window.MotionHandoffIsComplete?.(m)&&window.MotionHasOptimisedAnimation?.(m));return oi(()=>{d&&(p.current=!0,window.MotionIsMounted=!0,d.updateFeatures(),d.scheduleRenderMicrotask(),f.current&&d.animationState&&d.animationState.animateChanges())}),(0,e.useEffect)(()=>{d&&(!f.current&&d.animationState&&d.animationState.animateChanges(),f.current&&(queueMicrotask(()=>{window.MotionHandoffMarkAsComplete?.(m)}),f.current=!1))}),d}function Gs(e){if(e)return!1!==e.options.allowProjection?e.projection:Gs(e.parent)}function Xs(t){let{forwardMotionProps:n=!1}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},r=arguments.length>2?arguments[2]:void 0,i=arguments.length>3?arguments[3]:void 0;r&&function(e){for(const t in e)Va[t]={...Va[t],...e[t]}}(r);const o=ws(t)?Bs:Vs;function a(r,a){let s;const l={...(0,e.useContext)(ci),...r,layoutId:Qs(r)},{isStatic:c}=l,u=$s(r),d=o(r,c);if(!c&&ii){!function(){(0,e.useContext)(Ss).strict;0}();const n=function(e){const{drag:t,layout:n}=Va;if(!t&&!n)return{};const r={...t,...n};return{MeasureLayout:t?.isEnabled(e)||n?.isEnabled(e)?r.MeasureLayout:void 0,ProjectionNode:r.ProjectionNode}}(l);s=n.MeasureLayout,u.visualElement=Ks(t,d,l,i,n.ProjectionNode)}return(0,ti.jsxs)(js.Provider,{value:u,children:[s&&u.visualElement?(0,ti.jsx)(s,{visualElement:u.visualElement,...l}):null,Fs(t,r,Us(d,u.visualElement,a),d,c,n)]})}a.displayName=`motion.${"string"===typeof t?t:`create(${t.displayName??t.name??""})`}`;const s=(0,e.forwardRef)(a);return s[Ws]=t,s}function Qs(t){let{layoutId:n}=t;const r=(0,e.useContext)(ni).id;return r&&void 0!==n?r+"-"+n:n}function Js(e,t){if("undefined"===typeof Proxy)return Xs;const n=new Map,r=(n,r)=>Xs(n,r,e,t);return new Proxy((e,t)=>r(e,t),{get:(i,o)=>"create"===o?r:(n.has(o)||n.set(o,Xs(o,void 0,e,t)),n.get(o))})}function Zs(e,t,n){const r=e.getProps();return Za(r,t,void 0!==n?n:r.custom,e)}function el(e,t){return e?.[t]??e?.default??e}const tl=e=>Array.isArray(e);function nl(e,t,n){e.hasValue(t)?e.getValue(t).set(n):e.addValue(t,Oa(n))}function rl(e){return tl(e)?e[e.length-1]||0:e}function il(e,t){const n=e.getValue("willChange");if(r=n,Boolean(Ca(r)&&r.add))return n.add(t);if(!n&&Mo.WillChange){const n=new Mo.WillChange("auto");e.addValue("willChange",n),n.add(t)}var r}function ol(e){return e.props[qs]}const al=(e,t)=>n=>t(e(n)),sl=function(){for(var e=arguments.length,t=new Array(e),n=0;n<e;n++)t[n]=arguments[n];return t.reduce(al)},ll=e=>1e3*e,cl=e=>e/1e3,ul={layout:0,mainThread:0,waapi:0};function dl(e,t,n){return n<0&&(n+=1),n>1&&(n-=1),n<1/6?e+6*(t-e)*n:n<.5?t:n<2/3?e+(t-e)*(2/3-n)*6:e}function hl(e,t){return n=>n>0?t:e}const pl=(e,t,n)=>{const r=e*e,i=n*(t*t-r)+r;return i<0?0:Math.sqrt(i)},ml=[ra,na,ia];function fl(e){const t=(e=>ml.find(t=>t.test(e)))(e);if(Boolean(t),!Boolean(t))return!1;let n=t.parse(e);return t===ia&&(n=function(e){let{hue:t,saturation:n,lightness:r,alpha:i}=e;t/=360,n/=100,r/=100;let o=0,a=0,s=0;if(n){const e=r<.5?r*(1+n):r+n-r*n,i=2*r-e;o=dl(i,e,t+1/3),a=dl(i,e,t),s=dl(i,e,t-1/3)}else o=a=s=r;return{red:Math.round(255*o),green:Math.round(255*a),blue:Math.round(255*s),alpha:i}}(n)),n}const gl=(e,t)=>{const n=fl(e),r=fl(t);if(!n||!r)return hl(e,t);const i={...n};return e=>(i.red=pl(n.red,r.red,e),i.green=pl(n.green,r.green,e),i.blue=pl(n.blue,r.blue,e),i.alpha=Yi(n.alpha,r.alpha,e),na.transform(i))},yl=new Set(["none","hidden"]);function xl(e,t){return n=>Yi(e,t,n)}function vl(e){return"number"===typeof e?xl:"string"===typeof e?Hi(e)?hl:oa.test(e)?gl:kl:Array.isArray(e)?bl:"object"===typeof e?oa.test(e)?gl:wl:hl}function bl(e,t){const n=[...e],r=n.length,i=e.map((e,n)=>vl(e)(e,t[n]));return e=>{for(let t=0;t<r;t++)n[t]=i[t](e);return n}}function wl(e,t){const n={...e,...t},r={};for(const i in n)void 0!==e[i]&&void 0!==t[i]&&(r[i]=vl(e[i])(e[i],t[i]));return e=>{for(const t in r)n[t]=r[t](e);return n}}const kl=(e,t)=>{const n=ma.createTransformer(t),r=ua(e),i=ua(t);return r.indexes.var.length===i.indexes.var.length&&r.indexes.color.length===i.indexes.color.length&&r.indexes.number.length>=i.indexes.number.length?yl.has(e)&&!i.values.length||yl.has(t)&&!r.values.length?function(e,t){return yl.has(e)?n=>n<=0?e:t:n=>n>=1?t:e}(e,t):sl(bl(function(e,t){const n=[],r={color:0,var:0,number:0};for(let i=0;i<t.values.length;i++){const o=t.types[i],a=e.indexes[o][r[o]],s=e.values[a]??0;n[i]=s,r[o]++}return n}(r,i),i.values),n):hl(e,t)};function Sl(e,t,n){if("number"===typeof e&&"number"===typeof t&&"number"===typeof n)return Yi(e,t,n);return vl(e)(e,t)}const jl=e=>{const t=t=>{let{timestamp:n}=t;return e(n)};return{start:function(){let e=!(arguments.length>0&&void 0!==arguments[0])||arguments[0];return Fo.update(t,e)},stop:()=>No(t),now:()=>_o.isProcessing?_o.timestamp:Pa.now()}},$l=function(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:10,r="";const i=Math.max(Math.round(t/n),2);for(let o=0;o<i;o++)r+=Math.round(1e4*e(o/(i-1)))/1e4+", ";return`linear(${r.substring(0,r.length-2)})`},Cl=2e4;function El(e){let t=0;let n=e.next(t);for(;!n.done&&t<Cl;)t+=50,n=e.next(t);return t>=Cl?1/0:t}function Tl(e,t,n){const r=Math.max(t-5,0);return Ma(n-e(r),t-r)}const Pl={stiffness:100,damping:10,mass:1,velocity:0,duration:800,bounce:.3,visualDuration:.3,restSpeed:{granular:.01,default:2},restDelta:{granular:.005,default:.5},minDuration:.01,maxDuration:10,minDamping:.05,maxDamping:1},zl=.001;function Al(e){let t,n,{duration:r=Pl.duration,bounce:i=Pl.bounce,velocity:o=Pl.velocity,mass:a=Pl.mass}=e;ll(Pl.maxDuration);let s=1-i;s=uo(Pl.minDamping,Pl.maxDamping,s),r=uo(Pl.minDuration,Pl.maxDuration,cl(r)),s<1?(t=e=>{const t=e*s,n=t*r,i=t-o,a=Ml(e,s),l=Math.exp(-n);return zl-i/a*l},n=e=>{const n=e*s*r,i=n*o+o,a=Math.pow(s,2)*Math.pow(e,2)*r,l=Math.exp(-n),c=Ml(Math.pow(e,2),s);return(-t(e)+zl>0?-1:1)*((i-a)*l)/c}):(t=e=>Math.exp(-e*r)*((e-o)*r+1)-.001,n=e=>Math.exp(-e*r)*(r*r*(o-e)));const l=function(e,t,n){let r=n;for(let i=1;i<Rl;i++)r-=e(r)/t(r);return r}(t,n,5/r);if(r=ll(r),isNaN(l))return{stiffness:Pl.stiffness,damping:Pl.damping,duration:r};{const e=Math.pow(l,2)*a;return{stiffness:e,damping:2*s*Math.sqrt(a*e),duration:r}}}const Rl=12;function Ml(e,t){return e*Math.sqrt(1-t*t)}const Ll=["duration","bounce"],Dl=["stiffness","damping","mass"];function Ol(e,t){return t.some(t=>void 0!==e[t])}function Fl(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:Pl.visualDuration,t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:Pl.bounce;const n="object"!==typeof e?{visualDuration:e,keyframes:[0,1],bounce:t}:e;let{restSpeed:r,restDelta:i}=n;const o=n.keyframes[0],a=n.keyframes[n.keyframes.length-1],s={done:!1,value:o},{stiffness:l,damping:c,mass:u,duration:d,velocity:h,isResolvedFromDuration:p}=function(e){let t={velocity:Pl.velocity,stiffness:Pl.stiffness,damping:Pl.damping,mass:Pl.mass,isResolvedFromDuration:!1,...e};if(!Ol(e,Dl)&&Ol(e,Ll))if(e.visualDuration){const n=e.visualDuration,r=2*Math.PI/(1.2*n),i=r*r,o=2*uo(.05,1,1-(e.bounce||0))*Math.sqrt(i);t={...t,mass:Pl.mass,stiffness:i,damping:o}}else{const n=Al(e);t={...t,...n,mass:Pl.mass},t.isResolvedFromDuration=!0}return t}({...n,velocity:-cl(n.velocity||0)}),m=h||0,f=c/(2*Math.sqrt(l*u)),g=a-o,y=cl(Math.sqrt(l/u)),x=Math.abs(g)<5;let v;if(r||(r=x?Pl.restSpeed.granular:Pl.restSpeed.default),i||(i=x?Pl.restDelta.granular:Pl.restDelta.default),f<1){const e=Ml(y,f);v=t=>{const n=Math.exp(-f*y*t);return a-n*((m+f*y*g)/e*Math.sin(e*t)+g*Math.cos(e*t))}}else if(1===f)v=e=>a-Math.exp(-y*e)*(g+(m+y*g)*e);else{const e=y*Math.sqrt(f*f-1);v=t=>{const n=Math.exp(-f*y*t),r=Math.min(e*t,300);return a-n*((m+f*y*g)*Math.sinh(r)+e*g*Math.cosh(r))/e}}const b={calculatedDuration:p&&d||null,next:e=>{const t=v(e);if(p)s.done=e>=d;else{let n=0===e?m:0;f<1&&(n=0===e?ll(m):Tl(v,e,t));const o=Math.abs(n)<=r,l=Math.abs(a-t)<=i;s.done=o&&l}return s.value=s.done?a:t,s},toString:()=>{const e=Math.min(El(b),Cl),t=$l(t=>b.next(e*t).value,e,30);return e+"ms "+t},toTransition:()=>{}};return b}function Nl(e){let{keyframes:t,velocity:n=0,power:r=.8,timeConstant:i=325,bounceDamping:o=10,bounceStiffness:a=500,modifyTarget:s,min:l,max:c,restDelta:u=.5,restSpeed:d}=e;const h=t[0],p={done:!1,value:h},m=e=>void 0===l?c:void 0===c||Math.abs(l-e)<Math.abs(c-e)?l:c;let f=r*n;const g=h+f,y=void 0===s?g:s(g);y!==g&&(f=y-h);const x=e=>-f*Math.exp(-e/i),v=e=>y+x(e),b=e=>{const t=x(e),n=v(e);p.done=Math.abs(t)<=u,p.value=p.done?y:n};let w,k;const S=e=>{(e=>void 0!==l&&e<l||void 0!==c&&e>c)(p.value)&&(w=e,k=Fl({keyframes:[p.value,m(p.value)],velocity:Tl(v,e,p.value),damping:o,stiffness:a,restDelta:u,restSpeed:d}))};return S(0),{calculatedDuration:null,next:e=>{let t=!1;return k||void 0!==w||(t=!0,b(e),S(e)),void 0!==w&&e>=w?k.next(e-w):(!t&&b(e),p)}}}Fl.applyToOptions=e=>{const t=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:100;const n=(arguments.length>2?arguments[2]:void 0)({...e,keyframes:[0,t]}),r=Math.min(El(n),Cl);return{type:"keyframes",ease:e=>n.next(r*e).value/t,duration:cl(r)}}(e,100,Fl);return e.ease=t.ease,e.duration=ll(t.duration),e.type="keyframes",e};const _l=(e,t,n)=>(((1-3*n+3*t)*e+(3*n-6*t))*e+3*t)*e;function Il(e,t,n,r){if(e===t&&n===r)return Ro;const i=t=>function(e,t,n,r,i){let o,a,s=0;do{a=t+(n-t)/2,o=_l(a,r,i)-e,o>0?n=a:t=a}while(Math.abs(o)>1e-7&&++s<12);return a}(t,0,1,e,n);return e=>0===e||1===e?e:_l(i(e),t,r)}const Vl=Il(.42,0,1,1),Bl=Il(0,0,.58,1),Wl=Il(.42,0,.58,1),Hl=e=>t=>t<=.5?e(2*t)/2:(2-e(2*(1-t)))/2,Ul=e=>t=>1-e(1-t),ql=Il(.33,1.53,.69,.99),Yl=Ul(ql),Kl=Hl(Yl),Gl=e=>(e*=2)<1?.5*Yl(e):.5*(2-Math.pow(2,-10*(e-1))),Xl=e=>1-Math.sin(Math.acos(e)),Ql=Ul(Xl),Jl=Hl(Xl),Zl=e=>Array.isArray(e)&&"number"===typeof e[0],ec={linear:Ro,easeIn:Vl,easeInOut:Wl,easeOut:Bl,circIn:Xl,circInOut:Jl,circOut:Ql,backIn:Yl,backInOut:Kl,backOut:ql,anticipate:Gl},tc=e=>{if(Zl(e)){e.length;const[t,n,r,i]=e;return Il(t,n,r,i)}return"string"===typeof e?ec[e]:e},nc=(e,t,n)=>{const r=t-e;return 0===r?1:(n-e)/r};function rc(e,t){let{clamp:n=!0,ease:r,mixer:i}=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};const o=e.length;if(t.length,1===o)return()=>t[0];if(2===o&&t[0]===t[1])return()=>t[1];const a=e[0]===e[1];e[0]>e[o-1]&&(e=[...e].reverse(),t=[...t].reverse());const s=function(e,t,n){const r=[],i=n||Mo.mix||Sl,o=e.length-1;for(let a=0;a<o;a++){let n=i(e[a],e[a+1]);if(t){const e=Array.isArray(t)?t[a]||Ro:t;n=sl(e,n)}r.push(n)}return r}(t,r,i),l=s.length,c=n=>{if(a&&n<e[0])return t[0];let r=0;if(l>1)for(;r<e.length-2&&!(n<e[r+1]);r++);const i=nc(e[r],e[r+1],n);return s[r](i)};return n?t=>c(uo(e[0],e[o-1],t)):c}function ic(e){const t=[0];return function(e,t){const n=e[e.length-1];for(let r=1;r<=t;r++){const i=nc(0,t,r);e.push(Yi(n,1,i))}}(t,e.length-1),t}function oc(e){let{duration:t=300,keyframes:n,times:r,ease:i="easeInOut"}=e;const o=(e=>Array.isArray(e)&&"number"!==typeof e[0])(i)?i.map(tc):tc(i),a={done:!1,value:n[0]},s=function(e,t){return e.map(e=>e*t)}(r&&r.length===n.length?r:ic(n),t),l=rc(s,n,{ease:Array.isArray(o)?o:(c=n,u=o,c.map(()=>u||Wl).splice(0,c.length-1))});var c,u;return{calculatedDuration:t,next:e=>(a.value=l(e),a.done=e>=t,a)}}const ac=e=>null!==e;function sc(e,t,n){let{repeat:r,repeatType:i="loop"}=t,o=arguments.length>3&&void 0!==arguments[3]?arguments[3]:1;const a=e.filter(ac),s=o<0||r&&"loop"!==i&&r%2===1?0:a.length-1;return s&&void 0!==n?n:a[s]}const lc={decay:Nl,inertia:Nl,tween:oc,keyframes:oc,spring:Fl};function cc(e){"string"===typeof e.type&&(e.type=lc[e.type])}class uc{constructor(){this.updateFinished()}get finished(){return this._finished}updateFinished(){this._finished=new Promise(e=>{this.resolve=e})}notifyFinished(){this.resolve()}then(e,t){return this.finished.then(e,t)}}const dc=e=>e/100;class hc extends uc{constructor(e){super(),this.state="idle",this.startTime=null,this.isStopped=!1,this.currentTime=0,this.holdTime=null,this.playbackSpeed=1,this.stop=()=>{const{motionValue:e}=this.options;e&&e.updatedAt!==Pa.now()&&this.tick(Pa.now()),this.isStopped=!0,"idle"!==this.state&&(this.teardown(),this.options.onStop?.())},ul.mainThread++,this.options=e,this.initAnimation(),this.play(),!1===e.autoplay&&this.pause()}initAnimation(){const{options:e}=this;cc(e);const{type:t=oc,repeat:n=0,repeatDelay:r=0,repeatType:i,velocity:o=0}=e;let{keyframes:a}=e;const s=t||oc;s!==oc&&"number"!==typeof a[0]&&(this.mixKeyframes=sl(dc,Sl(a[0],a[1])),a=[0,100]);const l=s({...e,keyframes:a});"mirror"===i&&(this.mirroredGenerator=s({...e,keyframes:[...a].reverse(),velocity:-o})),null===l.calculatedDuration&&(l.calculatedDuration=El(l));const{calculatedDuration:c}=l;this.calculatedDuration=c,this.resolvedDuration=c+r,this.totalDuration=this.resolvedDuration*(n+1)-r,this.generator=l}updateTime(e){const t=Math.round(e-this.startTime)*this.playbackSpeed;null!==this.holdTime?this.currentTime=this.holdTime:this.currentTime=t}tick(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1];const{generator:n,totalDuration:r,mixKeyframes:i,mirroredGenerator:o,resolvedDuration:a,calculatedDuration:s}=this;if(null===this.startTime)return n.next(0);const{delay:l=0,keyframes:c,repeat:u,repeatType:d,repeatDelay:h,type:p,onUpdate:m,finalKeyframe:f}=this.options;this.speed>0?this.startTime=Math.min(this.startTime,e):this.speed<0&&(this.startTime=Math.min(e-r/this.speed,this.startTime)),t?this.currentTime=e:this.updateTime(e);const g=this.currentTime-l*(this.playbackSpeed>=0?1:-1),y=this.playbackSpeed>=0?g<0:g>r;this.currentTime=Math.max(g,0),"finished"===this.state&&null===this.holdTime&&(this.currentTime=r);let x=this.currentTime,v=n;if(u){const e=Math.min(this.currentTime,r)/a;let t=Math.floor(e),n=e%1;!n&&e>=1&&(n=1),1===n&&t--,t=Math.min(t,u+1);Boolean(t%2)&&("reverse"===d?(n=1-n,h&&(n-=h/a)):"mirror"===d&&(v=o)),x=uo(0,1,n)*a}const b=y?{done:!1,value:c[0]}:v.next(x);i&&(b.value=i(b.value));let{done:w}=b;y||null===s||(w=this.playbackSpeed>=0?this.currentTime>=r:this.currentTime<=0);const k=null===this.holdTime&&("finished"===this.state||"running"===this.state&&w);return k&&p!==Nl&&(b.value=sc(c,this.options,f,this.speed)),m&&m(b.value),k&&this.finish(),b}then(e,t){return this.finished.then(e,t)}get duration(){return cl(this.calculatedDuration)}get time(){return cl(this.currentTime)}set time(e){e=ll(e),this.currentTime=e,null===this.startTime||null!==this.holdTime||0===this.playbackSpeed?this.holdTime=e:this.driver&&(this.startTime=this.driver.now()-e/this.playbackSpeed),this.driver?.start(!1)}get speed(){return this.playbackSpeed}set speed(e){this.updateTime(Pa.now());const t=this.playbackSpeed!==e;this.playbackSpeed=e,t&&(this.time=cl(this.currentTime))}play(){if(this.isStopped)return;const{driver:e=jl,startTime:t}=this.options;this.driver||(this.driver=e(e=>this.tick(e))),this.options.onPlay?.();const n=this.driver.now();"finished"===this.state?(this.updateFinished(),this.startTime=n):null!==this.holdTime?this.startTime=n-this.holdTime:this.startTime||(this.startTime=t??n),"finished"===this.state&&this.speed<0&&(this.startTime+=this.calculatedDuration),this.holdTime=null,this.state="running",this.driver.start()}pause(){this.state="paused",this.updateTime(Pa.now()),this.holdTime=this.currentTime}complete(){"running"!==this.state&&this.play(),this.state="finished",this.holdTime=null}finish(){this.notifyFinished(),this.teardown(),this.state="finished",this.options.onComplete?.()}cancel(){this.holdTime=null,this.startTime=0,this.tick(0),this.teardown(),this.options.onCancel?.()}teardown(){this.state="idle",this.stopDriver(),this.startTime=this.holdTime=null,ul.mainThread--}stopDriver(){this.driver&&(this.driver.stop(),this.driver=void 0)}sample(e){return this.startTime=0,this.tick(e,!0)}attachTimeline(e){return this.options.allowFlatten&&(this.options.type="keyframes",this.options.ease="linear",this.initAnimation()),this.driver?.stop(),e.observe(this)}}function pc(e){let t;return()=>(void 0===t&&(t=e()),t)}const mc=pc(()=>void 0!==window.ScrollTimeline),fc={};function gc(e,t){const n=pc(e);return()=>fc[t]??n()}const yc=gc(()=>{try{document.createElement("div").animate({opacity:0},{easing:"linear(0, 1)"})}catch(w$){return!1}return!0},"linearEasing"),xc=e=>{let[t,n,r,i]=e;return`cubic-bezier(${t}, ${n}, ${r}, ${i})`},vc={linear:"linear",ease:"ease",easeIn:"ease-in",easeOut:"ease-out",easeInOut:"ease-in-out",circIn:xc([0,.65,.55,1]),circOut:xc([.55,0,1,.45]),backIn:xc([.31,.01,.66,-.59]),backOut:xc([.33,1.53,.69,.99])};function bc(e,t){return e?"function"===typeof e?yc()?$l(e,t):"ease-out":Zl(e)?xc(e):Array.isArray(e)?e.map(e=>bc(e,t)||vc.easeOut):vc[e]:void 0}function wc(e,t,n){let{delay:r=0,duration:i=300,repeat:o=0,repeatType:a="loop",ease:s="easeOut",times:l}=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{},c=arguments.length>4&&void 0!==arguments[4]?arguments[4]:void 0;const u={[t]:n};l&&(u.offset=l);const d=bc(s,i);Array.isArray(d)&&(u.easing=d),Do.value&&ul.waapi++;const h={delay:r,duration:i,easing:Array.isArray(d)?"linear":d,fill:"both",iterations:o+1,direction:"reverse"===a?"alternate":"normal"};c&&(h.pseudoElement=c);const p=e.animate(u,h);return Do.value&&p.finished.finally(()=>{ul.waapi--}),p}function kc(e){return"function"===typeof e&&"applyToOptions"in e}class Sc extends uc{constructor(e){if(super(),this.finishedTime=null,this.isStopped=!1,!e)return;const{element:t,name:n,keyframes:r,pseudoElement:i,allowFlatten:o=!1,finalKeyframe:a,onComplete:s}=e;this.isPseudoElement=Boolean(i),this.allowFlatten=o,this.options=e,e.type;const l=function(e){let{type:t,...n}=e;return kc(t)&&yc()?t.applyToOptions(n):(n.duration??(n.duration=300),n.ease??(n.ease="easeOut"),n)}(e);this.animation=wc(t,n,r,l,i),!1===l.autoplay&&this.animation.pause(),this.animation.onfinish=()=>{if(this.finishedTime=this.time,!i){const e=sc(r,this.options,a,this.speed);this.updateMotionValue?this.updateMotionValue(e):function(e,t,n){(e=>e.startsWith("--"))(t)?e.style.setProperty(t,n):e.style[t]=n}(t,n,e),this.animation.cancel()}s?.(),this.notifyFinished()}}play(){this.isStopped||(this.animation.play(),"finished"===this.state&&this.updateFinished())}pause(){this.animation.pause()}complete(){this.animation.finish?.()}cancel(){try{this.animation.cancel()}catch(w$){}}stop(){if(this.isStopped)return;this.isStopped=!0;const{state:e}=this;"idle"!==e&&"finished"!==e&&(this.updateMotionValue?this.updateMotionValue():this.commitStyles(),this.isPseudoElement||this.cancel())}commitStyles(){this.isPseudoElement||this.animation.commitStyles?.()}get duration(){const e=this.animation.effect?.getComputedTiming?.().duration||0;return cl(Number(e))}get time(){return cl(Number(this.animation.currentTime)||0)}set time(e){this.finishedTime=null,this.animation.currentTime=ll(e)}get speed(){return this.animation.playbackRate}set speed(e){e<0&&(this.finishedTime=null),this.animation.playbackRate=e}get state(){return null!==this.finishedTime?"finished":this.animation.playState}get startTime(){return Number(this.animation.startTime)}set startTime(e){this.animation.startTime=e}attachTimeline(e){let{timeline:t,observe:n}=e;return this.allowFlatten&&this.animation.effect?.updateTiming({easing:"linear"}),this.animation.onfinish=null,t&&mc()?(this.animation.timeline=t,Ro):n(this)}}const jc={anticipate:Gl,backInOut:Kl,circInOut:Jl};function $c(e){"string"===typeof e.ease&&e.ease in jc&&(e.ease=jc[e.ease])}class Cc extends Sc{constructor(e){$c(e),cc(e),super(e),e.startTime&&(this.startTime=e.startTime),this.options=e}updateMotionValue(e){const{motionValue:t,onUpdate:n,onComplete:r,element:i,...o}=this.options;if(!t)return;if(void 0!==e)return void t.set(e);const a=new hc({...o,autoplay:!1}),s=ll(this.finishedTime??this.time);t.setWithVelocity(a.sample(s-10).value,a.sample(s).value,10),a.stop()}}const Ec=(e,t)=>"zIndex"!==t&&(!("number"!==typeof e&&!Array.isArray(e))||!("string"!==typeof e||!ma.test(e)&&"0"!==e||e.startsWith("url(")));const Tc=new Set(["opacity","clipPath","filter","transform"]),Pc=pc(()=>Object.hasOwnProperty.call(Element.prototype,"animate"));class zc extends uc{constructor(e){let{autoplay:t=!0,delay:n=0,type:r="keyframes",repeat:i=0,repeatDelay:o=0,repeatType:a="loop",keyframes:s,name:l,motionValue:c,element:u,...d}=e;super(),this.stop=()=>{this._animation&&(this._animation.stop(),this.stopTimeline?.()),this.keyframeResolver?.cancel()},this.createdAt=Pa.now();const h={autoplay:t,delay:n,type:r,repeat:i,repeatDelay:o,repeatType:a,name:l,motionValue:c,element:u,...d},p=u?.KeyframeResolver||Yo;this.keyframeResolver=new p(s,(e,t,n)=>this.onKeyframesResolved(e,t,h,!n),l,c,u),this.keyframeResolver?.scheduleResolve()}onKeyframesResolved(e,t,n,r){this.keyframeResolver=void 0;const{name:i,type:o,velocity:a,delay:s,isHandoff:l,onUpdate:c}=n;this.resolvedAt=Pa.now(),function(e,t,n,r){const i=e[0];if(null===i)return!1;if("display"===t||"visibility"===t)return!0;const o=e[e.length-1],a=Ec(i,t),s=Ec(o,t);return!(!a||!s)&&(function(e){const t=e[0];if(1===e.length)return!0;for(let n=0;n<e.length;n++)if(e[n]!==t)return!0}(e)||("spring"===n||kc(n))&&r)}(e,i,o,a)||(!Mo.instantAnimations&&s||c?.(sc(e,n,t)),e[0]=e[e.length-1],n.duration=0,n.repeat=0);const u={startTime:r?this.resolvedAt&&this.resolvedAt-this.createdAt>40?this.resolvedAt:this.createdAt:void 0,finalKeyframe:t,...n,keyframes:e},d=!l&&function(e){const{motionValue:t,name:n,repeatDelay:r,repeatType:i,damping:o,type:a}=e,s=t?.owner?.current;if(!(s instanceof HTMLElement))return!1;const{onUpdate:l,transformTemplate:c}=t.owner.getProps();return Pc()&&n&&Tc.has(n)&&("transform"!==n||!c)&&!l&&!r&&"mirror"!==i&&0!==o&&"inertia"!==a}(u)?new Cc({...u,element:u.motionValue.owner.current}):new hc(u);d.finished.then(()=>this.notifyFinished()).catch(Ro),this.pendingTimeline&&(this.stopTimeline=d.attachTimeline(this.pendingTimeline),this.pendingTimeline=void 0),this._animation=d}get finished(){return this._animation?this.animation.finished:this._finished}then(e,t){return this.finished.finally(e).then(()=>{})}get animation(){return this._animation||(this.keyframeResolver?.resume(),Ho=!0,qo(),Uo(),Ho=!1),this._animation}get duration(){return this.animation.duration}get time(){return this.animation.time}set time(e){this.animation.time=e}get speed(){return this.animation.speed}get state(){return this.animation.state}set speed(e){this.animation.speed=e}get startTime(){return this.animation.startTime}attachTimeline(e){return this._animation?this.stopTimeline=this.animation.attachTimeline(e):this.pendingTimeline=e,()=>this.stop()}play(){this.animation.play()}pause(){this.animation.pause()}complete(){this.animation.complete()}cancel(){this._animation&&this.animation.cancel(),this.keyframeResolver?.cancel()}}const Ac=e=>null!==e;const Rc={type:"spring",stiffness:500,damping:25,restSpeed:10},Mc={type:"keyframes",duration:.8},Lc={type:"keyframes",ease:[.25,.1,.35,1],duration:.3},Dc=(e,t)=>{let{keyframes:n}=t;return n.length>2?Mc:zi.has(e)?e.startsWith("scale")?{type:"spring",stiffness:550,damping:0===n[1]?2*Math.sqrt(550):30,restSpeed:10}:Rc:Lc};const Oc=function(e,t,n){let r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{},i=arguments.length>4?arguments[4]:void 0,o=arguments.length>5?arguments[5]:void 0;return a=>{const s=el(r,e)||{},l=s.delay||r.delay||0;let{elapsed:c=0}=r;c-=ll(l);const u={keyframes:Array.isArray(n)?n:[null,n],ease:"easeOut",velocity:t.getVelocity(),...s,delay:-c,onUpdate:e=>{t.set(e),s.onUpdate&&s.onUpdate(e)},onComplete:()=>{a(),s.onComplete&&s.onComplete()},name:e,motionValue:t,element:o?void 0:i};(function(e){let{when:t,delay:n,delayChildren:r,staggerChildren:i,staggerDirection:o,repeat:a,repeatType:s,repeatDelay:l,from:c,elapsed:u,...d}=e;return!!Object.keys(d).length})(s)||Object.assign(u,Dc(e,u)),u.duration&&(u.duration=ll(u.duration)),u.repeatDelay&&(u.repeatDelay=ll(u.repeatDelay)),void 0!==u.from&&(u.keyframes[0]=u.from);let d=!1;if((!1===u.type||0===u.duration&&!u.repeatDelay)&&(u.duration=0,0===u.delay&&(d=!0)),(Mo.instantAnimations||Mo.skipAnimations)&&(d=!0,u.duration=0,u.delay=0),u.allowFlatten=!s.type&&!s.ease,d&&!o&&void 0!==t.get()){const e=function(e,t,n){let{repeat:r,repeatType:i="loop"}=t;const o=e.filter(Ac),a=r&&"loop"!==i&&r%2===1?0:o.length-1;return a&&void 0!==n?n:o[a]}(u.keyframes,s);if(void 0!==e)return void Fo.update(()=>{u.onUpdate(e),u.onComplete()})}return s.isSync?new hc(u):new zc(u)}};function Fc(e,t){let{protectedKeys:n,needsAnimating:r}=e;const i=n.hasOwnProperty(t)&&!0!==r[t];return r[t]=!1,i}function Nc(e,t){let{delay:n=0,transitionOverride:r,type:i}=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},{transition:o=e.getDefaultTransition(),transitionEnd:a,...s}=t;r&&(o=r);const l=[],c=i&&e.animationState&&e.animationState.getState()[i];for(const u in s){const t=e.getValue(u,e.latestValues[u]??null),r=s[u];if(void 0===r||c&&Fc(c,u))continue;const i={delay:n,...el(o||{},u)},a=t.get();if(void 0!==a&&!t.isAnimating&&!Array.isArray(r)&&r===a&&!i.velocity)continue;let d=!1;if(window.MotionHandoffAnimation){const t=ol(e);if(t){const e=window.MotionHandoffAnimation(t,u,Fo);null!==e&&(i.startTime=e,d=!0)}}il(e,u),t.start(Oc(u,t,r,e.shouldReduceMotion&&co.has(u)?{type:!1}:i,e,d));const h=t.animation;h&&l.push(h)}return a&&Promise.all(l).then(()=>{Fo.update(()=>{a&&function(e,t){const n=Zs(e,t);let{transitionEnd:r={},transition:i={},...o}=n||{};o={...o,...r};for(const a in o)nl(e,a,rl(o[a]))}(e,a)})}),l}function _c(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};const r=Zs(e,t,"exit"===n.type?e.presenceContext?.custom:void 0);let{transition:i=e.getDefaultTransition()||{}}=r||{};n.transitionOverride&&(i=n.transitionOverride);const o=r?()=>Promise.all(Nc(e,r,n)):()=>Promise.resolve(),a=e.variantChildren&&e.variantChildren.size?function(){let r=arguments.length>0&&void 0!==arguments[0]?arguments[0]:0;const{delayChildren:o=0,staggerChildren:a,staggerDirection:s}=i;return function(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:0,r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:0,i=arguments.length>4&&void 0!==arguments[4]?arguments[4]:0,o=arguments.length>5&&void 0!==arguments[5]?arguments[5]:1,a=arguments.length>6?arguments[6]:void 0;const s=[],l=e.variantChildren.size,c=(l-1)*i,u="function"===typeof r,d=u?e=>r(e,l):1===o?function(){return(arguments.length>0&&void 0!==arguments[0]?arguments[0]:0)*i}:function(){return c-(arguments.length>0&&void 0!==arguments[0]?arguments[0]:0)*i};return Array.from(e.variantChildren).sort(Ic).forEach((e,i)=>{e.notify("AnimationStart",t),s.push(_c(e,t,{...a,delay:n+(u?0:r)+d(i)}).then(()=>e.notify("AnimationComplete",t)))}),Promise.all(s)}(e,t,r,o,a,s,n)}:()=>Promise.resolve(),{when:s}=i;if(s){const[e,t]="beforeChildren"===s?[o,a]:[a,o];return e().then(()=>t())}return Promise.all([o(),a(n.delay)])}function Ic(e,t){return e.sortNodePosition(t)}function Vc(e,t){if(!Array.isArray(t))return!1;const n=t.length;if(n!==e.length)return!1;for(let r=0;r<n;r++)if(t[r]!==e[r])return!1;return!0}const Bc=Ga.length;function Wc(e){if(!e)return;if(!e.isControllingVariants){const t=e.parent&&Wc(e.parent)||{};return void 0!==e.props.initial&&(t.initial=e.props.initial),t}const t={};for(let n=0;n<Bc;n++){const r=Ga[n],i=e.props[r];(Ya(i)||!1===i)&&(t[r]=i)}return t}const Hc=[...Ka].reverse(),Uc=Ka.length;function qc(e){return t=>Promise.all(t.map(t=>{let{animation:n,options:r}=t;return function(e,t){let n,r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};if(e.notify("AnimationStart",t),Array.isArray(t)){const i=t.map(t=>_c(e,t,r));n=Promise.all(i)}else if("string"===typeof t)n=_c(e,t,r);else{const i="function"===typeof t?Zs(e,t,r.custom):t;n=Promise.all(Nc(e,i,r))}return n.then(()=>{e.notify("AnimationComplete",t)})}(e,n,r)}))}function Yc(e){let t=qc(e),n=Xc(),r=!0;const i=t=>(n,r)=>{const i=Zs(e,r,"exit"===t?e.presenceContext?.custom:void 0);if(i){const{transition:e,transitionEnd:t,...r}=i;n={...n,...r,...t}}return n};function o(o){const{props:a}=e,s=Wc(e.parent)||{},l=[],c=new Set;let u={},d=1/0;for(let t=0;t<Uc;t++){const h=Hc[t],p=n[h],m=void 0!==a[h]?a[h]:s[h],f=Ya(m),g=h===o?p.isActive:null;!1===g&&(d=t);let y=m===s[h]&&m!==a[h]&&f;if(y&&r&&e.manuallyAnimateOnMount&&(y=!1),p.protectedKeys={...u},!p.isActive&&null===g||!m&&!p.prevProp||qa(m)||"boolean"===typeof m)continue;const x=Kc(p.prevProp,m);let v=x||h===o&&p.isActive&&!y&&f||t>d&&f,b=!1;const w=Array.isArray(m)?m:[m];let k=w.reduce(i(h),{});!1===g&&(k={});const{prevResolvedValues:S={}}=p,j={...S,...k},$=t=>{v=!0,c.has(t)&&(b=!0,c.delete(t)),p.needsAnimating[t]=!0;const n=e.getValue(t);n&&(n.liveStyle=!1)};for(const e in j){const t=k[e],n=S[e];if(u.hasOwnProperty(e))continue;let r=!1;r=tl(t)&&tl(n)?!Vc(t,n):t!==n,r?void 0!==t&&null!==t?$(e):c.add(e):void 0!==t&&c.has(e)?$(e):p.protectedKeys[e]=!0}p.prevProp=m,p.prevResolvedValues=k,p.isActive&&(u={...u,...k}),r&&e.blockInitialAnimation&&(v=!1);v&&(!(y&&x)||b)&&l.push(...w.map(e=>({animation:e,options:{type:h}})))}if(c.size){const t={};if("boolean"!==typeof a.initial){const n=Zs(e,Array.isArray(a.initial)?a.initial[0]:a.initial);n&&n.transition&&(t.transition=n.transition)}c.forEach(n=>{const r=e.getBaseTarget(n),i=e.getValue(n);i&&(i.liveStyle=!0),t[n]=r??null}),l.push({animation:t})}let h=Boolean(l.length);return!r||!1!==a.initial&&a.initial!==a.animate||e.manuallyAnimateOnMount||(h=!1),r=!1,h?t(l):Promise.resolve()}return{animateChanges:o,setActive:function(t,r){if(n[t].isActive===r)return Promise.resolve();e.variantChildren?.forEach(e=>e.animationState?.setActive(t,r)),n[t].isActive=r;const i=o(t);for(const e in n)n[e].protectedKeys={};return i},setAnimateFunction:function(n){t=n(e)},getState:()=>n,reset:()=>{n=Xc(),r=!0}}}function Kc(e,t){return"string"===typeof t?t!==e:!!Array.isArray(t)&&!Vc(t,e)}function Gc(){return{isActive:arguments.length>0&&void 0!==arguments[0]&&arguments[0],protectedKeys:{},needsAnimating:{},prevResolvedValues:{}}}function Xc(){return{animate:Gc(!0),whileInView:Gc(),whileHover:Gc(),whileTap:Gc(),whileDrag:Gc(),whileFocus:Gc(),exit:Gc()}}class Qc{constructor(e){this.isMounted=!1,this.node=e}update(){}}let Jc=0;const Zc={animation:{Feature:class extends Qc{constructor(e){super(e),e.animationState||(e.animationState=Yc(e))}updateAnimationControlsSubscription(){const{animate:e}=this.node.getProps();qa(e)&&(this.unmountControls=e.subscribe(this.node))}mount(){this.updateAnimationControlsSubscription()}update(){const{animate:e}=this.node.getProps(),{animate:t}=this.node.prevProps||{};e!==t&&this.updateAnimationControlsSubscription()}unmount(){this.node.animationState.reset(),this.unmountControls?.()}}},exit:{Feature:class extends Qc{constructor(){super(...arguments),this.id=Jc++}update(){if(!this.node.presenceContext)return;const{isPresent:e,onExitComplete:t}=this.node.presenceContext,{isPresent:n}=this.node.prevPresenceContext||{};if(!this.node.animationState||e===n)return;const r=this.node.animationState.setActive("exit",!e);t&&!e&&r.then(()=>{t(this.id)})}mount(){const{register:e,onExitComplete:t}=this.node.presenceContext||{};t&&t(this.id),e&&(this.unmount=e(this.id))}unmount(){}}}},eu={x:!1,y:!1};function tu(){return eu.x||eu.y}function nu(e,t,n){let r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{passive:!0};return e.addEventListener(t,n,r),()=>e.removeEventListener(t,n)}const ru=e=>"mouse"===e.pointerType?"number"!==typeof e.button||e.button<=0:!1!==e.isPrimary;function iu(e){return{point:{x:e.pageX,y:e.pageY}}}function ou(e,t,n,r){return nu(e,t,(e=>t=>ru(t)&&e(t,iu(t)))(n),r)}function au(e){return e.max-e.min}function su(e,t,n){let r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:.5;e.origin=r,e.originPoint=Yi(t.min,t.max,e.origin),e.scale=au(n)/au(t),e.translate=Yi(n.min,n.max,e.origin)-e.originPoint,(e.scale>=.9999&&e.scale<=1.0001||isNaN(e.scale))&&(e.scale=1),(e.translate>=-.01&&e.translate<=.01||isNaN(e.translate))&&(e.translate=0)}function lu(e,t,n,r){su(e.x,t.x,n.x,r?r.originX:void 0),su(e.y,t.y,n.y,r?r.originY:void 0)}function cu(e,t,n){e.min=n.min+t.min,e.max=e.min+au(t)}function uu(e,t,n){e.min=t.min-n.min,e.max=e.min+au(t)}function du(e,t,n){uu(e.x,t.x,n.x),uu(e.y,t.y,n.y)}function hu(e){return[e("x"),e("y")]}const pu=e=>{let{current:t}=e;return t?t.ownerDocument.defaultView:null},mu=(e,t)=>Math.abs(e-t);class fu{constructor(e,t){let{transformPagePoint:n,contextWindow:r=window,dragSnapToOrigin:i=!1,distanceThreshold:o=3}=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};if(this.startEvent=null,this.lastMoveEvent=null,this.lastMoveEventInfo=null,this.handlers={},this.contextWindow=window,this.updatePoint=()=>{if(!this.lastMoveEvent||!this.lastMoveEventInfo)return;const e=xu(this.lastMoveEventInfo,this.history),t=null!==this.startEvent,n=function(e,t){const n=mu(e.x,t.x),r=mu(e.y,t.y);return Math.sqrt(n**2+r**2)}(e.offset,{x:0,y:0})>=this.distanceThreshold;if(!t&&!n)return;const{point:r}=e,{timestamp:i}=_o;this.history.push({...r,timestamp:i});const{onStart:o,onMove:a}=this.handlers;t||(o&&o(this.lastMoveEvent,e),this.startEvent=this.lastMoveEvent),a&&a(this.lastMoveEvent,e)},this.handlePointerMove=(e,t)=>{this.lastMoveEvent=e,this.lastMoveEventInfo=gu(t,this.transformPagePoint),Fo.update(this.updatePoint,!0)},this.handlePointerUp=(e,t)=>{this.end();const{onEnd:n,onSessionEnd:r,resumeAnimation:i}=this.handlers;if(this.dragSnapToOrigin&&i&&i(),!this.lastMoveEvent||!this.lastMoveEventInfo)return;const o=xu("pointercancel"===e.type?this.lastMoveEventInfo:gu(t,this.transformPagePoint),this.history);this.startEvent&&n&&n(e,o),r&&r(e,o)},!ru(e))return;this.dragSnapToOrigin=i,this.handlers=t,this.transformPagePoint=n,this.distanceThreshold=o,this.contextWindow=r||window;const a=gu(iu(e),this.transformPagePoint),{point:s}=a,{timestamp:l}=_o;this.history=[{...s,timestamp:l}];const{onSessionStart:c}=t;c&&c(e,xu(a,this.history)),this.removeListeners=sl(ou(this.contextWindow,"pointermove",this.handlePointerMove),ou(this.contextWindow,"pointerup",this.handlePointerUp),ou(this.contextWindow,"pointercancel",this.handlePointerUp))}updateHandlers(e){this.handlers=e}end(){this.removeListeners&&this.removeListeners(),No(this.updatePoint)}}function gu(e,t){return t?{point:t(e.point)}:e}function yu(e,t){return{x:e.x-t.x,y:e.y-t.y}}function xu(e,t){let{point:n}=e;return{point:n,delta:yu(n,bu(t)),offset:yu(n,vu(t)),velocity:wu(t,.1)}}function vu(e){return e[0]}function bu(e){return e[e.length-1]}function wu(e,t){if(e.length<2)return{x:0,y:0};let n=e.length-1,r=null;const i=bu(e);for(;n>=0&&(r=e[n],!(i.timestamp-r.timestamp>ll(t)));)n--;if(!r)return{x:0,y:0};const o=cl(i.timestamp-r.timestamp);if(0===o)return{x:0,y:0};const a={x:(i.x-r.x)/o,y:(i.y-r.y)/o};return a.x===1/0&&(a.x=0),a.y===1/0&&(a.y=0),a}function ku(e,t,n){return{min:void 0!==t?e.min+t:void 0,max:void 0!==n?e.max+n-(e.max-e.min):void 0}}function Su(e,t){let n=t.min-e.min,r=t.max-e.max;return t.max-t.min<e.max-e.min&&([n,r]=[r,n]),{min:n,max:r}}const ju=.35;function $u(e,t,n){return{min:Cu(e,t),max:Cu(e,n)}}function Cu(e,t){return"number"===typeof e?e:e[t]||0}const Eu=new WeakMap;class Tu{constructor(e){this.openDragLock=null,this.isDragging=!1,this.currentDirection=null,this.originPoint={x:0,y:0},this.constraints=!1,this.hasMutatedConstraints=!1,this.elastic={x:{min:0,max:0},y:{min:0,max:0}},this.latestPointerEvent=null,this.latestPanInfo=null,this.visualElement=e}start(e){let{snapToCursor:t=!1,distanceThreshold:n}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};const{presenceContext:r}=this.visualElement;if(r&&!1===r.isPresent)return;const{dragSnapToOrigin:i}=this.getProps();this.panSession=new fu(e,{onSessionStart:e=>{const{dragSnapToOrigin:n}=this.getProps();n?this.pauseAnimation():this.stopAnimation(),t&&this.snapToCursor(iu(e).point)},onStart:(e,t)=>{const{drag:n,dragPropagation:r,onDragStart:i}=this.getProps();if(n&&!r&&(this.openDragLock&&this.openDragLock(),this.openDragLock="x"===(o=n)||"y"===o?eu[o]?null:(eu[o]=!0,()=>{eu[o]=!1}):eu.x||eu.y?null:(eu.x=eu.y=!0,()=>{eu.x=eu.y=!1}),!this.openDragLock))return;var o;this.latestPointerEvent=e,this.latestPanInfo=t,this.isDragging=!0,this.currentDirection=null,this.resolveConstraints(),this.visualElement.projection&&(this.visualElement.projection.isAnimationBlocked=!0,this.visualElement.projection.target=void 0),hu(e=>{let t=this.getAxisMotionValue(e).get()||0;if(yo.test(t)){const{projection:n}=this.visualElement;if(n&&n.layout){const r=n.layout.layoutBox[e];if(r){t=au(r)*(parseFloat(t)/100)}}}this.originPoint[e]=t}),i&&Fo.postRender(()=>i(e,t)),il(this.visualElement,"transform");const{animationState:a}=this.visualElement;a&&a.setActive("whileDrag",!0)},onMove:(e,t)=>{this.latestPointerEvent=e,this.latestPanInfo=t;const{dragPropagation:n,dragDirectionLock:r,onDirectionLock:i,onDrag:o}=this.getProps();if(!n&&!this.openDragLock)return;const{offset:a}=t;if(r&&null===this.currentDirection)return this.currentDirection=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:10,n=null;Math.abs(e.y)>t?n="y":Math.abs(e.x)>t&&(n="x");return n}(a),void(null!==this.currentDirection&&i&&i(this.currentDirection));this.updateAxis("x",t.point,a),this.updateAxis("y",t.point,a),this.visualElement.render(),o&&o(e,t)},onSessionEnd:(e,t)=>{this.latestPointerEvent=e,this.latestPanInfo=t,this.stop(e,t),this.latestPointerEvent=null,this.latestPanInfo=null},resumeAnimation:()=>hu(e=>"paused"===this.getAnimationState(e)&&this.getAxisMotionValue(e).animation?.play())},{transformPagePoint:this.visualElement.getTransformPagePoint(),dragSnapToOrigin:i,distanceThreshold:n,contextWindow:pu(this.visualElement)})}stop(e,t){const n=e||this.latestPointerEvent,r=t||this.latestPanInfo,i=this.isDragging;if(this.cancel(),!i||!r||!n)return;const{velocity:o}=r;this.startAnimation(o);const{onDragEnd:a}=this.getProps();a&&Fo.postRender(()=>a(n,r))}cancel(){this.isDragging=!1;const{projection:e,animationState:t}=this.visualElement;e&&(e.isAnimationBlocked=!1),this.panSession&&this.panSession.end(),this.panSession=void 0;const{dragPropagation:n}=this.getProps();!n&&this.openDragLock&&(this.openDragLock(),this.openDragLock=null),t&&t.setActive("whileDrag",!1)}updateAxis(e,t,n){const{drag:r}=this.getProps();if(!n||!Pu(e,r,this.currentDirection))return;const i=this.getAxisMotionValue(e);let o=this.originPoint[e]+n[e];this.constraints&&this.constraints[e]&&(o=function(e,t,n){let{min:r,max:i}=t;return void 0!==r&&e<r?e=n?Yi(r,e,n.min):Math.max(e,r):void 0!==i&&e>i&&(e=n?Yi(i,e,n.max):Math.min(e,i)),e}(o,this.constraints[e],this.elastic[e])),i.set(o)}resolveConstraints(){const{dragConstraints:e,dragElastic:t}=this.getProps(),n=this.visualElement.projection&&!this.visualElement.projection.layout?this.visualElement.projection.measure(!1):this.visualElement.projection?.layout,r=this.constraints;e&&Hs(e)?this.constraints||(this.constraints=this.resolveRefConstraints()):this.constraints=!(!e||!n)&&function(e,t){let{top:n,left:r,bottom:i,right:o}=t;return{x:ku(e.x,r,o),y:ku(e.y,n,i)}}(n.layoutBox,e),this.elastic=function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:ju;return!1===e?e=0:!0===e&&(e=ju),{x:$u(e,"left","right"),y:$u(e,"top","bottom")}}(t),r!==this.constraints&&n&&this.constraints&&!this.hasMutatedConstraints&&hu(e=>{!1!==this.constraints&&this.getAxisMotionValue(e)&&(this.constraints[e]=function(e,t){const n={};return void 0!==t.min&&(n.min=t.min-e.min),void 0!==t.max&&(n.max=t.max-e.min),n}(n.layoutBox[e],this.constraints[e]))})}resolveRefConstraints(){const{dragConstraints:e,onMeasureDragConstraints:t}=this.getProps();if(!e||!Hs(e))return!1;const n=e.current,{projection:r}=this.visualElement;if(!r||!r.layout)return!1;const i=function(e,t,n){const r=lo(e,n),{scroll:i}=t;return i&&(oo(r.x,i.offset.x),oo(r.y,i.offset.y)),r}(n,r.root,this.visualElement.getTransformPagePoint());let o=function(e,t){return{x:Su(e.x,t.x),y:Su(e.y,t.y)}}(r.layout.layoutBox,i);if(t){const e=t(function(e){let{x:t,y:n}=e;return{top:n.min,right:t.max,bottom:n.max,left:t.min}}(o));this.hasMutatedConstraints=!!e,e&&(o=qi(e))}return o}startAnimation(e){const{drag:t,dragMomentum:n,dragElastic:r,dragTransition:i,dragSnapToOrigin:o,onDragTransitionEnd:a}=this.getProps(),s=this.constraints||{},l=hu(a=>{if(!Pu(a,t,this.currentDirection))return;let l=s&&s[a]||{};o&&(l={min:0,max:0});const c=r?200:1e6,u=r?40:1e7,d={type:"inertia",velocity:n?e[a]:0,bounceStiffness:c,bounceDamping:u,timeConstant:750,restDelta:1,restSpeed:10,...i,...l};return this.startAxisValueAnimation(a,d)});return Promise.all(l).then(a)}startAxisValueAnimation(e,t){const n=this.getAxisMotionValue(e);return il(this.visualElement,e),n.start(Oc(e,n,0,t,this.visualElement,!1))}stopAnimation(){hu(e=>this.getAxisMotionValue(e).stop())}pauseAnimation(){hu(e=>this.getAxisMotionValue(e).animation?.pause())}getAnimationState(e){return this.getAxisMotionValue(e).animation?.state}getAxisMotionValue(e){const t=`_drag${e.toUpperCase()}`,n=this.visualElement.getProps(),r=n[t];return r||this.visualElement.getValue(e,(n.initial?n.initial[e]:void 0)||0)}snapToCursor(e){hu(t=>{const{drag:n}=this.getProps();if(!Pu(t,n,this.currentDirection))return;const{projection:r}=this.visualElement,i=this.getAxisMotionValue(t);if(r&&r.layout){const{min:n,max:o}=r.layout.layoutBox[t];i.set(e[t]-Yi(n,o,.5))}})}scalePositionWithinConstraints(){if(!this.visualElement.current)return;const{drag:e,dragConstraints:t}=this.getProps(),{projection:n}=this.visualElement;if(!Hs(t)||!n||!this.constraints)return;this.stopAnimation();const r={x:0,y:0};hu(e=>{const t=this.getAxisMotionValue(e);if(t&&!1!==this.constraints){const n=t.get();r[e]=function(e,t){let n=.5;const r=au(e),i=au(t);return i>r?n=nc(t.min,t.max-r,e.min):r>i&&(n=nc(e.min,e.max-i,t.min)),uo(0,1,n)}({min:n,max:n},this.constraints[e])}});const{transformTemplate:i}=this.visualElement.getProps();this.visualElement.current.style.transform=i?i({},""):"none",n.root&&n.root.updateScroll(),n.updateLayout(),this.resolveConstraints(),hu(t=>{if(!Pu(t,e,null))return;const n=this.getAxisMotionValue(t),{min:i,max:o}=this.constraints[t];n.set(Yi(i,o,r[t]))})}addListeners(){if(!this.visualElement.current)return;Eu.set(this.visualElement,this);const e=ou(this.visualElement.current,"pointerdown",e=>{const{drag:t,dragListener:n=!0}=this.getProps();t&&n&&this.start(e)}),t=()=>{const{dragConstraints:e}=this.getProps();Hs(e)&&e.current&&(this.constraints=this.resolveRefConstraints())},{projection:n}=this.visualElement,r=n.addEventListener("measure",t);n&&!n.layout&&(n.root&&n.root.updateScroll(),n.updateLayout()),Fo.read(t);const i=nu(window,"resize",()=>this.scalePositionWithinConstraints()),o=n.addEventListener("didUpdate",e=>{let{delta:t,hasLayoutChanged:n}=e;this.isDragging&&n&&(hu(e=>{const n=this.getAxisMotionValue(e);n&&(this.originPoint[e]+=t[e].translate,n.set(n.get()+t[e].translate))}),this.visualElement.render())});return()=>{i(),e(),r(),o&&o()}}getProps(){const e=this.visualElement.getProps(),{drag:t=!1,dragDirectionLock:n=!1,dragPropagation:r=!1,dragConstraints:i=!1,dragElastic:o=ju,dragMomentum:a=!0}=e;return{...e,drag:t,dragDirectionLock:n,dragPropagation:r,dragConstraints:i,dragElastic:o,dragMomentum:a}}}function Pu(e,t,n){return(!0===t||t===e)&&(null===n||n===e)}const zu=e=>(t,n)=>{e&&Fo.postRender(()=>e(t,n))};const Au={hasAnimatedSinceResize:!0,hasEverUpdated:!1};function Ru(e,t){return t.max===t.min?0:e/(t.max-t.min)*100}const Mu={correct:(e,t)=>{if(!t.target)return e;if("string"===typeof e){if(!xo.test(e))return e;e=parseFloat(e)}return`${Ru(e,t.target.x)}% ${Ru(e,t.target.y)}%`}},Lu={correct:(e,t)=>{let{treeScale:n,projectionDelta:r}=t;const i=e,o=ma.parse(e);if(o.length>5)return i;const a=ma.createTransformer(e),s="number"!==typeof o[0]?1:0,l=r.x.scale*n.x,c=r.y.scale*n.y;o[0+s]/=l,o[1+s]/=c;const u=Yi(l,c,.5);return"number"===typeof o[2+s]&&(o[2+s]/=u),"number"===typeof o[3+s]&&(o[3+s]/=u),a(o)}};let Du=!1;class Ou extends e.Component{componentDidMount(){const{visualElement:e,layoutGroup:t,switchLayoutGroup:n,layoutId:r}=this.props,{projection:i}=e;!function(e){for(const t in e)ls[t]=e[t],Bi(t)&&(ls[t].isCSSVariable=!0)}(Nu),i&&(t.group&&t.group.add(i),n&&n.register&&r&&n.register(i),Du&&i.root.didUpdate(),i.addEventListener("animationComplete",()=>{this.safeToRemove()}),i.setOptions({...i.options,onExitComplete:()=>this.safeToRemove()})),Au.hasEverUpdated=!0}getSnapshotBeforeUpdate(e){const{layoutDependency:t,visualElement:n,drag:r,isPresent:i}=this.props,{projection:o}=n;return o?(o.isPresent=i,Du=!0,r||e.layoutDependency!==t||void 0===t||e.isPresent!==i?o.willUpdate():this.safeToRemove(),e.isPresent!==i&&(i?o.promote():o.relegate()||Fo.postRender(()=>{const e=o.getStack();e&&e.members.length||this.safeToRemove()})),null):null}componentDidUpdate(){const{projection:e}=this.props.visualElement;e&&(e.root.didUpdate(),Na.postRender(()=>{!e.currentAnimation&&e.isLead()&&this.safeToRemove()}))}componentWillUnmount(){const{visualElement:e,layoutGroup:t,switchLayoutGroup:n}=this.props,{projection:r}=e;r&&(r.scheduleCheckAfterUnmount(),t&&t.group&&t.group.remove(r),n&&n.deregister&&n.deregister(r))}safeToRemove(){const{safeToRemove:e}=this.props;e&&e()}render(){return null}}function Fu(t){const[n,r]=mi(),i=(0,e.useContext)(ni);return(0,ti.jsx)(Ou,{...t,layoutGroup:i,switchLayoutGroup:(0,e.useContext)(Ys),isPresent:n,safeToRemove:r})}const Nu={borderRadius:{...Mu,applyTo:["borderTopLeftRadius","borderTopRightRadius","borderBottomLeftRadius","borderBottomRightRadius"]},borderTopLeftRadius:Mu,borderTopRightRadius:Mu,borderBottomLeftRadius:Mu,borderBottomRightRadius:Mu,boxShadow:Lu};function _u(e){return si(e)&&"ownerSVGElement"in e}const Iu=(e,t)=>e.depth-t.depth;class Vu{constructor(){this.children=[],this.isDirty=!1}add(e){za(this.children,e),this.isDirty=!0}remove(e){Aa(this.children,e),this.isDirty=!0}forEach(e){this.isDirty&&this.children.sort(Iu),this.isDirty=!1,this.children.forEach(e)}}function Bu(e,t){const n=Pa.now(),r=i=>{let{timestamp:o}=i;const a=o-n;a>=t&&(No(r),e(a-t))};return Fo.setup(r,!0),()=>No(r)}const Wu=["TopLeft","TopRight","BottomLeft","BottomRight"],Hu=Wu.length,Uu=e=>"string"===typeof e?parseFloat(e):e,qu=e=>"number"===typeof e||xo.test(e);function Yu(e,t){return void 0!==e[t]?e[t]:e.borderRadius}const Ku=Xu(0,.5,Ql),Gu=Xu(.5,.95,Ro);function Xu(e,t,n){return r=>r<e?0:r>t?1:n(nc(e,t,r))}function Qu(e,t){e.min=t.min,e.max=t.max}function Ju(e,t){Qu(e.x,t.x),Qu(e.y,t.y)}function Zu(e,t){e.translate=t.translate,e.scale=t.scale,e.originPoint=t.originPoint,e.origin=t.origin}function ed(e,t,n,r,i){return e=Zi(e-=t,1/n,r),void 0!==i&&(e=Zi(e,1/i,r)),e}function td(e,t,n,r,i){let[o,a,s]=n;!function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0,n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:1,r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:.5,i=arguments.length>4?arguments[4]:void 0,o=arguments.length>5&&void 0!==arguments[5]?arguments[5]:e,a=arguments.length>6&&void 0!==arguments[6]?arguments[6]:e;yo.test(t)&&(t=parseFloat(t),t=Yi(a.min,a.max,t/100)-a.min);if("number"!==typeof t)return;let s=Yi(o.min,o.max,r);e===o&&(s-=t),e.min=ed(e.min,t,n,s,i),e.max=ed(e.max,t,n,s,i)}(e,t[o],t[a],t[s],t.scale,r,i)}const nd=["x","scaleX","originX"],rd=["y","scaleY","originY"];function id(e,t,n,r){td(e.x,t,nd,n?n.x:void 0,r?r.x:void 0),td(e.y,t,rd,n?n.y:void 0,r?r.y:void 0)}function od(e){return 0===e.translate&&1===e.scale}function ad(e){return od(e.x)&&od(e.y)}function sd(e,t){return e.min===t.min&&e.max===t.max}function ld(e,t){return Math.round(e.min)===Math.round(t.min)&&Math.round(e.max)===Math.round(t.max)}function cd(e,t){return ld(e.x,t.x)&&ld(e.y,t.y)}function ud(e){return au(e.x)/au(e.y)}function dd(e,t){return e.translate===t.translate&&e.scale===t.scale&&e.originPoint===t.originPoint}class hd{constructor(){this.members=[]}add(e){za(this.members,e),e.scheduleRender()}remove(e){if(Aa(this.members,e),e===this.prevLead&&(this.prevLead=void 0),e===this.lead){const e=this.members[this.members.length-1];e&&this.promote(e)}}relegate(e){const t=this.members.findIndex(t=>e===t);if(0===t)return!1;let n;for(let r=t;r>=0;r--){const e=this.members[r];if(!1!==e.isPresent){n=e;break}}return!!n&&(this.promote(n),!0)}promote(e,t){const n=this.lead;if(e!==n&&(this.prevLead=n,this.lead=e,e.show(),n)){n.instance&&n.scheduleRender(),e.scheduleRender(),e.resumeFrom=n,t&&(e.resumeFrom.preserveOpacity=!0),n.snapshot&&(e.snapshot=n.snapshot,e.snapshot.latestValues=n.animationValues||n.latestValues),e.root&&e.root.isUpdating&&(e.isLayoutDirty=!0);const{crossfade:r}=e.options;!1===r&&n.hide()}}exitAnimationComplete(){this.members.forEach(e=>{const{options:t,resumingFrom:n}=e;t.onExitComplete&&t.onExitComplete(),n&&n.options.onExitComplete&&n.options.onExitComplete()})}scheduleRender(){this.members.forEach(e=>{e.instance&&e.scheduleRender(!1)})}removeLeadSnapshot(){this.lead&&this.lead.snapshot&&(this.lead.snapshot=void 0)}}const pd={nodes:0,calculatedTargetDeltas:0,calculatedProjections:0},md=["","X","Y","Z"];let fd=0;function gd(e,t,n,r){const{latestValues:i}=t;i[e]&&(n[e]=i[e],t.setStaticValue(e,0),r&&(r[e]=0))}function yd(e){if(e.hasCheckedOptimisedAppear=!0,e.root===e)return;const{visualElement:t}=e.options;if(!t)return;const n=ol(t);if(window.MotionHasOptimisedAnimation(n,"transform")){const{layout:t,layoutId:r}=e.options;window.MotionCancelOptimisedAnimation(n,"transform",Fo,!(t||r))}const{parent:r}=e;r&&!r.hasCheckedOptimisedAppear&&yd(r)}function xd(e){let{attachResizeListener:t,defaultParent:n,measureScroll:r,checkIsScrollRoot:i,resetTransform:o}=e;return class{constructor(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:n?.();this.id=fd++,this.animationId=0,this.animationCommitId=0,this.children=new Set,this.options={},this.isTreeAnimating=!1,this.isAnimationBlocked=!1,this.isLayoutDirty=!1,this.isProjectionDirty=!1,this.isSharedProjectionDirty=!1,this.isTransformDirty=!1,this.updateManuallyBlocked=!1,this.updateBlockedByResize=!1,this.isUpdating=!1,this.isSVG=!1,this.needsReset=!1,this.shouldResetTransform=!1,this.hasCheckedOptimisedAppear=!1,this.treeScale={x:1,y:1},this.eventHandlers=new Map,this.hasTreeAnimated=!1,this.updateScheduled=!1,this.scheduleUpdate=()=>this.update(),this.projectionUpdateScheduled=!1,this.checkUpdateFailed=()=>{this.isUpdating&&(this.isUpdating=!1,this.clearAllSnapshots())},this.updateProjection=()=>{this.projectionUpdateScheduled=!1,Do.value&&(pd.nodes=pd.calculatedTargetDeltas=pd.calculatedProjections=0),this.nodes.forEach(wd),this.nodes.forEach(Td),this.nodes.forEach(Pd),this.nodes.forEach(kd),Do.addProjectionMetrics&&Do.addProjectionMetrics(pd)},this.resolvedRelativeTargetAt=0,this.hasProjected=!1,this.isVisible=!0,this.animationProgress=0,this.sharedNodes=new Map,this.latestValues=e,this.root=t?t.root||t:this,this.path=t?[...t.path,t]:[],this.parent=t,this.depth=t?t.depth+1:0;for(let n=0;n<this.path.length;n++)this.path[n].shouldResetTransform=!0;this.root===this&&(this.nodes=new Vu)}addEventListener(e,t){return this.eventHandlers.has(e)||this.eventHandlers.set(e,new Ra),this.eventHandlers.get(e).add(t)}notifyListeners(e){const t=this.eventHandlers.get(e);for(var n=arguments.length,r=new Array(n>1?n-1:0),i=1;i<n;i++)r[i-1]=arguments[i];t&&t.notify(...r)}hasListeners(e){return this.eventHandlers.has(e)}mount(e){if(this.instance)return;var n;this.isSVG=_u(e)&&!(_u(n=e)&&"svg"===n.tagName),this.instance=e;const{layoutId:r,layout:i,visualElement:o}=this.options;if(o&&!o.current&&o.mount(e),this.root.nodes.add(this),this.parent&&this.parent.children.add(this),this.root.hasTreeAnimated&&(i||r)&&(this.isLayoutDirty=!0),t){let n,r=0;const i=()=>this.root.updateBlockedByResize=!1;Fo.read(()=>{r=window.innerWidth}),t(e,()=>{const e=window.innerWidth;e!==r&&(r=e,this.root.updateBlockedByResize=!0,n&&n(),n=Bu(i,250),Au.hasAnimatedSinceResize&&(Au.hasAnimatedSinceResize=!1,this.nodes.forEach(Ed)))})}r&&this.root.registerSharedNode(r,this),!1!==this.options.animate&&o&&(r||i)&&this.addEventListener("didUpdate",e=>{let{delta:t,hasLayoutChanged:n,hasRelativeLayoutChanged:r,layout:i}=e;if(this.isTreeAnimationBlocked())return this.target=void 0,void(this.relativeTarget=void 0);const a=this.options.transition||o.getDefaultTransition()||Dd,{onLayoutAnimationStart:s,onLayoutAnimationComplete:l}=o.getProps(),c=!this.targetLayout||!cd(this.targetLayout,i),u=!n&&r;if(this.options.layoutRoot||this.resumeFrom||u||n&&(c||!this.currentAnimation)){this.resumeFrom&&(this.resumingFrom=this.resumeFrom,this.resumingFrom.resumingFrom=void 0);const e={...el(a,"layout"),onPlay:s,onComplete:l};(o.shouldReduceMotion||this.options.layoutRoot)&&(e.delay=0,e.type=!1),this.startAnimation(e),this.setAnimationOrigin(t,u)}else n||Ed(this),this.isLead()&&this.options.onExitComplete&&this.options.onExitComplete();this.targetLayout=i})}unmount(){this.options.layoutId&&this.willUpdate(),this.root.nodes.remove(this);const e=this.getStack();e&&e.remove(this),this.parent&&this.parent.children.delete(this),this.instance=void 0,this.eventHandlers.clear(),No(this.updateProjection)}blockUpdate(){this.updateManuallyBlocked=!0}unblockUpdate(){this.updateManuallyBlocked=!1}isUpdateBlocked(){return this.updateManuallyBlocked||this.updateBlockedByResize}isTreeAnimationBlocked(){return this.isAnimationBlocked||this.parent&&this.parent.isTreeAnimationBlocked()||!1}startUpdate(){this.isUpdateBlocked()||(this.isUpdating=!0,this.nodes&&this.nodes.forEach(zd),this.animationId++)}getTransformTemplate(){const{visualElement:e}=this.options;return e&&e.getProps().transformTemplate}willUpdate(){let e=!(arguments.length>0&&void 0!==arguments[0])||arguments[0];if(this.root.hasTreeAnimated=!0,this.root.isUpdateBlocked())return void(this.options.onExitComplete&&this.options.onExitComplete());if(window.MotionCancelOptimisedAnimation&&!this.hasCheckedOptimisedAppear&&yd(this),!this.root.isUpdating&&this.root.startUpdate(),this.isLayoutDirty)return;this.isLayoutDirty=!0;for(let i=0;i<this.path.length;i++){const e=this.path[i];e.shouldResetTransform=!0,e.updateScroll("snapshot"),e.options.layoutRoot&&e.willUpdate(!1)}const{layoutId:t,layout:n}=this.options;if(void 0===t&&!n)return;const r=this.getTransformTemplate();this.prevTransformTemplateValue=r?r(this.latestValues,""):void 0,this.updateSnapshot(),e&&this.notifyListeners("willUpdate")}update(){this.updateScheduled=!1;if(this.isUpdateBlocked())return this.unblockUpdate(),this.clearAllSnapshots(),void this.nodes.forEach(jd);if(this.animationId<=this.animationCommitId)return void this.nodes.forEach($d);this.animationCommitId=this.animationId,this.isUpdating?(this.isUpdating=!1,this.nodes.forEach(Cd),this.nodes.forEach(vd),this.nodes.forEach(bd)):this.nodes.forEach($d),this.clearAllSnapshots();const e=Pa.now();_o.delta=uo(0,1e3/60,e-_o.timestamp),_o.timestamp=e,_o.isProcessing=!0,Io.update.process(_o),Io.preRender.process(_o),Io.render.process(_o),_o.isProcessing=!1}didUpdate(){this.updateScheduled||(this.updateScheduled=!0,Na.read(this.scheduleUpdate))}clearAllSnapshots(){this.nodes.forEach(Sd),this.sharedNodes.forEach(Ad)}scheduleUpdateProjection(){this.projectionUpdateScheduled||(this.projectionUpdateScheduled=!0,Fo.preRender(this.updateProjection,!1,!0))}scheduleCheckAfterUnmount(){Fo.postRender(()=>{this.isLayoutDirty?this.root.didUpdate():this.root.checkUpdateFailed()})}updateSnapshot(){!this.snapshot&&this.instance&&(this.snapshot=this.measure(),!this.snapshot||au(this.snapshot.measuredBox.x)||au(this.snapshot.measuredBox.y)||(this.snapshot=void 0))}updateLayout(){if(!this.instance)return;if(this.updateScroll(),(!this.options.alwaysMeasureLayout||!this.isLead())&&!this.isLayoutDirty)return;if(this.resumeFrom&&!this.resumeFrom.instance)for(let n=0;n<this.path.length;n++){this.path[n].updateScroll()}const e=this.layout;this.layout=this.measure(!1),this.layoutCorrected={x:{min:0,max:0},y:{min:0,max:0}},this.isLayoutDirty=!1,this.projectionDelta=void 0,this.notifyListeners("measure",this.layout.layoutBox);const{visualElement:t}=this.options;t&&t.notify("LayoutMeasure",this.layout.layoutBox,e?e.layoutBox:void 0)}updateScroll(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"measure",t=Boolean(this.options.layoutScroll&&this.instance);if(this.scroll&&this.scroll.animationId===this.root.animationId&&this.scroll.phase===e&&(t=!1),t&&this.instance){const t=i(this.instance);this.scroll={animationId:this.root.animationId,phase:e,isRoot:t,offset:r(this.instance),wasRoot:this.scroll?this.scroll.isRoot:t}}}resetTransform(){if(!o)return;const e=this.isLayoutDirty||this.shouldResetTransform||this.options.alwaysMeasureLayout,t=this.projectionDelta&&!ad(this.projectionDelta),n=this.getTransformTemplate(),r=n?n(this.latestValues,""):void 0,i=r!==this.prevTransformTemplateValue;e&&this.instance&&(t||Xi(this.latestValues)||i)&&(o(this.instance,r),this.shouldResetTransform=!1,this.scheduleRender())}measure(){let e=!(arguments.length>0&&void 0!==arguments[0])||arguments[0];const t=this.measurePageBox();let n=this.removeElementScroll(t);var r;return e&&(n=this.removeTransform(n)),Nd((r=n).x),Nd(r.y),{animationId:this.root.animationId,measuredBox:t,layoutBox:n,latestValues:{},source:this.id}}measurePageBox(){const{visualElement:e}=this.options;if(!e)return{x:{min:0,max:0},y:{min:0,max:0}};const t=e.measureViewportBox();if(!(this.scroll?.wasRoot||this.path.some(Id))){const{scroll:e}=this.root;e&&(oo(t.x,e.offset.x),oo(t.y,e.offset.y))}return t}removeElementScroll(e){const t={x:{min:0,max:0},y:{min:0,max:0}};if(Ju(t,e),this.scroll?.wasRoot)return t;for(let n=0;n<this.path.length;n++){const r=this.path[n],{scroll:i,options:o}=r;r!==this.root&&i&&o.layoutScroll&&(i.wasRoot&&Ju(t,e),oo(t.x,i.offset.x),oo(t.y,i.offset.y))}return t}applyTransform(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1];const n={x:{min:0,max:0},y:{min:0,max:0}};Ju(n,e);for(let r=0;r<this.path.length;r++){const e=this.path[r];!t&&e.options.layoutScroll&&e.scroll&&e!==e.root&&so(n,{x:-e.scroll.offset.x,y:-e.scroll.offset.y}),Xi(e.latestValues)&&so(n,e.latestValues)}return Xi(this.latestValues)&&so(n,this.latestValues),n}removeTransform(e){const t={x:{min:0,max:0},y:{min:0,max:0}};Ju(t,e);for(let n=0;n<this.path.length;n++){const e=this.path[n];if(!e.instance)continue;if(!Xi(e.latestValues))continue;Gi(e.latestValues)&&e.updateSnapshot();const r=Ba();Ju(r,e.measurePageBox()),id(t,e.latestValues,e.snapshot?e.snapshot.layoutBox:void 0,r)}return Xi(this.latestValues)&&id(t,this.latestValues),t}setTargetDelta(e){this.targetDelta=e,this.root.scheduleUpdateProjection(),this.isProjectionDirty=!0}setOptions(e){this.options={...this.options,...e,crossfade:void 0===e.crossfade||e.crossfade}}clearMeasurements(){this.scroll=void 0,this.layout=void 0,this.snapshot=void 0,this.prevTransformTemplateValue=void 0,this.targetDelta=void 0,this.target=void 0,this.isLayoutDirty=!1}forceRelativeParentToResolveTarget(){this.relativeParent&&this.relativeParent.resolvedRelativeTargetAt!==_o.timestamp&&this.relativeParent.resolveTargetDelta(!0)}resolveTargetDelta(){let e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];const t=this.getLead();this.isProjectionDirty||(this.isProjectionDirty=t.isProjectionDirty),this.isTransformDirty||(this.isTransformDirty=t.isTransformDirty),this.isSharedProjectionDirty||(this.isSharedProjectionDirty=t.isSharedProjectionDirty);const n=Boolean(this.resumingFrom)||this!==t;if(!(e||n&&this.isSharedProjectionDirty||this.isProjectionDirty||this.parent?.isProjectionDirty||this.attemptToResolveRelativeTarget||this.root.updateBlockedByResize))return;const{layout:r,layoutId:i}=this.options;if(this.layout&&(r||i)){if(this.resolvedRelativeTargetAt=_o.timestamp,!this.targetDelta&&!this.relativeTarget){const e=this.getClosestProjectingParent();e&&e.layout&&1!==this.animationProgress?(this.relativeParent=e,this.forceRelativeParentToResolveTarget(),this.relativeTarget={x:{min:0,max:0},y:{min:0,max:0}},this.relativeTargetOrigin={x:{min:0,max:0},y:{min:0,max:0}},du(this.relativeTargetOrigin,this.layout.layoutBox,e.layout.layoutBox),Ju(this.relativeTarget,this.relativeTargetOrigin)):this.relativeParent=this.relativeTarget=void 0}if(this.relativeTarget||this.targetDelta){var o,a,s;if(this.target||(this.target={x:{min:0,max:0},y:{min:0,max:0}},this.targetWithTransforms={x:{min:0,max:0},y:{min:0,max:0}}),this.relativeTarget&&this.relativeTargetOrigin&&this.relativeParent&&this.relativeParent.target?(this.forceRelativeParentToResolveTarget(),o=this.target,a=this.relativeTarget,s=this.relativeParent.target,cu(o.x,a.x,s.x),cu(o.y,a.y,s.y)):this.targetDelta?(Boolean(this.resumingFrom)?this.target=this.applyTransform(this.layout.layoutBox):Ju(this.target,this.layout.layoutBox),no(this.target,this.targetDelta)):Ju(this.target,this.layout.layoutBox),this.attemptToResolveRelativeTarget){this.attemptToResolveRelativeTarget=!1;const e=this.getClosestProjectingParent();e&&Boolean(e.resumingFrom)===Boolean(this.resumingFrom)&&!e.options.layoutScroll&&e.target&&1!==this.animationProgress?(this.relativeParent=e,this.forceRelativeParentToResolveTarget(),this.relativeTarget={x:{min:0,max:0},y:{min:0,max:0}},this.relativeTargetOrigin={x:{min:0,max:0},y:{min:0,max:0}},du(this.relativeTargetOrigin,this.target,e.target),Ju(this.relativeTarget,this.relativeTargetOrigin)):this.relativeParent=this.relativeTarget=void 0}Do.value&&pd.calculatedTargetDeltas++}}}getClosestProjectingParent(){if(this.parent&&!Gi(this.parent.latestValues)&&!Qi(this.parent.latestValues))return this.parent.isProjecting()?this.parent:this.parent.getClosestProjectingParent()}isProjecting(){return Boolean((this.relativeTarget||this.targetDelta||this.options.layoutRoot)&&this.layout)}calcProjection(){const e=this.getLead(),t=Boolean(this.resumingFrom)||this!==e;let n=!0;if((this.isProjectionDirty||this.parent?.isProjectionDirty)&&(n=!1),t&&(this.isSharedProjectionDirty||this.isTransformDirty)&&(n=!1),this.resolvedRelativeTargetAt===_o.timestamp&&(n=!1),n)return;const{layout:r,layoutId:i}=this.options;if(this.isTreeAnimating=Boolean(this.parent&&this.parent.isTreeAnimating||this.currentAnimation||this.pendingAnimation),this.isTreeAnimating||(this.targetDelta=this.relativeTarget=void 0),!this.layout||!r&&!i)return;Ju(this.layoutCorrected,this.layout.layoutBox);const o=this.treeScale.x,a=this.treeScale.y;!function(e,t,n){let r=arguments.length>3&&void 0!==arguments[3]&&arguments[3];const i=n.length;if(!i)return;let o,a;t.x=t.y=1;for(let s=0;s<i;s++){o=n[s],a=o.projectionDelta;const{visualElement:i}=o.options;i&&i.props.style&&"contents"===i.props.style.display||(r&&o.options.layoutScroll&&o.scroll&&o!==o.root&&so(e,{x:-o.scroll.offset.x,y:-o.scroll.offset.y}),a&&(t.x*=a.x.scale,t.y*=a.y.scale,no(e,a)),r&&Xi(o.latestValues)&&so(e,o.latestValues))}t.x<io&&t.x>ro&&(t.x=1),t.y<io&&t.y>ro&&(t.y=1)}(this.layoutCorrected,this.treeScale,this.path,t),!e.layout||e.target||1===this.treeScale.x&&1===this.treeScale.y||(e.target=e.layout.layoutBox,e.targetWithTransforms={x:{min:0,max:0},y:{min:0,max:0}});const{target:s}=e;s?(this.projectionDelta&&this.prevProjectionDelta?(Zu(this.prevProjectionDelta.x,this.projectionDelta.x),Zu(this.prevProjectionDelta.y,this.projectionDelta.y)):this.createProjectionDeltas(),lu(this.projectionDelta,this.layoutCorrected,s,this.latestValues),this.treeScale.x===o&&this.treeScale.y===a&&dd(this.projectionDelta.x,this.prevProjectionDelta.x)&&dd(this.projectionDelta.y,this.prevProjectionDelta.y)||(this.hasProjected=!0,this.scheduleRender(),this.notifyListeners("projectionUpdate",s)),Do.value&&pd.calculatedProjections++):this.prevProjectionDelta&&(this.createProjectionDeltas(),this.scheduleRender())}hide(){this.isVisible=!1}show(){this.isVisible=!0}scheduleRender(){let e=!(arguments.length>0&&void 0!==arguments[0])||arguments[0];if(this.options.visualElement?.scheduleRender(),e){const e=this.getStack();e&&e.scheduleRender()}this.resumingFrom&&!this.resumingFrom.instance&&(this.resumingFrom=void 0)}createProjectionDeltas(){this.prevProjectionDelta={x:{translate:0,scale:1,origin:0,originPoint:0},y:{translate:0,scale:1,origin:0,originPoint:0}},this.projectionDelta={x:{translate:0,scale:1,origin:0,originPoint:0},y:{translate:0,scale:1,origin:0,originPoint:0}},this.projectionDeltaWithTransform={x:{translate:0,scale:1,origin:0,originPoint:0},y:{translate:0,scale:1,origin:0,originPoint:0}}}setAnimationOrigin(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1];const n=this.snapshot,r=n?n.latestValues:{},i={...this.latestValues},o={x:{translate:0,scale:1,origin:0,originPoint:0},y:{translate:0,scale:1,origin:0,originPoint:0}};this.relativeParent&&this.relativeParent.options.layoutRoot||(this.relativeTarget=this.relativeTargetOrigin=void 0),this.attemptToResolveRelativeTarget=!t;const a={x:{min:0,max:0},y:{min:0,max:0}},s=(n?n.source:void 0)!==(this.layout?this.layout.source:void 0),l=this.getStack(),c=!l||l.members.length<=1,u=Boolean(s&&!c&&!0===this.options.crossfade&&!this.path.some(Ld));let d;this.animationProgress=0,this.mixTargetDelta=t=>{const n=t/1e3;Rd(o.x,e.x,n),Rd(o.y,e.y,n),this.setTargetDelta(o),this.relativeTarget&&this.relativeTargetOrigin&&this.layout&&this.relativeParent&&this.relativeParent.layout&&(du(a,this.layout.layoutBox,this.relativeParent.layout.layoutBox),function(e,t,n,r){Md(e.x,t.x,n.x,r),Md(e.y,t.y,n.y,r)}(this.relativeTarget,this.relativeTargetOrigin,a,n),d&&function(e,t){return sd(e.x,t.x)&&sd(e.y,t.y)}(this.relativeTarget,d)&&(this.isProjectionDirty=!1),d||(d={x:{min:0,max:0},y:{min:0,max:0}}),Ju(d,this.relativeTarget)),s&&(this.animationValues=i,function(e,t,n,r,i,o){i?(e.opacity=Yi(0,n.opacity??1,Ku(r)),e.opacityExit=Yi(t.opacity??1,0,Gu(r))):o&&(e.opacity=Yi(t.opacity??1,n.opacity??1,r));for(let a=0;a<Hu;a++){const i=`border${Wu[a]}Radius`;let o=Yu(t,i),s=Yu(n,i);void 0===o&&void 0===s||(o||(o=0),s||(s=0),0===o||0===s||qu(o)===qu(s)?(e[i]=Math.max(Yi(Uu(o),Uu(s),r),0),(yo.test(s)||yo.test(o))&&(e[i]+="%")):e[i]=s)}(t.rotate||n.rotate)&&(e.rotate=Yi(t.rotate||0,n.rotate||0,r))}(i,r,this.latestValues,n,u,c)),this.root.scheduleUpdateProjection(),this.scheduleRender(),this.animationProgress=n},this.mixTargetDelta(this.options.layoutRoot?1e3:0)}startAnimation(e){this.notifyListeners("animationStart"),this.currentAnimation?.stop(),this.resumingFrom?.currentAnimation?.stop(),this.pendingAnimation&&(No(this.pendingAnimation),this.pendingAnimation=void 0),this.pendingAnimation=Fo.update(()=>{Au.hasAnimatedSinceResize=!0,ul.layout++,this.motionValue||(this.motionValue=Oa(0)),this.currentAnimation=function(e,t,n){const r=Ca(e)?e:Oa(e);return r.start(Oc("",r,t,n)),r.animation}(this.motionValue,[0,1e3],{...e,velocity:0,isSync:!0,onUpdate:t=>{this.mixTargetDelta(t),e.onUpdate&&e.onUpdate(t)},onStop:()=>{ul.layout--},onComplete:()=>{ul.layout--,e.onComplete&&e.onComplete(),this.completeAnimation()}}),this.resumingFrom&&(this.resumingFrom.currentAnimation=this.currentAnimation),this.pendingAnimation=void 0})}completeAnimation(){this.resumingFrom&&(this.resumingFrom.currentAnimation=void 0,this.resumingFrom.preserveOpacity=void 0);const e=this.getStack();e&&e.exitAnimationComplete(),this.resumingFrom=this.currentAnimation=this.animationValues=void 0,this.notifyListeners("animationComplete")}finishAnimation(){this.currentAnimation&&(this.mixTargetDelta&&this.mixTargetDelta(1e3),this.currentAnimation.stop()),this.completeAnimation()}applyTransformsToTarget(){const e=this.getLead();let{targetWithTransforms:t,target:n,layout:r,latestValues:i}=e;if(t&&n&&r){if(this!==e&&this.layout&&r&&_d(this.options.animationType,this.layout.layoutBox,r.layoutBox)){n=this.target||{x:{min:0,max:0},y:{min:0,max:0}};const t=au(this.layout.layoutBox.x);n.x.min=e.target.x.min,n.x.max=n.x.min+t;const r=au(this.layout.layoutBox.y);n.y.min=e.target.y.min,n.y.max=n.y.min+r}Ju(t,n),so(t,i),lu(this.projectionDeltaWithTransform,this.layoutCorrected,t,i)}}registerSharedNode(e,t){this.sharedNodes.has(e)||this.sharedNodes.set(e,new hd);this.sharedNodes.get(e).add(t);const n=t.options.initialPromotionConfig;t.promote({transition:n?n.transition:void 0,preserveFollowOpacity:n&&n.shouldPreserveFollowOpacity?n.shouldPreserveFollowOpacity(t):void 0})}isLead(){const e=this.getStack();return!e||e.lead===this}getLead(){const{layoutId:e}=this.options;return e&&this.getStack()?.lead||this}getPrevLead(){const{layoutId:e}=this.options;return e?this.getStack()?.prevLead:void 0}getStack(){const{layoutId:e}=this.options;if(e)return this.root.sharedNodes.get(e)}promote(){let{needsReset:e,transition:t,preserveFollowOpacity:n}=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};const r=this.getStack();r&&r.promote(this,n),e&&(this.projectionDelta=void 0,this.needsReset=!0),t&&this.setOptions({transition:t})}relegate(){const e=this.getStack();return!!e&&e.relegate(this)}resetSkewAndRotation(){const{visualElement:e}=this.options;if(!e)return;let t=!1;const{latestValues:n}=e;if((n.z||n.rotate||n.rotateX||n.rotateY||n.rotateZ||n.skewX||n.skewY)&&(t=!0),!t)return;const r={};n.z&&gd("z",e,r,this.animationValues);for(let i=0;i<md.length;i++)gd(`rotate${md[i]}`,e,r,this.animationValues),gd(`skew${md[i]}`,e,r,this.animationValues);e.render();for(const i in r)e.setStaticValue(i,r[i]),this.animationValues&&(this.animationValues[i]=r[i]);e.scheduleRender()}applyProjectionStyles(e,t){if(!this.instance||this.isSVG)return;if(!this.isVisible)return void(e.visibility="hidden");const n=this.getTransformTemplate();if(this.needsReset)return this.needsReset=!1,e.visibility="",e.opacity="",e.pointerEvents=Ns(t?.pointerEvents)||"",void(e.transform=n?n(this.latestValues,""):"none");const r=this.getLead();if(!this.projectionDelta||!this.layout||!r.target)return this.options.layoutId&&(e.opacity=void 0!==this.latestValues.opacity?this.latestValues.opacity:1,e.pointerEvents=Ns(t?.pointerEvents)||""),void(this.hasProjected&&!Xi(this.latestValues)&&(e.transform=n?n({},""):"none",this.hasProjected=!1));e.visibility="";const i=r.animationValues||r.latestValues;this.applyTransformsToTarget();let o=function(e,t,n){let r="";const i=e.x.translate/t.x,o=e.y.translate/t.y,a=n?.z||0;if((i||o||a)&&(r=`translate3d(${i}px, ${o}px, ${a}px) `),1===t.x&&1===t.y||(r+=`scale(${1/t.x}, ${1/t.y}) `),n){const{transformPerspective:e,rotate:t,rotateX:i,rotateY:o,skewX:a,skewY:s}=n;e&&(r=`perspective(${e}px) ${r}`),t&&(r+=`rotate(${t}deg) `),i&&(r+=`rotateX(${i}deg) `),o&&(r+=`rotateY(${o}deg) `),a&&(r+=`skewX(${a}deg) `),s&&(r+=`skewY(${s}deg) `)}const s=e.x.scale*t.x,l=e.y.scale*t.y;return 1===s&&1===l||(r+=`scale(${s}, ${l})`),r||"none"}(this.projectionDeltaWithTransform,this.treeScale,i);n&&(o=n(i,o)),e.transform=o;const{x:a,y:s}=this.projectionDelta;e.transformOrigin=`${100*a.origin}% ${100*s.origin}% 0`,r.animationValues?e.opacity=r===this?i.opacity??this.latestValues.opacity??1:this.preserveOpacity?this.latestValues.opacity:i.opacityExit:e.opacity=r===this?void 0!==i.opacity?i.opacity:"":void 0!==i.opacityExit?i.opacityExit:0;for(const l in ls){if(void 0===i[l])continue;const{correct:t,applyTo:n,isCSSVariable:a}=ls[l],s="none"===o?i[l]:t(i[l],r);if(n){const t=n.length;for(let r=0;r<t;r++)e[n[r]]=s}else a?this.options.visualElement.renderState.vars[l]=s:e[l]=s}this.options.layoutId&&(e.pointerEvents=r===this?Ns(t?.pointerEvents)||"":"none")}clearSnapshot(){this.resumeFrom=this.snapshot=void 0}resetTree(){this.root.nodes.forEach(e=>e.currentAnimation?.stop()),this.root.nodes.forEach(jd),this.root.sharedNodes.clear()}}}function vd(e){e.updateLayout()}function bd(e){const t=e.resumeFrom?.snapshot||e.snapshot;if(e.isLead()&&e.layout&&t&&e.hasListeners("didUpdate")){const{layoutBox:n,measuredBox:r}=e.layout,{animationType:i}=e.options,o=t.source!==e.layout.source;"size"===i?hu(e=>{const r=o?t.measuredBox[e]:t.layoutBox[e],i=au(r);r.min=n[e].min,r.max=r.min+i}):_d(i,t.layoutBox,n)&&hu(r=>{const i=o?t.measuredBox[r]:t.layoutBox[r],a=au(n[r]);i.max=i.min+a,e.relativeTarget&&!e.currentAnimation&&(e.isProjectionDirty=!0,e.relativeTarget[r].max=e.relativeTarget[r].min+a)});const a={x:{translate:0,scale:1,origin:0,originPoint:0},y:{translate:0,scale:1,origin:0,originPoint:0}};lu(a,n,t.layoutBox);const s={x:{translate:0,scale:1,origin:0,originPoint:0},y:{translate:0,scale:1,origin:0,originPoint:0}};o?lu(s,e.applyTransform(r,!0),t.measuredBox):lu(s,n,t.layoutBox);const l=!ad(a);let c=!1;if(!e.resumeFrom){const r=e.getClosestProjectingParent();if(r&&!r.resumeFrom){const{snapshot:i,layout:o}=r;if(i&&o){const a={x:{min:0,max:0},y:{min:0,max:0}};du(a,t.layoutBox,i.layoutBox);const s={x:{min:0,max:0},y:{min:0,max:0}};du(s,n,o.layoutBox),cd(a,s)||(c=!0),r.options.layoutRoot&&(e.relativeTarget=s,e.relativeTargetOrigin=a,e.relativeParent=r)}}}e.notifyListeners("didUpdate",{layout:n,snapshot:t,delta:s,layoutDelta:a,hasLayoutChanged:l,hasRelativeLayoutChanged:c})}else if(e.isLead()){const{onExitComplete:t}=e.options;t&&t()}e.options.transition=void 0}function wd(e){Do.value&&pd.nodes++,e.parent&&(e.isProjecting()||(e.isProjectionDirty=e.parent.isProjectionDirty),e.isSharedProjectionDirty||(e.isSharedProjectionDirty=Boolean(e.isProjectionDirty||e.parent.isProjectionDirty||e.parent.isSharedProjectionDirty)),e.isTransformDirty||(e.isTransformDirty=e.parent.isTransformDirty))}function kd(e){e.isProjectionDirty=e.isSharedProjectionDirty=e.isTransformDirty=!1}function Sd(e){e.clearSnapshot()}function jd(e){e.clearMeasurements()}function $d(e){e.isLayoutDirty=!1}function Cd(e){const{visualElement:t}=e.options;t&&t.getProps().onBeforeLayoutMeasure&&t.notify("BeforeLayoutMeasure"),e.resetTransform()}function Ed(e){e.finishAnimation(),e.targetDelta=e.relativeTarget=e.target=void 0,e.isProjectionDirty=!0}function Td(e){e.resolveTargetDelta()}function Pd(e){e.calcProjection()}function zd(e){e.resetSkewAndRotation()}function Ad(e){e.removeLeadSnapshot()}function Rd(e,t,n){e.translate=Yi(t.translate,0,n),e.scale=Yi(t.scale,1,n),e.origin=t.origin,e.originPoint=t.originPoint}function Md(e,t,n,r){e.min=Yi(t.min,n.min,r),e.max=Yi(t.max,n.max,r)}function Ld(e){return e.animationValues&&void 0!==e.animationValues.opacityExit}const Dd={duration:.45,ease:[.4,0,.1,1]},Od=e=>"undefined"!==typeof navigator&&navigator.userAgent&&navigator.userAgent.toLowerCase().includes(e),Fd=Od("applewebkit/")&&!Od("chrome/")?Math.round:Ro;function Nd(e){e.min=Fd(e.min),e.max=Fd(e.max)}function _d(e,t,n){return"position"===e||"preserve-aspect"===e&&(r=ud(t),i=ud(n),o=.2,!(Math.abs(r-i)<=o));var r,i,o}function Id(e){return e!==e.root&&e.scroll?.wasRoot}const Vd=xd({attachResizeListener:(e,t)=>nu(e,"resize",t),measureScroll:()=>({x:document.documentElement.scrollLeft||document.body.scrollLeft,y:document.documentElement.scrollTop||document.body.scrollTop}),checkIsScrollRoot:()=>!0}),Bd={current:void 0},Wd=xd({measureScroll:e=>({x:e.scrollLeft,y:e.scrollTop}),defaultParent:()=>{if(!Bd.current){const e=new Vd({});e.mount(window),e.setOptions({layoutScroll:!0}),Bd.current=e}return Bd.current},resetTransform:(e,t)=>{e.style.transform=void 0!==t?t:"none"},checkIsScrollRoot:e=>Boolean("fixed"===window.getComputedStyle(e).position)}),Hd={pan:{Feature:class extends Qc{constructor(){super(...arguments),this.removePointerDownListener=Ro}onPointerDown(e){this.session=new fu(e,this.createPanHandlers(),{transformPagePoint:this.node.getTransformPagePoint(),contextWindow:pu(this.node)})}createPanHandlers(){const{onPanSessionStart:e,onPanStart:t,onPan:n,onPanEnd:r}=this.node.getProps();return{onSessionStart:zu(e),onStart:zu(t),onMove:n,onEnd:(e,t)=>{delete this.session,r&&Fo.postRender(()=>r(e,t))}}}mount(){this.removePointerDownListener=ou(this.node.current,"pointerdown",e=>this.onPointerDown(e))}update(){this.session&&this.session.updateHandlers(this.createPanHandlers())}unmount(){this.removePointerDownListener(),this.session&&this.session.end()}}},drag:{Feature:class extends Qc{constructor(e){super(e),this.removeGroupControls=Ro,this.removeListeners=Ro,this.controls=new Tu(e)}mount(){const{dragControls:e}=this.node.getProps();e&&(this.removeGroupControls=e.subscribe(this.controls)),this.removeListeners=this.controls.addListeners()||Ro}unmount(){this.removeGroupControls(),this.removeListeners()}},ProjectionNode:Wd,MeasureLayout:Fu}};function Ud(e,t){const n=function(e,t,n){if(e instanceof EventTarget)return[e];if("string"===typeof e){let r=document;t&&(r=t.current);const i=n?.[e]??r.querySelectorAll(e);return i?Array.from(i):[]}return Array.from(e)}(e),r=new AbortController;return[n,{passive:!0,...t,signal:r.signal},()=>r.abort()]}function qd(e){return!("touch"===e.pointerType||tu())}function Yd(e,t,n){const{props:r}=e;e.animationState&&r.whileHover&&e.animationState.setActive("whileHover","Start"===n);const i=r["onHover"+n];i&&Fo.postRender(()=>i(t,iu(t)))}const Kd=(e,t)=>!!t&&(e===t||Kd(e,t.parentElement)),Gd=new Set(["BUTTON","INPUT","SELECT","TEXTAREA","A"]);const Xd=new WeakSet;function Qd(e){return t=>{"Enter"===t.key&&e(t)}}function Jd(e,t){e.dispatchEvent(new PointerEvent("pointer"+t,{isPrimary:!0,bubbles:!0}))}function Zd(e){return ru(e)&&!tu()}function eh(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};const[r,i,o]=Ud(e,n),a=e=>{const r=e.currentTarget;if(!Zd(e))return;Xd.add(r);const o=t(r,e),a=(e,t)=>{window.removeEventListener("pointerup",s),window.removeEventListener("pointercancel",l),Xd.has(r)&&Xd.delete(r),Zd(e)&&"function"===typeof o&&o(e,{success:t})},s=e=>{a(e,r===window||r===document||n.useGlobalTarget||Kd(r,e.target))},l=e=>{a(e,!1)};window.addEventListener("pointerup",s,i),window.addEventListener("pointercancel",l,i)};return r.forEach(e=>{var t;(n.useGlobalTarget?window:e).addEventListener("pointerdown",a,i),li(e)&&(e.addEventListener("focus",e=>((e,t)=>{const n=e.currentTarget;if(!n)return;const r=Qd(()=>{if(Xd.has(n))return;Jd(n,"down");const e=Qd(()=>{Jd(n,"up")});n.addEventListener("keyup",e,t),n.addEventListener("blur",()=>Jd(n,"cancel"),t)});n.addEventListener("keydown",r,t),n.addEventListener("blur",()=>n.removeEventListener("keydown",r),t)})(e,i)),t=e,Gd.has(t.tagName)||-1!==t.tabIndex||e.hasAttribute("tabindex")||(e.tabIndex=0))}),o}function th(e,t,n){const{props:r}=e;if(e.current instanceof HTMLButtonElement&&e.current.disabled)return;e.animationState&&r.whileTap&&e.animationState.setActive("whileTap","Start"===n);const i=r["onTap"+("End"===n?"":n)];i&&Fo.postRender(()=>i(t,iu(t)))}const nh=new WeakMap,rh=new WeakMap,ih=e=>{const t=nh.get(e.target);t&&t(e)},oh=e=>{e.forEach(ih)};function ah(e,t,n){const r=function(e){let{root:t,...n}=e;const r=t||document;rh.has(r)||rh.set(r,{});const i=rh.get(r),o=JSON.stringify(n);return i[o]||(i[o]=new IntersectionObserver(oh,{root:t,...n})),i[o]}(t);return nh.set(e,n),r.observe(e),()=>{nh.delete(e),r.unobserve(e)}}const sh={some:0,all:1};const lh={inView:{Feature:class extends Qc{constructor(){super(...arguments),this.hasEnteredView=!1,this.isInView=!1}startObserver(){this.unmount();const{viewport:e={}}=this.node.getProps(),{root:t,margin:n,amount:r="some",once:i}=e,o={root:t?t.current:void 0,rootMargin:n,threshold:"number"===typeof r?r:sh[r]};return ah(this.node.current,o,e=>{const{isIntersecting:t}=e;if(this.isInView===t)return;if(this.isInView=t,i&&!t&&this.hasEnteredView)return;t&&(this.hasEnteredView=!0),this.node.animationState&&this.node.animationState.setActive("whileInView",t);const{onViewportEnter:n,onViewportLeave:r}=this.node.getProps(),o=t?n:r;o&&o(e)})}mount(){this.startObserver()}update(){if("undefined"===typeof IntersectionObserver)return;const{props:e,prevProps:t}=this.node,n=["amount","margin","root"].some(function(e){let{viewport:t={}}=e,{viewport:n={}}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};return e=>t[e]!==n[e]}(e,t));n&&this.startObserver()}unmount(){}}},tap:{Feature:class extends Qc{mount(){const{current:e}=this.node;e&&(this.unmount=eh(e,(e,t)=>(th(this.node,t,"Start"),(e,t)=>{let{success:n}=t;return th(this.node,e,n?"End":"Cancel")}),{useGlobalTarget:this.node.props.globalTapTarget}))}unmount(){}}},focus:{Feature:class extends Qc{constructor(){super(...arguments),this.isActive=!1}onFocus(){let e=!1;try{e=this.node.current.matches(":focus-visible")}catch(w$){e=!0}e&&this.node.animationState&&(this.node.animationState.setActive("whileFocus",!0),this.isActive=!0)}onBlur(){this.isActive&&this.node.animationState&&(this.node.animationState.setActive("whileFocus",!1),this.isActive=!1)}mount(){this.unmount=sl(nu(this.node.current,"focus",()=>this.onFocus()),nu(this.node.current,"blur",()=>this.onBlur()))}unmount(){}}},hover:{Feature:class extends Qc{mount(){const{current:e}=this.node;e&&(this.unmount=function(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};const[r,i,o]=Ud(e,n),a=e=>{if(!qd(e))return;const{target:n}=e,r=t(n,e);if("function"!==typeof r||!n)return;const o=e=>{qd(e)&&(r(e),n.removeEventListener("pointerleave",o))};n.addEventListener("pointerleave",o,i)};return r.forEach(e=>{e.addEventListener("pointerenter",a,i)}),o}(e,(e,t)=>(Yd(this.node,t,"Start"),e=>Yd(this.node,e,"End"))))}unmount(){}}}},ch={layout:{ProjectionNode:Wd,MeasureLayout:Fu}},uh={...Zc,...lh,...Hd,...ch},dh=Js(uh,ks),hh=n.p+"static/media/ASTRA-removebg-preview.2d80e8c571e953cafc9c.png",ph=Si("sun",[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]),mh=Si("moon",[["path",{d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}]]),fh=Jr.div`
  position: relative;
  display: inline-block;
`,gh=Jr.button`
  position: relative;
  width: 60px;
  height: 32px;
  background: ${e=>{let{$isDark:t,theme:n}=e;return t?"linear-gradient(45deg, #1e293b, #334155)":"linear-gradient(45deg, #60a5fa, #3b82f6)"}};
  border: none;
  border-radius: 16px;
  cursor: pointer;
  transition: all 0.3s ease;
  padding: 0;
  overflow: hidden;
  
  &:hover {
    transform: scale(1.05);
  }
  
  &:active {
    transform: scale(0.95);
  }
`,yh=Jr.div`
  position: absolute;
  top: 2px;
  left: ${e=>{let{$isDark:t}=e;return t?"30px":"2px"}};
  width: 28px;
  height: 28px;
  background: white;
  border-radius: 50%;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  
  svg {
    width: 16px;
    height: 16px;
    color: ${e=>{let{$isDark:t,theme:n}=e;return t?n.colors.text:"#fbbf24"}};
    transition: all 0.3s ease;
  }
`,xh=Jr.div`
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  ${e=>{let{$position:t}=e;return t}}: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: ${e=>{let{$position:t,$isDark:n}=e;return"left"===t&&!n||"right"===t&&n?.3:.7}};
  transition: opacity 0.3s ease;
  
  svg {
    width: 14px;
    height: 14px;
    color: white;
  }
`,vh=e=>{let{isDark:t,onToggle:n}=e;return(0,ti.jsx)(fh,{children:(0,ti.jsxs)(gh,{$isDark:t,onClick:n,children:[(0,ti.jsx)(xh,{$position:"left",$isDark:t,children:(0,ti.jsx)(ph,{})}),(0,ti.jsx)(xh,{$position:"right",$isDark:t,children:(0,ti.jsx)(mh,{})}),(0,ti.jsx)(yh,{$isDark:t,children:t?(0,ti.jsx)(mh,{}):(0,ti.jsx)(ph,{})})]})})},bh={colors:{primary:"#667eea",primaryHover:"#5a67d8",secondary:"#764ba2",accent:"#f093fb",background:"#f8f9fa",backgroundSecondary:"#ffffff",backgroundTertiary:"#f1f3f4",surface:"#ffffff",text:"#2d3748",textSecondary:"#718096",textLight:"#a0aec0",border:"#e2e8f0",borderLight:"#f0f4f8",success:"#48bb78",error:"#f56565",warning:"#ed8936",info:"#4299e1",shadow:"rgba(0, 0, 0, 0.1)",shadowHover:"rgba(0, 0, 0, 0.15)",boxShadow:"0 4px 6px rgba(0, 0, 0, 0.1)",overlay:"rgba(0, 0, 0, 0.5)",gradient:"linear-gradient(135deg, #667eea 0%, #764ba2 100%)",gradientHover:"linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%)"},spacing:{xs:"4px",sm:"8px",md:"16px",lg:"24px",xl:"32px",xxl:"48px"},borderRadius:{sm:"4px",md:"8px",lg:"12px",xl:"16px",full:"9999px"},typography:{fontSizes:{xs:"12px",sm:"14px",md:"16px",lg:"18px",xl:"20px",xxl:"24px",heading:"32px",display:"48px"},fontWeights:{normal:400,medium:500,semibold:600,bold:700},lineHeights:{tight:1.25,normal:1.5,relaxed:1.75}},breakpoints:{xs:"320px",sm:"480px",md:"768px",lg:"1024px",xl:"1280px",xxl:"1440px",mobile:"480px",tablet:"768px",desktop:"1024px",wide:"1440px"},zIndex:{dropdown:1e3,sticky:1020,fixed:1030,modal:1050,popover:1060,tooltip:1070,toast:1080},animation:{duration:{fast:"0.2s",normal:"0.3s",slow:"0.5s"},easing:{default:"cubic-bezier(0.4, 0, 0.2, 1)",bounce:"cubic-bezier(0.68, -0.55, 0.265, 1.55)"}},createShadow:(e,t)=>{const n={1:`0 1px 3px ${t.colors.shadow}`,2:`0 4px 6px ${t.colors.shadow}`,3:`0 10px 15px ${t.colors.shadow}`,4:`0 20px 25px ${t.colors.shadow}`,5:`0 25px 50px ${t.colors.shadow}`};return n[e]||n[1]}},wh={...bh,colors:{...bh.colors,primary:"#7c3aed",primaryHover:"#8b5cf6",secondary:"#a855f7",accent:"#ec4899",background:"#0f172a",backgroundSecondary:"#1e293b",backgroundTertiary:"#334155",surface:"#1e293b",text:"#f1f5f9",textSecondary:"#cbd5e1",textLight:"#94a3b8",border:"#334155",borderLight:"#475569",shadow:"rgba(0, 0, 0, 0.3)",shadowHover:"rgba(0, 0, 0, 0.5)",boxShadow:"0 4px 6px rgba(0, 0, 0, 0.3)",overlay:"rgba(0, 0, 0, 0.7)",gradient:"linear-gradient(135deg, #7c3aed 0%, #a855f7 100%)",gradientHover:"linear-gradient(135deg, #8b5cf6 0%, #c084fc 100%)"}},kh=(0,e.createContext)(void 0),Sh=()=>{const t=(0,e.useContext)(kh);if(!t)throw new Error("useTheme must be used within a ThemeProvider");return t},jh=t=>{let{children:n}=t;const[r,i]=(0,e.useState)(()=>{const e=localStorage.getItem("astra-theme");return"dark"===e||!e&&window.matchMedia("(prefers-color-scheme: dark)").matches});(0,e.useEffect)(()=>{localStorage.setItem("astra-theme",r?"dark":"light")},[r]);const o=r?wh:bh;return(0,ti.jsx)(kh.Provider,{value:{isDark:r,toggleTheme:()=>{i(!r)},theme:o},children:n})},$h=(0,e.createContext)(void 0),Ch=()=>{const t=(0,e.useContext)($h);if(!t)throw new Error("useAuth must be used within an AuthProvider");return t},Eh=t=>{let{children:n}=t;const[r,i]=(0,e.useState)(null);(0,e.useEffect)(()=>{const e=localStorage.getItem("astra-user");if(e)try{const t=JSON.parse(e);i(t)}catch(t){console.error("Error parsing saved user:",t),localStorage.removeItem("astra-user")}},[]);const o=!!r;return(0,ti.jsx)($h.Provider,{value:{user:r,login:e=>{i(e),localStorage.setItem("astra-user",JSON.stringify(e))},logout:()=>{i(null),localStorage.removeItem("astra-user")},register:e=>{const t={...e,joinDate:(new Date).toISOString(),avatar:e.avatar||"/default-avatar.png"};i(t),localStorage.setItem("astra-user",JSON.stringify(t))},updateUser:e=>{if(r){const t={...r,...e};i(t),localStorage.setItem("astra-user",JSON.stringify(t))}},isAuthenticated:o},children:n})},Th=Si("x",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]),Ph=Si("triangle-alert",[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]]),zh=Jr(dh.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  padding: 20px;
`,Ah=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  width: 100%;
  max-width: 400px;
  position: relative;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(5,t)}};
`,Rh=Jr.button`
  position: absolute;
  top: 16px;
  right: 16px;
  background: none;
  border: none;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  cursor: pointer;
  padding: 8px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.2s;

  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  }
`,Mh=Jr.div`
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,Lh=Jr.div`
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: ${e=>{let{variant:t,theme:n}=e;return"danger"===t?"#fee2e2":"warning"===t?"#fef3c7":n.colors.primary+"20"}};
  color: ${e=>{let{variant:t,theme:n}=e;return"danger"===t?"#dc2626":"warning"===t?"#d97706":n.colors.primary}};
`,Dh=Jr.h2`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  margin: 0;
`,Oh=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  line-height: 1.5;
  margin: 0 0 ${e=>{let{theme:t}=e;return t.spacing.xl}} 0;
`,Fh=Jr.div`
  display: flex;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  justify-content: flex-end;
`,Nh=Jr(dh.button)`
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}} ${e=>{let{theme:t}=e;return t.spacing.lg}};
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  cursor: pointer;
  transition: all 0.2s;

  ${e=>{let{variant:t,theme:n}=e;switch(t){case"primary":return`\n          background: ${n.colors.primary};\n          color: white;\n          &:hover {\n            opacity: 0.9;\n          }\n        `;case"danger":return"\n          background: #dc2626;\n          color: white;\n          &:hover {\n            background: #b91c1c;\n          }\n        ";default:return`\n          background: ${n.colors.backgroundSecondary};\n          color: ${n.colors.text};\n          &:hover {\n            background: ${n.colors.border};\n          }\n        `}}}
`,_h=e=>{let{isOpen:t,onClose:n,onConfirm:r,title:i,message:o,confirmText:a="Confirm",cancelText:s="Cancel",variant:l="info"}=e;return(0,ti.jsx)(yi,{children:t&&(0,ti.jsx)(zh,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:n,children:(0,ti.jsxs)(Ah,{initial:{opacity:0,scale:.9},animate:{opacity:1,scale:1},exit:{opacity:0,scale:.9},onClick:e=>e.stopPropagation(),children:[(0,ti.jsx)(Rh,{onClick:n,children:(0,ti.jsx)(Th,{size:20})}),(0,ti.jsxs)(Mh,{children:[(0,ti.jsx)(Lh,{variant:l,children:(0,ti.jsx)(Ph,{size:24})}),(0,ti.jsx)(Dh,{children:i})]}),(0,ti.jsx)(Oh,{children:o}),(0,ti.jsxs)(Fh,{children:[(0,ti.jsx)(Nh,{variant:"secondary",onClick:n,whileHover:{scale:1.02},whileTap:{scale:.98},children:s}),(0,ti.jsx)(Nh,{variant:"danger"===l?"danger":"primary",onClick:()=>{r(),n()},whileHover:{scale:1.02},whileTap:{scale:.98},children:a})]})]})})})},Ih=Jr.header`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}} ${e=>{let{theme:t}=e;return t.spacing.lg}};
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(1,t)}};
  position: fixed;
  width: 100%;
  top: 0;
  z-index: ${e=>{let{theme:t}=e;return t.zIndex.sticky}};
  max-width: 100vw;
  box-sizing: border-box;
`,Vh=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,Bh=Jr.div`
  flex: 1;
  max-width: 400px;
  margin: 0 ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,Wh=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Hh=Jr.div`
  position: relative;
  width: 100%;
`,Uh=Jr.input`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}} ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding-left: 40px;
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  outline: none;
  transition: all 0.2s ease;
  
  &:focus {
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    box-shadow: 0 0 0 3px ${e=>{let{theme:t}=e;return t.colors.primary}}20;
  }
  
  &::placeholder {
    color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  }
`,qh=Jr.div`
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  
  svg {
    width: 16px;
    height: 16px;
  }
`,Yh=Jr.button`
  background: none;
  border: none;
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  border-radius: 50%;
  cursor: pointer;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  position: relative;
  transition: all 0.2s ease;
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
  
  ${e=>{let{$hasNotification:t,theme:n}=e;return t&&`\n    &::after {\n      content: '';\n      position: absolute;\n      top: 8px;\n      right: 8px;\n      width: 8px;\n      height: 8px;\n      background: ${n.colors.error};\n      border-radius: 50%;\n      border: 2px solid ${n.colors.surface};\n    }\n  `}}
`,Kh=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  cursor: pointer;
`,Gh=Jr.span`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,Xh=Jr.button`
  background: none;
  border: none;
  padding: 0;
  cursor: pointer;
  border-radius: 50%;
  transition: all 0.2s ease;
  
  &:hover {
    transform: scale(1.05);
  }
`,Qh=Jr.img`
  width: 32px;
  height: 32px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,Jh=ei`
  0%, 100% {
    filter: drop-shadow(0 0 5px rgba(102, 126, 234, 0.4));
  }
  50% {
    filter: drop-shadow(0 0 15px rgba(102, 126, 234, 0.8)) drop-shadow(0 0 25px rgba(118, 75, 162, 0.6));
  }
`,Zh=ei`
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-3px);
  }
`,ep=Jr(dh.img)`
  height: 40px;
  animation: ${Jh} 2s ease-in-out infinite, ${Zh} 3s ease-in-out infinite;
  transition: all 0.3s ease;
  
  &:hover {
    transform: scale(1.1);
    filter: drop-shadow(0 0 20px rgba(102, 126, 234, 1)) drop-shadow(0 0 30px rgba(118, 75, 162, 0.8));
  }
`,tp=(Jr.nav`
  display: flex;
  gap: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,Jr(tt)`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  text-decoration: none;
  transition: color 0.3s ease;

  &.active {
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }

  &:hover {
    color: ${e=>{let{theme:t}=e;return t.colors.primaryHover}};
  }
`,()=>{const[t,n]=(0,e.useState)(""),[r,i]=(0,e.useState)(!1),[o,a]=(0,e.useState)(3),[s,l]=(0,e.useState)(5),{isDark:c,toggleTheme:u}=Sh(),{user:d,logout:h}=Ch(),p=ee();return(0,ti.jsxs)(ti.Fragment,{children:[(0,ti.jsxs)(Ih,{children:[(0,ti.jsx)(Vh,{children:(0,ti.jsxs)(Kh,{onClick:()=>{p("/")},children:[(0,ti.jsx)(ep,{src:hh,alt:"Astra Logo"}),(0,ti.jsx)(Gh,{children:"Astra"})]})}),(0,ti.jsx)(Bh,{children:(0,ti.jsxs)(Hh,{children:[(0,ti.jsx)(qh,{children:(0,ti.jsx)(ji,{})}),(0,ti.jsx)(Uh,{type:"text",placeholder:"Search people, posts, accounts...",value:t,onChange:e=>n(e.target.value),onKeyDown:e=>{"Enter"===e.key&&t.trim()&&console.log("Searching for:",t)}})]})}),(0,ti.jsxs)(Wh,{children:[(0,ti.jsx)(vh,{isDark:c,onToggle:u}),(0,ti.jsx)(Yh,{title:"Friends",onClick:()=>p("/friends"),children:(0,ti.jsx)($i,{})}),(0,ti.jsxs)(Yh,{title:"Messages",onClick:()=>{p("/messages"),a(0)},$hasNotification:o>0,children:[(0,ti.jsx)(Ci,{}),o>0&&(0,ti.jsx)("span",{style:{position:"absolute",top:"4px",right:"4px",background:"#ff4444",color:"white",borderRadius:"50%",width:"16px",height:"16px",fontSize:"10px",display:"flex",alignItems:"center",justifyContent:"center"},children:o})]}),(0,ti.jsxs)(Yh,{title:"Notifications",onClick:()=>{console.log("Opening notifications"),l(0)},$hasNotification:s>0,children:[(0,ti.jsx)(Ei,{}),s>0&&(0,ti.jsx)("span",{style:{position:"absolute",top:"4px",right:"4px",background:"#ff4444",color:"white",borderRadius:"50%",width:"16px",height:"16px",fontSize:"10px",display:"flex",alignItems:"center",justifyContent:"center"},children:s})]}),(0,ti.jsx)(Xh,{onClick:()=>{p("/profile")},title:"Profile",children:(0,ti.jsx)(Qh,{src:hh,alt:"Profile"})}),(0,ti.jsx)(Yh,{title:"Logout",onClick:()=>i(!0),style:{color:"#ff4444"},children:(0,ti.jsx)(Ti,{})})]})]}),(0,ti.jsx)(_h,{isOpen:r,onClose:()=>i(!1),onConfirm:()=>{h(),p("/auth")},title:"Logout",message:"Are you sure you want to logout from your account?",confirmText:"Logout",cancelText:"Cancel",variant:"warning"})]})}),np=Si("house",[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"1d0kgt"}]]),rp=Si("message-square",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]]),ip=Si("video",[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]]),op=Si("music",[["path",{d:"M9 18V5l12-2v13",key:"1jmyc2"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["circle",{cx:"18",cy:"16",r:"3",key:"1hluhg"}]]),ap=Si("shopping-bag",[["path",{d:"M16 10a4 4 0 0 1-8 0",key:"1ltviw"}],["path",{d:"M3.103 6.034h17.794",key:"awc11p"}],["path",{d:"M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",key:"o988cm"}]]),sp=Si("wallet",[["path",{d:"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",key:"18etb6"}],["path",{d:"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",key:"xoc0q4"}]]),lp=Si("building",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",ry:"2",key:"76otgf"}],["path",{d:"M9 22v-4h6v4",key:"r93iot"}],["path",{d:"M8 6h.01",key:"1dz90k"}],["path",{d:"M16 6h.01",key:"1x0f13"}],["path",{d:"M12 6h.01",key:"1vi96p"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M16 14h.01",key:"1gbofw"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M8 14h.01",key:"6423bh"}]]),cp=Si("code",[["path",{d:"m16 18 6-6-6-6",key:"eg8j8"}],["path",{d:"m8 6-6 6 6 6",key:"ppft3o"}]]),up=Si("gamepad-2",[["line",{x1:"6",x2:"10",y1:"11",y2:"11",key:"1gktln"}],["line",{x1:"8",x2:"8",y1:"9",y2:"13",key:"qnk9ow"}],["line",{x1:"15",x2:"15.01",y1:"12",y2:"12",key:"krot7o"}],["line",{x1:"18",x2:"18.01",y1:"10",y2:"10",key:"1lcuu1"}],["path",{d:"M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",key:"mfqc10"}]]),dp=Si("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]),hp=Si("play",[["polygon",{points:"6 3 20 12 6 21 6 3",key:"1oa8hb"}]]),pp=Si("rss",[["path",{d:"M4 11a9 9 0 0 1 9 9",key:"pv89mb"}],["path",{d:"M4 4a16 16 0 0 1 16 16",key:"k0647b"}],["circle",{cx:"5",cy:"19",r:"1",key:"bfqh0e"}]]),mp=Si("user",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]),fp=Si("bookmark",[["path",{d:"m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z",key:"1fy3hk"}]]),gp=Si("heart",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}]]),yp=Si("settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]),xp=Si("phone",[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]]),vp=Si("user-plus",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["line",{x1:"19",x2:"19",y1:"8",y2:"14",key:"1bvyxn"}],["line",{x1:"22",x2:"16",y1:"11",y2:"11",key:"1shjgl"}]]),bp=Si("log-in",[["path",{d:"m10 17 5-5-5-5",key:"1bsop3"}],["path",{d:"M15 12H3",key:"6jk70r"}],["path",{d:"M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",key:"u53s6r"}]]),wp=Si("menu",[["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 18h16",key:"19g7jn"}],["path",{d:"M4 6h16",key:"1o0s65"}]]),kp=Jr.nav`
  position: fixed;
  left: 0;
  top: 80px;
  height: calc(100vh - 80px);
  width: ${e=>{let{$isOpen:t}=e;return t?"280px":"80px"}};
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  z-index: ${e=>{let{theme:t}=e;return t.zIndex.sticky-1}};
  overflow-y: auto;
  border-right: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  
  &::-webkit-scrollbar {
    width: 4px;
  }
  
  &::-webkit-scrollbar-track {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  }
  
  &::-webkit-scrollbar-thumb {
    background: ${e=>{let{theme:t}=e;return t.colors.primary}};
    border-radius: 2px;
  }
`,Sp=Jr.button`
  position: absolute;
  top: 20px;
  right: 20px;
  background: none;
  border: none;
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  cursor: pointer;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  transition: all 0.2s ease;
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
`,jp=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}} ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding-top: 60px;
`,$p=Jr.div`
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
`,Cp=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding-left: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  text-transform: uppercase;
  letter-spacing: 0.5px;
  opacity: ${e=>{let{$isOpen:t}=e;return t?1:0}};
  transition: opacity 0.3s ease;
  white-space: nowrap;
`,Ep=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}} ${e=>{let{theme:t}=e;return t.spacing.md}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
  
  background: ${e=>{let{theme:t,$active:n}=e;return n?t.colors.primary+"15":"transparent"}};
  color: ${e=>{let{theme:t,$active:n}=e;return n?t.colors.primary:t.colors.textSecondary}};
  
  &:hover {
    background: ${e=>{let{theme:t,$active:n}=e;return n?t.colors.primary+"25":t.colors.backgroundSecondary}};
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    transform: translateX(4px);
  }
  
  svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
  }
`,Tp=Jr.span`
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  opacity: ${e=>{let{$isOpen:t}=e;return t?1:0}};
  transition: opacity 0.3s ease;
  white-space: nowrap;
`,Pp=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.error}};
  color: white;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  padding: 2px 6px;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  min-width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-left: auto;
`,zp=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.success}};
  color: white;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  padding: 2px 6px;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  margin-left: auto;
`,Ap=e=>{let{isOpen:t,onToggle:n}=e;const r=ee(),i=Q(),o=[{section:"Main",items:[{path:"/",icon:np,label:"Home",badge:null},{path:"/community",icon:$i,label:"Community",badge:null},{path:"/groups",icon:rp,label:"Groups",badge:3},{path:"/messages",icon:rp,label:"Messages",badge:5},{path:"/reels",icon:ip,label:"Reels",badge:"NEW"},{path:"/music",icon:op,label:"Music",badge:null}]},{section:"Business",items:[{path:"/shop",icon:ap,label:"Shop",badge:null},{path:"/wallet",icon:sp,label:"Wallet",badge:null},{path:"/business",icon:lp,label:"Business",badge:null},{path:"/developer",icon:cp,label:"Developer",badge:null}]},{section:"Entertainment",items:[{path:"/gaming",icon:up,label:"Gaming",badge:null},{path:"/trending",icon:dp,label:"Trending",badge:null},{path:"/live",icon:hp,label:"Live",badge:"LIVE"},{path:"/feed",icon:pp,label:"Feed",badge:null}]},{section:"Personal",items:[{path:"/profile",icon:mp,label:"Profile",badge:null},{path:"/saved",icon:fp,label:"Saved",badge:null},{path:"/liked",icon:gp,label:"Liked",badge:null},{path:"/settings",icon:yp,label:"Settings",badge:null}]},{section:"Support",items:[{path:"/contact",icon:xp,label:"Contact",badge:null},{path:"/register",icon:vp,label:"Register",badge:null},{path:"/login",icon:bp,label:"Login",badge:null}]}];return(0,ti.jsxs)(kp,{$isOpen:t,children:[(0,ti.jsx)(Sp,{onClick:n,children:t?(0,ti.jsx)(Th,{}):(0,ti.jsx)(wp,{})}),(0,ti.jsx)(jp,{children:o.map(e=>(0,ti.jsxs)($p,{children:[(0,ti.jsx)(Cp,{$isOpen:t,children:e.section}),e.items.map(e=>(0,ti.jsxs)(Ep,{$active:i.pathname===e.path,$isOpen:t,onClick:()=>{return t=e.path,void r(t);var t},children:[(0,ti.jsx)(e.icon,{}),(0,ti.jsx)(Tp,{$isOpen:t,children:e.label}),e.badge&&"number"===typeof e.badge&&(0,ti.jsx)(Pp,{children:e.badge}),e.badge&&"string"===typeof e.badge&&(0,ti.jsx)(zp,{children:e.badge})]},e.path))]},e.section))})]})},Rp=Jr.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.9);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: ${e=>{let{theme:t}=e;return t.zIndex.modal}};
  opacity: ${e=>{let{$active:t}=e;return t?1:0}};
  visibility: ${e=>{let{$active:t}=e;return t?"visible":"hidden"}};
  transition: opacity 0.3s ease, visibility 0.3s ease;
`,Mp=Jr.div`
  text-align: center;
  color: white;
  max-width: 400px;
  padding: ${e=>{let{theme:t}=e;return t.spacing.xxl}};
`,Lp=Jr.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: ${e=>{let{theme:t}=e;return t.zIndex.modal-1}};
  opacity: ${e=>{let{$active:t}=e;return t?1:0}};
  visibility: ${e=>{let{$active:t}=e;return t?"visible":"hidden"}};
  transition: opacity 0.3s ease, visibility 0.3s ease;
`,Dp=Jr.div`
  text-align: center;
  color: white;
  max-width: 400px;
  padding: ${e=>{let{theme:t}=e;return t.spacing.xxl}};
`,Op=Jr.img`
  width: 100px;
  height: 100px;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  animation: rotate 2s linear infinite;
  filter: brightness(0) invert(1);
`,Fp=Jr.img`
  width: 80px;
  height: 80px;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  animation: rotate 2s linear infinite;
  filter: brightness(0) invert(1);
`,Np=Jr.div`
  width: 250px;
  height: 4px;
  background: rgba(255, 255, 255, 0.3);
  border-radius: 2px;
  overflow: hidden;
  margin: 0 auto;
`,_p=Jr.div`
  height: 100%;
  background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%);
  border-radius: 2px;
  transition: width 1.5s ease-out;
  width: ${e=>{let{$progress:t}=e;return t}}%;
`,Ip=Jr.div`
  position: fixed;
  bottom: 20px;
  left: 20px;
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}} ${e=>{let{theme:t}=e;return t.spacing.md}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  z-index: ${e=>{let{theme:t}=e;return t.zIndex.fixed}};
  background: ${e=>{let{$online:t,theme:n}=e;return t?n.colors.success:n.colors.error}};
  color: white;
  transition: all 0.3s ease;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(3,t)}};
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  &::before {
    content: '';
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: currentColor;
    animation: pulse 2s ease-in-out infinite;
  }
  
  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }
`,Vp=Jr.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  opacity: 0.7;
  margin-top: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Bp=Jr.span`
  width: 8px;
  height: 8px;
  background: #ff6b6b;
  border-radius: 50%;
  animation: pulse 1.5s ease-in-out infinite;
`,Wp=()=>{const[t,n]=(0,e.useState)(navigator.onLine),[r,i]=(0,e.useState)(!1),[o,a]=(0,e.useState)(!1),[s,l]=(0,e.useState)(0);(0,e.useEffect)(()=>{const e=()=>{n(!0),i(!1),c()},t=()=>{n(!1),i(!0),a(!1)};return window.addEventListener("online",e),window.addEventListener("offline",t),navigator.onLine||i(!0),()=>{window.removeEventListener("online",e),window.removeEventListener("offline",t)}},[]);const c=()=>{a(!0),l(0),setTimeout(()=>{l(100)},100),setTimeout(()=>{a(!1)},2e3)};return(0,e.useEffect)(()=>{let e;return t||(e=setInterval(()=>{fetch("/favicon.ico",{method:"HEAD",cache:"no-cache"}).then(()=>{navigator.onLine||window.dispatchEvent(new Event("online"))}).catch(()=>{})},5e3)),()=>{e&&clearInterval(e)}},[t]),(0,ti.jsxs)(ti.Fragment,{children:[(0,ti.jsx)(Ip,{$online:t,children:t?"Online":"Offline"}),(0,ti.jsx)(Rp,{$active:r,children:(0,ti.jsxs)(Mp,{children:[(0,ti.jsx)(Fp,{src:hh,alt:"Astra Logo"}),(0,ti.jsx)("h2",{children:"You're Offline"}),(0,ti.jsx)("p",{children:"Please check your internet connection and try again."}),(0,ti.jsxs)(Vp,{children:[(0,ti.jsx)(Bp,{}),(0,ti.jsx)("span",{children:"Attempting to reconnect..."})]})]})}),(0,ti.jsx)(Lp,{$active:o,children:(0,ti.jsxs)(Dp,{children:[(0,ti.jsx)(Op,{src:hh,alt:"Astra Logo"}),(0,ti.jsxs)("div",{children:[(0,ti.jsx)("h2",{children:"Astra"}),(0,ti.jsx)("p",{children:"Loading your social experience..."})]}),(0,ti.jsx)(Np,{children:(0,ti.jsx)(_p,{$progress:s})})]})})]})},Hp=ei`
  0% {
    transform: rotate(0deg);
    filter: drop-shadow(0 0 10px rgba(102, 126, 234, 0.5));
  }
  25% {
    filter: drop-shadow(0 0 20px rgba(118, 75, 162, 0.7));
  }
  50% {
    transform: rotate(180deg);
    filter: drop-shadow(0 0 30px rgba(240, 147, 251, 0.8));
  }
  75% {
    filter: drop-shadow(0 0 20px rgba(118, 75, 162, 0.7));
  }
  100% {
    transform: rotate(360deg);
    filter: drop-shadow(0 0 10px rgba(102, 126, 234, 0.5));
  }
`,Up=ei`
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.6;
  }
`,qp=Jr(dh.div)`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 9999;
`,Yp=Jr(dh.div)`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 2rem;
`,Kp=Jr.img`
  width: 120px;
  height: 120px;
  animation: ${Hp} 2s infinite linear;
  filter: drop-shadow(0 0 20px rgba(255, 255, 255, 0.3));
`,Gp=Jr(dh.h1)`
  color: white;
  font-size: 2rem;
  font-weight: 600;
  margin-bottom: 1rem;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
`,Xp=Jr(dh.p)`
  color: rgba(255, 255, 255, 0.8);
  font-size: 1.1rem;
  margin-bottom: 2rem;
  text-align: center;
  max-width: 400px;
`,Qp=Jr(dh.div)`
  width: 300px;
  height: 4px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 2px;
  overflow: hidden;
  margin-bottom: 1rem;
`,Jp=Jr(dh.div)`
  height: 100%;
  background: linear-gradient(90deg, #ffffff, #f093fb, #ffffff);
  border-radius: 2px;
  width: 0%;
`,Zp=Jr.div`
  display: flex;
  gap: 0.5rem;
  margin-top: 1rem;
`,em=Jr.div`
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: white;
  animation: ${Up} 1.5s infinite;
  animation-delay: ${e=>{let{delay:t}=e;return t}}s;
`,tm=t=>{let{onComplete:n}=t;const[r,i]=e.useState(0);return e.useEffect(()=>{const e=setInterval(()=>{i(t=>t>=100?(clearInterval(e),setTimeout(()=>null===n||void 0===n?void 0:n(),500),100):t+15*Math.random())},150);return()=>clearInterval(e)},[n]),(0,ti.jsxs)(qp,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:.5},children:[(0,ti.jsx)(Yp,{initial:{scale:.5,opacity:0},animate:{scale:1,opacity:1},transition:{duration:.8,ease:"easeOut"},children:(0,ti.jsx)(Kp,{src:hh,alt:"Astra Logo"})}),(0,ti.jsx)(Gp,{initial:{y:20,opacity:0},animate:{y:0,opacity:1},transition:{delay:.3,duration:.6},children:"Welcome to Astra"}),(0,ti.jsxs)(Xp,{initial:{y:20,opacity:0},animate:{y:0,opacity:1},transition:{delay:.5,duration:.6},children:["The future of social networking is here. Connect, share, and explore in a whole new way.",(0,ti.jsx)("br",{}),(0,ti.jsx)("br",{}),"Developed by NEF",(0,ti.jsx)("br",{}),"Silver Studio V1.1.0"]}),(0,ti.jsx)(Qp,{initial:{width:0,opacity:0},animate:{width:300,opacity:1},transition:{delay:.7,duration:.5},children:(0,ti.jsx)(Jp,{initial:{width:"0%"},animate:{width:`${r}%`},transition:{duration:.3}})}),(0,ti.jsxs)(dh.div,{initial:{opacity:0},animate:{opacity:1},transition:{delay:.8,duration:.5},style:{color:"rgba(255, 255, 255, 0.7)",fontSize:"0.9rem"},children:[Math.round(r),"% Complete"]}),(0,ti.jsxs)(Zp,{children:[(0,ti.jsx)(em,{delay:0}),(0,ti.jsx)(em,{delay:.2}),(0,ti.jsx)(em,{delay:.4})]})]})},nm=Si("mail",[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",key:"132q7q"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2",key:"izxlao"}]]),rm=Si("lock",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]]),im=Si("eye-off",[["path",{d:"M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",key:"ct8e1f"}],["path",{d:"M14.084 14.158a3 3 0 0 1-4.242-4.242",key:"151rxh"}],["path",{d:"M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",key:"13bj9a"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]]),om=Si("eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]),am=Si("calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]),sm=Si("map-pin",[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]),lm=Si("camera",[["path",{d:"M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z",key:"1tc9qg"}],["circle",{cx:"12",cy:"13",r:"3",key:"1vg3eu"}]]),cm=Jr(dh.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(5px);
`,um=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.xl}};
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  position: relative;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(5,t)}};
`,dm=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  border-bottom: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.xl}} ${e=>{let{theme:t}=e;return t.borderRadius.xl}} 0 0;
`,hm=Jr.h2`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  margin: 0;
`,pm=Jr.button`
  background: none;
  border: none;
  color: white;
  cursor: pointer;
  padding: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  border-radius: 50%;
  transition: all 0.2s ease;
  
  &:hover {
    background: rgba(255, 255, 255, 0.1);
  }
`,mm=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}};
`,fm=Jr.form`
  display: flex;
  flex-direction: column;
  gap: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,gm=Jr.div`
  display: flex;
  justify-content: center;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
`,ym=Jr.div`
  width: 30px;
  height: 30px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: ${e=>{let{theme:t,active:n,completed:r}=e;return r?t.colors.success:n?t.colors.primary:t.colors.border}};
  color: ${e=>{let{theme:t,active:n,completed:r}=e;return n||r?"white":t.colors.textSecondary}};
  margin: 0 ${e=>{let{theme:t}=e;return t.spacing.sm}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  transition: all 0.3s ease;
`,xm=Jr.div`
  flex: 1;
  height: 2px;
  background: ${e=>{let{theme:t,completed:n}=e;return n?t.colors.success:t.colors.border}};
  margin: 14px 0;
  transition: all 0.3s ease;
`,vm=Jr.div`
  display: flex;
  flex-direction: column;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
`,bm=Jr.label`
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,wm=Jr.div`
  position: relative;
`,km=Jr.input`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding-left: 40px;
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  transition: all 0.2s ease;
  box-sizing: border-box;
  
  &:focus {
    outline: none;
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    box-shadow: 0 0 0 3px ${e=>{let{theme:t}=e;return t.colors.primary}}20;
  }
`,Sm=Jr.div`
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  
  svg {
    width: 16px;
    height: 16px;
  }
`,jm=Jr.button`
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  cursor: pointer;
  
  svg {
    width: 16px;
    height: 16px;
  }
`,$m=Jr.div`
  display: flex;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  margin-top: ${e=>{let{theme:t}=e;return t.spacing.xl}};
`,Cm=Jr(dh.button)`
  flex: 1;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  cursor: pointer;
  transition: all 0.2s ease;
  
  ${e=>{let{theme:t,variant:n="primary"}=e;return"primary"===n?`\n        background: ${t.colors.gradient};\n        color: white;\n        &:hover {\n          transform: translateY(-2px);\n          box-shadow: ${t.createShadow(2,t)};\n        }\n      `:`\n        background: ${t.colors.backgroundSecondary};\n        color: ${t.colors.text};\n        border: 1px solid ${t.colors.border};\n        &:hover {\n          background: ${t.colors.border};\n        }\n      `}}
`,Em=Jr.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  border: 2px dashed ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    background: ${e=>{let{theme:t}=e;return t.colors.primary}}10;
  }
`,Tm=Jr.img`
  width: 80px;
  height: 80px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid ${e=>{let{theme:t}=e;return t.colors.primary}};
`,Pm=Jr.div`
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 2rem;
`,zm=t=>{let{isOpen:n,onClose:r,onRegister:i}=t;const[o,a]=(0,e.useState)(1),[s,l]=(0,e.useState)({firstName:"",lastName:"",email:"",password:"",confirmPassword:"",phone:"",dateOfBirth:"",location:"",avatar:null}),[c,u]=(0,e.useState)(!1),[d,h]=(0,e.useState)(!1),[p,m]=(0,e.useState)(null),f=e=>{const{name:t,value:n}=e.target;l(e=>({...e,[t]:n}))},g=e=>{var t;const n=null===(t=e.target.files)||void 0===t?void 0:t[0];if(n){l(e=>({...e,avatar:n}));const e=new FileReader;e.onload=e=>{var t;m(null===(t=e.target)||void 0===t?void 0:t.result)},e.readAsDataURL(n)}};return(0,ti.jsx)(yi,{children:n&&(0,ti.jsx)(cm,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:r,children:(0,ti.jsxs)(um,{initial:{scale:.8,opacity:0},animate:{scale:1,opacity:1},exit:{scale:.8,opacity:0},transition:{type:"spring",damping:20,stiffness:300},onClick:e=>e.stopPropagation(),children:[(0,ti.jsxs)(dm,{children:[(0,ti.jsx)(hm,{children:"Join Astra"}),(0,ti.jsx)(pm,{onClick:r,children:(0,ti.jsx)(Th,{size:24})})]}),(0,ti.jsxs)(mm,{children:[(0,ti.jsxs)(gm,{children:[(0,ti.jsx)(ym,{active:1===o,completed:o>1,children:"1"}),(0,ti.jsx)(xm,{completed:o>1}),(0,ti.jsx)(ym,{active:2===o,completed:o>2,children:"2"}),(0,ti.jsx)(xm,{completed:o>2}),(0,ti.jsx)(ym,{active:3===o,completed:!1,children:"3"})]}),(0,ti.jsxs)(fm,{onSubmit:e=>{e.preventDefault(),3===o?(i(s),r()):o<3&&a(e=>e+1)},children:[(0,ti.jsx)(dh.div,{initial:{x:20,opacity:0},animate:{x:0,opacity:1},transition:{duration:.3},children:(()=>{switch(o){case 1:return(0,ti.jsxs)(ti.Fragment,{children:[(0,ti.jsxs)(vm,{children:[(0,ti.jsx)(bm,{children:"First Name"}),(0,ti.jsxs)(wm,{children:[(0,ti.jsx)(Sm,{children:(0,ti.jsx)(mp,{})}),(0,ti.jsx)(km,{name:"firstName",value:s.firstName,onChange:f,placeholder:"Enter your first name",required:!0})]})]}),(0,ti.jsxs)(vm,{children:[(0,ti.jsx)(bm,{children:"Last Name"}),(0,ti.jsxs)(wm,{children:[(0,ti.jsx)(Sm,{children:(0,ti.jsx)(mp,{})}),(0,ti.jsx)(km,{name:"lastName",value:s.lastName,onChange:f,placeholder:"Enter your last name",required:!0})]})]}),(0,ti.jsxs)(vm,{children:[(0,ti.jsx)(bm,{children:"Email"}),(0,ti.jsxs)(wm,{children:[(0,ti.jsx)(Sm,{children:(0,ti.jsx)(nm,{})}),(0,ti.jsx)(km,{type:"email",name:"email",value:s.email,onChange:f,placeholder:"Enter your email",required:!0})]})]})]});case 2:return(0,ti.jsxs)(ti.Fragment,{children:[(0,ti.jsxs)(vm,{children:[(0,ti.jsx)(bm,{children:"Password"}),(0,ti.jsxs)(wm,{children:[(0,ti.jsx)(Sm,{children:(0,ti.jsx)(rm,{})}),(0,ti.jsx)(km,{type:c?"text":"password",name:"password",value:s.password,onChange:f,placeholder:"Create a password",required:!0}),(0,ti.jsx)(jm,{type:"button",onClick:()=>u(!c),children:c?(0,ti.jsx)(im,{}):(0,ti.jsx)(om,{})})]})]}),(0,ti.jsxs)(vm,{children:[(0,ti.jsx)(bm,{children:"Confirm Password"}),(0,ti.jsxs)(wm,{children:[(0,ti.jsx)(Sm,{children:(0,ti.jsx)(rm,{})}),(0,ti.jsx)(km,{type:d?"text":"password",name:"confirmPassword",value:s.confirmPassword,onChange:f,placeholder:"Confirm your password",required:!0}),(0,ti.jsx)(jm,{type:"button",onClick:()=>h(!d),children:d?(0,ti.jsx)(im,{}):(0,ti.jsx)(om,{})})]})]}),(0,ti.jsxs)(vm,{children:[(0,ti.jsx)(bm,{children:"Phone Number"}),(0,ti.jsxs)(wm,{children:[(0,ti.jsx)(Sm,{children:(0,ti.jsx)(xp,{})}),(0,ti.jsx)(km,{type:"tel",name:"phone",value:s.phone,onChange:f,placeholder:"Enter your phone number"})]})]})]});case 3:return(0,ti.jsxs)(ti.Fragment,{children:[(0,ti.jsxs)(vm,{children:[(0,ti.jsx)(bm,{children:"Date of Birth"}),(0,ti.jsxs)(wm,{children:[(0,ti.jsx)(Sm,{children:(0,ti.jsx)(am,{})}),(0,ti.jsx)(km,{type:"date",name:"dateOfBirth",value:s.dateOfBirth,onChange:f})]})]}),(0,ti.jsxs)(vm,{children:[(0,ti.jsx)(bm,{children:"Location"}),(0,ti.jsxs)(wm,{children:[(0,ti.jsx)(Sm,{children:(0,ti.jsx)(sm,{})}),(0,ti.jsx)(km,{name:"location",value:s.location,onChange:f,placeholder:"Enter your location"})]})]}),(0,ti.jsxs)(vm,{children:[(0,ti.jsx)(bm,{children:"Profile Picture"}),(0,ti.jsxs)(Em,{onClick:()=>{var e;return null===(e=document.getElementById("avatar-input"))||void 0===e?void 0:e.click()},children:[p?(0,ti.jsx)(Tm,{src:p,alt:"Avatar preview"}):(0,ti.jsx)(Pm,{children:(0,ti.jsx)(lm,{})}),(0,ti.jsx)("p",{children:"Click to upload your profile picture"}),(0,ti.jsx)("input",{id:"avatar-input",type:"file",accept:"image/*",onChange:g,style:{display:"none"}})]})]})]});default:return null}})()},o),(0,ti.jsxs)($m,{children:[o>1&&(0,ti.jsx)(Cm,{type:"button",variant:"secondary",onClick:()=>{o>1&&a(e=>e-1)},whileHover:{scale:1.02},whileTap:{scale:.98},children:"Previous"}),(0,ti.jsx)(Cm,{type:"submit",whileHover:{scale:1.02},whileTap:{scale:.98},children:3===o?"Create Account":"Next"})]})]})]})]})})})},Am=Si("skip-back",[["polygon",{points:"19 20 9 12 19 4 19 20",key:"o2sva"}],["line",{x1:"5",x2:"5",y1:"19",y2:"5",key:"1ocqjk"}]]),Rm=Si("pause",[["rect",{x:"14",y:"4",width:"4",height:"16",rx:"1",key:"zuxfzm"}],["rect",{x:"6",y:"4",width:"4",height:"16",rx:"1",key:"1okwgv"}]]),Mm=Si("skip-forward",[["polygon",{points:"5 4 15 12 5 20 5 4",key:"16p6eg"}],["line",{x1:"19",x2:"19",y1:"5",y2:"19",key:"futhcm"}]]),Lm=Si("volume-2",[["path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",key:"uqj9uw"}],["path",{d:"M16 9a5 5 0 0 1 0 6",key:"1q6k2b"}],["path",{d:"M19.364 18.364a9 9 0 0 0 0-12.728",key:"ijwkga"}]]),Dm=(0,e.createContext)(void 0),Om=()=>{const t=(0,e.useContext)(Dm);if(!t)throw new Error("useMusicPlayer must be used within a MusicPlayerProvider");return t},Fm=t=>{let{children:n}=t;const[r,i]=(0,e.useState)(null),[o,a]=(0,e.useState)(!1),[s,l]=(0,e.useState)(.7),[c,u]=(0,e.useState)(0),[d,h]=(0,e.useState)(0),[p,m]=(0,e.useState)([]),f=(0,e.useRef)(null),g=e=>{i(e),a(!0),f.current&&(e.url?(f.current.src=e.url,f.current.load(),f.current.play().catch(console.error)):(f.current.src="https://www.soundjay.com/misc/sounds/clock-ticking-5.wav",f.current.load(),f.current.play().catch(console.error)))},y=()=>{if(r&&p.length>0){const e=(p.findIndex(e=>e.id===r.id)+1)%p.length;g(p[e])}};return(0,ti.jsxs)(Dm.Provider,{value:{currentTrack:r,isPlaying:o,volume:s,currentTime:c,duration:d,playTrack:g,pauseTrack:()=>{a(!1),f.current&&f.current.pause()},resumeTrack:()=>{a(!0),f.current&&f.current.play()},nextTrack:y,previousTrack:()=>{if(r&&p.length>0){const e=(p.findIndex(e=>e.id===r.id)-1+p.length)%p.length;g(p[e])}},setVolume:e=>{l(e),f.current&&(f.current.volume=e)},setCurrentTime:u,playlist:p,addToPlaylist:e=>{m(t=>[...t,e])},removeFromPlaylist:e=>{m(t=>t.filter(t=>t.id!==e))},clearPlaylist:()=>{m([])}},children:[n,(0,ti.jsx)("audio",{ref:f,onTimeUpdate:e=>u(e.currentTarget.currentTime),onLoadedMetadata:e=>h(e.currentTarget.duration),onEnded:y})]})},Nm=Jr(dh.div)`
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-top: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  padding: 12px 20px;
  display: flex;
  align-items: center;
  gap: 16px;
  z-index: 1000;
  backdrop-filter: blur(10px);
`,_m=Jr.div`
  flex: 1;
  min-width: 0;
`,Im=Jr.h4`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  margin: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`,Vm=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
  margin: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`,Bm=Jr.div`
  display: flex;
  align-items: center;
  gap: 12px;
`,Wm=Jr(dh.button)`
  background: none;
  border: none;
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  cursor: pointer;
  padding: 8px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.2s;

  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  }
`,Hm=Jr(Wm)`
  background: ${e=>{let{theme:t}=e;return t.colors.primary}};
  color: white;

  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.primary}};
    opacity: 0.8;
  }
`,Um=Jr.div`
  flex: 1;
  margin: 0 16px;
`,qm=Jr.div`
  width: 100%;
  height: 4px;
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  border-radius: 2px;
  overflow: hidden;
  cursor: pointer;
`,Ym=Jr.div`
  height: 100%;
  width: ${e=>{let{progress:t}=e;return t}}%;
  background: ${e=>{let{theme:t}=e;return t.colors.primary}};
  transition: width 0.1s;
`,Km=Jr.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,Gm=Jr.input`
  width: 80px;
  height: 4px;
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  outline: none;
  border-radius: 2px;
  
  &::-webkit-slider-thumb {
    appearance: none;
    width: 16px;
    height: 16px;
    background: ${e=>{let{theme:t}=e;return t.colors.primary}};
    border-radius: 50%;
    cursor: pointer;
  }
  
  &::-moz-range-thumb {
    width: 16px;
    height: 16px;
    background: ${e=>{let{theme:t}=e;return t.colors.primary}};
    border-radius: 50%;
    cursor: pointer;
    border: none;
  }
`,Xm=Jr.span`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
  min-width: 40px;
`,Qm=()=>{const{currentTrack:e,isPlaying:t,volume:n,currentTime:r,duration:i,playTrack:o,pauseTrack:a,resumeTrack:s,nextTrack:l,previousTrack:c,setVolume:u}=Om(),d=e=>`${Math.floor(e/60)}:${Math.floor(e%60).toString().padStart(2,"0")}`;return e?(0,ti.jsx)(yi,{children:(0,ti.jsxs)(Nm,{initial:{y:100},animate:{y:0},exit:{y:100},transition:{type:"spring",stiffness:300,damping:30},children:[(0,ti.jsxs)(_m,{children:[(0,ti.jsx)(Im,{children:e.title}),(0,ti.jsx)(Vm,{children:e.artist})]}),(0,ti.jsxs)(Bm,{children:[(0,ti.jsx)(Wm,{onClick:c,whileHover:{scale:1.1},whileTap:{scale:.9},children:(0,ti.jsx)(Am,{size:20})}),(0,ti.jsx)(Hm,{onClick:t?a:s,whileHover:{scale:1.1},whileTap:{scale:.9},children:t?(0,ti.jsx)(Rm,{size:20}):(0,ti.jsx)(hp,{size:20})}),(0,ti.jsx)(Wm,{onClick:l,whileHover:{scale:1.1},whileTap:{scale:.9},children:(0,ti.jsx)(Mm,{size:20})})]}),(0,ti.jsx)(Um,{children:(0,ti.jsx)(qm,{onClick:e=>{const t=e.currentTarget.getBoundingClientRect(),n=(e.clientX-t.left)/t.width;console.log("Seeking to:",n*i)},children:(0,ti.jsx)(Ym,{progress:r/i*100||0})})}),(0,ti.jsx)(Xm,{children:d(r)}),(0,ti.jsx)(Xm,{children:d(i)}),(0,ti.jsxs)(Km,{children:[(0,ti.jsx)(Lm,{size:16}),(0,ti.jsx)(Gm,{type:"range",min:"0",max:"1",step:"0.1",value:n,onChange:e=>u(Number(e.target.value))})]})]})}):null},Jm=(function(t){for(var n=[],r=1;r<arguments.length;r++)n[r-1]=arguments[r];var i=Gr.apply(void 0,ct([t],n,!1)),o="sc-global-".concat(Mn(JSON.stringify(i))),a=new Zr(i,o),s=function(t){var n=Rr(),r=e.useContext(Wr),i=e.useRef(n.styleSheet.allocateGSInstance(o)).current;return n.styleSheet.server&&l(i,t,n.styleSheet,r,n.stylis),e.useLayoutEffect(function(){if(!n.styleSheet.server)return l(i,t,n.styleSheet,r,n.stylis),function(){return a.removeStyles(i,n.styleSheet)}},[i,t,n.styleSheet,r,n.stylis]),null};function l(e,t,n,r,i){if(a.isStatic)a.renderStyles(e,vn,n,i);else{var o=lt(lt({},t),{theme:kn(t,r,s.defaultProps)});a.renderStyles(e,o,n,i)}}return e.memo(s)})`
  *, *::before, *::after {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    background-color: ${e=>{let{theme:t}=e;return t.colors.background}};
    color: ${e=>{let{theme:t}=e;return t.colors.text}};
    transition: background-color 0.3s, color 0.3s;
    line-height: 1.5;
  }

  a {
    text-decoration: none;
    color: inherit;
  }
  
  ul, ol {
    list-style: none;
  }

  img {
    max-width: 100%;
    height: auto;
  }
`,Zm=(0,e.createContext)(void 0),ef=()=>{const t=(0,e.useContext)(Zm);if(!t)throw new Error("useMultimedia must be used within a MultimediaProvider");return t},tf=t=>{let{children:n}=t;const[r,i]=(0,e.useState)([]),[o,a]=(0,e.useState)([]),[s,l]=(0,e.useState)([]),[c,u]=(0,e.useState)(null),[d,h]=(0,e.useState)(null),[p,m]=(0,e.useState)(!1),[f,g]=(0,e.useState)(!1),[y,x]=(0,e.useState)(50);(0,e.useEffect)(()=>{(async()=>{try{const e=[{id:"1",type:"video",src:"/src/assets/Vids/sample-video-1.mp4",title:"Amazing Nature Documentary",duration:180,thumbnail:"/src/assets/Vids/thumbs/video-1-thumb.jpg",description:"A breathtaking journey through nature",tags:["nature","documentary","wildlife"],createdAt:new Date("2024-01-01"),views:1500,likes:245},{id:"2",type:"video",src:"/src/assets/Vids/sample-video-2.mp4",title:"Tech Innovation Showcase",duration:240,thumbnail:"/src/assets/Vids/thumbs/video-2-thumb.jpg",description:"Latest innovations in technology",tags:["tech","innovation","future"],createdAt:new Date("2024-01-02"),views:2300,likes:456},{id:"3",type:"video",src:"/src/assets/Vids/sample-video-3.mp4",title:"Cooking Masterclass",duration:300,thumbnail:"/src/assets/Vids/thumbs/video-3-thumb.jpg",description:"Learn to cook like a professional chef",tags:["cooking","food","tutorial"],createdAt:new Date("2024-01-03"),views:3200,likes:678}],t=[{id:"4",type:"audio",src:"/src/assets/Vids/sample-audio-1.mp3",title:"Chill Vibes",artist:"Relaxation Studio",duration:210,thumbnail:"/src/assets/Vids/thumbs/audio-1-thumb.jpg",description:"Perfect for relaxation and focus",tags:["chill","ambient","relaxation"],createdAt:new Date("2024-01-04"),views:5600,likes:892},{id:"5",type:"audio",src:"/src/assets/Vids/sample-audio-2.mp3",title:"Epic Motivation",artist:"Power Beats",duration:195,thumbnail:"/src/assets/Vids/thumbs/audio-2-thumb.jpg",description:"Get motivated and energized",tags:["motivation","energy","workout"],createdAt:new Date("2024-01-05"),views:4200,likes:734},{id:"6",type:"audio",src:"/src/assets/Vids/sample-audio-3.mp3",title:"Jazz Evening",artist:"Smooth Jazz Collective",duration:280,thumbnail:"/src/assets/Vids/thumbs/audio-3-thumb.jpg",description:"Smooth jazz for evening relaxation",tags:["jazz","smooth","evening"],createdAt:new Date("2024-01-06"),views:3800,likes:567}],n=[{id:"7",type:"video",src:"/src/assets/Vids/reel-1.mp4",title:"Quick Life Hack",duration:15,thumbnail:"/src/assets/Vids/thumbs/reel-1-thumb.jpg",description:"Amazing life hack in 15 seconds",tags:["lifehack","quick","tips"],createdAt:new Date("2024-01-07"),views:12e3,likes:2340},{id:"8",type:"video",src:"/src/assets/Vids/reel-2.mp4",title:"Dance Challenge",duration:30,thumbnail:"/src/assets/Vids/thumbs/reel-2-thumb.jpg",description:"Latest dance trend",tags:["dance","challenge","trending"],createdAt:new Date("2024-01-08"),views:8500,likes:1890}];i(e),a(t),l(n)}catch(e){console.error("Error initializing media:",e)}})()},[]);const v={videos:r,audios:o,reels:s,currentPlayingVideo:c,currentPlayingAudio:d,isPlaying:p,isMuted:f,volume:y,setCurrentPlayingVideo:u,setCurrentPlayingAudio:h,togglePlay:()=>{m(!p)},toggleMute:()=>{g(!f)},setVolume:x,addToPlaylist:e=>{console.log("Adding to playlist:",e)},removeFromPlaylist:e=>{console.log("Removing from playlist:",e)},getMediaByType:e=>"video"===e?r:o,searchMedia:e=>[...r,...o,...s].filter(t=>{var n,r;return t.title.toLowerCase().includes(e.toLowerCase())||(null===(n=t.description)||void 0===n?void 0:n.toLowerCase().includes(e.toLowerCase()))||(null===(r=t.tags)||void 0===r?void 0:r.some(t=>t.toLowerCase().includes(e.toLowerCase())))}),getRecommendations:e=>[...r,...o,...s].filter(t=>t.id!==e.id).filter(t=>{var n;return(null===(n=t.tags)||void 0===n?void 0:n.some(t=>{var n;return null===(n=e.tags)||void 0===n?void 0:n.includes(t)}))||t.type===e.type}).slice(0,6)};return(0,ti.jsx)(Zm.Provider,{value:v,children:n})},nf={theme:"light",language:"en",notifications:{push:!0,email:!0,sms:!1},privacy:{profileVisible:!0,activityTracking:!1,dataCollection:!1},feed:{layout:"grid",content:"trending"}},rf=(0,e.createContext)(void 0),of=()=>{const t=(0,e.useContext)(rf);if(!t)throw new Error("usePreferences must be used within a PreferencesProvider");return t},af=t=>{let{children:n}=t;const[r,i]=(0,e.useState)(nf);(0,e.useEffect)(()=>{const e=localStorage.getItem("astra-preferences");e&&i(JSON.parse(e))},[]),(0,e.useEffect)(()=>{localStorage.setItem("astra-preferences",JSON.stringify(r))},[r]);return(0,ti.jsx)(rf.Provider,{value:{preferences:r,setTheme:e=>{i(t=>({...t,theme:e}))},setLanguage:e=>{i(t=>({...t,language:e}))},updateNotifications:e=>{i(t=>({...t,notifications:{...t.notifications,...e}}))},updatePrivacy:e=>{i(t=>({...t,privacy:{...t.privacy,...e}}))},updateFeed:e=>{i(t=>({...t,feed:{...t.feed,...e}}))}},children:n})},sf={balance:0,totalEarnings:0,pendingBalance:0,transactions:[],linkedAccounts:{paypal:!1,bank:!1,crypto:!1}},lf=(0,e.createContext)(void 0),cf=t=>{let{children:n}=t;const[r,i]=(0,e.useState)(sf);(0,e.useEffect)(()=>{const e=localStorage.getItem("astra-wallet");if(e){const t=JSON.parse(e);t.transactions=t.transactions.map(e=>({...e,date:new Date(e.date)})),i(t)}},[]),(0,e.useEffect)(()=>{localStorage.setItem("astra-wallet",JSON.stringify(r))},[r]);return(0,ti.jsx)(lf.Provider,{value:{wallet:r,addTransaction:e=>{const t={...e,id:Date.now().toString()};i(n=>{const r="income"===e.type?n.balance+e.amount:n.balance-e.amount,i="income"===e.type?n.totalEarnings+e.amount:n.totalEarnings;return{...n,balance:r,totalEarnings:i,transactions:[t,...n.transactions]}})},withdrawFunds:(e,t)=>{if(r.balance<e)throw new Error("Insufficient funds");const n={id:Date.now().toString(),type:"expense",amount:e,description:`Withdrawal to ${t}`,category:"other",date:new Date,status:"pending"};i(t=>({...t,balance:t.balance-e,pendingBalance:t.pendingBalance+e,transactions:[n,...t.transactions]})),setTimeout(()=>{i(t=>({...t,pendingBalance:t.pendingBalance-e,transactions:t.transactions.map(e=>e.id===n.id?{...e,status:"completed"}:e)}))},3e3)},linkAccount:e=>{i(t=>({...t,linkedAccounts:{...t.linkedAccounts,[e]:!0}}))},unlinkAccount:e=>{i(t=>({...t,linkedAccounts:{...t.linkedAccounts,[e]:!1}}))}},children:n})},uf=(0,e.createContext)(void 0),df=t=>{let{children:n}=t;const[r,i]=(0,e.useState)([]),[o,a]=(0,e.useState)([]),[s,l]=(0,e.useState)([]),[c,u]=(0,e.useState)([]),[d,h]=(0,e.useState)(new Map),[p,m]=(0,e.useState)(!1),[f,g]=(0,e.useState)(null);(0,e.useEffect)(()=>{y()},[]);const y=()=>{const e=[{id:"1",name:"Alice Johnson",username:"@alice",avatar:"/avatars/alice.jpg",verified:!0,isOnline:!0,bio:"Designer & Creative",location:"New York, NY",mutualFriends:12,followersCount:1250,followingCount:845,postsCount:167},{id:"2",name:"Bob Smith",username:"@bob",avatar:"/avatars/bob.jpg",verified:!1,isOnline:!0,bio:"Developer & Gamer",location:"San Francisco, CA",mutualFriends:8,followersCount:890,followingCount:634,postsCount:234},{id:"3",name:"Carol Davis",username:"@carol",avatar:"/avatars/carol.jpg",verified:!0,isOnline:!1,lastSeen:new Date(Date.now()-18e5),bio:"Photographer & Traveler",location:"Los Angeles, CA",mutualFriends:5,followersCount:2100,followingCount:456,postsCount:89},{id:"4",name:"David Wilson",username:"@david",avatar:"/avatars/david.jpg",verified:!1,isOnline:!0,bio:"Music Producer",location:"Nashville, TN",mutualFriends:3,followersCount:567,followingCount:234,postsCount:78},{id:"5",name:"Eva Martinez",username:"@eva",avatar:"/avatars/eva.jpg",verified:!0,isOnline:!1,lastSeen:new Date(Date.now()-72e5),bio:"Fitness Coach",location:"Miami, FL",mutualFriends:7,followersCount:3400,followingCount:123,postsCount:456}],t=[...e,{id:"6",name:"Frank Brown",username:"@frank",avatar:"/avatars/frank.jpg",verified:!1,isOnline:!1,bio:"Writer & Blogger",location:"Chicago, IL",mutualFriends:2,followersCount:789,followingCount:456,postsCount:234},{id:"7",name:"Grace Lee",username:"@grace",avatar:"/avatars/grace.jpg",verified:!0,isOnline:!0,bio:"Marketing Manager",location:"Seattle, WA",mutualFriends:9,followersCount:1567,followingCount:890,postsCount:345}],n=[...e.slice(0,3),{id:"8",name:"Henry Clark",username:"@henry",avatar:"/avatars/henry.jpg",verified:!1,isOnline:!0,bio:"Chef & Food Lover",location:"Portland, OR",mutualFriends:4,followersCount:2300,followingCount:567,postsCount:123}],r=[{id:"req1",from:{id:"9",name:"Isabella Rodriguez",username:"@isabella",avatar:"/avatars/isabella.jpg",verified:!1,isOnline:!0,bio:"Artist & Designer",location:"Austin, TX",mutualFriends:6,followersCount:1890,followingCount:456,postsCount:89},to:{id:"current-user",name:"Current User",username:"@current",avatar:"/avatars/current.jpg",verified:!0,isOnline:!0},createdAt:new Date(Date.now()-864e5),status:"pending"},{id:"req2",from:{id:"10",name:"Jack Thompson",username:"@jack",avatar:"/avatars/jack.jpg",verified:!0,isOnline:!1,bio:"Entrepreneur",location:"Denver, CO",mutualFriends:11,followersCount:5600,followingCount:234,postsCount:567},to:{id:"current-user",name:"Current User",username:"@current",avatar:"/avatars/current.jpg",verified:!0,isOnline:!0},createdAt:new Date(Date.now()-216e5),status:"pending"}],o=new Map;e.forEach(e=>{o.set(e.id,{userId:e.id,isFollowing:!0,isFollower:!0,isMutualFollowing:!0,isFriend:!0,createdAt:new Date(Date.now()-1e3*Math.random()*60*60*24*30)})}),t.forEach(e=>{o.has(e.id)||o.set(e.id,{userId:e.id,isFollowing:!1,isFollower:!0,isMutualFollowing:!1,isFriend:!1,createdAt:new Date(Date.now()-1e3*Math.random()*60*60*24*30)})}),n.forEach(e=>{o.has(e.id)||o.set(e.id,{userId:e.id,isFollowing:!0,isFollower:!1,isMutualFollowing:!1,isFriend:!1,createdAt:new Date(Date.now()-1e3*Math.random()*60*60*24*30)})}),i(e),a(t),l(n),u(r),h(o)},x=r.filter(e=>e.isOnline),v={friends:r,onlineFriends:x,followers:o,following:s,friendRequests:c,getRelationship:e=>d.get(e)||null,isFollowing:e=>{var t;return(null===(t=d.get(e))||void 0===t?void 0:t.isFollowing)||!1},isFollower:e=>{var t;return(null===(t=d.get(e))||void 0===t?void 0:t.isFollower)||!1},isMutualFollowing:e=>{var t;return(null===(t=d.get(e))||void 0===t?void 0:t.isMutualFollowing)||!1},isFriend:e=>{var t;return(null===(t=d.get(e))||void 0===t?void 0:t.isFriend)||!1},followUser:async e=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,500));const t=d.get(e),n={userId:e,isFollowing:!0,isFollower:(null===t||void 0===t?void 0:t.isFollower)||!1,isMutualFollowing:(null===t||void 0===t?void 0:t.isFollower)||!1,isFriend:(null===t||void 0===t?void 0:t.isFriend)||!1,createdAt:(null===t||void 0===t?void 0:t.createdAt)||new Date};h(t=>new Map(t).set(e,n));const i=[...o,...r].find(t=>t.id===e);i&&!s.some(t=>t.id===e)&&l(e=>[...e,i])}catch(t){g("Failed to follow user")}finally{m(!1)}},unfollowUser:async e=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,500));const t=d.get(e);if(t){const n={...t,isFollowing:!1,isMutualFollowing:!1};h(t=>new Map(t).set(e,n)),l(t=>t.filter(t=>t.id!==e))}}catch(t){g("Failed to unfollow user")}finally{m(!1)}},sendFriendRequest:async e=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,500)),console.log(`Friend request sent to user ${e}`)}catch(t){g("Failed to send friend request")}finally{m(!1)}},acceptFriendRequest:async e=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,500));const t=c.find(t=>t.id===e);if(t){i(e=>[...e,t.from]);const n={userId:t.from.id,isFollowing:!0,isFollower:!0,isMutualFollowing:!0,isFriend:!0,createdAt:new Date};h(e=>new Map(e).set(t.from.id,n)),u(t=>t.filter(t=>t.id!==e))}}catch(t){g("Failed to accept friend request")}finally{m(!1)}},rejectFriendRequest:async e=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,500)),u(t=>t.filter(t=>t.id!==e))}catch(t){g("Failed to reject friend request")}finally{m(!1)}},removeFriend:async e=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,500)),i(t=>t.filter(t=>t.id!==e));const t=d.get(e);if(t){const n={...t,isFriend:!1,isFollowing:!1,isMutualFollowing:!1};h(t=>new Map(t).set(e,n))}}catch(t){g("Failed to remove friend")}finally{m(!1)}},blockUser:async e=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,500)),i(t=>t.filter(t=>t.id!==e)),a(t=>t.filter(t=>t.id!==e)),l(t=>t.filter(t=>t.id!==e)),u(t=>t.filter(t=>t.from.id!==e)),h(t=>{const n=new Map(t);return n.delete(e),n})}catch(t){g("Failed to block user")}finally{m(!1)}},unblockUser:async e=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,500)),console.log(`User ${e} unblocked`)}catch(t){g("Failed to unblock user")}finally{m(!1)}},searchUsers:async e=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,300));const t=[...r,...o,...s];return Array.from(new Map(t.map(e=>[e.id,e])).values()).filter(t=>{var n;return t.name.toLowerCase().includes(e.toLowerCase())||t.username.toLowerCase().includes(e.toLowerCase())||(null===(n=t.bio)||void 0===n?void 0:n.toLowerCase().includes(e.toLowerCase()))})}catch(t){return g("Failed to search users"),[]}finally{m(!1)}},getSuggestedUsers:async()=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,500));return[{id:"suggested1",name:"Maya Patel",username:"@maya",avatar:"/avatars/maya.jpg",verified:!1,isOnline:!0,bio:"UX Designer",location:"San Diego, CA",mutualFriends:15,followersCount:3400,followingCount:890,postsCount:234},{id:"suggested2",name:"Alex Chen",username:"@alex",avatar:"/avatars/alex.jpg",verified:!0,isOnline:!1,bio:"Software Engineer",location:"Boston, MA",mutualFriends:12,followersCount:1200,followingCount:567,postsCount:89}]}catch(e){return g("Failed to get suggested users"),[]}finally{m(!1)}},getMutualFriends:async e=>{m(!0),g(null);try{await new Promise(e=>setTimeout(e,300));return r.slice(0,Math.floor(3*Math.random())+1)}catch(t){return g("Failed to get mutual friends"),[]}finally{m(!1)}},isLoading:p,error:f};return(0,ti.jsx)(uf.Provider,{value:v,children:n})},hf=Si("shopping-cart",[["circle",{cx:"8",cy:"21",r:"1",key:"jimo8o"}],["circle",{cx:"19",cy:"21",r:"1",key:"13723u"}],["path",{d:"M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",key:"9zh506"}]]),pf=Si("sparkles",[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]]),mf=Si("crown",[["path",{d:"M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z",key:"1vdc57"}],["path",{d:"M5 21h14",key:"11awu3"}]]),ff=Si("zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]]),gf=Si("gift",[["rect",{x:"3",y:"8",width:"18",height:"4",rx:"1",key:"bkv52"}],["path",{d:"M12 8v13",key:"1c76mn"}],["path",{d:"M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7",key:"6wjy6b"}],["path",{d:"M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5",key:"1ihvrl"}]]),yf=Si("coins",[["circle",{cx:"8",cy:"8",r:"6",key:"3yglwk"}],["path",{d:"M18.09 10.37A6 6 0 1 1 10.34 18",key:"t5s6rm"}],["path",{d:"M7 6h1v4",key:"1obek4"}],["path",{d:"m16.71 13.88.7.71-2.82 2.82",key:"1rbuyh"}]]),xf=Si("star",[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]]),vf=Si("circle-check-big",[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]]),bf=Si("circle-alert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]),wf=Si("circle-x",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]]),kf=Si("info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]),Sf=Jr(dh.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: ${e=>{let{theme:t}=e;return t.zIndex.modal}};
  backdrop-filter: blur(3px);
`,jf=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  width: 90%;
  max-width: 400px;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(5,t)}};
  overflow: hidden;
  position: relative;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: ${e=>{let{theme:t,type:n}=e;switch(n){case"success":return t.colors.success;case"warning":return t.colors.warning;case"error":return t.colors.error;default:return t.colors.primary}}};
  }
`,$f=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  padding-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
  display: flex;
  align-items: center;
  justify-content: space-between;
`,Cf=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  color: ${e=>{let{theme:t,type:n}=e;switch(n){case"success":return t.colors.success;case"warning":return t.colors.warning;case"error":return t.colors.error;default:return t.colors.primary}}};
`,Ef=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin: 0;
`,Tf=Jr.button`
  background: none;
  border: none;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  cursor: pointer;
  padding: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  border-radius: 50%;
  transition: all 0.2s ease;
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  }
`,Pf=Jr.div`
  padding: 0 ${e=>{let{theme:t}=e;return t.spacing.lg}};
  padding-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,zf=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  line-height: 1.5;
  margin: 0 0 ${e=>{let{theme:t}=e;return t.spacing.lg}} 0;
`,Af=Jr(dh.button)`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  cursor: pointer;
  
  &:hover {
    transform: translateY(-1px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  }
`,Rf=e=>{let{isOpen:t,onClose:n,type:r,title:i,message:o,onAction:a,actionText:s}=e;return(0,ti.jsx)(yi,{children:t&&(0,ti.jsx)(Sf,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:n,children:(0,ti.jsxs)(jf,{type:r,initial:{scale:.8,opacity:0},animate:{scale:1,opacity:1},exit:{scale:.8,opacity:0},transition:{type:"spring",damping:20,stiffness:300},onClick:e=>e.stopPropagation(),children:[(0,ti.jsxs)($f,{children:[(0,ti.jsxs)(Cf,{type:r,children:[(()=>{switch(r){case"success":return(0,ti.jsx)(vf,{size:20});case"warning":return(0,ti.jsx)(bf,{size:20});case"error":return(0,ti.jsx)(wf,{size:20});default:return(0,ti.jsx)(kf,{size:20})}})(),(0,ti.jsx)(Ef,{children:i})]}),(0,ti.jsx)(Tf,{onClick:n,children:(0,ti.jsx)(Th,{size:18})})]}),(0,ti.jsxs)(Pf,{children:[(0,ti.jsx)(zf,{children:o}),a&&s&&(0,ti.jsx)(Af,{onClick:a,whileHover:{scale:1.02},whileTap:{scale:.98},children:s})]})]})})})},Mf=n.p+"static/media/img (30).2760218c1b55da0b6510.jpg",Lf=n.p+"static/media/img (31).e943e9a610a43926db6b.jpg",Df=n.p+"static/media/img (33).846e3f819090e3afbafc.jpg",Of=n.p+"static/media/img (34).6b351fca931d34910e08.jpg",Ff=n.p+"static/media/img (35).ef2ae8b57b59e87c0367.jpg",Nf=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  min-height: 80vh;
  
  @media (max-width: ${e=>{let{theme:t}=e;return t.breakpoints.md}}) {
    padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  }
`,_f=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  
  @media (max-width: ${e=>{let{theme:t}=e;return t.breakpoints.md}}) {
    flex-direction: column;
    gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  }
`,If=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin: 0;
`,Vf=Jr.div`
  position: relative;
  width: 300px;
  
  @media (max-width: ${e=>{let{theme:t}=e;return t.breakpoints.md}}) {
    width: 100%;
  }
`,Bf=Jr.input`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding-left: 40px;
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  outline: none;
  box-sizing: border-box;
  
  &:focus {
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    box-shadow: 0 0 0 3px ${e=>{let{theme:t}=e;return t.colors.primary}}20;
  }
`,Wf=Jr.div`
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
`,Hf=Jr.div`
  display: flex;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  flex-wrap: wrap;
`,Uf=Jr.button`
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}} ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  background: ${e=>{let{theme:t,active:n}=e;return n?t.colors.primary:t.colors.surface}};
  color: ${e=>{let{theme:t,active:n}=e;return n?"white":t.colors.text}};
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  &:hover {
    transform: translateY(-1px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(1,t)}};
  }
`,qf=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
`,Yf=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  overflow: hidden;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  cursor: pointer;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
`,Kf=Jr.img`
  width: 100%;
  height: 200px;
  object-fit: cover;
  transition: transform 0.3s ease;
  
  ${Yf}:hover & {
    transform: scale(1.05);
  }
`,Gf=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,Xf=Jr.div`
  position: absolute;
  top: ${e=>{let{theme:t}=e;return t.spacing.md}};
  right: ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.xs}} ${e=>{let{theme:t}=e;return t.spacing.sm}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.sm}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  color: white;
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  ${e=>{let{type:t,theme:n}=e;switch(t){case"nft":return"background: linear-gradient(45deg, #667eea, #764ba2);";case"premium":return"background: linear-gradient(45deg, #f093fb, #f5576c);";case"trending":return"background: linear-gradient(45deg, #4facfe, #00f2fe);";case"new":return"background: linear-gradient(45deg, #43e97b, #38f9d7);";default:return`background: ${n.colors.primary};`}}}
`,Qf=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin: 0 0 ${e=>{let{theme:t}=e;return t.spacing.sm}} 0;
`,Jf=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  line-height: 1.5;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Zf=Jr.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,eg=Jr.div`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
`,tg=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  color: ${e=>{let{theme:t}=e;return t.colors.warning}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,ng=Jr(dh.button)`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  }
`,rg=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  text-align: center;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    animation: shimmer 2s infinite;
  }
  
  @keyframes shimmer {
    0% { left: -100%; }
    100% { left: 100%; }
  }
`,ig=Jr.h2`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xxl}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,og=Jr.p`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  opacity: 0.9;
`,ag=Jr(dh.button)`
  background: rgba(255, 255, 255, 0.2);
  border: 2px solid white;
  color: white;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}} ${e=>{let{theme:t}=e;return t.spacing.xl}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  cursor: pointer;
  backdrop-filter: blur(10px);
  
  &:hover {
    background: white;
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,sg=()=>{const{user:t}=Ch(),[n,r]=(0,e.useState)(""),[i,o]=(0,e.useState)("all"),[a,s]=(0,e.useState)(!1),[l,c]=(0,e.useState)([]),u=[{key:"all",label:"All Products",icon:hf},{key:"nft",label:"NFTs",icon:pf},{key:"premium",label:"Premium",icon:mf},{key:"gaming",label:"Gaming",icon:ff},{key:"trending",label:"Trending",icon:dp}],d=[{id:"1",name:"Digital Art NFT Collection",description:"Exclusive digital artwork minted on the blockchain",price:2.5,currency:"ETH",image:Mf,rating:4.8,category:"nft",type:"nft",blockchain:!0},{id:"2",name:"Premium Membership",description:"Unlock exclusive features and content",price:9.99,currency:"USD",image:Lf,rating:4.9,category:"premium",type:"premium"},{id:"3",name:"Gaming Collectibles",description:"Rare in-game items and collectibles",price:.8,currency:"ETH",image:"data:image/jpeg;base64,",rating:4.6,category:"gaming",type:"trending",blockchain:!0},{id:"4",name:"Music NFT Album",description:"Limited edition music album as NFT",price:1.2,currency:"ETH",image:Df,rating:4.7,category:"music",type:"new",blockchain:!0},{id:"5",name:"Developer Tools",description:"Professional development tools and resources",price:29.99,currency:"USD",image:Of,rating:4.5,category:"tools",type:"premium"},{id:"6",name:"Virtual Real Estate",description:"Own virtual land in the metaverse",price:5,currency:"ETH",image:Ff,rating:4.4,category:"metaverse",type:"trending",blockchain:!0}].filter(e=>{const t=e.name.toLowerCase().includes(n.toLowerCase())||e.description.toLowerCase().includes(n.toLowerCase()),r="all"===i||e.category===i||e.type===i;return t&&r}),h=e=>{switch(e){case"nft":return(0,ti.jsx)(pf,{size:12});case"premium":return(0,ti.jsx)(mf,{size:12});case"trending":return(0,ti.jsx)(dp,{size:12});case"new":return(0,ti.jsx)(gf,{size:12});default:return null}};return(0,ti.jsxs)(ti.Fragment,{children:[(0,ti.jsxs)(Nf,{children:[(0,ti.jsxs)(_f,{children:[(0,ti.jsx)(If,{children:"\ud83d\udecd\ufe0f Astra Marketplace"}),(0,ti.jsxs)(Vf,{children:[(0,ti.jsx)(Wf,{children:(0,ti.jsx)(ji,{size:16})}),(0,ti.jsx)(Bf,{placeholder:"Search products...",value:n,onChange:e=>r(e.target.value)})]})]}),(0,ti.jsxs)(rg,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5},children:[(0,ti.jsx)(ig,{children:"\ud83d\ude80 Blockchain-Powered Marketplace"}),(0,ti.jsx)(og,{children:"Trade NFTs, digital assets, and premium content securely on the blockchain"}),(0,ti.jsx)(ag,{whileHover:{scale:1.05},whileTap:{scale:.95},children:"Explore Now"})]}),(0,ti.jsx)(Hf,{children:u.map(e=>{const t=e.icon;return(0,ti.jsxs)(Uf,{active:i===e.key,onClick:()=>o(e.key),children:[(0,ti.jsx)(t,{size:16}),e.label]},e.key)})}),(0,ti.jsx)(qf,{children:(0,ti.jsx)(yi,{children:d.map((e,n)=>(0,ti.jsxs)(Yf,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},exit:{opacity:0,y:-20},transition:{duration:.3,delay:.1*n},style:{position:"relative"},children:[(0,ti.jsxs)(Xf,{type:e.type,children:[h(e.type),e.type.toUpperCase()]}),(0,ti.jsx)(Kf,{src:e.image,alt:e.name}),(0,ti.jsxs)(Gf,{children:[(0,ti.jsx)(Qf,{children:e.name}),(0,ti.jsx)(Jf,{children:e.description}),(0,ti.jsxs)(Zf,{children:[(0,ti.jsxs)(eg,{children:[e.blockchain&&(0,ti.jsx)(yf,{size:16}),e.price," ",e.currency]}),(0,ti.jsxs)(tg,{children:[(0,ti.jsx)(xf,{size:14,fill:"currentColor"}),e.rating]})]}),(0,ti.jsxs)(ng,{onClick:()=>(e=>{t?console.log("Buying product:",e):s(!0)})(e),whileHover:{scale:1.02},whileTap:{scale:.98},children:[(0,ti.jsx)(hf,{size:16}),e.blockchain?"Buy with Crypto":"Buy Now"]})]})]},e.id))})})]}),(0,ti.jsx)(Rf,{isOpen:a,onClose:()=>s(!1),type:"info",title:"Sign In Required",message:"Please sign in to purchase items from the marketplace.",actionText:"Sign In",onAction:()=>{window.location.href="/login"}})]})},lg=Si("globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]),cg=Si("plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]),ug=n.p+"static/media/img (10).50a69302a9c519e5a00a.jpg",dg=n.p+"static/media/img (11).ba2b7f3b95b0e07d2109.jpg",hg=n.p+"static/media/img (12).ecc6e02ea5d742f743dc.jpg",pg=n.p+"static/media/img (13).32430fdabc3d8dc710a5.jpg",mg=n.p+"static/media/img (14).23e16030bc3d6a9505f8.jpg",fg=n.p+"static/media/img (15).faf8c848203ceda23f19.jpg",gg=n.p+"static/media/img (16).4e65f8643150e6f13d5a.jpg",yg=n.p+"static/media/img (17).5f92da046edf119fb80e.jpg",xg=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  min-height: 80vh;
`,vg=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  text-align: center;
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,bg=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  flex-wrap: wrap;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,wg=Jr.div`
  position: relative;
  flex: 1;
  max-width: 400px;
`,kg=Jr.input`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding-left: 40px;
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  outline: none;
  transition: all 0.3s ease;
  
  &:focus {
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    box-shadow: 0 0 0 3px ${e=>{let{theme:t}=e;return t.colors.primary}}20;
  }
`,Sg=Jr.div`
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
`,jg=Jr(dh.button)`
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(3,t)}};
  }
`,$g=Jr.div`
  display: flex;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  flex-wrap: wrap;
`,Cg=Jr.button`
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}} ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  background: ${e=>{let{theme:t,active:n}=e;return n?t.colors.primary:t.colors.surface}};
  color: ${e=>{let{theme:t,active:n}=e;return n?"white":t.colors.text}};
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-1px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(1,t)}};
  }
`,Eg=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,Tg=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  overflow: hidden;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  cursor: pointer;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
`,Pg=Jr.img`
  width: 100%;
  height: 200px;
  object-fit: cover;
  transition: transform 0.3s ease;
  
  ${Tg}:hover & {
    transform: scale(1.05);
  }
`,zg=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,Ag=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Rg=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin: 0;
`,Mg=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.xs}} ${e=>{let{theme:t}=e;return t.spacing.sm}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.sm}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  ${e=>{let{type:t,theme:n}=e;switch(t){case"public":return`background: ${n.colors.success}20; color: ${n.colors.success};`;case"private":return`background: ${n.colors.warning}20; color: ${n.colors.warning};`;case"premium":return`background: ${n.colors.primary}20; color: ${n.colors.primary};`;default:return""}}}
`,Lg=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  line-height: 1.5;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,Dg=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border-top: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,Og=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,Fg=Jr(dh.button)`
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}} ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  cursor: pointer;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  
  &:hover {
    transform: scale(1.05);
  }
`,Ng=()=>{const[t,n]=(0,e.useState)(""),[r,i]=(0,e.useState)("all"),o=[{id:1,name:"Tech Innovators",description:"Discover the latest in technology, AI, and innovation. Share ideas and collaborate on projects.",image:ug,members:12500,posts:3420,type:"public",category:"technology"},{id:2,name:"Digital Artists",description:"A creative space for digital artists to showcase their work and learn from each other.",image:dg,members:8750,posts:2890,type:"public",category:"art"},{id:3,name:"Crypto Traders",description:"Professional trading community focused on cryptocurrency and blockchain technology.",image:hg,members:25e3,posts:8750,type:"premium",category:"finance"},{id:4,name:"Fitness Enthusiasts",description:"Join fellow fitness lovers in sharing workout tips, nutrition advice, and motivation.",image:pg,members:15600,posts:4230,type:"public",category:"health"},{id:5,name:"Book Club Elite",description:"An exclusive community for book lovers to discuss literature and share recommendations.",image:mg,members:3200,posts:1890,type:"private",category:"books"},{id:6,name:"Travel Adventurers",description:"Share your travel experiences, get tips, and plan your next adventure with fellow travelers.",image:fg,members:22100,posts:6750,type:"public",category:"travel"},{id:7,name:"Gaming Legends",description:"Connect with gamers worldwide, share strategies, and participate in tournaments.",image:gg,members:18900,posts:9230,type:"public",category:"gaming"},{id:8,name:"Music Producers",description:"Collaborate with music producers, share beats, and get feedback on your tracks.",image:yg,members:7800,posts:3450,type:"premium",category:"music"}].filter(e=>{const n=e.name.toLowerCase().includes(t.toLowerCase())||e.description.toLowerCase().includes(t.toLowerCase()),i="all"===r||e.type===r;return n&&i}),a=e=>{switch(e){case"public":return(0,ti.jsx)(lg,{size:12});case"private":return(0,ti.jsx)(rm,{size:12});case"premium":return(0,ti.jsx)(mf,{size:12});default:return null}};return(0,ti.jsxs)(xg,{children:[(0,ti.jsx)(vg,{children:"\ud83c\udf1f Community Hub"}),(0,ti.jsxs)(bg,{children:[(0,ti.jsxs)(wg,{children:[(0,ti.jsx)(Sg,{children:(0,ti.jsx)(ji,{size:16})}),(0,ti.jsx)(kg,{type:"text",placeholder:"Search communities...",value:t,onChange:e=>n(e.target.value)})]}),(0,ti.jsxs)(jg,{whileHover:{scale:1.05},whileTap:{scale:.95},children:[(0,ti.jsx)(cg,{size:16}),"Create Community"]})]}),(0,ti.jsx)($g,{children:[{key:"all",label:"All Communities"},{key:"public",label:"Public"},{key:"private",label:"Private"},{key:"premium",label:"Premium"}].map(e=>(0,ti.jsx)(Cg,{active:r===e.key,onClick:()=>i(e.key),children:e.label},e.key))}),(0,ti.jsx)(Eg,{children:(0,ti.jsx)(yi,{children:o.map((e,t)=>(0,ti.jsxs)(Tg,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},exit:{opacity:0,y:-20},transition:{duration:.3,delay:.1*t},children:[(0,ti.jsx)(Pg,{src:e.image,alt:e.name}),(0,ti.jsxs)(zg,{children:[(0,ti.jsxs)(Ag,{children:[(0,ti.jsx)(Rg,{children:e.name}),(0,ti.jsxs)(Mg,{type:e.type,children:[a(e.type),e.type]})]}),(0,ti.jsx)(Lg,{children:e.description}),(0,ti.jsxs)(Dg,{children:[(0,ti.jsxs)(Og,{children:[(0,ti.jsx)($i,{size:16}),e.members.toLocaleString()]}),(0,ti.jsxs)(Og,{children:[(0,ti.jsx)(Ci,{size:16}),e.posts.toLocaleString()]}),(0,ti.jsx)(Fg,{whileHover:{scale:1.05},whileTap:{scale:.95},children:"Join"})]})]})]},e.id))})})]})},_g=Si("credit-card",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]]),Ig=Si("dollar-sign",[["line",{x1:"12",x2:"12",y1:"2",y2:"22",key:"7eqyqh"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",key:"1b0p4s"}]]),Vg=Si("send",[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]),Bg=Si("download",[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]]),Wg=Si("upload",[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]]),Hg=Si("chart-column",[["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["path",{d:"M18 17V9",key:"2bz60n"}],["path",{d:"M13 17V5",key:"1frdt8"}],["path",{d:"M8 17v-3",key:"17ska0"}]]),Ug=Jr.div`
  padding: 32px 24px;
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  min-height: 80vh;
`,qg=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 24px;
`,Yg=(Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  line-height: 1.6;
`,Jr.div`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 20px;
  padding: 30px;
  color: white;
  margin-bottom: 30px;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
    pointer-events: none;
  }
`),Kg=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`,Gg=Jr.h2`
  font-size: 1.5rem;
  font-weight: 600;
  margin: 0;
`,Xg=Jr.div`
  font-size: 3rem;
  font-weight: 700;
  margin-bottom: 10px;
`,Qg=Jr.p`
  opacity: 0.8;
  margin: 0;
  font-size: 1.1rem;
`,Jg=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
`,Zg=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  display: flex;
  align-items: center;
  gap: 16px;
`,ey=Jr.div`
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background: linear-gradient(45deg, #667eea, #764ba2);
  display: flex;
  align-items: center;
  justify-content: center;
  
  svg {
    width: 24px;
    height: 24px;
    color: white;
  }
`,ty=Jr.div`
  flex: 1;
  
  h3 {
    font-size: 1.8rem;
    font-weight: 700;
    color: ${e=>{let{theme:t}=e;return t.colors.text}};
    margin: 0 0 4px 0;
  }
  
  p {
    color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
    margin: 0;
    font-size: 0.9rem;
  }
`,ny=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
  margin-bottom: 30px;
`,ry=Jr.button`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: 12px;
  padding: 20px;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 12px;
  
  &:hover {
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
  }
  
  svg {
    width: 20px;
    height: 20px;
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
  
  span {
    color: ${e=>{let{theme:t}=e;return t.colors.text}};
    font-weight: 600;
  }
`,iy=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: 16px;
  padding: 24px;
  margin-bottom: 30px;
`,oy=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  
  h3 {
    font-size: 1.3rem;
    font-weight: 600;
    color: ${e=>{let{theme:t}=e;return t.colors.text}};
    margin: 0;
  }
`,ay=Jr.div`
  display: flex;
  flex-direction: column;
  gap: 12px;
`,sy=Jr.div`
  display: flex;
  align-items: center;
  padding: 16px;
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  border-radius: 12px;
  transition: all 0.3s ease;
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  }
`,ly=Jr.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: ${e=>{let{type:t}=e;return"income"===t?"#10b981":"#ef4444"}};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
  
  svg {
    width: 20px;
    height: 20px;
    color: white;
  }
`,cy=Jr.div`
  flex: 1;
  
  h4 {
    font-size: 1rem;
    font-weight: 600;
    color: ${e=>{let{theme:t}=e;return t.colors.text}};
    margin: 0 0 4px 0;
  }
  
  p {
    color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
    margin: 0;
    font-size: 0.9rem;
  }
`,uy=Jr.div`
  font-size: 1.1rem;
  font-weight: 700;
  color: ${e=>{let{type:t}=e;return"income"===t?"#10b981":"#ef4444"}};
`,dy=Jr.button`
  background: none;
  border: none;
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  font-weight: 600;
  cursor: pointer;
  padding: 8px 16px;
  border-radius: 8px;
  transition: all 0.3s ease;
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.primary}}20;
  }
`,hy=()=>{const[t,n]=(0,e.useState)({balance:2847.5,totalEarnings:12450.75,pendingBalance:125,linkedAccounts:{paypal:!0,bank:!0,crypto:!1}}),[r]=(0,e.useState)([{id:1,type:"income",amount:450,description:"Content monetization",date:"2024-01-15",status:"completed"},{id:2,type:"expense",amount:200,description:"Withdrawal to PayPal",date:"2024-01-14",status:"completed"},{id:3,type:"income",amount:78.5,description:"Reel monetization",date:"2024-01-13",status:"completed"},{id:4,type:"income",amount:125,description:"Group subscription",date:"2024-01-12",status:"pending"}]),i=e=>{switch(e){case"send":alert("Send money feature coming soon!");break;case"receive":alert("Receive money feature coming soon!");break;case"withdraw":alert("Withdraw funds feature coming soon!");break;case"deposit":alert("Deposit funds feature coming soon!");break;case"history":alert("Transaction history feature coming soon!");break;case"settings":alert("Wallet settings feature coming soon!")}};return(0,ti.jsxs)(Ug,{children:[(0,ti.jsx)(qg,{children:"Wallet"}),(0,ti.jsxs)(Yg,{children:[(0,ti.jsxs)(Kg,{children:[(0,ti.jsx)(Gg,{children:"Total Balance"}),(0,ti.jsx)(_g,{size:24})]}),(0,ti.jsxs)(Xg,{children:["$",t.balance.toFixed(2)]}),(0,ti.jsx)(Qg,{children:"Available for withdrawal"})]}),(0,ti.jsxs)(Jg,{children:[(0,ti.jsxs)(Zg,{children:[(0,ti.jsx)(ey,{children:(0,ti.jsx)(dp,{})}),(0,ti.jsxs)(ty,{children:[(0,ti.jsxs)("h3",{children:["$",t.totalEarnings.toFixed(2)]}),(0,ti.jsx)("p",{children:"Total Earnings"})]})]}),(0,ti.jsxs)(Zg,{children:[(0,ti.jsx)(ey,{children:(0,ti.jsx)(Ig,{})}),(0,ti.jsxs)(ty,{children:[(0,ti.jsxs)("h3",{children:["$",t.pendingBalance.toFixed(2)]}),(0,ti.jsx)("p",{children:"Pending Balance"})]})]}),(0,ti.jsxs)(Zg,{children:[(0,ti.jsx)(ey,{children:(0,ti.jsx)(_g,{})}),(0,ti.jsxs)(ty,{children:[(0,ti.jsx)("h3",{children:Object.values(t.linkedAccounts).filter(Boolean).length}),(0,ti.jsx)("p",{children:"Linked Accounts"})]})]})]}),(0,ti.jsxs)(ny,{children:[(0,ti.jsxs)(ry,{onClick:()=>i("send"),children:[(0,ti.jsx)(Vg,{}),(0,ti.jsx)("span",{children:"Send Money"})]}),(0,ti.jsxs)(ry,{onClick:()=>i("receive"),children:[(0,ti.jsx)(Bg,{}),(0,ti.jsx)("span",{children:"Receive"})]}),(0,ti.jsxs)(ry,{onClick:()=>i("withdraw"),children:[(0,ti.jsx)(Wg,{}),(0,ti.jsx)("span",{children:"Withdraw"})]}),(0,ti.jsxs)(ry,{onClick:()=>i("deposit"),children:[(0,ti.jsx)(Ig,{}),(0,ti.jsx)("span",{children:"Deposit"})]}),(0,ti.jsxs)(ry,{onClick:()=>i("history"),children:[(0,ti.jsx)(Hg,{}),(0,ti.jsx)("span",{children:"History"})]}),(0,ti.jsxs)(ry,{onClick:()=>i("settings"),children:[(0,ti.jsx)(yp,{}),(0,ti.jsx)("span",{children:"Settings"})]})]}),(0,ti.jsxs)(iy,{children:[(0,ti.jsxs)(oy,{children:[(0,ti.jsx)("h3",{children:"Recent Transactions"}),(0,ti.jsx)(dy,{onClick:()=>i("history"),children:"View All"})]}),(0,ti.jsx)(ay,{children:r.slice(0,4).map(e=>{return(0,ti.jsxs)(sy,{children:[(0,ti.jsx)(ly,{type:e.type,children:"income"===e.type?(0,ti.jsx)(dp,{}):(0,ti.jsx)(Vg,{})}),(0,ti.jsxs)(cy,{children:[(0,ti.jsx)("h4",{children:e.description}),(0,ti.jsxs)("p",{children:[(t=e.date,new Date(t).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}))," \u2022 ",e.status]})]}),(0,ti.jsxs)(uy,{type:e.type,children:["income"===e.type?"+":"-","$",e.amount.toFixed(2)]})]},e.id);var t})})]})]})},py=Jr.div`
  padding: 32px 24px;
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  min-height: 80vh;
  max-width: 800px;
  margin: 0 auto;
`,my=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 32px;
`,fy=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 24px;
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,gy=Jr.h2`
  font-size: 20px;
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 16px;
  font-weight: 600;
`,yy=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 0;
  border-bottom: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  
  &:last-child {
    border-bottom: none;
  }
`,xy=Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-weight: 500;
`,vy=Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: 14px;
  margin-top: 4px;
`,by=Jr.input`
  width: 48px;
  height: 24px;
  border-radius: 12px;
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  cursor: pointer;
  outline: none;
  appearance: none;
  position: relative;
  transition: all 0.3s ease;
  
  &:checked {
    background: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
  
  &::before {
    content: '';
    position: absolute;
    width: 18px;
    height: 18px;
    border-radius: 50%;
    background: white;
    top: 2px;
    left: 2px;
    transition: all 0.3s ease;
  }
  
  &:checked::before {
    transform: translateX(24px);
  }
`,wy=Jr.select`
  padding: 8px 12px;
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: 8px;
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: 14px;
  cursor: pointer;
  outline: none;
  
  &:focus {
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,ky=Jr.button`
  padding: 12px 24px;
  background: ${e=>{let{theme:t}=e;return t.colors.primary}};
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.primaryHover}};
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,Sy=Jr(ky)`
  background: #dc3545;
  
  &:hover {
    background: #c82333;
  }
`,jy=Jr.div`
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
`,$y=Jr.img`
  width: 64px;
  height: 64px;
  border-radius: 50%;
  object-fit: cover;
`,Cy=Jr.div`
  h3 {
    margin: 0 0 4px 0;
    color: ${e=>{let{theme:t}=e;return t.colors.text}};
    font-size: 20px;
  }
  
  p {
    margin: 0;
    color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
    font-size: 14px;
  }
`,Ey=()=>{const{preferences:e,updateNotifications:t,updatePrivacy:n,setLanguage:r}=of(),{theme:i,toggleTheme:o}=Sh(),{user:a}=Ch(),s=r=>{"pushNotifications"===r||"emailNotifications"===r?t({[r.replace("Notifications","").toLowerCase()]:!e.notifications[r.replace("Notifications","").toLowerCase()]}):"dataAnalytics"===r||"locationServices"===r?n({[r.replace("data","").replace("Analytics","Collection").replace("locationServices","activityTracking")]:!e.privacy[r.replace("data","").replace("Analytics","Collection").replace("locationServices","activityTracking")]}):"autoPlayVideos"!==r&&"showSensitiveContent"!==r||console.log(`Toggle ${r} - feature not fully implemented`)},l=(e,t)=>{"language"===e?r(t):"profileVisibility"===e&&n({profileVisible:"public"===t})};return(0,ti.jsxs)(py,{children:[(0,ti.jsx)(my,{children:"Settings"}),(0,ti.jsxs)(fy,{children:[(0,ti.jsx)(gy,{children:"Account"}),(0,ti.jsxs)(jy,{children:[(0,ti.jsx)($y,{src:(null===a||void 0===a?void 0:a.avatar)||"/default-avatar.png",alt:(null===a||void 0===a?void 0:a.name)||"User"}),(0,ti.jsxs)(Cy,{children:[(0,ti.jsx)("h3",{children:(null===a||void 0===a?void 0:a.name)||"User"}),(0,ti.jsxs)("p",{children:["@",(null===a||void 0===a?void 0:a.username)||"username"]})]})]})]}),(0,ti.jsxs)(fy,{children:[(0,ti.jsx)(gy,{children:"Appearance"}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Dark Mode"}),(0,ti.jsx)(vy,{children:"Switch between light and dark themes"})]}),(0,ti.jsx)(by,{type:"checkbox",checked:"#0f172a"===i.colors.background,onChange:o})]}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Language"}),(0,ti.jsx)(vy,{children:"Choose your preferred language"})]}),(0,ti.jsxs)(wy,{value:e.language,onChange:e=>l("language",e.target.value),children:[(0,ti.jsx)("option",{value:"en",children:"English"}),(0,ti.jsx)("option",{value:"es",children:"Spanish"}),(0,ti.jsx)("option",{value:"fr",children:"French"}),(0,ti.jsx)("option",{value:"de",children:"German"}),(0,ti.jsx)("option",{value:"it",children:"Italian"}),(0,ti.jsx)("option",{value:"pt",children:"Portuguese"})]})]})]}),(0,ti.jsxs)(fy,{children:[(0,ti.jsx)(gy,{children:"Notifications"}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Push Notifications"}),(0,ti.jsx)(vy,{children:"Receive notifications for new messages and activities"})]}),(0,ti.jsx)(by,{type:"checkbox",checked:e.notifications.push,onChange:()=>s("pushNotifications")})]}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Email Notifications"}),(0,ti.jsx)(vy,{children:"Get updates via email"})]}),(0,ti.jsx)(by,{type:"checkbox",checked:e.notifications.email,onChange:()=>s("emailNotifications")})]}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Sound Effects"}),(0,ti.jsx)(vy,{children:"Play sounds for actions and notifications"})]}),(0,ti.jsx)(by,{type:"checkbox",checked:e.notifications.sms,onChange:()=>s("soundEffects")})]})]}),(0,ti.jsxs)(fy,{children:[(0,ti.jsx)(gy,{children:"Privacy"}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Profile Visibility"}),(0,ti.jsx)(vy,{children:"Who can see your profile"})]}),(0,ti.jsxs)(wy,{value:e.privacy.profileVisible?"public":"private",onChange:e=>l("profileVisibility",e.target.value),children:[(0,ti.jsx)("option",{value:"public",children:"Public"}),(0,ti.jsx)("option",{value:"friends",children:"Friends Only"}),(0,ti.jsx)("option",{value:"private",children:"Private"})]})]}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Data Analytics"}),(0,ti.jsx)(vy,{children:"Allow anonymous usage data collection"})]}),(0,ti.jsx)(by,{type:"checkbox",checked:e.privacy.dataCollection,onChange:()=>s("dataAnalytics")})]}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Location Services"}),(0,ti.jsx)(vy,{children:"Share your location for better recommendations"})]}),(0,ti.jsx)(by,{type:"checkbox",checked:e.privacy.activityTracking,onChange:()=>s("locationServices")})]})]}),(0,ti.jsxs)(fy,{children:[(0,ti.jsx)(gy,{children:"Content"}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Auto-play Videos"}),(0,ti.jsx)(vy,{children:"Automatically play videos in feed"})]}),(0,ti.jsx)(by,{type:"checkbox",checked:!1,onChange:()=>s("autoPlayVideos")})]}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Show Sensitive Content"}),(0,ti.jsx)(vy,{children:"Display content marked as sensitive"})]}),(0,ti.jsx)(by,{type:"checkbox",checked:!1,onChange:()=>s("showSensitiveContent")})]})]}),(0,ti.jsxs)(fy,{children:[(0,ti.jsx)(gy,{children:"Data Management"}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Clear Cache"}),(0,ti.jsx)(vy,{children:"Remove temporary files and cached data"})]}),(0,ti.jsx)(ky,{onClick:()=>{window.confirm("Are you sure you want to clear all app data? This action cannot be undone.")&&(localStorage.clear(),window.location.reload())},children:"Clear Data"})]})]}),(0,ti.jsxs)(fy,{children:[(0,ti.jsx)(gy,{children:"Danger Zone"}),(0,ti.jsxs)(yy,{children:[(0,ti.jsxs)("div",{children:[(0,ti.jsx)(xy,{children:"Delete Account"}),(0,ti.jsx)(vy,{children:"Permanently delete your account and all data"})]}),(0,ti.jsx)(Sy,{onClick:()=>alert("Account deletion feature coming soon"),children:"Delete Account"})]})]})]})},Ty=Si("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]),Py=Jr.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,zy=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.xl}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.xxl}};
  width: 100%;
  max-width: 400px;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(5,t)}};
  position: relative;
  overflow: hidden;
`,Ay=Jr.div`
  text-align: center;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
`,Ry=Jr.img`
  width: 80px;
  height: 80px;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,My=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  text-align: center;
`,Ly=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  text-align: center;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
`,Dy=Jr.div`
  display: flex;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  padding: 4px;
`,Oy=Jr.button`
  flex: 1;
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  background: ${e=>{let{active:t,theme:n}=e;return t?n.colors.primary:"transparent"}};
  color: ${e=>{let{active:t,theme:n}=e;return t?"white":n.colors.text}};
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.sm}};
  cursor: pointer;
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  transition: all 0.3s ease;
`,Fy=Jr.div`
  position: relative;
  min-height: 300px;
`,Ny=Jr(dh.form)`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  display: flex;
  flex-direction: column;
  gap: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,_y=Jr.div`
  position: relative;
`,Iy=Jr.input`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding-left: 50px;
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  transition: all 0.3s ease;
  box-sizing: border-box;
  
  &:focus {
    outline: none;
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    box-shadow: 0 0 0 3px ${e=>{let{theme:t}=e;return t.colors.primary}}20;
  }
`,Vy=Jr.div`
  position: absolute;
  left: 16px;
  top: 50%;
  transform: translateY(-50%);
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
`,By=Jr.button`
  position: absolute;
  right: 16px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  cursor: pointer;
`,Wy=Jr(dh.button)`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  margin-top: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Hy=Jr.button`
  background: none;
  border: none;
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  cursor: pointer;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  text-decoration: underline;
  margin-top: ${e=>{let{theme:t}=e;return t.spacing.sm}};
`,Uy=()=>{const[t,n]=(0,e.useState)(!0),[r,i]=(0,e.useState)(!1),[o,a]=(0,e.useState)(!1),[s,l]=(0,e.useState)(!1),[c,u]=(0,e.useState)({email:"",password:"",confirmPassword:"",name:""}),{login:d}=Ch(),h=ee(),p=e=>{const{name:t,value:n}=e.target;u(e=>({...e,[t]:n}))},m={hidden:{opacity:0,x:t?-20:20},visible:{opacity:1,x:0},exit:{opacity:0,x:t?20:-20}};return(0,ti.jsx)(Py,{children:(0,ti.jsxs)(zy,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.5},children:[(0,ti.jsxs)(Ay,{children:[(0,ti.jsx)(Ry,{src:hh,alt:"Astra Logo"}),(0,ti.jsx)(My,{children:"Welcome to Astra"}),(0,ti.jsx)(Ly,{children:t?"Sign in to your account":"Create your account"})]}),(0,ti.jsxs)(Dy,{children:[(0,ti.jsx)(Oy,{active:t,onClick:()=>n(!0),type:"button",children:"Sign In"}),(0,ti.jsx)(Oy,{active:!t,onClick:()=>n(!1),type:"button",children:"Sign Up"})]}),(0,ti.jsx)(Fy,{children:(0,ti.jsx)(yi,{mode:"wait",children:(0,ti.jsxs)(Ny,{variants:m,initial:"hidden",animate:"visible",exit:"exit",transition:{duration:.3},onSubmit:async e=>{if(e.preventDefault(),l(!0),await new Promise(e=>setTimeout(e,1e3)),t){if(c.email&&c.password){const e={id:"user-"+Date.now(),name:c.name||"User",username:c.email.split("@")[0],avatar:"/default-avatar.png",email:c.email};d(e),h("/")}}else if(c.email&&c.password&&c.name){const e={id:"user-"+Date.now(),name:c.name,username:c.email.split("@")[0],avatar:"/default-avatar.png",email:c.email};d(e),h("/")}l(!1)},children:[!t&&(0,ti.jsxs)(_y,{children:[(0,ti.jsx)(Vy,{children:(0,ti.jsx)(mp,{})}),(0,ti.jsx)(Iy,{type:"text",name:"name",placeholder:"Full Name",value:c.name,onChange:p,required:!0})]}),(0,ti.jsxs)(_y,{children:[(0,ti.jsx)(Vy,{children:(0,ti.jsx)(nm,{})}),(0,ti.jsx)(Iy,{type:"email",name:"email",placeholder:"Email Address",value:c.email,onChange:p,required:!0})]}),(0,ti.jsxs)(_y,{children:[(0,ti.jsx)(Vy,{children:(0,ti.jsx)(rm,{})}),(0,ti.jsx)(Iy,{type:r?"text":"password",name:"password",placeholder:"Password",value:c.password,onChange:p,required:!0}),(0,ti.jsx)(By,{type:"button",onClick:()=>i(!r),children:r?(0,ti.jsx)(im,{}):(0,ti.jsx)(om,{})})]}),!t&&(0,ti.jsxs)(_y,{children:[(0,ti.jsx)(Vy,{children:(0,ti.jsx)(rm,{})}),(0,ti.jsx)(Iy,{type:o?"text":"password",name:"confirmPassword",placeholder:"Confirm Password",value:c.confirmPassword,onChange:p,required:!0}),(0,ti.jsx)(By,{type:"button",onClick:()=>a(!o),children:o?(0,ti.jsx)(im,{}):(0,ti.jsx)(om,{})})]}),(0,ti.jsxs)(Wy,{type:"submit",disabled:s,whileHover:{scale:1.02},whileTap:{scale:.98},children:[s?"Please wait...":t?"Sign In":"Create Account",(0,ti.jsx)(Ty,{size:18})]}),t&&(0,ti.jsx)(Hy,{type:"button",children:"Forgot your password?"})]},t?"login":"signup")})})]})})},qy=Si("coffee",[["path",{d:"M10 2v2",key:"7u0qdc"}],["path",{d:"M14 2v2",key:"6buw04"}],["path",{d:"M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1",key:"pwadti"}],["path",{d:"M6 2v2",key:"colzsn"}]]),Yy=Si("github",[["path",{d:"M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4",key:"tonef"}],["path",{d:"M9 18c-4.51 2-5-2-7-2",key:"9comsn"}]]),Ky=n.p+"static/media/img (1).226e6bde0cca6be0034b.jpg",Gy=n.p+"static/media/img (2).15fd60624d5a1933b793.jpg",Xy=n.p+"static/media/img (3).c895e7b13911806b2b13.jpg",Qy=n.p+"static/media/img (4).5498d7e192a6e73701f0.jpg",Jy=n.p+"static/media/img (5).21968001fafdc0d6cb9c.jpg",Zy=n.p+"static/media/img (6).6ce28737ffab0dbf83a6.jpg",ex=n.p+"static/media/img (7).b397a950694cc7a30276.jpg",tx=n.p+"static/media/img (8).dd186e623a9e03815ad1.jpg",nx=Jr.div`
  padding: 32px 24px;
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  min-height: 100vh;
`,rx=Jr.div`
  text-align: center;
  margin-bottom: 48px;
`,ix=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 16px;
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,ox=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  max-width: 600px;
  margin: 0 auto;
  line-height: 1.6;
`,ax=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 24px;
  margin-bottom: 48px;
`,sx=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  padding: 24px;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  text-align: center;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
`,lx=Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  margin-bottom: 12px;
`,cx=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 8px;
`,ux=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,dx=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 24px;
  margin-top: 48px;
`,hx=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: 24px;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
`,px=Jr.img`
  width: 80px;
  height: 80px;
  border-radius: 50%;
  object-fit: cover;
  margin-bottom: 16px;
  border: 3px solid ${e=>{let{theme:t}=e;return t.colors.primary}};
`,mx=Jr.div`
  text-align: center;
`,fx=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 8px;
`,gx=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  margin-bottom: 12px;
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
`,yx=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  line-height: 1.5;
  margin-bottom: 16px;
`,xx=Jr.div`
  display: flex;
  justify-content: center;
  gap: 12px;
`,vx=Jr.a`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  transition: color 0.3s ease;
  
  &:hover {
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,bx=Jr.h2`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 24px;
  text-align: center;
`,wx=[{id:1,name:"Alex Johnson",role:"Senior Full Stack Developer",image:Ky,description:"Passionate about creating scalable web applications with modern technologies.",github:"https://github.com/alexjohnson",website:"https://alexjohnson.dev"},{id:2,name:"Sarah Mitchell",role:"Frontend Developer",image:Gy,description:"Expert in React, TypeScript, and modern UI/UX design principles.",github:"https://github.com/sarahmitchell",website:"https://sarahmitchell.dev"},{id:3,name:"Michael Chen",role:"Backend Developer",image:Xy,description:"Specialized in Node.js, databases, and cloud infrastructure.",github:"https://github.com/michaelchen",website:"https://michaelchen.dev"},{id:4,name:"Emma Davis",role:"Mobile Developer",image:Qy,description:"Cross-platform mobile app development with React Native and Flutter.",github:"https://github.com/emmadavis",website:"https://emmadavis.dev"},{id:5,name:"David Wilson",role:"DevOps Engineer",image:Jy,description:"Cloud infrastructure, CI/CD, and automated deployment solutions.",github:"https://github.com/davidwilson",website:"https://davidwilson.dev"},{id:6,name:"Jessica Brown",role:"UI/UX Designer",image:Zy,description:"Creating beautiful and intuitive user experiences for web and mobile.",github:"https://github.com/jessicabrown",website:"https://jessicabrown.design"},{id:7,name:"Ryan Taylor",role:"Data Scientist",image:ex,description:"Machine learning, data analytics, and AI-powered solutions.",github:"https://github.com/ryantaylor",website:"https://ryantaylor.ai"},{id:8,name:"Lisa Anderson",role:"Security Engineer",image:tx,description:"Cybersecurity, penetration testing, and secure application development.",github:"https://github.com/lisaanderson",website:"https://lisaanderson.security"}],kx=[{icon:cp,number:"50+",label:"Active Developers"},{icon:xf,number:"200+",label:"Projects Created"},{icon:$i,number:"10K+",label:"API Calls/Day"},{icon:qy,number:"\u221e",label:"Coffee Consumed"}],Sx=()=>(0,ti.jsxs)(nx,{children:[(0,ti.jsxs)(rx,{children:[(0,ti.jsx)(ix,{children:"Developer Community"}),(0,ti.jsx)(ox,{children:"Meet the talented developers building the future of Astra. Join our community and contribute to innovative projects."})]}),(0,ti.jsx)(ax,{children:kx.map((e,t)=>(0,ti.jsxs)(sx,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*t},children:[(0,ti.jsx)(lx,{children:(0,ti.jsx)(e.icon,{size:32})}),(0,ti.jsx)(cx,{children:e.number}),(0,ti.jsx)(ux,{children:e.label})]},t))}),(0,ti.jsx)(bx,{children:"Our Developer Team"}),(0,ti.jsx)(dx,{children:wx.map((e,t)=>(0,ti.jsx)(hx,{initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{delay:.1*t},children:(0,ti.jsxs)(mx,{children:[(0,ti.jsx)(px,{src:e.image,alt:e.name}),(0,ti.jsx)(fx,{children:e.name}),(0,ti.jsx)(gx,{children:e.role}),(0,ti.jsx)(yx,{children:e.description}),(0,ti.jsxs)(xx,{children:[(0,ti.jsx)(vx,{href:e.github,target:"_blank",rel:"noopener noreferrer",children:(0,ti.jsx)(Yy,{size:20})}),(0,ti.jsx)(vx,{href:e.website,target:"_blank",rel:"noopener noreferrer",children:(0,ti.jsx)(lg,{size:20})})]})]})},e.id))})]}),jx=Si("trophy",[["path",{d:"M10 14.66v1.626a2 2 0 0 1-.976 1.696A5 5 0 0 0 7 21.978",key:"1n3hpd"}],["path",{d:"M14 14.66v1.626a2 2 0 0 0 .976 1.696A5 5 0 0 1 17 21.978",key:"rfe1zi"}],["path",{d:"M18 9h1.5a1 1 0 0 0 0-5H18",key:"7xy6bh"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M6 9a6 6 0 0 0 12 0V3a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1z",key:"1mhfuq"}],["path",{d:"M6 9H4.5a1 1 0 0 1 0-5H6",key:"tex48p"}]]),$x=n.p+"static/media/bg (1).4b97344c921b546f9851.jpg",Cx=n.p+"static/media/bg (2).af337d7ff01294c04bc5.jpg",Ex=n.p+"static/media/bg (3).ff14770e0a508dfe8366.jpg",Tx=n.p+"static/media/bg (4).dd389cc5932efe211f32.jpg",Px=n.p+"static/media/bg (5).18f701bce0428f7962bb.jpg",zx=n.p+"static/media/bg (6).af1980d155828c3f1ed4.jpg",Ax=n.p+"static/media/bg (7).4b9ffb26fcae2fffb1b8.jpg",Rx=Jr.div`
  padding: 32px 16px;
  background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(${$x});
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
  min-height: 100vh;
`,Mx=Jr.div`
  text-align: center;
  margin-bottom: 48px;
  backdrop-filter: blur(10px);
  background: rgba(255, 255, 255, 0.1);
  padding: 32px;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.xl}};
  border: 1px solid rgba(255, 255, 255, 0.2);
`,Lx=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: white;
  margin-bottom: 16px;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
`,Dx=Jr.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  max-width: 600px;
  margin: 0 auto;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
`,Ox=Jr.div`
  margin-bottom: 48px;
`,Fx=Jr.div`
  position: relative;
  width: 100%;
  height: 400px;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  overflow: hidden;
  margin-bottom: 32px;
  background: rgba(0, 0, 0, 0.3);
  backdrop-filter: blur(10px);
`,Nx=Jr.video`
  width: 100%;
  height: 100%;
  object-fit: cover;
`,_x=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 24px;
  margin-top: 32px;
`,Ix=Jr(dh.div)`
  background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.8)), url(${e=>e.backgroundImage});
  background-size: cover;
  background-position: center;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: 24px;
  min-height: 300px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  position: relative;
  overflow: hidden;
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(5px);
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
  }
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
    opacity: 0;
    transition: opacity 0.3s ease;
  }
  
  &:hover::before {
    opacity: 1;
  }
`,Vx=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  color: white;
  margin-bottom: 8px;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
`,Bx=Jr.p`
  color: rgba(255, 255, 255, 0.9);
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  margin-bottom: 16px;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
`,Wx=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: auto;
`,Hx=Jr(dh.button)`
  padding: 12px 24px;
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  cursor: pointer;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  display: flex;
  align-items: center;
  gap: 8px;
  backdrop-filter: blur(5px);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
`,Ux=Jr.div`
  display: flex;
  gap: 16px;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  color: rgba(255, 255, 255, 0.8);
  
  span {
    display: flex;
    align-items: center;
    gap: 4px;
    background: rgba(0, 0, 0, 0.3);
    padding: 4px 8px;
    border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.sm}};
    backdrop-filter: blur(5px);
  }
`,qx=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 24px;
  margin-top: 32px;
`,Yx=Jr(dh.div)`
  background: rgba(0, 0, 0, 0.4);
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: 20px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  
  &:hover {
    transform: translateY(-5px);
    background: rgba(0, 0, 0, 0.6);
  }
`,Kx=Jr.div`
  width: 100%;
  height: 180px;
  background: linear-gradient(45deg, #667eea, #764ba2);
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 16px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  
  &:hover {
    transform: scale(1.02);
  }
`,Gx=Jr.div`
  width: 60px;
  height: 60px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #333;
  transition: all 0.3s ease;
  
  &:hover {
    background: white;
    transform: scale(1.1);
  }
`,Xx=Jr.h4`
  color: white;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  margin-bottom: 8px;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
`,Qx=Jr.p`
  color: rgba(255, 255, 255, 0.7);
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  line-height: 1.4;
`,Jx=Jr.h2`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  color: white;
  margin-bottom: 24px;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  gap: 12px;
`,Zx=()=>{const[t,n]=(0,e.useState)(null),r=[{id:1,title:"Stellar Combat",description:"Epic space battles in a vast galaxy with stunning visuals",players:1250,rating:4.8,background:Cx},{id:2,title:"Cyber Runner",description:"Fast-paced cyberpunk adventure through neon cities",players:890,rating:4.6,background:Ex},{id:3,title:"Kingdom Builder",description:"Build and manage your medieval kingdom",players:2100,rating:4.9,background:Tx},{id:4,title:"Ocean Explorer",description:"Dive deep into mysterious underwater worlds",players:1680,rating:4.7,background:Px},{id:5,title:"Sky Racers",description:"High-speed aerial racing through clouds",players:956,rating:4.5,background:zx},{id:6,title:"Magic Realms",description:"Mystical adventure in enchanted lands",players:1345,rating:4.8,background:Ax}];return(0,ti.jsxs)(Rx,{children:[(0,ti.jsxs)(Mx,{children:[(0,ti.jsxs)(Lx,{children:[(0,ti.jsx)(up,{size:40}),"Gaming Hub"]}),(0,ti.jsx)(Dx,{children:"Discover amazing games, watch trailers, and connect with fellow gamers"})]}),(0,ti.jsxs)(Ox,{children:[(0,ti.jsxs)(Jx,{children:[(0,ti.jsx)(ip,{size:24}),"Featured Videos"]}),(0,ti.jsx)(qx,{children:[{id:1,title:"Stellar Combat - Official Trailer",description:"Watch the epic trailer for the most anticipated space combat game of the year.",url:"https://www.w3schools.com/html/mov_bbb.mp4"},{id:2,title:"Cyber Runner - Gameplay Demo",description:"See the fast-paced cyberpunk action in this exclusive gameplay demonstration.",url:"https://www.w3schools.com/html/movie.mp4"},{id:3,title:"Kingdom Builder - Strategy Guide",description:"Learn advanced strategies to build the ultimate medieval kingdom.",url:"https://www.w3schools.com/html/mov_bbb.mp4"}].map(e=>(0,ti.jsxs)(Yx,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*e.id},children:[(0,ti.jsx)(Kx,{onClick:()=>{return t=e.url,void n(t);var t},children:(0,ti.jsx)(Gx,{children:(0,ti.jsx)(hp,{size:24})})}),(0,ti.jsx)(Xx,{children:e.title}),(0,ti.jsx)(Qx,{children:e.description})]},e.id))})]}),t&&(0,ti.jsx)(Fx,{children:(0,ti.jsx)(Nx,{src:t,controls:!0,autoPlay:!0,onEnded:()=>n(null)})}),(0,ti.jsxs)(Jx,{children:[(0,ti.jsx)(jx,{size:24}),"Featured Games"]}),(0,ti.jsx)(_x,{children:r.map(e=>(0,ti.jsxs)(Ix,{backgroundImage:e.background,initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*e.id},children:[(0,ti.jsx)(Vx,{children:e.title}),(0,ti.jsx)(Bx,{children:e.description}),(0,ti.jsxs)(Wx,{children:[(0,ti.jsxs)(Hx,{whileHover:{scale:1.05},whileTap:{scale:.95},onClick:()=>{return t=e.title,console.log(`Starting ${t}...`),void alert(`Loading ${t}... Game would start here!`);var t},children:[(0,ti.jsx)(hp,{size:18}),"Play Now"]}),(0,ti.jsxs)(Ux,{children:[(0,ti.jsxs)("span",{children:[(0,ti.jsx)($i,{size:14})," ",e.players]}),(0,ti.jsxs)("span",{children:[(0,ti.jsx)(xf,{size:14})," ",e.rating]})]})]})]},e.id))})]})},ev=Si("briefcase",[["path",{d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",key:"jecpp"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}]]),tv=Si("target",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]]),nv=Jr.div`
  padding: 32px 24px;
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  min-height: 80vh;
`,rv=(Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 24px;
`,Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  line-height: 1.6;
`,Jr.div`
  background: linear-gradient(135deg, rgba(0,0,0,0.7), rgba(0,0,0,0.4)), url(${$x});
  background-size: cover;
  background-position: center;
  border-radius: 16px;
  padding: 60px 40px;
  text-align: center;
  color: white;
  margin-bottom: 40px;
`),iv=Jr.h1`
  font-size: 3.5rem;
  font-weight: 700;
  margin-bottom: 20px;
  background: linear-gradient(45deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
`,ov=Jr.p`
  font-size: 1.3rem;
  margin-bottom: 30px;
  opacity: 0.9;
`,av=Jr(dh.button)`
  background: linear-gradient(45deg, #667eea, #764ba2);
  color: white;
  border: none;
  padding: 16px 32px;
  border-radius: 50px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 12px;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
  }
`,sv=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
  margin-bottom: 60px;
`,lv=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: 16px;
  padding: 30px;
  text-align: center;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 30px rgba(0,0,0,0.15);
  }
`,cv=Jr.div`
  width: 80px;
  height: 80px;
  background: linear-gradient(45deg, #667eea, #764ba2);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 20px;
  
  svg {
    width: 40px;
    height: 40px;
    color: white;
  }
`,uv=Jr.h3`
  font-size: 1.5rem;
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 15px;
  font-weight: 600;
`,dv=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  line-height: 1.6;
  margin-bottom: 20px;
`,hv=Jr.div`
  margin-bottom: 60px;
`,pv=Jr.h2`
  font-size: 2.5rem;
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  text-align: center;
  margin-bottom: 40px;
  font-weight: 700;
`,mv=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 30px;
  max-width: 1200px;
  margin: 0 auto;
`,fv=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: 16px;
  padding: 40px 30px;
  text-align: center;
  position: relative;
  border: 2px solid ${e=>{let{featured:t,theme:n}=e;return t?n.colors.primary:"transparent"}};
  transform: ${e=>{let{featured:t}=e;return t?"scale(1.05)":"scale(1)"}};
  
  ${e=>{let{featured:t}=e;return t&&"\n    &::before {\n      content: 'Most Popular';\n      position: absolute;\n      top: -15px;\n      left: 50%;\n      transform: translateX(-50%);\n      background: linear-gradient(45deg, #667eea, #764ba2);\n      color: white;\n      padding: 8px 24px;\n      border-radius: 20px;\n      font-size: 0.9rem;\n      font-weight: 600;\n    }\n  "}}
`,gv=Jr.h3`
  font-size: 1.8rem;
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 10px;
  font-weight: 600;
`,yv=Jr.div`
  font-size: 3rem;
  font-weight: 700;
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  margin-bottom: 20px;
  
  span {
    font-size: 1rem;
    color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  }
`,xv=Jr.ul`
  list-style: none;
  padding: 0;
  margin: 30px 0;
  
  li {
    padding: 10px 0;
    color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
    display: flex;
    align-items: center;
    gap: 10px;
    
    svg {
      color: ${e=>{let{theme:t}=e;return t.colors.success}};
    }
  }
`,vv=Jr(dh.button)`
  width: 100%;
  padding: 15px;
  border: none;
  border-radius: 10px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  background: ${e=>{let{featured:t,theme:n}=e;return t?"linear-gradient(45deg, #667eea, #764ba2)":"transparent"}};
  color: ${e=>{let{featured:t,theme:n}=e;return t?"white":n.colors.primary}};
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.primary}};
  transition: all 0.3s ease;
  
  &:hover {
    background: ${e=>{let{featured:t}=e;return t?"linear-gradient(45deg, #5a67d8, #6b46c1)":"linear-gradient(45deg, #667eea, #764ba2)"}};
    color: white;
  }
`,bv=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: 16px;
  padding: 50px 40px;
  margin-bottom: 40px;
`,wv=Jr.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 50px;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`,kv=Jr.div`
  h3 {
    font-size: 1.8rem;
    color: ${e=>{let{theme:t}=e;return t.colors.text}};
    margin-bottom: 20px;
    font-weight: 600;
  }
  
  p {
    color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
    line-height: 1.6;
    margin-bottom: 30px;
  }
`,Sv=Jr.div`
  display: flex;
  align-items: center;
  gap: 15px;
  margin-bottom: 20px;
  
  svg {
    width: 20px;
    height: 20px;
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
  
  span {
    color: ${e=>{let{theme:t}=e;return t.colors.text}};
  }
`,jv=Jr.form`
  display: flex;
  flex-direction: column;
  gap: 20px;
`,$v=Jr.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,Cv=Jr.label`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-weight: 600;
`,Ev=Jr.input`
  padding: 15px;
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: 10px;
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: 1rem;
  transition: border-color 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,Tv=Jr.textarea`
  padding: 15px;
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: 10px;
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: 1rem;
  min-height: 120px;
  resize: vertical;
  font-family: inherit;
  transition: border-color 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,Pv=Jr(dh.button)`
  background: linear-gradient(45deg, #667eea, #764ba2);
  color: white;
  border: none;
  padding: 15px 30px;
  border-radius: 10px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
  }
`,zv=()=>{const[t,n]=(0,e.useState)({name:"",email:"",company:"",message:""}),r=e=>{n({...t,[e.target.name]:e.target.value})},i=[{icon:(0,ti.jsx)(ev,{}),title:"Business Solutions",description:"Comprehensive blockchain integration and smart contract development for enterprises"},{icon:(0,ti.jsx)(tv,{}),title:"Custom Development",description:"Tailored applications and solutions built specifically for your business needs"},{icon:(0,ti.jsx)(ff,{}),title:"Performance Optimization",description:"Enhance your digital presence with cutting-edge technology and optimization"}];return(0,ti.jsxs)(nv,{children:[(0,ti.jsxs)(rv,{children:[(0,ti.jsx)(iv,{children:"Astra Business Solutions"}),(0,ti.jsx)(ov,{children:"Empowering businesses with cutting-edge blockchain technology and innovative digital solutions"}),(0,ti.jsxs)(av,{whileHover:{scale:1.05},whileTap:{scale:.95},children:["Get Started",(0,ti.jsx)(Ty,{})]})]}),(0,ti.jsx)(pv,{children:"Our Services"}),(0,ti.jsx)(sv,{children:i.map((e,t)=>(0,ti.jsxs)(lv,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*t},children:[(0,ti.jsx)(cv,{children:e.icon}),(0,ti.jsx)(uv,{children:e.title}),(0,ti.jsx)(dv,{children:e.description})]},t))}),(0,ti.jsxs)(hv,{children:[(0,ti.jsx)(pv,{children:"Pricing Plans"}),(0,ti.jsx)(mv,{children:[{name:"Starter",price:"Free",features:["Basic blockchain integration","Community support","Standard templates","Basic analytics"],featured:!1},{name:"Professional",price:"$99",period:"/month",features:["Advanced blockchain features","Priority support","Custom templates","Advanced analytics","API access"],featured:!0},{name:"Enterprise",price:"Custom",features:["Full blockchain ecosystem","Dedicated support","Unlimited customization","Enterprise analytics","Full API access","White-label solutions"],featured:!1}].map((e,t)=>(0,ti.jsxs)(fv,{featured:e.featured,initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*t},children:[(0,ti.jsx)(gv,{children:e.name}),(0,ti.jsxs)(yv,{children:[e.price,e.period&&(0,ti.jsx)("span",{children:e.period})]}),(0,ti.jsx)(xv,{children:e.features.map((e,t)=>(0,ti.jsxs)("li",{children:[(0,ti.jsx)(vf,{size:16}),e]},t))}),(0,ti.jsx)(vv,{featured:e.featured,whileHover:{scale:1.02},whileTap:{scale:.98},children:"Enterprise"===e.name?"Contact Sales":"Get Started"})]},t))})]}),(0,ti.jsxs)(bv,{children:[(0,ti.jsx)(pv,{children:"Contact Us"}),(0,ti.jsxs)(wv,{children:[(0,ti.jsxs)(kv,{children:[(0,ti.jsx)("h3",{children:"Get in Touch"}),(0,ti.jsx)("p",{children:"Ready to transform your business with blockchain technology? Contact our expert team today to discuss your project and explore how we can help you succeed."}),(0,ti.jsxs)(Sv,{children:[(0,ti.jsx)(nm,{}),(0,ti.jsx)("span",{children:"business@astra.com"})]}),(0,ti.jsxs)(Sv,{children:[(0,ti.jsx)(xp,{}),(0,ti.jsx)("span",{children:"+1 (555) 123-4567"})]}),(0,ti.jsxs)(Sv,{children:[(0,ti.jsx)(sm,{}),(0,ti.jsx)("span",{children:"123 Business Ave, Tech City, TC 12345"})]})]}),(0,ti.jsxs)(jv,{onSubmit:e=>{e.preventDefault(),console.log("Form submitted:",t),alert("Thank you for your message! We will get back to you soon."),n({name:"",email:"",company:"",message:""})},children:[(0,ti.jsxs)($v,{children:[(0,ti.jsx)(Cv,{children:"Name"}),(0,ti.jsx)(Ev,{type:"text",name:"name",value:t.name,onChange:r,placeholder:"Your full name",required:!0})]}),(0,ti.jsxs)($v,{children:[(0,ti.jsx)(Cv,{children:"Email"}),(0,ti.jsx)(Ev,{type:"email",name:"email",value:t.email,onChange:r,placeholder:"your@email.com",required:!0})]}),(0,ti.jsxs)($v,{children:[(0,ti.jsx)(Cv,{children:"Company"}),(0,ti.jsx)(Ev,{type:"text",name:"company",value:t.company,onChange:r,placeholder:"Your company name"})]}),(0,ti.jsxs)($v,{children:[(0,ti.jsx)(Cv,{children:"Message"}),(0,ti.jsx)(Tv,{name:"message",value:t.message,onChange:r,placeholder:"Tell us about your project...",required:!0})]}),(0,ti.jsxs)(Pv,{type:"submit",whileHover:{scale:1.02},whileTap:{scale:.98},children:["Send Message",(0,ti.jsx)(Vg,{})]})]})]})]})]})},Av=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}} ${e=>{let{theme:t}=e;return t.spacing.lg}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  min-height: 100vh;
`,Rv=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xxl}};
`,Mv=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.display}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,Lv=Jr.div`
  display: flex;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  align-items: center;
`,Dv=Jr.div`
  position: relative;
  flex: 1;
  max-width: 400px;
`,Ov=Jr.input`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}} ${e=>{let{theme:t}=e;return t.spacing.lg}};
  padding-left: 48px;
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  outline: none;
  transition: all 0.3s ease;
  
  &:focus {
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    box-shadow: 0 0 0 4px ${e=>{let{theme:t}=e;return t.colors.primary}}20;
  }
`,Fv=Jr.div`
  position: absolute;
  left: 16px;
  top: 50%;
  transform: translateY(-50%);
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  
  svg {
    width: 20px;
    height: 20px;
  }
`,Nv=Jr.button`
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  border: none;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}} ${e=>{let{theme:t}=e;return t.spacing.lg}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
`,_v=Jr.div`
  display: flex;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  border-bottom: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,Iv=Jr.button`
  background: none;
  border: none;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}} ${e=>{let{theme:t}=e;return t.spacing.lg}};
  cursor: pointer;
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  color: ${e=>{let{theme:t,$active:n}=e;return n?t.colors.primary:t.colors.textSecondary}};
  border-bottom: 2px solid ${e=>{let{theme:t,$active:n}=e;return n?t.colors.primary:"transparent"}};
  transition: all 0.3s ease;
  
  &:hover {
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,Vv=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xxl}};
`,Bv=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  overflow: hidden;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  cursor: pointer;
  
  &:hover {
    transform: translateY(-4px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
`,Wv=Jr.div`
  height: 120px;
  background: linear-gradient(135deg, rgba(0,0,0,0.3), rgba(0,0,0,0.1)), url(${e=>{let{$image:t}=e;return t}});
  background-size: cover;
  background-position: center;
  position: relative;
  display: flex;
  align-items: flex-end;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Hv=Jr.div`
  position: absolute;
  top: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  right: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.xs}} ${e=>{let{theme:t}=e;return t.spacing.sm}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  ${e=>{let{$type:t,theme:n}=e;switch(t){case"premium":return`background: ${n.colors.warning}; color: white;`;case"trending":return`background: ${n.colors.success}; color: white;`;case"new":return`background: ${n.colors.primary}; color: white;`;default:return""}}}
  
  svg {
    width: 12px;
    height: 12px;
  }
`,Uv=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,qv=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Yv=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin: 0 0 ${e=>{let{theme:t}=e;return t.spacing.xs}} 0;
`,Kv=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  line-height: 1.5;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Gv=Jr.div`
  display: flex;
  gap: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Xv=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  
  svg {
    width: 16px;
    height: 16px;
  }
`,Qv=Jr.button`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}} ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: 2px solid ${e=>{let{theme:t,$joined:n}=e;return n?t.colors.success:t.colors.primary}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t,$joined:n}=e;return n?t.colors.success:t.colors.primary}};
  color: white;
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    opacity: 0.9;
    transform: translateY(-1px);
  }
`,Jv=()=>{const[t,n]=(0,e.useState)("all"),[r,i]=(0,e.useState)(""),[o,a]=(0,e.useState)([{id:"1",name:"Blockchain Innovators",description:"A community of forward-thinking blockchain developers and enthusiasts sharing the latest innovations.",cover:$x,members:12500,posts:847,type:"trending",category:"technology",isJoined:!0},{id:"2",name:"Crypto Art Collective",description:"Digital artists creating and trading NFTs, sharing techniques and market insights.",cover:Cx,members:8900,posts:1203,type:"premium",category:"art",isJoined:!1},{id:"3",name:"Web3 Gaming Hub",description:"Play-to-earn gaming community discussing the latest blockchain games and strategies.",cover:Ex,members:15600,posts:2341,type:"new",category:"gaming",isJoined:!0},{id:"4",name:"DeFi Traders",description:"Share trading strategies, market analysis, and DeFi protocol insights.",cover:$x,members:23400,posts:3456,type:"trending",category:"finance",isJoined:!1},{id:"5",name:"Metaverse Builders",description:"Building the future of virtual worlds and metaverse experiences.",cover:Cx,members:6700,posts:567,type:"normal",category:"technology",isJoined:!0},{id:"6",name:"Astra Developers",description:"Official developer community for Astra platform contributors and enthusiasts.",cover:Ex,members:4500,posts:289,type:"premium",category:"development",isJoined:!1}]),s=o.filter(e=>{const n=e.name.toLowerCase().includes(r.toLowerCase())||e.description.toLowerCase().includes(r.toLowerCase()),i="all"===t||"my-groups"===t&&e.isJoined||"trending"===t&&"trending"===e.type||"new"===t&&"new"===e.type;return n&&i}),l=e=>{switch(e){case"premium":return(0,ti.jsx)(mf,{});case"trending":return(0,ti.jsx)(dp,{});case"new":return(0,ti.jsx)(xf,{});default:return null}};return(0,ti.jsxs)(Av,{children:[(0,ti.jsxs)(Rv,{children:[(0,ti.jsx)(Mv,{children:"Groups"}),(0,ti.jsxs)(Lv,{children:[(0,ti.jsxs)(Dv,{children:[(0,ti.jsx)(Fv,{children:(0,ti.jsx)(ji,{})}),(0,ti.jsx)(Ov,{placeholder:"Search groups...",value:r,onChange:e=>i(e.target.value)})]}),(0,ti.jsxs)(Nv,{children:[(0,ti.jsx)(cg,{}),"Create Group"]})]})]}),(0,ti.jsxs)(_v,{children:[(0,ti.jsx)(Iv,{$active:"all"===t,onClick:()=>n("all"),children:"All Groups"}),(0,ti.jsx)(Iv,{$active:"my-groups"===t,onClick:()=>n("my-groups"),children:"My Groups"}),(0,ti.jsx)(Iv,{$active:"trending"===t,onClick:()=>n("trending"),children:"Trending"}),(0,ti.jsx)(Iv,{$active:"new"===t,onClick:()=>n("new"),children:"New"})]}),(0,ti.jsx)(Vv,{children:s.map(e=>(0,ti.jsxs)(Bv,{children:[(0,ti.jsx)(Wv,{$image:e.cover,children:"normal"!==e.type&&(0,ti.jsxs)(Hv,{$type:e.type,children:[l(e.type),e.type]})}),(0,ti.jsxs)(Uv,{children:[(0,ti.jsx)(qv,{children:(0,ti.jsx)("div",{children:(0,ti.jsx)(Yv,{children:e.name})})}),(0,ti.jsx)(Kv,{children:e.description}),(0,ti.jsxs)(Gv,{children:[(0,ti.jsxs)(Xv,{children:[(0,ti.jsx)($i,{}),e.members.toLocaleString()," members"]}),(0,ti.jsxs)(Xv,{children:[(0,ti.jsx)(Ci,{}),e.posts," posts"]})]}),(0,ti.jsx)(Qv,{$joined:e.isJoined,onClick:()=>{return t=e.id,void a(o.map(e=>e.id===t?{...e,isJoined:!e.isJoined}:e));var t},children:e.isJoined?"Joined":"Join Group"})]})]},e.id))})]})},Zv=Si("clock",[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]),eb=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}} ${e=>{let{theme:t}=e;return t.spacing.lg}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  min-height: 100vh;
`,tb=Jr.div`
  text-align: center;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xxl}};
`,nb=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.display}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.bold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,rb=Jr.p`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  max-width: 600px;
  margin: 0 auto;
  line-height: 1.6;
`,ib=Jr.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xxl}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xxl}};
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`,ob=Jr.div`
  display: flex;
  flex-direction: column;
  gap: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,ab=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
`,sb=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,lb=Jr.div`
  width: 48px;
  height: 48px;
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  
  svg {
    width: 24px;
    height: 24px;
  }
`,cb=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin: 0;
`,ub=Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  line-height: 1.6;
`,db=Jr.form`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
`,hb=Jr.h2`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  text-align: center;
`,pb=Jr.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
  
  @media (max-width: 480px) {
    grid-template-columns: 1fr;
  }
`,mb=Jr.div`
  display: flex;
  flex-direction: column;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
`,fb=Jr.label`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
`,gb=Jr.input`
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    box-shadow: 0 0 0 3px ${e=>{let{theme:t}=e;return t.colors.primary}}20;
  }
`,yb=Jr.textarea`
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  resize: vertical;
  min-height: 120px;
  font-family: inherit;
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    box-shadow: 0 0 0 3px ${e=>{let{theme:t}=e;return t.colors.primary}}20;
  }
`,xb=Jr.select`
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    box-shadow: 0 0 0 3px ${e=>{let{theme:t}=e;return t.colors.primary}}20;
  }
`,vb=Jr.button`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}} ${e=>{let{theme:t}=e;return t.spacing.lg}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
`,bb=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.success}}20;
  color: ${e=>{let{theme:t}=e;return t.colors.success}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  svg {
    width: 20px;
    height: 20px;
  }
`,wb=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}};
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
`,kb=Jr.h2`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  text-align: center;
`,Sb=Jr.div`
  border-bottom: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}} 0;
  
  &:last-child {
    border-bottom: none;
  }
`,jb=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xs}};
`,$b=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  line-height: 1.6;
  margin: 0;
`,Cb=()=>{const[t,n]=(0,e.useState)({name:"",email:"",subject:"",category:"general",message:""}),[r,i]=(0,e.useState)(!1),[o,a]=(0,e.useState)(!1),s=e=>{n({...t,[e.target.name]:e.target.value})};return(0,ti.jsxs)(eb,{children:[(0,ti.jsxs)(tb,{children:[(0,ti.jsx)(nb,{children:"Get In Touch"}),(0,ti.jsx)(rb,{children:"Have questions about Astra Social Space? We're here to help you connect, create, and thrive in our community."})]}),(0,ti.jsxs)(ib,{children:[(0,ti.jsxs)(ob,{children:[(0,ti.jsxs)(ab,{children:[(0,ti.jsxs)(sb,{children:[(0,ti.jsx)(lb,{children:(0,ti.jsx)(nm,{})}),(0,ti.jsx)(cb,{children:"Email Support"})]}),(0,ti.jsxs)(ub,{children:[(0,ti.jsx)("p",{children:"Get support via email within 24 hours"}),(0,ti.jsx)("strong",{children:"support@astra.space"})]})]}),(0,ti.jsxs)(ab,{children:[(0,ti.jsxs)(sb,{children:[(0,ti.jsx)(lb,{children:(0,ti.jsx)(xp,{})}),(0,ti.jsx)(cb,{children:"Phone Support"})]}),(0,ti.jsxs)(ub,{children:[(0,ti.jsx)("p",{children:"Talk to our team directly"}),(0,ti.jsx)("strong",{children:"+1 (555) 123-ASTRA"})]})]}),(0,ti.jsxs)(ab,{children:[(0,ti.jsxs)(sb,{children:[(0,ti.jsx)(lb,{children:(0,ti.jsx)(sm,{})}),(0,ti.jsx)(cb,{children:"Office Location"})]}),(0,ti.jsxs)(ub,{children:[(0,ti.jsx)("p",{children:"Visit us at our headquarters"}),(0,ti.jsxs)("strong",{children:["123 Innovation Drive",(0,ti.jsx)("br",{}),"Tech City, TC 12345"]})]})]}),(0,ti.jsxs)(ab,{children:[(0,ti.jsxs)(sb,{children:[(0,ti.jsx)(lb,{children:(0,ti.jsx)(Zv,{})}),(0,ti.jsx)(cb,{children:"Business Hours"})]}),(0,ti.jsxs)(ub,{children:[(0,ti.jsx)("p",{children:"Monday - Friday: 9:00 AM - 6:00 PM PST"}),(0,ti.jsx)("p",{children:"Saturday: 10:00 AM - 4:00 PM PST"}),(0,ti.jsx)("p",{children:"Sunday: Closed"})]})]})]}),(0,ti.jsxs)(db,{onSubmit:async e=>{e.preventDefault(),i(!0),setTimeout(()=>{i(!1),a(!0),n({name:"",email:"",subject:"",category:"general",message:""}),setTimeout(()=>{a(!1)},5e3)},2e3)},children:[(0,ti.jsx)(hb,{children:"Send us a Message"}),o&&(0,ti.jsxs)(bb,{children:[(0,ti.jsx)(vf,{}),"Thank you for your message! We'll get back to you soon."]}),(0,ti.jsxs)(pb,{children:[(0,ti.jsxs)(mb,{children:[(0,ti.jsx)(fb,{htmlFor:"name",children:"Full Name"}),(0,ti.jsx)(gb,{id:"name",name:"name",type:"text",value:t.name,onChange:s,required:!0,placeholder:"John Doe"})]}),(0,ti.jsxs)(mb,{children:[(0,ti.jsx)(fb,{htmlFor:"email",children:"Email Address"}),(0,ti.jsx)(gb,{id:"email",name:"email",type:"email",value:t.email,onChange:s,required:!0,placeholder:"john@example.com"})]})]}),(0,ti.jsxs)(pb,{children:[(0,ti.jsxs)(mb,{children:[(0,ti.jsx)(fb,{htmlFor:"subject",children:"Subject"}),(0,ti.jsx)(gb,{id:"subject",name:"subject",type:"text",value:t.subject,onChange:s,required:!0,placeholder:"How can we help?"})]}),(0,ti.jsxs)(mb,{children:[(0,ti.jsx)(fb,{htmlFor:"category",children:"Category"}),(0,ti.jsxs)(xb,{id:"category",name:"category",value:t.category,onChange:s,required:!0,children:[(0,ti.jsx)("option",{value:"general",children:"General Inquiry"}),(0,ti.jsx)("option",{value:"support",children:"Technical Support"}),(0,ti.jsx)("option",{value:"billing",children:"Billing"}),(0,ti.jsx)("option",{value:"partnership",children:"Partnership"}),(0,ti.jsx)("option",{value:"feedback",children:"Feedback"}),(0,ti.jsx)("option",{value:"bug",children:"Bug Report"})]})]})]}),(0,ti.jsxs)(mb,{children:[(0,ti.jsx)(fb,{htmlFor:"message",children:"Message"}),(0,ti.jsx)(yb,{id:"message",name:"message",value:t.message,onChange:s,required:!0,placeholder:"Tell us more about your inquiry..."})]}),(0,ti.jsxs)(vb,{type:"submit",disabled:r,$loading:r,children:[r?"Sending...":"Send Message",(0,ti.jsx)(Vg,{})]})]})]}),(0,ti.jsxs)(wb,{children:[(0,ti.jsx)(kb,{children:"Frequently Asked Questions"}),(0,ti.jsxs)(Sb,{children:[(0,ti.jsx)(jb,{children:"How do I create an account on Astra Social Space?"}),(0,ti.jsx)($b,{children:'Simply click the "Register" button in the top right corner and follow the simple signup process. You\'ll be part of our community in minutes!'})]}),(0,ti.jsxs)(Sb,{children:[(0,ti.jsx)(jb,{children:"Is Astra Social Space free to use?"}),(0,ti.jsx)($b,{children:"Yes! Astra Social Space is completely free to use. We also offer premium features for users who want enhanced functionality."})]}),(0,ti.jsxs)(Sb,{children:[(0,ti.jsx)(jb,{children:"How do I report inappropriate content?"}),(0,ti.jsx)($b,{children:'You can report any post or user by clicking the menu button (three dots) and selecting "Report". Our moderation team reviews all reports promptly.'})]}),(0,ti.jsxs)(Sb,{children:[(0,ti.jsx)(jb,{children:"Can I integrate Astra with other platforms?"}),(0,ti.jsx)($b,{children:"Yes! We offer API access and integrations with popular platforms. Check out our developer documentation for more information."})]}),(0,ti.jsxs)(Sb,{children:[(0,ti.jsx)(jb,{children:"How do I delete my account?"}),(0,ti.jsx)($b,{children:"You can delete your account by going to Settings \u2192 Account \u2192 Delete Account. Please note that this action is irreversible."})]})]})]})},Eb=n.p+"static/media/img (20).245c06d57adadee5e3a8.jpg",Tb=n.p+"static/media/img (21).0acabc442e3858b2324a.jpg",Pb=n.p+"static/media/img (22).fefd6d8d9168aa0699dc.jpg",zb=Jr.div`
  display: flex;
  height: calc(100vh - 80px);
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
`,Ab=Jr.div`
  width: 300px;
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-right: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  display: flex;
  flex-direction: column;
`,Rb=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  border-bottom: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,Mb=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Lb=Jr.div`
  position: relative;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Db=Jr.input`
  width: 100%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}} ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding-left: 40px;
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  outline: none;
  box-sizing: border-box;
  
  &:focus {
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,Ob=Jr.div`
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
`,Fb=Jr.div`
  flex: 1;
  overflow-y: auto;
`,Nb=Jr.div`
  display: flex;
  align-items: center;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  cursor: pointer;
  transition: background 0.2s ease;
  background: ${e=>{let{theme:t,active:n}=e;return n?t.colors.primary+"20":"transparent"}};
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  }
`,_b=Jr.img`
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Ib=Jr.div`
  flex: 1;
`,Vb=Jr.div`
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xs}};
`,Bb=Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`,Wb=Jr.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
`,Hb=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-bottom: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  display: flex;
  align-items: center;
  justify-content: space-between;
`,Ub=Jr.div`
  flex: 1;
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,qb=Jr(dh.div)`
  max-width: 70%;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  background: ${e=>{let{theme:t,isOwn:n}=e;return n?t.colors.primary:t.colors.surface}};
  color: ${e=>{let{theme:t,isOwn:n}=e;return n?"white":t.colors.text}};
  align-self: ${e=>{let{isOwn:t}=e;return t?"flex-end":"flex-start"}};
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(1,t)}};
`,Yb=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-top: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,Kb=Jr.input`
  flex: 1;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  outline: none;
  
  &:focus {
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,Gb=Jr.button`
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  border: none;
  color: white;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
  
  &:hover {
    transform: scale(1.05);
  }
`,Xb=Jr.div`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  text-align: center;
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}};
`,Qb=()=>{const{user:t}=Ch(),[n,r]=(0,e.useState)(null),[i,o]=(0,e.useState)([]),[a,s]=(0,e.useState)(""),[l,c]=(0,e.useState)(""),[u,d]=(0,e.useState)(!1),h=(0,e.useRef)(null),p=[{id:"1",name:"Sarah Johnson",avatar:Eb,lastMessage:"Hey! How are you doing?",time:"2m ago",online:!0},{id:"2",name:"Mike Chen",avatar:Tb,lastMessage:"The project looks great!",time:"1h ago",online:!0},{id:"3",name:"Emma Davis",avatar:Pb,lastMessage:"Can we schedule a meeting?",time:"3h ago",online:!1}],m=[{id:"1",text:"Hey! How are you doing?",isOwn:!1,time:"10:30 AM"},{id:"2",text:"I'm doing great! Just working on some new features for Astra.",isOwn:!0,time:"10:32 AM"}];(0,e.useEffect)(()=>{t||d(!0)},[t]);const f=()=>{if(t){if(a.trim()&&n){const e={id:Date.now().toString(),text:a,isOwn:!0,time:(new Date).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})};o(t=>[...t,e]),s("")}}else d(!0)};return(0,ti.jsxs)(ti.Fragment,{children:[(0,ti.jsxs)(zb,{children:[(0,ti.jsxs)(Ab,{children:[(0,ti.jsxs)(Rb,{children:[(0,ti.jsx)(Mb,{children:"Messages"}),(0,ti.jsxs)(Lb,{children:[(0,ti.jsx)(Ob,{children:(0,ti.jsx)(ji,{size:16})}),(0,ti.jsx)(Db,{placeholder:"Search conversations...",value:l,onChange:e=>c(e.target.value)})]})]}),(0,ti.jsx)(Fb,{children:p.map(e=>(0,ti.jsxs)(Nb,{active:(null===n||void 0===n?void 0:n.id)===e.id,onClick:()=>(e=>{t?(r(e),o(m)):d(!0)})(e),children:[(0,ti.jsx)(_b,{src:e.avatar,alt:e.name}),(0,ti.jsxs)(Ib,{children:[(0,ti.jsx)(Vb,{children:e.name}),(0,ti.jsx)(Bb,{children:e.lastMessage})]})]},e.id))})]}),(0,ti.jsx)(Wb,{children:n?(0,ti.jsxs)(ti.Fragment,{children:[(0,ti.jsx)(Hb,{children:(0,ti.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"16px"},children:[(0,ti.jsx)(_b,{src:n.avatar,alt:n.name}),(0,ti.jsxs)("div",{children:[(0,ti.jsx)("div",{style:{fontWeight:600},children:n.name}),(0,ti.jsx)("div",{style:{color:"#48bb78",fontSize:"14px"},children:n.online?"Online":"Offline"})]})]})}),(0,ti.jsxs)(Ub,{children:[(0,ti.jsx)(yi,{children:i.map(e=>(0,ti.jsx)(qb,{isOwn:e.isOwn,initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.3},children:e.text},e.id))}),(0,ti.jsx)("div",{ref:h})]}),(0,ti.jsxs)(Yb,{children:[(0,ti.jsx)(Kb,{placeholder:"Type a message...",value:a,onChange:e=>s(e.target.value),onKeyPress:e=>"Enter"===e.key&&f()}),(0,ti.jsx)(Gb,{onClick:f,children:(0,ti.jsx)(Vg,{size:20})})]})]}):(0,ti.jsxs)(Xb,{children:[(0,ti.jsx)("h2",{children:"Select a conversation"}),(0,ti.jsx)("p",{children:"Choose from your existing conversations or start a new one"})]})})]}),(0,ti.jsx)(Rf,{isOpen:u,onClose:()=>d(!1),type:"info",title:"Sign In Required",message:"Please sign in to access your messages and start chatting with friends.",actionText:"Sign In",onAction:()=>{window.location.href="/login"}})]})},Jb=Si("ellipsis",[["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}],["circle",{cx:"19",cy:"12",r:"1",key:"1wjl8i"}],["circle",{cx:"5",cy:"12",r:"1",key:"1pcz8c"}]]),Zb=Jr.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
`,ew=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
`,tw=Jr.h1`
  color: ${e=>e.theme.colors.text};
  font-size: 2rem;
  font-weight: 700;
`,nw=Jr.div`
  position: relative;
  max-width: 400px;
  width: 100%;
`,rw=Jr.input`
  width: 100%;
  padding: 12px 16px 12px 48px;
  border: 2px solid ${e=>e.theme.colors.border};
  border-radius: 25px;
  background: ${e=>e.theme.colors.backgroundSecondary};
  color: ${e=>e.theme.colors.text};
  font-size: 16px;
  transition: all 0.3s ease;

  &:focus {
    outline: none;
    border-color: ${e=>e.theme.colors.primary};
    box-shadow: 0 0 0 3px ${e=>e.theme.colors.primary}20;
  }

  &::placeholder {
    color: ${e=>e.theme.colors.textSecondary};
  }
`,iw=Jr(ji)`
  position: absolute;
  left: 16px;
  top: 50%;
  transform: translateY(-50%);
  color: ${e=>e.theme.colors.textSecondary};
  width: 20px;
  height: 20px;
`,ow=Jr.div`
  display: flex;
  gap: 8px;
  margin-bottom: 30px;
  border-bottom: 2px solid ${e=>e.theme.colors.border};
`,aw=Jr.button`
  padding: 12px 20px;
  border: none;
  background: none;
  color: ${e=>e.active?e.theme.colors.primary:e.theme.colors.textSecondary};
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  position: relative;
  transition: all 0.3s ease;

  &:hover {
    color: ${e=>e.theme.colors.primary};
  }

  ${e=>e.active&&`\n    &::after {\n      content: '';\n      position: absolute;\n      bottom: -2px;\n      left: 0;\n      right: 0;\n      height: 2px;\n      background: ${e.theme.colors.primary};\n    }\n  `}
`,sw=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
`,lw=Jr(dh.div)`
  background: ${e=>e.theme.colors.backgroundSecondary};
  border: 1px solid ${e=>e.theme.colors.border};
  border-radius: 12px;
  padding: 20px;
  transition: all 0.3s ease;

  &:hover {
    border-color: ${e=>e.theme.colors.primary};
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }
`,cw=Jr.div`
  display: flex;
  align-items: center;
  gap: 15px;
  margin-bottom: 15px;
`,uw=Jr.img`
  width: 50px;
  height: 50px;
  border-radius: 50%;
  object-fit: cover;
`,dw=Jr.div`
  flex: 1;
`,hw=Jr.h3`
  color: ${e=>e.theme.colors.text};
  font-size: 16px;
  font-weight: 600;
  margin: 0 0 4px 0;
`,pw=Jr.p`
  color: ${e=>e.theme.colors.textSecondary};
  font-size: 14px;
  margin: 0;
`,mw=Jr.div`
  display: flex;
  gap: 20px;
  margin-bottom: 15px;
`,fw=Jr.div`
  text-align: center;
`,gw=Jr.div`
  color: ${e=>e.theme.colors.text};
  font-size: 16px;
  font-weight: 600;
`,yw=Jr.div`
  color: ${e=>e.theme.colors.textSecondary};
  font-size: 12px;
`,xw=Jr.div`
  display: flex;
  gap: 10px;
`,vw=Jr.button`
  flex: 1;
  padding: 8px 16px;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  ${e=>{switch(e.variant){case"primary":return`\n          background: ${e.theme.colors.primary};\n          color: white;\n          &:hover {\n            background: ${e.theme.colors.primaryHover};\n          }\n        `;case"danger":return`\n          background: ${e.theme.colors.error};\n          color: white;\n          &:hover {\n            opacity: 0.8;\n          }\n        `;default:return`\n          background: ${e.theme.colors.border};\n          color: ${e.theme.colors.text};\n          &:hover {\n            background: ${e.theme.colors.border};\n          }\n        `}}}
`,bw=Jr.button`
  padding: 8px;
  border: none;
  border-radius: 8px;
  background: ${e=>e.theme.colors.border};
  color: ${e=>e.theme.colors.text};
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background: ${e=>e.theme.colors.border};
  }
`,ww=Jr.div`
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: ${e=>e.online?"#4CAF50":"#757575"};
  border: 2px solid ${e=>e.theme.colors.backgroundSecondary};
  position: absolute;
  bottom: 0;
  right: 0;
`,kw=Jr.div`
  position: relative;
`,Sw=Jr.div`
  background: ${e=>e.theme.colors.primary};
  color: white;
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
  margin-top: 4px;
`,jw=Jr.div`
  text-align: center;
  padding: 60px 20px;
  color: ${e=>e.theme.colors.textSecondary};
  grid-column: 1 / -1;
`,$w=Jr.div`
  font-size: 48px;
  margin-bottom: 16px;
`,Cw=Jr.h3`
  color: ${e=>e.theme.colors.text};
  margin-bottom: 8px;
`,Ew=()=>{const[t,n]=(0,e.useState)("friends"),[r,i]=(0,e.useState)(""),{friends:o,followers:a,following:s,friendRequests:l,followUser:c,unfollowUser:u,acceptFriendRequest:d,sendFriendRequest:h,removeFriend:p,isFollowing:m,isMutualFollowing:f,rejectFriendRequest:g}=(()=>{const t=(0,e.useContext)(uf);if(!t)throw new Error("useSocial must be used within a SocialProvider");return t})(),y=(()=>{switch(t){case"friends":return o;case"followers":return a;case"following":return s;case"requests":return l.map(e=>e.from);default:return[]}})().filter(e=>e.name.toLowerCase().includes(r.toLowerCase())||e.username.toLowerCase().includes(r.toLowerCase())),x=e=>{switch(e){case"friends":return o.length;case"followers":return a.length;case"following":return s.length;case"requests":return l.length;default:return 0}},v=(()=>{switch(t){case"friends":return{icon:"\ud83d\udc65",title:"No friends yet",message:"Start connecting with people to build your network!"};case"followers":return{icon:"\ud83d\udc64",title:"No followers yet",message:"Share interesting content to attract followers!"};case"following":return{icon:"\u2795",title:"Not following anyone",message:"Discover and follow interesting people!"};case"requests":return{icon:"\ud83d\udce8",title:"No pending requests",message:"Friend requests will appear here when you receive them."};default:return{icon:"\ud83d\udd0d",title:"Nothing found",message:"Try adjusting your search or explore different tabs."}}})();return(0,ti.jsxs)(Zb,{children:[(0,ti.jsxs)(ew,{children:[(0,ti.jsx)(tw,{children:"Friends"}),(0,ti.jsxs)(nw,{children:[(0,ti.jsx)(iw,{}),(0,ti.jsx)(rw,{type:"text",placeholder:"Search friends...",value:r,onChange:e=>i(e.target.value)})]})]}),(0,ti.jsxs)(ow,{children:[(0,ti.jsxs)(aw,{active:"friends"===t,onClick:()=>n("friends"),children:["Friends (",x("friends"),")"]}),(0,ti.jsxs)(aw,{active:"followers"===t,onClick:()=>n("followers"),children:["Followers (",x("followers"),")"]}),(0,ti.jsxs)(aw,{active:"following"===t,onClick:()=>n("following"),children:["Following (",x("following"),")"]}),(0,ti.jsxs)(aw,{active:"requests"===t,onClick:()=>n("requests"),children:["Requests (",x("requests"),")"]})]}),(0,ti.jsx)(sw,{children:0===y.length?(0,ti.jsxs)(jw,{children:[(0,ti.jsx)($w,{children:v.icon}),(0,ti.jsx)(Cw,{children:v.title}),(0,ti.jsx)("p",{children:v.message})]}):y.map(e=>(0,ti.jsxs)(lw,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{duration:.3},children:[(0,ti.jsxs)(cw,{children:[(0,ti.jsxs)(kw,{children:[(0,ti.jsx)(uw,{src:e.avatar||"/api/placeholder/50/50",alt:e.name}),(0,ti.jsx)(ww,{online:e.isOnline})]}),(0,ti.jsxs)(dw,{children:[(0,ti.jsx)(hw,{children:e.name}),(0,ti.jsxs)(pw,{children:["@",e.username]}),f(e.id)&&(0,ti.jsx)(Sw,{children:"Mutual Follow"})]})]}),(0,ti.jsxs)(mw,{children:[(0,ti.jsxs)(fw,{children:[(0,ti.jsx)(gw,{children:e.followersCount||0}),(0,ti.jsx)(yw,{children:"Followers"})]}),(0,ti.jsxs)(fw,{children:[(0,ti.jsx)(gw,{children:e.followingCount||0}),(0,ti.jsx)(yw,{children:"Following"})]}),(0,ti.jsxs)(fw,{children:[(0,ti.jsx)(gw,{children:e.postsCount||0}),(0,ti.jsx)(yw,{children:"Posts"})]})]}),(0,ti.jsx)(xw,{children:"requests"===t?(0,ti.jsxs)(ti.Fragment,{children:[(0,ti.jsx)(vw,{variant:"primary",onClick:()=>{var t;return d((null===(t=l.find(t=>t.from.id===e.id))||void 0===t?void 0:t.id)||"")},children:"Accept"}),(0,ti.jsx)(vw,{variant:"secondary",onClick:()=>{var t;return g((null===(t=l.find(t=>t.from.id===e.id))||void 0===t?void 0:t.id)||"")},children:"Decline"})]}):(0,ti.jsxs)(ti.Fragment,{children:["friends"===t&&(0,ti.jsx)(vw,{variant:"danger",onClick:()=>p(e.id),children:"Remove"}),"following"===t&&(0,ti.jsx)(vw,{variant:"secondary",onClick:()=>u(e.id),children:"Unfollow"}),"followers"===t&&!m(e.id)&&(0,ti.jsx)(vw,{variant:"primary",onClick:()=>c(e.id),children:"Follow Back"}),(0,ti.jsx)(bw,{onClick:()=>console.log("Message",e.name),children:(0,ti.jsx)(Ci,{size:16})}),(0,ti.jsx)(bw,{onClick:()=>console.log("More options",e.name),children:(0,ti.jsx)(Jb,{size:16})})]})})]},e.id))})]})},Tw=Jr.div`
  position: relative;
  width: 100%;
  background: #000;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: ${e=>{let{theme:t}=e;return t.colors.boxShadow}};
`,Pw=Jr.video`
  width: 100%;
  height: 100%;
  object-fit: cover;
  outline: none;
`,zw=Jr.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
  padding: 20px;
  transform: translateY(${e=>{let{show:t}=e;return t?"0":"100%"}});
  transition: transform 0.3s ease;
`,Aw=Jr.div`
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
`,Rw=Jr.button`
  background: none;
  border: none;
  color: white;
  font-size: 24px;
  cursor: pointer;
  padding: 8px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
  transition: background-color 0.2s;

  &:hover {
    background: rgba(255, 255, 255, 0.1);
  }
`,Mw=Jr.div`
  flex: 1;
  height: 4px;
  background: rgba(255, 255, 255, 0.3);
  border-radius: 2px;
  cursor: pointer;
  position: relative;
`,Lw=Jr.div`
  height: 100%;
  background: #007bff;
  border-radius: 2px;
  width: ${e=>{let{progress:t}=e;return t}}%;
  transition: width 0.1s ease;
`,Dw=Jr.span`
  color: white;
  font-size: 12px;
  min-width: 40px;
`,Ow=Jr.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,Fw=Jr.button`
  background: none;
  border: none;
  color: white;
  font-size: 16px;
  cursor: pointer;
  padding: 4px;
`,Nw=Jr.input`
  width: 60px;
  height: 4px;
  background: rgba(255, 255, 255, 0.3);
  border-radius: 2px;
  outline: none;
  cursor: pointer;

  &::-webkit-slider-thumb {
    appearance: none;
    width: 12px;
    height: 12px;
    background: #007bff;
    border-radius: 50%;
    cursor: pointer;
  }
`,_w=Jr.button`
  background: none;
  border: none;
  color: white;
  font-size: 16px;
  cursor: pointer;
  padding: 4px;
`,Iw=Jr.div`
  position: absolute;
  top: 20px;
  left: 20px;
  right: 20px;
  color: white;
  z-index: 10;
`,Vw=Jr.h3`
  margin: 0 0 8px 0;
  font-size: 18px;
  font-weight: 600;
`,Bw=Jr.div`
  display: flex;
  gap: 16px;
  font-size: 12px;
  opacity: 0.8;
`,Ww=Jr.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(0, 0, 0, 0.7);
  border-radius: 50%;
  width: 80px;
  height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  opacity: ${e=>{let{show:t}=e;return t?1:0}};
  transition: opacity 0.3s ease;
  z-index: 5;

  &:hover {
    background: rgba(0, 0, 0, 0.8);
  }
`,Hw=Jr.div`
  width: 0;
  height: 0;
  border-left: 20px solid white;
  border-top: 12px solid transparent;
  border-bottom: 12px solid transparent;
  margin-left: 4px;
`,Uw=Jr.div`
  display: flex;
  gap: 4px;
  
  &::before,
  &::after {
    content: '';
    width: 4px;
    height: 20px;
    background: white;
  }
`,qw=t=>{var n,r;let{mediaItem:i,autoPlay:o=!1,showControls:a=!0,className:s,onEnded:l}=t;const c=(0,e.useRef)(null),[u,d]=(0,e.useState)(!1),[h,p]=(0,e.useState)(0),[m,f]=(0,e.useState)(0),[g,y]=(0,e.useState)(50),[x,v]=(0,e.useState)(!1),[b,w]=(0,e.useState)(!1),[k,S]=(0,e.useState)(!1),{setCurrentPlayingVideo:j}=ef();(0,e.useEffect)(()=>{const e=c.current;if(!e)return;const t=()=>{p(e.currentTime)},n=()=>{f(e.duration)},r=()=>{d(!1),j(null),null===l||void 0===l||l()};return e.addEventListener("timeupdate",t),e.addEventListener("loadedmetadata",n),e.addEventListener("ended",r),()=>{e.removeEventListener("timeupdate",t),e.removeEventListener("loadedmetadata",n),e.removeEventListener("ended",r)}},[l,j]);const $=()=>{const e=c.current;e&&(u?(e.pause(),j(null)):(e.play(),j(i)),d(!u))},C=e=>`${Math.floor(e/60)}:${Math.floor(e%60).toString().padStart(2,"0")}`,E=m?h/m*100:0;return(0,ti.jsxs)(Tw,{className:s,onMouseEnter:()=>w(!0),onMouseLeave:()=>w(!1),children:[(0,ti.jsx)(Pw,{ref:c,src:i.src,autoPlay:o,muted:x,onClick:$}),a&&(0,ti.jsxs)(ti.Fragment,{children:[(0,ti.jsxs)(Iw,{children:[(0,ti.jsx)(Vw,{children:i.title}),(0,ti.jsxs)(Bw,{children:[(0,ti.jsxs)("span",{children:[null===(n=i.views)||void 0===n?void 0:n.toLocaleString()," views"]}),(0,ti.jsxs)("span",{children:[null===(r=i.likes)||void 0===r?void 0:r.toLocaleString()," likes"]})]})]}),(0,ti.jsx)(Ww,{show:!u&&b,onClick:$,children:(0,ti.jsx)(Hw,{})}),(0,ti.jsxs)(zw,{show:b,children:[(0,ti.jsx)(Mw,{onClick:e=>{const t=c.current;if(!t)return;const n=e.currentTarget.getBoundingClientRect(),r=(e.clientX-n.left)/n.width*m;t.currentTime=r},children:(0,ti.jsx)(Lw,{progress:E})}),(0,ti.jsxs)(Aw,{children:[(0,ti.jsx)(Rw,{onClick:$,children:u?(0,ti.jsx)(Uw,{}):(0,ti.jsx)(Hw,{})}),(0,ti.jsxs)(Dw,{children:[C(h)," / ",C(m)]}),(0,ti.jsxs)(Ow,{children:[(0,ti.jsx)(Fw,{onClick:()=>{const e=c.current;e&&(e.muted=!x,v(!x))},children:x?"\ud83d\udd07":"\ud83d\udd0a"}),(0,ti.jsx)(Nw,{type:"range",min:"0",max:"100",value:g,onChange:e=>{const t=c.current;if(!t)return;const n=parseInt(e.target.value);y(n),t.volume=n/100}})]}),(0,ti.jsx)(_w,{onClick:()=>{var e;const t=null===(e=c.current)||void 0===e?void 0:e.parentElement;t&&(k?document.exitFullscreen():t.requestFullscreen(),S(!k))},children:"\u26f6"})]})]})]})]})},Yw=Jr.div`
  width: 100%;
  max-width: 500px;
  margin: 0 auto;
  padding: 20px;
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  min-height: 100vh;
`,Kw=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: 12px;
  margin-bottom: 20px;
  padding: 15px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,Gw=Jr.div`
  display: flex;
  align-items: center;
  margin-bottom: 15px;
`,Xw=Jr.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(45deg, #ff6b6b, #4ecdc4);
  margin-right: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
  font-size: 14px;
`,Qw=Jr.div`
  flex: 1;
`,Jw=Jr.h4`
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
`,Zw=Jr.span`
  font-size: 12px;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
`,ek=Jr.div`
  margin-bottom: 15px;
`,tk=Jr.p`
  margin: 0 0 15px 0;
  font-size: 14px;
  line-height: 1.4;
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
`,nk=Jr.div`
  width: 100%;
  max-height: 600px;
  border-radius: 8px;
  overflow: hidden;
  background: #000;
`,rk=Jr.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 15px;
  padding-top: 15px;
  border-top: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,ik=Jr.div`
  display: flex;
  align-items: center;
  gap: 20px;
`,ok=Jr.button`
  background: none;
  border: none;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 14px;
  padding: 5px 10px;
  border-radius: 20px;
  transition: all 0.2s;

  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }

  &.liked {
    color: #ff6b6b;
  }

  &.saved {
    color: #4ecdc4;
  }
`,ak=Jr.h1`
  font-size: 28px;
  font-weight: 700;
  margin-bottom: 30px;
  text-align: center;
  background: linear-gradient(45deg, #ff6b6b, #4ecdc4);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,sk=Jr.p`
  text-align: center;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: 16px;
  margin-top: 50px;
`,lk=()=>{const{reels:t}=ef(),[n,r]=(0,e.useState)(new Set),[i,o]=(0,e.useState)(new Set);return(0,ti.jsxs)(Yw,{children:[(0,ti.jsx)(ak,{children:"Reels"}),t.map(e=>(0,ti.jsxs)(Kw,{children:[(0,ti.jsxs)(Gw,{children:[(0,ti.jsx)(Xw,{children:e.title.charAt(0).toUpperCase()}),(0,ti.jsxs)(Qw,{children:[(0,ti.jsx)(Jw,{children:e.title}),(0,ti.jsx)(Zw,{children:e.createdAt.toLocaleDateString()})]})]}),(0,ti.jsxs)(ek,{children:[e.description&&(0,ti.jsx)(tk,{children:e.description}),(0,ti.jsx)(nk,{children:(0,ti.jsx)(qw,{mediaItem:{id:e.id,title:e.description||"Video",src:e.src,type:"video",duration:e.duration,thumbnail:e.thumbnail,createdAt:e.createdAt,views:e.views||0,likes:e.likes||0},autoPlay:!1,showControls:!0})})]}),(0,ti.jsxs)(rk,{children:[(0,ti.jsxs)(ik,{children:[(0,ti.jsxs)(ok,{className:n.has(e.id)?"liked":"",onClick:()=>{return t=e.id,void r(e=>{const n=new Set(e);return n.has(t)?n.delete(t):n.add(t),n});var t},children:[n.has(e.id)?"\u2764\ufe0f":"\ud83e\udd0d"," ",(e.likes||0)+(n.has(e.id)?1:0)]}),(0,ti.jsx)(ok,{onClick:()=>(e=>{navigator.share?navigator.share({title:`Check out this reel: ${e.title}`,text:e.description,url:window.location.href}):(navigator.clipboard.writeText(window.location.href),alert("Link copied to clipboard!"))})(e),children:"\ud83d\udce4 Share"})]}),(0,ti.jsxs)(ok,{className:i.has(e.id)?"saved":"",onClick:()=>{return t=e.id,void o(e=>{const n=new Set(e);return n.has(t)?n.delete(t):n.add(t),n});var t},children:[i.has(e.id)?"\ud83d\udd16":"\ud83d\udccc"," Save"]})]})]},e.id)),0===t.length&&(0,ti.jsx)(sk,{children:"No reels available. Create your first reel!"})]})},ck=Si("headphones",[["path",{d:"M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3",key:"1xhozi"}]]),uk=[{id:1,title:"Stellar Beats",artist:"DJ Nova",likes:4200,url:"https://www.soundjay.com/misc/sounds/bell-ringing-05.wav"},{id:2,title:"Cosmic Vibes",artist:"Lunar Waves",likes:3100,url:"https://www.soundjay.com/misc/sounds/clock-ticking-5.wav"},{id:3,title:"Galactic Groove",artist:"Starry Night",likes:2800,url:"https://www.soundjay.com/misc/sounds/fail-buzzer-02.wav"},{id:4,title:"Interstellar Jam",artist:"Celestial Rhythms",likes:2500,url:"https://www.soundjay.com/misc/sounds/bell-ringing-05.wav"},{id:5,title:"Astro Beat",artist:"Space Cadet",likes:1900,url:"https://www.soundjay.com/misc/sounds/clock-ticking-5.wav"}],dk=Jr.div`
  padding: 32px 16px;
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  min-height: 100vh;
`,hk=Jr.div`
  text-align: center;
  margin-bottom: 48px;
`,pk=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,mk=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  max-width: 600px;
  margin: 0 auto;
`,fk=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 24px;
  margin-top: 32px;
`,gk=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  padding: 20px;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 16px;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
`,yk=Jr.div`
  flex: 1;
`,xk=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 4px;
`,vk=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  margin-bottom: 8px;
`,bk=Jr.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,wk=Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  display: flex;
  align-items: center;
  gap: 4px;
`,kk=()=>{const{playTrack:e,currentTrack:t,isPlaying:n,addToPlaylist:r}=Om();return(0,ti.jsxs)(dk,{children:[(0,ti.jsxs)(hk,{children:[(0,ti.jsxs)(pk,{children:[(0,ti.jsx)(op,{size:32}),"Tune In to Your Music"]}),(0,ti.jsx)(mk,{children:"Discover and listen to the latest tracks from your favorite artists"})]}),(0,ti.jsx)(fk,{children:uk.map(i=>(0,ti.jsxs)(gk,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*i.id},children:[(0,ti.jsx)(ck,{size:42,color:"#888888"}),(0,ti.jsxs)(yk,{children:[(0,ti.jsx)(xk,{children:i.title}),(0,ti.jsx)(vk,{children:i.artist})]}),(0,ti.jsxs)(bk,{children:[(0,ti.jsx)(hp,{size:20,color:(null===t||void 0===t?void 0:t.id)===i.id.toString()&&n?"#ff6b6b":"#3f51b5",cursor:"pointer",onClick:()=>(t=>{const n={id:t.id.toString(),title:t.title,artist:t.artist,duration:"3:45",url:t.url};e(n),r(n)})(i)}),(0,ti.jsxs)(wk,{children:[(0,ti.jsx)(gp,{size:16}),i.likes]})]})]},i.id))})]})},Sk=Si("flame",[["path",{d:"M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z",key:"96xj49"}]]),jk=Jr.div`
  padding: 32px 16px;
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  min-height: 100vh;
`,$k=Jr.div`
  text-align: center;
  margin-bottom: 48px;
`,Ck=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 16px;
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
`,Ek=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  max-width: 600px;
  margin: 0 auto;
`,Tk=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 24px;
  margin-bottom: 48px;
`,Pk=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  overflow: hidden;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
`,zk=Jr.img`
  width: 100%;
  height: 200px;
  object-fit: cover;
`,Ak=Jr.div`
  padding: 20px;
`,Rk=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 8px;
`,Mk=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  margin-bottom: 12px;
`,Lk=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`,Dk=Jr.div`
  display: flex;
  align-items: center;
  gap: 4px;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,Ok=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: 32px;
  max-width: 500px;
  margin: 0 auto;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(3,t)}};
`,Fk=Jr.h2`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 16px;
  text-align: center;
`,Nk=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  text-align: center;
  margin-bottom: 24px;
`,_k=Jr.form`
  display: flex;
  flex-direction: column;
  gap: 16px;
`,Ik=Jr.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,Vk=Jr.label`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
`,Bk=Jr.input`
  padding: 12px 16px;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  transition: border-color 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,Wk=Jr(dh.button)`
  padding: 12px 24px;
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
  color: white;
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  margin-top: 8px;
`,Hk=[{id:1,title:"AI-Powered Social Features",description:"Experience the future of social interaction with our new AI-powered features.",image:ug,views:"12.5K",likes:"2.1K"},{id:2,title:"Virtual Reality Meetups",description:"Join virtual reality meetups with friends and meet new people in immersive spaces.",image:dg,views:"8.7K",likes:"1.8K"},{id:3,title:"Crypto Integration",description:"Seamlessly integrate cryptocurrency payments and NFT collections.",image:hg,views:"15.2K",likes:"3.4K"},{id:4,title:"Live Streaming Events",description:"Host and attend live streaming events with interactive features.",image:pg,views:"9.8K",likes:"2.7K"},{id:5,title:"Creative Collaboration",description:"Collaborate on creative projects with artists and creators worldwide.",image:mg,views:"6.3K",likes:"1.9K"},{id:6,title:"Personalized Content",description:"Discover personalized content tailored to your interests and preferences.",image:fg,views:"11.1K",likes:"2.8K"}],Uk=()=>{const[t,n]=(0,e.useState)({name:"",email:"",photo:""}),r=e=>{const{name:t,value:r}=e.target;n(e=>({...e,[t]:r}))};return(0,ti.jsxs)(jk,{children:[(0,ti.jsxs)($k,{children:[(0,ti.jsxs)(Ck,{children:[(0,ti.jsx)(dp,{size:32}),"Trending Now"]}),(0,ti.jsx)(Ek,{children:"Discover what's hot and trending in the Astra community"})]}),(0,ti.jsx)(Tk,{children:Hk.map((e,t)=>(0,ti.jsxs)(Pk,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*t},children:[(0,ti.jsx)(zk,{src:e.image,alt:e.title}),(0,ti.jsxs)(Ak,{children:[(0,ti.jsx)(Rk,{children:e.title}),(0,ti.jsx)(Mk,{children:e.description}),(0,ti.jsxs)(Lk,{children:[(0,ti.jsxs)(Dk,{children:[(0,ti.jsx)($i,{size:16}),e.views]}),(0,ti.jsxs)(Dk,{children:[(0,ti.jsx)(xf,{size:16}),e.likes]}),(0,ti.jsxs)(Dk,{children:[(0,ti.jsx)(Sk,{size:16}),"Hot"]})]})]})]},e.id))}),(0,ti.jsxs)(Ok,{children:[(0,ti.jsx)(Fk,{children:"Join the Trending Community"}),(0,ti.jsx)(Nk,{children:"Register to participate in trending discussions and share your content"}),(0,ti.jsxs)(_k,{onSubmit:e=>{e.preventDefault(),console.log("Registration data:",t),alert("Registration successful! Welcome to trending!"),n({name:"",email:"",photo:""})},children:[(0,ti.jsxs)(Ik,{children:[(0,ti.jsx)(Vk,{htmlFor:"name",children:"Full Name"}),(0,ti.jsx)(Bk,{id:"name",type:"text",placeholder:"Enter your full name",name:"name",value:t.name,onChange:r,required:!0})]}),(0,ti.jsxs)(Ik,{children:[(0,ti.jsx)(Vk,{htmlFor:"email",children:"Email Address"}),(0,ti.jsx)(Bk,{id:"email",type:"email",placeholder:"Enter your email address",name:"email",value:t.email,onChange:r,required:!0})]}),(0,ti.jsxs)(Ik,{children:[(0,ti.jsx)(Vk,{htmlFor:"photo",children:"Profile Photo URL"}),(0,ti.jsx)(Bk,{id:"photo",type:"url",placeholder:"Add your profile photo URL",name:"photo",value:t.photo,onChange:r})]}),(0,ti.jsxs)(Wk,{whileHover:{scale:1.02},whileTap:{scale:.98},type:"submit",children:[(0,ti.jsx)(lm,{size:18}),"Join Trending"]})]})]})]})},qk=Jr.div`
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
`,Yk=Jr.h1`
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  margin-bottom: 20px;
`,Kk=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 20px;
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,Gk=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.secondary}}20;
  border-radius: 8px;
  padding: 40px;
  text-align: center;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  margin-bottom: 20px;
`,Xk=Jr.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
`,Qk=Jr.h3`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin: 0;
`,Jk=Jr.span`
  color: ${e=>{let{theme:t}=e;return t.colors.error}};
  font-weight: bold;
`,Zk=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  margin: 0;
`,eS=()=>(0,ti.jsxs)(qk,{children:[(0,ti.jsx)(Yk,{children:"\ud83d\udd34 Live Streams"}),(0,ti.jsxs)(Kk,{children:[(0,ti.jsxs)(Gk,{children:["\ud83c\udfa5 Live streaming feature coming soon!",(0,ti.jsx)("br",{}),"Watch live content from your favorite creators"]}),(0,ti.jsxs)(Xk,{children:[(0,ti.jsx)(Qk,{children:"Featured Live Stream"}),(0,ti.jsx)(Jk,{children:"\u25cf 1,234 watching"})]}),(0,ti.jsx)(Zk,{children:"Join the live conversation and interact with streamers in real-time"})]}),(0,ti.jsxs)(Kk,{children:[(0,ti.jsxs)(Gk,{children:["\ud83d\udcfa Start your own live stream",(0,ti.jsx)("br",{}),"Share your moments with the world"]}),(0,ti.jsxs)(Xk,{children:[(0,ti.jsx)(Qk,{children:"Go Live"}),(0,ti.jsx)(Jk,{children:"\u25cf Ready to stream"})]}),(0,ti.jsx)(Zk,{children:"Click to start broadcasting to your followers"})]})]}),tS=Si("share",[["path",{d:"M12 2v13",key:"1km8f5"}],["path",{d:"m16 6-4-4-4 4",key:"13yo43"}],["path",{d:"M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8",key:"1b2hhj"}]]),nS=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(1,t)}};
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  
  &:hover {
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(3,t)}};
    transform: translateY(-2px);
  }
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: ${e=>{let{theme:t}=e;return t.colors.gradient}};
    opacity: 0;
    transition: opacity 0.3s ease;
  }
  
  &:hover::before {
    opacity: 1;
  }
`,rS=Jr.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,iS=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.sm}};
`,oS=Jr.img`
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,aS=Jr.div`
  display: flex;
  flex-direction: column;
`,sS=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  span {
    font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
    color: ${e=>{let{theme:t}=e;return t.colors.text}};
  }
`,lS=Jr.div`
  width: 16px;
  height: 16px;
  background: ${e=>{let{theme:t}=e;return t.colors.primary}};
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 10px;
`,cS=Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,uS=(Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,Jr.button`
  background: none;
  border: none;
  padding: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  border-radius: 50%;
  cursor: pointer;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  transition: all 0.2s ease;
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  }
`),dS=Jr.div`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  line-height: 1.6;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
`,hS=Jr.img`
  width: 100%;
  max-height: 400px;
  object-fit: cover;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,pS=Jr.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-top: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  padding-top: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,mS=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.lg}};
`,fS=Jr.button`
  background: none;
  border: none;
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.xs}} ${e=>{let{theme:t}=e;return t.spacing.sm}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  cursor: pointer;
  transition: all 0.2s ease;
  color: ${e=>{let{theme:t,$active:n}=e;return n?t.colors.primary:t.colors.textSecondary}};
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  }
  
  svg {
    width: 18px;
    height: 18px;
  }
  
  span {
    font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
    font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  }
`,gS=Jr.button`
  background: none;
  border: none;
  padding: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  border-radius: 50%;
  cursor: pointer;
  transition: all 0.2s ease;
  color: ${e=>{let{theme:t,$active:n}=e;return n?t.colors.primary:t.colors.textSecondary}};
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
`,yS=t=>{let{id:n,author:r,content:i,image:o,timestamp:a,likes:s,comments:l,shares:c,liked:u=!1,bookmarked:d=!1}=t;const[h,p]=(0,e.useState)(u),[m,f]=(0,e.useState)(d),[g,y]=(0,e.useState)(s);return(0,ti.jsxs)(nS,{children:[(0,ti.jsxs)(rS,{children:[(0,ti.jsxs)(iS,{children:[(0,ti.jsx)(oS,{src:r.avatar,alt:r.name}),(0,ti.jsxs)(aS,{children:[(0,ti.jsxs)(sS,{children:[(0,ti.jsx)("span",{children:r.name}),r.verified&&(0,ti.jsx)(lS,{children:"\u2713"})]}),(0,ti.jsxs)(cS,{children:["@",r.username," \u2022 ",a]})]})]}),(0,ti.jsx)(uS,{children:(0,ti.jsx)(Jb,{})})]}),(0,ti.jsx)(dS,{children:i}),o&&(0,ti.jsx)(hS,{src:o,alt:"Post content"}),(0,ti.jsxs)(pS,{children:[(0,ti.jsxs)(mS,{children:[(0,ti.jsxs)(fS,{$active:h,onClick:()=>{p(!h),y(h?g-1:g+1)},children:[(0,ti.jsx)(gp,{fill:h?"currentColor":"none"}),(0,ti.jsx)("span",{children:g})]}),(0,ti.jsxs)(fS,{children:[(0,ti.jsx)(Ci,{}),(0,ti.jsx)("span",{children:l})]}),(0,ti.jsxs)(fS,{children:[(0,ti.jsx)(tS,{}),(0,ti.jsx)("span",{children:c})]})]}),(0,ti.jsx)(gS,{$active:m,onClick:()=>{f(!m)},children:(0,ti.jsx)(fp,{fill:m?"currentColor":"none"})})]})]})},xS=Si("image",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]]),vS=Si("smile",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M8 14s1.5 2 4 2 4-2 4-2",key:"1y1vjs"}],["line",{x1:"9",x2:"9.01",y1:"9",y2:"9",key:"yxxnd0"}],["line",{x1:"15",x2:"15.01",y1:"9",y2:"9",key:"1p4y9e"}]]),bS=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(1,t)}};
`,wS=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,kS=Jr.img`
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,SS=Jr.textarea`
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  resize: none;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  min-height: 80px;
  font-family: inherit;
  
  &::placeholder {
    color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  }
`,jS=Jr.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-top: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  padding-top: ${e=>{let{theme:t}=e;return t.spacing.md}};
  margin-top: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,$S=Jr.div`
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,CS=Jr.button`
  background: none;
  border: none;
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  cursor: pointer;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
`,ES=Jr.button`
  background: ${e=>{let{theme:t,$disabled:n}=e;return n?t.colors.textSecondary:t.colors.primary}};
  color: white;
  border: none;
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}} ${e=>{let{theme:t}=e;return t.spacing.lg}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  cursor: ${e=>{let{$disabled:t}=e;return t?"not-allowed":"pointer"}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  &:hover {
    opacity: ${e=>{let{$disabled:t}=e;return t?.5:.9}};
  }
  
  svg {
    width: 16px;
    height: 16px;
  }
`,TS=Jr.div`
  color: ${e=>{let{theme:t,$isOverLimit:n}=e;return n?t.colors.error:t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  margin-right: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,PS=Jr.div`
  position: relative;
  margin-top: ${e=>{let{theme:t}=e;return t.spacing.md}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  overflow: hidden;
`,zS=Jr.img`
  width: 100%;
  max-height: 300px;
  object-fit: cover;
`,AS=Jr.button`
  position: absolute;
  top: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  right: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  background: rgba(0, 0, 0, 0.7);
  color: white;
  border: none;
  border-radius: 50%;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    background: rgba(0, 0, 0, 0.9);
  }
`,RS=Jr.input`
  display: none;
`,MS=t=>{let{onPost:n}=t;const[r,i]=(0,e.useState)(""),[o,a]=(0,e.useState)(null),[s,l]=(0,e.useState)(null),c=r.length>280,u=(r.trim()||o)&&!c;return(0,ti.jsxs)(bS,{children:[(0,ti.jsxs)(wS,{children:[(0,ti.jsx)(kS,{src:hh,alt:"Your Avatar"}),(0,ti.jsx)(SS,{placeholder:"What's happening in the Astra universe?",value:r,onChange:e=>i(e.target.value),maxLength:330})]}),s&&(0,ti.jsxs)(PS,{children:[(0,ti.jsx)(zS,{src:s,alt:"Preview"}),(0,ti.jsx)(AS,{onClick:()=>{a(null),l(null)},children:"\xd7"})]}),(0,ti.jsxs)(jS,{children:[(0,ti.jsxs)($S,{children:[(0,ti.jsxs)(CS,{onClick:()=>{var e;return null===(e=document.getElementById("image-input"))||void 0===e?void 0:e.click()},children:[(0,ti.jsx)(xS,{}),(0,ti.jsx)("span",{children:"Photo"})]}),(0,ti.jsxs)(CS,{children:[(0,ti.jsx)(ip,{}),(0,ti.jsx)("span",{children:"Video"})]}),(0,ti.jsxs)(CS,{children:[(0,ti.jsx)(am,{}),(0,ti.jsx)("span",{children:"Event"})]}),(0,ti.jsxs)(CS,{children:[(0,ti.jsx)(sm,{}),(0,ti.jsx)("span",{children:"Location"})]}),(0,ti.jsxs)(CS,{children:[(0,ti.jsx)(vS,{}),(0,ti.jsx)("span",{children:"Mood"})]})]}),(0,ti.jsxs)("div",{style:{display:"flex",alignItems:"center"},children:[(0,ti.jsx)(TS,{$isOverLimit:c,children:280-r.length}),(0,ti.jsxs)(ES,{$disabled:!u,onClick:()=>{(r.trim()||o)&&(null===n||void 0===n||n(r,o||void 0),i(""),a(null),l(null))},children:[(0,ti.jsx)(Vg,{}),"Post"]})]})]}),(0,ti.jsx)(RS,{id:"image-input",type:"file",accept:"image/*",onChange:e=>{var t;const n=null===(t=e.target.files)||void 0===t?void 0:t[0];if(n){a(n);const e=new FileReader;e.onload=e=>{var t;l(null===(t=e.target)||void 0===t?void 0:t.result)},e.readAsDataURL(n)}}})]})},LS=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(1,t)}};
  overflow-x: auto;
  
  &::-webkit-scrollbar {
    height: 4px;
  }
  
  &::-webkit-scrollbar-track {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
    border-radius: 2px;
  }
  
  &::-webkit-scrollbar-thumb {
    background: ${e=>{let{theme:t}=e;return t.colors.primary}};
    border-radius: 2px;
  }
`,DS=Jr.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.md}};
`,OS=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.semibold}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin: 0;
`,FS=Jr.div`
  display: flex;
  gap: ${e=>{let{theme:t}=e;return t.spacing.md}};
  padding-bottom: ${e=>{let{theme:t}=e;return t.spacing.xs}};
`,NS=Jr.div`
  position: relative;
  min-width: 80px;
  height: 120px;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s ease;
  
  ${e=>{let{$isAddStory:t,theme:n}=e;return t?`\n    background: ${n.colors.backgroundSecondary};\n    border: 2px dashed ${n.colors.border};\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    justify-content: center;\n    \n    &:hover {\n      border-color: ${n.colors.primary};\n      background: ${n.colors.primary}10;\n    }\n  `:`\n    background: linear-gradient(45deg, ${n.colors.primary}, ${n.colors.secondary});\n    padding: 2px;\n    \n    &:hover {\n      transform: scale(1.05);\n    }\n  `}}
`,_S=Jr.div`
  width: 100%;
  height: 100%;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  overflow: hidden;
  position: relative;
`,IS=Jr.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
`,VS=Jr.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));
  padding: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
`,BS=Jr.img`
  width: 32px;
  height: 32px;
  border-radius: 50%;
  border: 2px solid white;
  object-fit: cover;
`,WS=Jr.span`
  color: white;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.5);
`,HS=Jr.div`
  width: 40px;
  height: 40px;
  background: ${e=>{let{theme:t}=e;return t.colors.primary}};
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  
  svg {
    width: 20px;
    height: 20px;
  }
`,US=Jr.span`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  text-align: center;
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
`,qS=Jr.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 32px;
  height: 32px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.2s ease;
  
  svg {
    width: 16px;
    height: 16px;
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    margin-left: 2px;
  }
  
  ${NS}:hover & {
    opacity: 1;
  }
`,YS=Jr.div`
  position: absolute;
  top: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  right: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  background: rgba(0, 0, 0, 0.5);
  color: white;
  padding: 2px 6px;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.full}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
`,KS=()=>{const[t]=(0,e.useState)([{id:"1",user:{name:"Alex Thompson",username:"alexthompson",avatar:Ky},image:Gy,timestamp:"2h",views:234,isViewed:!1},{id:"2",user:{name:"Sarah Chen",username:"sarahchen",avatar:Xy},image:Qy,timestamp:"4h",views:189,isViewed:!0},{id:"3",user:{name:"Michael Rodriguez",username:"mikerodriguez",avatar:Jy},image:Ky,timestamp:"6h",views:456,isViewed:!1},{id:"4",user:{name:"Emma Wilson",username:"emmawilson",avatar:Gy},image:Xy,timestamp:"8h",views:123,isViewed:!0},{id:"5",user:{name:"David Kim",username:"davidkim",avatar:Qy},image:Jy,timestamp:"10h",views:567,isViewed:!1}]);return(0,ti.jsxs)(LS,{children:[(0,ti.jsx)(DS,{children:(0,ti.jsx)(OS,{children:"Stories"})}),(0,ti.jsxs)(FS,{children:[(0,ti.jsxs)(NS,{$isAddStory:!0,onClick:()=>{console.log("Add story clicked")},children:[(0,ti.jsx)(HS,{children:(0,ti.jsx)(cg,{})}),(0,ti.jsx)(US,{children:"Add Story"})]}),t.map(e=>(0,ti.jsx)(NS,{onClick:()=>(e=>{console.log("Story clicked:",e)})(e),children:(0,ti.jsxs)(_S,{children:[(0,ti.jsx)(IS,{src:e.image,alt:`${e.user.name}'s story`}),(0,ti.jsx)(YS,{children:e.views}),(0,ti.jsx)(qS,{children:(0,ti.jsx)(hp,{})}),(0,ti.jsxs)(VS,{children:[(0,ti.jsx)(BS,{src:e.user.avatar,alt:e.user.name}),(0,ti.jsx)(WS,{children:e.user.name})]})]})},e.id))]})]})},GS=Jr.div`
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
`,XS=Jr.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`,QS=Jr.div`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: 12px;
  padding: 20px;
  text-align: center;
  border: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,JS=Jr.h2`
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  margin-bottom: 10px;
`,ZS=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  margin: 0;
`,ej=()=>(0,ti.jsx)(GS,{children:(0,ti.jsxs)(XS,{children:[(0,ti.jsxs)(QS,{children:[(0,ti.jsx)(JS,{children:"Welcome to ASTRA"}),(0,ti.jsx)(ZS,{children:"Connect, share, and discover amazing content from your community"})]}),(0,ti.jsx)(KS,{}),(0,ti.jsx)(MS,{}),[{id:"1",author:{name:"John Doe",username:"@johndoe",avatar:"/assets/images/avatar1.jpg"},content:"Just launched my new project! Excited to share it with the ASTRA community \ud83d\ude80",timestamp:"2 hours ago",likes:42,comments:8,shares:12,bookmarks:5,image:"/assets/images/content1.jpg"},{id:"2",author:{name:"Jane Smith",username:"@janesmith",avatar:"/assets/images/avatar2.jpg"},content:"Beautiful sunset today! Nature never fails to amaze me \ud83c\udf05",timestamp:"4 hours ago",likes:128,comments:23,shares:34,bookmarks:15,image:"/assets/images/content2.jpg"},{id:"3",author:{name:"Alex Johnson",username:"@alexj",avatar:"/assets/images/avatar3.jpg"},content:"Working on some exciting features for the next update. Can't wait to show you all! \ud83d\udcbb",timestamp:"6 hours ago",likes:89,comments:12,shares:8,bookmarks:7}].map(e=>(0,ti.jsx)(yS,{...e},e.id))]})}),tj=Jr.div`
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
  text-align: center;
`,nj=Jr.h1`
  font-size: 24px;
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
`,rj=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
`,ij=()=>(0,ti.jsxs)(tj,{children:[(0,ti.jsx)(nj,{children:"Your Saved Posts"}),(0,ti.jsx)(rj,{children:"Here you'll find all the posts you've saved for later. Enjoy exploring your favorite content!"})]}),oj=Jr.div`
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
  text-align: center;
`,aj=Jr.h1`
  font-size: 24px;
  color: ${e=>{let{theme:t}=e;return t.colors.primary}};
`,sj=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
`,lj=()=>(0,ti.jsxs)(oj,{children:[(0,ti.jsx)(aj,{children:"Your Liked Posts"}),(0,ti.jsx)(sj,{children:"Here you'll find all the posts you've liked. Great memories and content await!"})]}),cj=Jr.div`
  padding: ${e=>{let{theme:t}=e;return t.spacing.xl}} ${e=>{let{theme:t}=e;return t.spacing.lg}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  min-height: 80vh;
`,uj=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.lg}};
  animation: fadeIn 0.8s ease-out;
`,dj=Jr.section`
  margin-bottom: ${e=>{let{theme:t}=e;return t.spacing.xxl}};
`,hj=()=>{const{user:t}=Ch(),{preferences:n}=of(),{wallet:r}=(()=>{const t=(0,e.useContext)(lf);if(!t)throw new Error("useWallet must be used within a WalletProvider");return t})();e.useEffect(()=>{t&&console.log("User logged in:",t),n&&console.log("User preferences:",n),r&&console.log("Wallet connected:",r)},[t,n,r]);const i=[{id:"1",author:{name:"Alex Thompson",username:"alexthompson",avatar:Ky,verified:!0},content:"Just discovered this amazing new blockchain technology! The future is here \ud83d\ude80 #BlockchainRevolution #Web3",image:Gy,timestamp:"2h",likes:234,comments:56,shares:12,liked:!1,bookmarked:!1},{id:"2",author:{name:"Sarah Chen",username:"sarahchen",avatar:Xy},content:"Building the future of social media with Astra! Can't wait to see what the community creates together \ud83d\udcab",image:null,timestamp:"4h",likes:189,comments:43,shares:8,liked:!0,bookmarked:!0},{id:"3",author:{name:"Michael Rodriguez",username:"mikerodriguez",avatar:Ky,verified:!1},content:"Amazing sunset from my hike today! Nature never fails to inspire creativity \ud83c\udf05 #Photography #Nature",image:Xy,timestamp:"6h",likes:456,comments:78,shares:23,liked:!1,bookmarked:!1}];return(0,ti.jsxs)(cj,{children:[(0,ti.jsx)(uj,{children:"Welcome to Astra Social Space \ud83c\udf1f"}),(0,ti.jsx)(KS,{}),(0,ti.jsx)(MS,{onPost:(e,t)=>{console.log("New post created:",{content:e,image:t})}}),(0,ti.jsx)(dj,{children:i.map(e=>(0,ti.jsx)(yS,{...e},e.id))})]})},pj=Si("link",[["path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",key:"1cjeqo"}],["path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",key:"19qd67"}]]),mj=Si("pen-line",[["path",{d:"M12 20h9",key:"t2du7b"}],["path",{d:"M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z",key:"1ykcvy"}]]),fj=Si("grid-3x3",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M3 15h18",key:"5xshup"}],["path",{d:"M9 3v18",key:"fh3hqa"}],["path",{d:"M15 3v18",key:"14nvp0"}]]),gj=Si("tag",[["path",{d:"M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",key:"vktsd0"}],["circle",{cx:"7.5",cy:"7.5",r:".5",fill:"currentColor",key:"kqv944"}]]),yj=Si("share-2",[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]]),xj=n.p+"static/media/img (9).bd52ca20194a81a71681.jpg",vj=Jr.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 32px 16px;
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  min-height: 100vh;
`,bj=Jr.div`
  display: flex;
  gap: 32px;
  margin-bottom: 32px;
  padding: 32px;
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.xl}};
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  
  @media (max-width: 768px) {
    flex-direction: column;
    text-align: center;
    gap: 24px;
  }
`,wj=Jr.div`
  position: relative;
  flex-shrink: 0;
`,kj=Jr.img`
  width: 150px;
  height: 150px;
  border-radius: 50%;
  object-fit: cover;
  border: 4px solid ${e=>{let{theme:t}=e;return t.colors.primary}};
`,Sj=Jr.button`
  position: absolute;
  bottom: 10px;
  right: 10px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: ${e=>{let{theme:t}=e;return t.colors.primary}};
  color: white;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  
  &:hover {
    transform: scale(1.1);
  }
`,jj=Jr.div`
  flex: 1;
`,$j=Jr.h1`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.heading}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 12px;
`,Cj=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.lg}};
  margin-bottom: 16px;
`,Ej=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  line-height: 1.5;
  margin-bottom: 16px;
  max-width: 500px;
`,Tj=Jr.div`
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 16px;
  
  @media (max-width: 768px) {
    justify-content: center;
  }
`,Pj=Jr.div`
  display: flex;
  align-items: center;
  gap: 8px;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,zj=Jr.div`
  display: flex;
  gap: 32px;
  margin-bottom: 24px;
  
  @media (max-width: 768px) {
    justify-content: center;
  }
`,Aj=Jr.div`
  text-align: center;
  cursor: pointer;
  transition: transform 0.2s ease;
  
  &:hover {
    transform: scale(1.05);
  }
`,Rj=Jr.h3`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 4px;
`,Mj=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,Lj=Jr.div`
  display: flex;
  gap: 12px;
  
  @media (max-width: 768px) {
    justify-content: center;
  }
`,Dj=Jr(dh.button)`
  padding: 12px 24px;
  border: none;
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.primary}};
  color: white;
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.3s ease;
  
  &:hover {
    opacity: 0.9;
  }
`,Oj=Jr(Dj)`
  background: transparent;
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  
  &:hover {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  }
`,Fj=Jr.div`
  margin-bottom: 32px;
`,Nj=Jr.h2`
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xl}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  gap: 8px;
`,_j=Jr.div`
  display: flex;
  gap: 16px;
  overflow-x: auto;
  padding: 16px 0;
  
  &::-webkit-scrollbar {
    height: 6px;
  }
  
  &::-webkit-scrollbar-track {
    background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
    border-radius: 3px;
  }
  
  &::-webkit-scrollbar-thumb {
    background: ${e=>{let{theme:t}=e;return t.colors.border}};
    border-radius: 3px;
  }
`,Ij=Jr.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  min-width: 80px;
  cursor: pointer;
  transition: transform 0.2s ease;
  
  &:hover {
    transform: scale(1.05);
  }
`,Vj=Jr.img`
  width: 70px;
  height: 70px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid ${e=>{let{theme:t}=e;return t.colors.primary}};
`,Bj=Jr.p`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.xs}};
  text-align: center;
  max-width: 70px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`,Wj=Jr.div`
  width: 70px;
  height: 70px;
  border-radius: 50%;
  border: 3px dashed ${e=>{let{theme:t}=e;return t.colors.border}};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,Hj=Jr.div`
  display: flex;
  justify-content: center;
  gap: 32px;
  margin-bottom: 32px;
  border-bottom: 1px solid ${e=>{let{theme:t}=e;return t.colors.border}};
`,Uj=Jr.button`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 16px 0;
  border: none;
  background: none;
  color: ${e=>{let{active:t,theme:n}=e;return t?n.colors.primary:n.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
  cursor: pointer;
  position: relative;
  transition: color 0.3s ease;
  
  &::after {
    content: '';
    position: absolute;
    bottom: -1px;
    left: 0;
    right: 0;
    height: 2px;
    background: ${e=>{let{theme:t}=e;return t.colors.primary}};
    transform: ${e=>{let{active:t}=e;return t?"scaleX(1)":"scaleX(0)"}};
    transition: transform 0.3s ease;
  }
  
  &:hover {
    color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,qj=Jr.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 24px;
`,Yj=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  overflow: hidden;
  box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(2,t)}};
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-5px);
    box-shadow: ${e=>{let{theme:t}=e;return t.createShadow(4,t)}};
  }
`,Kj=Jr.img`
  width: 100%;
  height: 200px;
  object-fit: cover;
`,Gj=Jr.div`
  padding: 16px;
`,Xj=Jr.div`
  display: flex;
  justify-content: space-between;
  color: ${e=>{let{theme:t}=e;return t.colors.textSecondary}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
`,Qj=Jr(dh.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  padding: 20px;
`,Jj=Jr(dh.div)`
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.lg}};
  padding: 32px;
  width: 100%;
  max-width: 500px;
  max-height: 80vh;
  overflow-y: auto;
`,Zj=Jr.form`
  display: flex;
  flex-direction: column;
  gap: 20px;
`,e$=Jr.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,t$=Jr.label`
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.sm}};
  font-weight: ${e=>{let{theme:t}=e;return t.typography.fontWeights.medium}};
`,n$=Jr.input`
  padding: 12px 16px;
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  transition: border-color 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,r$=Jr.textarea`
  padding: 12px 16px;
  border: 2px solid ${e=>{let{theme:t}=e;return t.colors.border}};
  border-radius: ${e=>{let{theme:t}=e;return t.borderRadius.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.backgroundSecondary}};
  color: ${e=>{let{theme:t}=e;return t.colors.text}};
  font-size: ${e=>{let{theme:t}=e;return t.typography.fontSizes.md}};
  resize: vertical;
  min-height: 100px;
  font-family: inherit;
  transition: border-color 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: ${e=>{let{theme:t}=e;return t.colors.primary}};
  }
`,i$=Jr.div`
  display: flex;
  gap: 12px;
  justify-content: flex-end;
`,o$=Jr.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: ${e=>{let{theme:t}=e;return t.colors.primary}};
  color: white;
`,a$=Jr(dh.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.95);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 3000;
  padding: 20px;
`,s$=Jr.div`
  display: flex;
  max-width: 1200px;
  width: 100%;
  height: 90vh;
  gap: 20px;
  
  @media (max-width: 768px) {
    flex-direction: column;
    height: 100vh;
  }
`,l$=Jr.div`
  flex: 1;
  max-width: 500px;
  position: relative;
  background: #000;
  border-radius: 16px;
  overflow: hidden;
  
  @media (max-width: 768px) {
    max-width: 100%;
  }
`,c$=Jr.video`
  width: 100%;
  height: 100%;
  object-fit: cover;
`,u$=Jr.div`
  position: absolute;
  bottom: 20px;
  left: 20px;
  right: 80px;
  color: white;
  z-index: 10;
`,d$=Jr.div`
  position: absolute;
  bottom: 20px;
  right: 20px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  align-items: center;
  color: white;
  z-index: 10;
`,h$=Jr.button`
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  padding: 12px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.1);
  }
`,p$=Jr.div`
  flex: 1;
  background: ${e=>{let{theme:t}=e;return t.colors.surface}};
  border-radius: 16px;
  padding: 24px;
  overflow-y: auto;
  
  @media (max-width: 768px) {
    flex: none;
    height: 200px;
  }
`,m$=Jr.button`
  position: absolute;
  top: 20px;
  right: 20px;
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  padding: 10px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 20;
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(255, 255, 255, 0.3);
  }
`,f$=(Jr(dh.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.95);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 3000;
  padding: 20px;
`,Jr.div`
  position: relative;
  max-width: 400px;
  width: 100%;
  height: 80vh;
  background: #000;
  border-radius: 16px;
  overflow: hidden;
`,Jr.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
`,Jr.div`
  position: absolute;
  top: 16px;
  left: 16px;
  right: 16px;
  display: flex;
  gap: 4px;
  z-index: 10;
`,Jr.div`
  flex: 1;
  height: 3px;
  background: rgba(255, 255, 255, 0.3);
  border-radius: 2px;
  overflow: hidden;
  
  &::after {
    content: '';
    display: block;
    height: 100%;
    background: white;
    width: ${e=>{let{active:t,progress:n}=e;return t?`${n}%`:"0%"}};
    transition: width 0.1s linear;
  }
`,Jr.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  z-index: 5;
`,Jr.button`
  flex: 1;
  background: transparent;
  border: none;
  cursor: pointer;
  outline: none;
`,Jr.button`
  position: absolute;
  top: 16px;
  right: 16px;
  background: rgba(255, 255, 255, 0.2);
  border: none;
  color: white;
  padding: 8px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 20;
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(255, 255, 255, 0.3);
  }
`,Jr.div`
  position: absolute;
  bottom: 20px;
  left: 20px;
  right: 20px;
  color: white;
  z-index: 10;
`,Jr.h3`
  margin: 0 0 8px 0;
  font-size: 16px;
  font-weight: 600;
`,Jr.p`
  margin: 0;
  font-size: 12px;
  opacity: 0.8;
`,()=>{const[t,n]=(0,e.useState)("posts"),[r,i]=(0,e.useState)(!1),[o,a]=(0,e.useState)(!1),[s,l]=(0,e.useState)(!1),[c,u]=(0,e.useState)(!1),[d,h]=(0,e.useState)(!1),[p,m]=(0,e.useState)(!1),[f,g]=(0,e.useState)(!1),[y,x]=(0,e.useState)(!1),[v,b]=(0,e.useState)(null),[w,k]=(0,e.useState)(0),[S,j]=(0,e.useState)(!1),{user:$,updateUser:C}=Ch(),[E,T]=(0,e.useState)({name:(null===$||void 0===$?void 0:$.name)||"John Doe",username:(null===$||void 0===$?void 0:$.username)||"@johndoe",bio:"Digital creator & tech enthusiast. Building the future one line of code at a time. \ud83d\ude80\n\n\ud83d\udd17 Links: Instagram | YouTube | Twitter",location:"San Francisco, CA",website:"https://johndoe.dev",joinDate:"March 2020",verified:!0,verificationLevel:"blue",socialLinks:{instagram:"https://instagram.com/johndoe",twitter:"https://twitter.com/johndoe",youtube:"https://youtube.com/johndoe",facebook:"https://facebook.com/johndoe",website:"https://johndoe.dev"},businessInfo:{isBusinessAccount:!1,businessName:"",businessCategory:"",businessDescription:"",businessEmail:"",businessPhone:""}}),[P]=(0,e.useState)({posts:127,reels:45,followers:1250,following:384,stories:8,earnings:1250.75}),[z]=(0,e.useState)([{id:1,title:"Travel",image:tx},{id:2,title:"Code",image:xj},{id:3,title:"Food",image:ug}]),[A]=(0,e.useState)([{id:1,image:Gy,viewed:!1,timestamp:new Date},{id:2,image:Xy,viewed:!0,timestamp:new Date},{id:3,image:Qy,viewed:!1,timestamp:new Date}]),[R]=(0,e.useState)([{id:1,image:Gy,likes:45,comments:12,type:"image",tags:["travel","sunset","nature"]},{id:2,image:Xy,likes:78,comments:23,type:"image",tags:["code","programming","tech"]},{id:3,image:Qy,likes:92,comments:34,type:"image",tags:["food","cooking","recipe"]},{id:4,image:Jy,likes:156,comments:45,type:"image",tags:["fitness","workout","health"]},{id:5,image:Zy,likes:203,comments:67,type:"image",tags:["art","design","creative"]},{id:6,image:ex,likes:89,comments:21,type:"image",tags:["music","concert","live"]}]),[M]=(0,e.useState)([{id:1,video:Gy,likes:234,comments:45,views:5600,duration:"0:15",tags:["funny","viral","trending"]},{id:2,video:Xy,likes:456,comments:78,views:8900,duration:"0:30",tags:["tutorial","howto","tips"]},{id:3,video:Qy,likes:789,comments:123,views:12300,duration:"0:45",tags:["dance","music","entertainment"]},{id:4,video:Jy,likes:345,comments:67,views:6700,duration:"0:25",tags:["lifestyle","daily","vlog"]}]),[L]=(0,e.useState)([{id:1,image:Gy,likes:45,comments:12,taggedBy:"@friend1"},{id:2,image:Qy,likes:92,comments:34,taggedBy:"@friend2"},{id:3,image:Zy,likes:203,comments:67,taggedBy:"@friend3"}]),[D]=(0,e.useState)([{id:1,image:Xy,likes:78,comments:23},{id:2,image:Jy,likes:156,comments:45},{id:3,image:ex,likes:89,comments:21}]),[O]=(0,e.useState)([{id:1,image:Gy,likes:45,comments:12},{id:2,image:Qy,likes:92,comments:34},{id:3,image:Zy,likes:203,comments:67}]),[F]=(0,e.useState)({balance:1250.75,totalEarnings:5430.25,pendingPayments:125.5,transactions:[{id:1,type:"earning",amount:45,description:"Post monetization",date:"2024-01-15"},{id:2,type:"withdrawal",amount:-200,description:"Bank transfer",date:"2024-01-14"},{id:3,type:"earning",amount:78.5,description:"Reel bonus",date:"2024-01-13"}]}),[N]=(0,e.useState)({favorites:[{id:1,title:"Bohemian Rhapsody",artist:"Queen",genre:"Rock",duration:"5:55",album:"A Night at the Opera",year:"1975",image:Gy},{id:2,title:"Blinding Lights",artist:"The Weeknd",genre:"Pop",duration:"3:20",album:"After Hours",year:"2020",image:Xy},{id:3,title:"Hotel California",artist:"Eagles",genre:"Rock",duration:"6:30",album:"Hotel California",year:"1976",image:Qy},{id:4,title:"Shape of You",artist:"Ed Sheeran",genre:"Pop",duration:"3:53",album:"\xf7 (Divide)",year:"2017",image:Jy},{id:5,title:"Stairway to Heaven",artist:"Led Zeppelin",genre:"Rock",duration:"8:02",album:"Led Zeppelin IV",year:"1971",image:Zy},{id:6,title:"Imagine",artist:"John Lennon",genre:"Pop",duration:"3:03",album:"Imagine",year:"1971",image:ex},{id:7,title:"Billie Jean",artist:"Michael Jackson",genre:"Pop",duration:"4:54",album:"Thriller",year:"1982",image:Gy},{id:8,title:"Smells Like Teen Spirit",artist:"Nirvana",genre:"Grunge",duration:"5:01",album:"Nevermind",year:"1991",image:Xy},{id:9,title:"Hey Jude",artist:"The Beatles",genre:"Rock",duration:"7:11",album:"The Beatles (White Album)",year:"1968",image:Qy},{id:10,title:"Purple Rain",artist:"Prince",genre:"Rock",duration:"8:41",album:"Purple Rain",year:"1984",image:Jy},{id:11,title:"Like a Rolling Stone",artist:"Bob Dylan",genre:"Folk Rock",duration:"6:13",album:"Highway 61 Revisited",year:"1965",image:Zy},{id:12,title:"Sweet Child O Mine",artist:"Guns N Roses",genre:"Hard Rock",duration:"5:03",album:"Appetite for Destruction",year:"1987",image:ex},{id:13,title:"Watermelon Sugar",artist:"Harry Styles",genre:"Pop",duration:"2:54",album:"Fine Line",year:"2020",image:Gy},{id:14,title:"bad guy",artist:"Billie Eilish",genre:"Pop",duration:"3:14",album:"When We All Fall Asleep",year:"2019",image:Xy},{id:15,title:"Uptown Funk",artist:"Mark Ronson ft. Bruno Mars",genre:"Funk",duration:"4:30",album:"Uptown Special",year:"2014",image:Qy}],playlists:[{id:1,name:"Workout Hits",songCount:45,image:Gy,description:"High-energy tracks for your fitness routine"},{id:2,name:"Chill Vibes",songCount:32,image:Xy,description:"Relaxing songs for unwinding"},{id:3,name:"Road Trip",songCount:67,image:Qy,description:"Perfect tracks for long drives"},{id:4,name:"Party Mix",songCount:28,image:Jy,description:"Dance floor favorites"},{id:5,name:"Study Sessions",songCount:54,image:Zy,description:"Focus music for productivity"},{id:6,name:"Classic Rock",songCount:89,image:ex,description:"Timeless rock anthems"}],recentlyPlayed:[{id:1,title:"Levitating",artist:"Dua Lipa",genre:"Pop",duration:"3:23",album:"Future Nostalgia",year:"2020",image:Gy},{id:2,title:"Good 4 U",artist:"Olivia Rodrigo",genre:"Pop Rock",duration:"2:58",album:"SOUR",year:"2021",image:Xy},{id:3,title:"Stay",artist:"The Kid LAROI & Justin Bieber",genre:"Pop",duration:"2:21",album:"Stay",year:"2021",image:Qy},{id:4,title:"Heat Waves",artist:"Glass Animals",genre:"Indie Pop",duration:"3:58",album:"Dreamland",year:"2020",image:Jy},{id:5,title:"As It Was",artist:"Harry Styles",genre:"Pop",duration:"2:47",album:"Harrys House",year:"2022",image:Zy}]}),[_,I]=(0,e.useState)(null),[V,B]=(0,e.useState)(!1),[W,H]=(0,e.useState)(0),[U,q]=(0,e.useState)(0),[Y,K]=(0,e.useState)(.8),[G,X]=(0,e.useState)(!1),[Q,J]=(0,e.useState)(!1),[Z,ee]=(0,e.useState)(0),[te,ne]=(0,e.useState)(!1),[re,ie]=(0,e.useState)(N.favorites),[oe,ae]=(0,e.useState)(0),[se,le]=(0,e.useState)([]),[ce,ue]=(0,e.useState)(!1),de=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:N.favorites;I(e),ie(t),ae(t.findIndex(t=>t.id===e.id)),B(!0),ne(!0)},he=()=>{B(!V)},pe=()=>{let e=oe+1;if(e>=re.length&&(e=1===Z?0:oe),e!==oe){const t=re[e];I(t),ae(e),B(!0)}},me=()=>{let e=oe-1;if(e<0&&(e=1===Z?re.length-1:0),e!==oe){const t=re[e];I(t),ae(e),B(!0)}};return(0,ti.jsxs)(vj,{children:[(0,ti.jsxs)(bj,{children:[(0,ti.jsxs)(wj,{children:[(0,ti.jsx)(kj,{src:Ky,alt:"Profile"}),(0,ti.jsx)(Sj,{children:(0,ti.jsx)(lm,{size:20})})]}),(0,ti.jsxs)(jj,{children:[(0,ti.jsxs)($j,{children:[E.name,E.verified&&(0,ti.jsx)(o$,{children:(0,ti.jsx)(xf,{size:12})})]}),(0,ti.jsx)(Cj,{children:E.username}),(0,ti.jsx)(Ej,{children:E.bio}),(0,ti.jsxs)(Tj,{children:[(0,ti.jsxs)(Pj,{children:[(0,ti.jsx)(sm,{size:16}),E.location]}),(0,ti.jsxs)(Pj,{children:[(0,ti.jsx)(pj,{size:16}),E.website]}),(0,ti.jsxs)(Pj,{children:[(0,ti.jsx)(am,{size:16}),"Joined ",E.joinDate]})]}),(0,ti.jsxs)(zj,{children:[(0,ti.jsxs)(Aj,{children:[(0,ti.jsx)(Rj,{children:P.posts}),(0,ti.jsx)(Mj,{children:"Posts"})]}),(0,ti.jsxs)(Aj,{children:[(0,ti.jsx)(Rj,{children:P.followers}),(0,ti.jsx)(Mj,{children:"Followers"})]}),(0,ti.jsxs)(Aj,{children:[(0,ti.jsx)(Rj,{children:P.following}),(0,ti.jsx)(Mj,{children:"Following"})]})]}),(0,ti.jsxs)(Lj,{children:[(0,ti.jsxs)(Dj,{onClick:()=>i(!0),whileHover:{scale:1.02},whileTap:{scale:.98},children:[(0,ti.jsx)(mj,{size:16}),"Edit Profile"]}),(0,ti.jsxs)(Oj,{onClick:()=>a(!0),whileHover:{scale:1.02},whileTap:{scale:.98},children:[(0,ti.jsx)(yp,{size:16}),"Account Settings"]})]})]})]}),(0,ti.jsxs)(Fj,{children:[(0,ti.jsx)(Nj,{children:"Highlights"}),(0,ti.jsxs)(_j,{children:[z.map(e=>(0,ti.jsxs)(Ij,{children:[(0,ti.jsx)(Vj,{src:e.image,alt:e.title}),(0,ti.jsx)(Bj,{children:e.title})]},e.id)),(0,ti.jsxs)(Ij,{children:[(0,ti.jsx)(Wj,{children:(0,ti.jsx)(cg,{size:24})}),(0,ti.jsx)(Bj,{children:"Add"})]})]})]}),(0,ti.jsxs)(Hj,{children:[(0,ti.jsxs)(Uj,{active:"posts"===t,onClick:()=>n("posts"),children:[(0,ti.jsx)(fj,{size:20}),"Posts"]}),(0,ti.jsxs)(Uj,{active:"reels"===t,onClick:()=>n("reels"),children:[(0,ti.jsx)(ip,{size:20}),"Reels"]}),(0,ti.jsxs)(Uj,{active:"tagged"===t,onClick:()=>n("tagged"),children:[(0,ti.jsx)(gj,{size:20}),"Tagged"]}),(0,ti.jsxs)(Uj,{active:"liked"===t,onClick:()=>n("liked"),children:[(0,ti.jsx)(gp,{size:20}),"Liked"]}),(0,ti.jsxs)(Uj,{active:"saved"===t,onClick:()=>n("saved"),children:[(0,ti.jsx)(fp,{size:20}),"Saved"]}),(0,ti.jsxs)(Uj,{active:"music"===t,onClick:()=>n("music"),children:[(0,ti.jsx)(hp,{size:20}),"Music"]})]}),(()=>{switch(t){case"posts":return(0,ti.jsx)(qj,{children:R.map(e=>(0,ti.jsxs)(Yj,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*e.id},children:[(0,ti.jsx)(Kj,{src:e.image,alt:`Post ${e.id}`}),(0,ti.jsxs)(Gj,{children:[(0,ti.jsxs)(Xj,{children:[(0,ti.jsxs)("span",{children:[e.likes," likes"]}),(0,ti.jsxs)("span",{children:[e.comments," comments"]})]}),(0,ti.jsx)("div",{style:{marginTop:"8px",display:"flex",flexWrap:"wrap",gap:"4px"},children:e.tags.map((e,t)=>(0,ti.jsxs)("span",{style:{background:"#667eea20",color:"#667eea",padding:"2px 8px",borderRadius:"12px",fontSize:"12px"},children:["#",e]},t))})]})]},e.id))});case"reels":return(0,ti.jsx)(qj,{children:M.map(e=>(0,ti.jsxs)(Yj,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*e.id},onClick:()=>{b(e),x(!0)},children:[(0,ti.jsxs)("div",{style:{position:"relative"},children:[(0,ti.jsx)(Kj,{src:e.video,alt:`Reel ${e.id}`}),(0,ti.jsx)("div",{style:{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)",background:"rgba(0,0,0,0.7)",borderRadius:"50%",padding:"12px",color:"white"},children:(0,ti.jsx)(hp,{size:24})}),(0,ti.jsx)("div",{style:{position:"absolute",bottom:"8px",right:"8px",background:"rgba(0,0,0,0.7)",color:"white",padding:"4px 8px",borderRadius:"4px",fontSize:"12px"},children:e.duration})]}),(0,ti.jsxs)(Gj,{children:[(0,ti.jsxs)(Xj,{children:[(0,ti.jsxs)("span",{children:[e.likes," likes"]}),(0,ti.jsxs)("span",{children:[e.comments," comments"]}),(0,ti.jsxs)("span",{children:[e.views," views"]})]}),(0,ti.jsx)("div",{style:{marginTop:"8px",display:"flex",flexWrap:"wrap",gap:"4px"},children:e.tags.map((e,t)=>(0,ti.jsxs)("span",{style:{background:"#667eea20",color:"#667eea",padding:"2px 8px",borderRadius:"12px",fontSize:"12px"},children:["#",e]},t))})]})]},e.id))});case"tagged":return(0,ti.jsx)(qj,{children:L.map(e=>(0,ti.jsxs)(Yj,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*e.id},children:[(0,ti.jsx)(Kj,{src:e.image,alt:`Tagged post ${e.id}`}),(0,ti.jsxs)(Gj,{children:[(0,ti.jsxs)(Xj,{children:[(0,ti.jsxs)("span",{children:[e.likes," likes"]}),(0,ti.jsxs)("span",{children:[e.comments," comments"]})]}),(0,ti.jsxs)("div",{style:{marginTop:"8px",fontSize:"12px",color:"#667eea"},children:["Tagged by ",e.taggedBy]})]})]},e.id))});case"music":return(0,ti.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:"24px"},children:[(0,ti.jsxs)("div",{children:[(0,ti.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"16px"},children:[(0,ti.jsx)("h3",{style:{margin:0,color:"#2d3748"},children:"Local Music Library"}),(0,ti.jsxs)("button",{onClick:()=>ue(!0),style:{background:"#667eea",color:"white",border:"none",padding:"8px 16px",borderRadius:"8px",cursor:"pointer",display:"flex",alignItems:"center",gap:"8px",fontSize:"14px"},children:[(0,ti.jsx)(Bg,{size:16}),"Upload Music"]})]}),se.length>0?(0,ti.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:"8px"},children:se.map(e=>(0,ti.jsxs)("div",{style:{background:"#ffffff",borderRadius:"8px",padding:"12px 16px",boxShadow:"0 1px 3px rgba(0,0,0,0.1)",display:"flex",alignItems:"center",gap:"12px",cursor:"pointer"},children:[(0,ti.jsx)("div",{style:{width:"40px",height:"40px",borderRadius:"50%",background:"#667eea20",display:"flex",alignItems:"center",justifyContent:"center",color:"#667eea"},onClick:()=>de(e,se),children:(null===_||void 0===_?void 0:_.id)===e.id&&V?(0,ti.jsx)(Rm,{size:16}):(0,ti.jsx)(hp,{size:16})}),(0,ti.jsx)("img",{src:e.image,alt:e.title,style:{width:"40px",height:"40px",borderRadius:"4px",objectFit:"cover"}}),(0,ti.jsxs)("div",{style:{flex:1},children:[(0,ti.jsx)("h4",{style:{margin:"0 0 4px 0",color:"#2d3748",fontSize:"14px"},children:e.title}),(0,ti.jsxs)("p",{style:{margin:0,color:"#718096",fontSize:"12px"},children:[e.artist," \u2022 ",e.album]})]}),(0,ti.jsx)("button",{onClick:()=>{return t=e.id,void le(e=>e.filter(e=>e.id!==t));var t},style:{background:"#fc8181",color:"white",border:"none",padding:"4px 8px",borderRadius:"4px",cursor:"pointer",fontSize:"12px"},children:"Delete"})]},e.id))}):(0,ti.jsxs)("div",{style:{background:"#f7fafc",border:"2px dashed #e2e8f0",borderRadius:"8px",padding:"24px",textAlign:"center",color:"#718096"},children:[(0,ti.jsx)(op,{size:48,style:{margin:"0 auto 12px"}}),(0,ti.jsx)("p",{style:{margin:0,fontSize:"14px"},children:"No local music files uploaded yet"}),(0,ti.jsx)("p",{style:{margin:"4px 0 0 0",fontSize:"12px"},children:'Click "Upload Music" to add your favorite songs'})]})]}),(0,ti.jsxs)("div",{children:[(0,ti.jsx)("h3",{style:{marginBottom:"16px",color:"#2d3748"},children:"My Playlists"}),(0,ti.jsx)("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(200px, 1fr))",gap:"16px"},children:N.playlists.map(e=>(0,ti.jsxs)("div",{style:{background:"#ffffff",borderRadius:"12px",padding:"16px",boxShadow:"0 2px 8px rgba(0,0,0,0.1)",cursor:"pointer",transition:"transform 0.2s ease",display:"flex",flexDirection:"column",alignItems:"center"},onClick:()=>I(N.favorites.find(t=>t.title===e.name)||null),children:[(0,ti.jsx)("img",{src:e.image,alt:e.name,style:{width:"100%",height:"120px",borderRadius:"8px",objectFit:"cover",marginBottom:"12px"}}),(0,ti.jsx)("h4",{style:{margin:"0 0 4px 0",color:"#2d3748"},children:e.name}),(0,ti.jsxs)("p",{style:{margin:0,color:"#718096",fontSize:"14px"},children:[e.songCount," songs"]})]},e.id))})]}),(0,ti.jsxs)("div",{children:[(0,ti.jsx)("h3",{style:{marginBottom:"16px",color:"#2d3748"},children:"Favorite Songs"}),(0,ti.jsx)("div",{style:{display:"flex",flexDirection:"column",gap:"8px"},children:N.favorites.map(e=>(0,ti.jsxs)("div",{style:{background:"#ffffff",borderRadius:"8px",padding:"12px 16px",boxShadow:"0 1px 3px rgba(0,0,0,0.1)",display:"flex",alignItems:"center",gap:"12px",cursor:"pointer"},onClick:()=>de(e),children:[(0,ti.jsx)("div",{style:{width:"40px",height:"40px",borderRadius:"50%",background:"#667eea20",display:"flex",alignItems:"center",justifyContent:"center",color:"#667eea"},children:(null===_||void 0===_?void 0:_.id)===e.id&&V?(0,ti.jsx)(Rm,{size:16}):(0,ti.jsx)(hp,{size:16})}),(0,ti.jsxs)("div",{style:{flex:1},children:[(0,ti.jsx)("h4",{style:{margin:"0 0 4px 0",color:"#2d3748",fontSize:"14px"},children:e.title}),(0,ti.jsxs)("p",{style:{margin:0,color:"#718096",fontSize:"12px"},children:[e.artist," \u2022 ",e.genre]})]}),(0,ti.jsx)("span",{style:{color:"#718096",fontSize:"12px"},children:e.duration})]},e.id))})]}),te&&_&&(0,ti.jsxs)("div",{style:{background:"#ffffff",padding:"16px",borderRadius:"12px",boxShadow:"0 1px 3px rgba(0,0,0,0.1)",display:"flex",alignItems:"center",gap:"16px",marginTop:"24px"},children:[(0,ti.jsx)("img",{src:_.image,alt:_.title,style:{width:"60px",height:"60px",borderRadius:"8px",objectFit:"cover"}}),(0,ti.jsxs)("div",{style:{flex:1},children:[(0,ti.jsx)("h4",{style:{margin:"0 0 4px 0",color:"#2d3748"},children:_.title}),(0,ti.jsxs)("p",{style:{margin:0,color:"#718096",fontSize:"14px"},children:[_.artist," \u2022 ",_.genre]})]}),(0,ti.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"12px"},children:[(0,ti.jsx)("button",{onClick:me,style:{background:"transparent",border:"none",cursor:"pointer"},children:(0,ti.jsx)(Am,{size:20,color:"#718096"})}),(0,ti.jsx)("button",{onClick:he,style:{background:"transparent",border:"none",cursor:"pointer"},children:V?(0,ti.jsx)(Rm,{size:20,color:"#2d3748"}):(0,ti.jsx)(hp,{size:20,color:"#2d3748"})}),(0,ti.jsx)("button",{onClick:pe,style:{background:"transparent",border:"none",cursor:"pointer"},children:(0,ti.jsx)(Mm,{size:20,color:"#718096"})})]})]})]});case"liked":return(0,ti.jsx)(qj,{children:D.map(e=>(0,ti.jsxs)(Yj,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*e.id},children:[(0,ti.jsx)(Kj,{src:e.image,alt:`Liked post ${e.id}`}),(0,ti.jsx)(Gj,{children:(0,ti.jsxs)(Xj,{children:[(0,ti.jsxs)("span",{children:[e.likes," likes"]}),(0,ti.jsxs)("span",{children:[e.comments," comments"]})]})})]},e.id))});case"saved":return(0,ti.jsx)(qj,{children:O.map(e=>(0,ti.jsxs)(Yj,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*e.id},children:[(0,ti.jsx)(Kj,{src:e.image,alt:`Saved post ${e.id}`}),(0,ti.jsx)(Gj,{children:(0,ti.jsxs)(Xj,{children:[(0,ti.jsxs)("span",{children:[e.likes," likes"]}),(0,ti.jsxs)("span",{children:[e.comments," comments"]})]})})]},e.id))});default:return null}})(),(0,ti.jsx)(yi,{children:r&&(0,ti.jsx)(Qj,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:()=>i(!1),children:(0,ti.jsxs)(Jj,{initial:{opacity:0,scale:.9},animate:{opacity:1,scale:1},exit:{opacity:0,scale:.9},onClick:e=>e.stopPropagation(),children:[(0,ti.jsx)(Nj,{children:"Edit Profile"}),(0,ti.jsxs)(Zj,{onSubmit:e=>{e.preventDefault();const t=new FormData(e.target),n={...E,name:t.get("name"),bio:t.get("bio"),location:t.get("location"),website:t.get("website")};T(n),C({name:n.name}),i(!1)},children:[(0,ti.jsxs)(e$,{children:[(0,ti.jsx)(t$,{htmlFor:"name",children:"Name"}),(0,ti.jsx)(n$,{id:"name",name:"name",defaultValue:E.name,required:!0})]}),(0,ti.jsxs)(e$,{children:[(0,ti.jsx)(t$,{htmlFor:"bio",children:"Bio"}),(0,ti.jsx)(r$,{id:"bio",name:"bio",defaultValue:E.bio,placeholder:"Tell us about yourself..."})]}),(0,ti.jsxs)(e$,{children:[(0,ti.jsx)(t$,{htmlFor:"location",children:"Location"}),(0,ti.jsx)(n$,{id:"location",name:"location",defaultValue:E.location,placeholder:"Where are you from?"})]}),(0,ti.jsxs)(e$,{children:[(0,ti.jsx)(t$,{htmlFor:"website",children:"Website"}),(0,ti.jsx)(n$,{id:"website",name:"website",type:"url",defaultValue:E.website,placeholder:"https://yourwebsite.com"})]}),(0,ti.jsxs)(i$,{children:[(0,ti.jsx)(Oj,{type:"button",onClick:()=>i(!1),children:"Cancel"}),(0,ti.jsx)(Dj,{type:"submit",children:"Save Changes"})]})]})]})})}),(0,ti.jsx)(yi,{children:y&&v&&(0,ti.jsx)(a$,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:()=>x(!1),children:(0,ti.jsxs)(s$,{onClick:e=>e.stopPropagation(),children:[(0,ti.jsxs)(l$,{children:[(0,ti.jsx)(c$,{src:v.video,autoPlay:!0,muted:!0,loop:!0,controls:!1}),(0,ti.jsx)(m$,{onClick:()=>x(!1),children:(0,ti.jsx)(Th,{size:20})}),(0,ti.jsxs)(u$,{children:[(0,ti.jsx)("div",{style:{marginBottom:"8px"},children:(0,ti.jsxs)("strong",{children:["@",E.username]})}),(0,ti.jsx)("div",{style:{fontSize:"14px",opacity:.9},children:"Check out this amazing reel! \ud83c\udfac"}),(0,ti.jsx)("div",{style:{marginTop:"8px",display:"flex",flexWrap:"wrap",gap:"4px"},children:v.tags.map((e,t)=>(0,ti.jsxs)("span",{style:{background:"rgba(255,255,255,0.2)",padding:"2px 8px",borderRadius:"12px",fontSize:"12px"},children:["#",e]},t))})]}),(0,ti.jsxs)(d$,{children:[(0,ti.jsxs)("div",{style:{textAlign:"center"},children:[(0,ti.jsx)(h$,{children:(0,ti.jsx)(gp,{size:24})}),(0,ti.jsx)("div",{style:{fontSize:"12px",marginTop:"4px"},children:v.likes})]}),(0,ti.jsxs)("div",{style:{textAlign:"center"},children:[(0,ti.jsx)(h$,{children:(0,ti.jsx)(Ci,{size:24})}),(0,ti.jsx)("div",{style:{fontSize:"12px",marginTop:"4px"},children:v.comments})]}),(0,ti.jsxs)("div",{style:{textAlign:"center"},children:[(0,ti.jsx)(h$,{children:(0,ti.jsx)(yj,{size:24})}),(0,ti.jsx)("div",{style:{fontSize:"12px",marginTop:"4px"},children:"Share"})]}),(0,ti.jsxs)("div",{style:{textAlign:"center"},children:[(0,ti.jsx)(h$,{children:(0,ti.jsx)(om,{size:24})}),(0,ti.jsx)("div",{style:{fontSize:"12px",marginTop:"4px"},children:v.views})]})]})]}),(0,ti.jsxs)(p$,{children:[(0,ti.jsxs)("div",{style:{marginBottom:"20px"},children:[(0,ti.jsxs)("h3",{style:{margin:"0 0 8px 0",display:"flex",alignItems:"center",gap:"8px"},children:[(0,ti.jsx)(ip,{size:20}),"Reel Details"]}),(0,ti.jsxs)("div",{style:{display:"flex",gap:"16px",marginBottom:"12px"},children:[(0,ti.jsxs)("span",{style:{color:"#718096",fontSize:"14px"},children:["Duration: ",v.duration]}),(0,ti.jsxs)("span",{style:{color:"#718096",fontSize:"14px"},children:["Views: ",v.views]})]})]}),(0,ti.jsxs)("div",{style:{marginBottom:"20px"},children:[(0,ti.jsx)("h4",{style:{margin:"0 0 12px 0"},children:"Engagement"}),(0,ti.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:"8px"},children:[(0,ti.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"8px"},children:[(0,ti.jsx)(gp,{size:16,color:"#e53e3e"}),(0,ti.jsxs)("span",{children:[v.likes," likes"]})]}),(0,ti.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"8px"},children:[(0,ti.jsx)(Ci,{size:16,color:"#3182ce"}),(0,ti.jsxs)("span",{children:[v.comments," comments"]})]}),(0,ti.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"8px"},children:[(0,ti.jsx)(om,{size:16,color:"#38a169"}),(0,ti.jsxs)("span",{children:[v.views," views"]})]})]})]}),(0,ti.jsxs)("div",{children:[(0,ti.jsx)("h4",{style:{margin:"0 0 12px 0"},children:"Tags"}),(0,ti.jsx)("div",{style:{display:"flex",flexWrap:"wrap",gap:"8px"},children:v.tags.map((e,t)=>(0,ti.jsxs)("span",{style:{background:"#667eea20",color:"#667eea",padding:"4px 12px",borderRadius:"12px",fontSize:"12px",border:"1px solid #667eea30"},children:["#",e]},t))})]})]})]})})}),(0,ti.jsx)(_h,{isOpen:o,onClose:()=>a(!1),onConfirm:()=>{alert("Account deletion functionality would be implemented here"),a(!1)},title:"Delete Account",message:"Are you sure you want to delete your account? This action cannot be undone and all your data will be permanently removed.",confirmText:"Delete Account",cancelText:"Cancel",variant:"danger"})]})}),g$=Jr.div`
  display: flex;
  min-height: 100vh;
`,y$=Jr.main`
  flex: 1;
  margin-left: ${e=>{let{$navOpen:t}=e;return t?"280px":"80px"}};
  margin-top: 80px;
  padding: ${e=>{let{theme:t}=e;return t.spacing.md}};
  background: ${e=>{let{theme:t}=e;return t.colors.background}};
  min-height: calc(100vh - 80px);
  transition: margin-left 0.3s ease;
  
  @media (max-width: ${e=>{let{theme:t}=e;return t.breakpoints.md}}) {
    margin-left: 0;
    padding: ${e=>{let{theme:t}=e;return t.spacing.sm}};
  }
  
  @media (max-width: ${e=>{let{theme:t}=e;return t.breakpoints.sm}}) {
    margin-top: 70px;
    padding: ${e=>{let{theme:t}=e;return t.spacing.xs}};
  }
`,x$=()=>{const{theme:t}=Sh(),{isAuthenticated:n}=Ch(),[r,i]=(0,e.useState)(!1),[o,a]=(0,e.useState)(!0),[s,l]=(0,e.useState)(!1);return o||n?(0,ti.jsxs)(Hr,{theme:t,children:[(0,ti.jsx)(Jm,{}),(0,ti.jsx)(yi,{mode:"wait",children:o?(0,ti.jsx)(tm,{onComplete:()=>{a(!1)}},"loading"):(0,ti.jsxs)(Je,{children:[(0,ti.jsx)(Wp,{}),(0,ti.jsxs)(g$,{children:[(0,ti.jsx)(tp,{}),(0,ti.jsx)(Ap,{isOpen:r,onToggle:()=>i(!r)}),(0,ti.jsxs)(y$,{$navOpen:r,children:[(0,ti.jsxs)(ye,{children:[(0,ti.jsx)(fe,{path:"/",element:(0,ti.jsx)(hj,{})}),(0,ti.jsx)(fe,{path:"/profile",element:(0,ti.jsx)(f$,{})}),(0,ti.jsx)(fe,{path:"/shop",element:(0,ti.jsx)(sg,{})}),(0,ti.jsx)(fe,{path:"/community",element:(0,ti.jsx)(Ng,{})}),(0,ti.jsx)(fe,{path:"/wallet",element:(0,ti.jsx)(hy,{})}),(0,ti.jsx)(fe,{path:"/settings",element:(0,ti.jsx)(Ey,{})}),(0,ti.jsx)(fe,{path:"/auth",element:(0,ti.jsx)(Uy,{})}),(0,ti.jsx)(fe,{path:"/login",element:(0,ti.jsx)(Uy,{})}),(0,ti.jsx)(fe,{path:"/register",element:(0,ti.jsx)(Uy,{})}),(0,ti.jsx)(fe,{path:"/developer",element:(0,ti.jsx)(Sx,{})}),(0,ti.jsx)(fe,{path:"/gaming",element:(0,ti.jsx)(Zx,{})}),(0,ti.jsx)(fe,{path:"/business",element:(0,ti.jsx)(zv,{})}),(0,ti.jsx)(fe,{path:"/groups",element:(0,ti.jsx)(Jv,{})}),(0,ti.jsx)(fe,{path:"/contact",element:(0,ti.jsx)(Cb,{})}),(0,ti.jsx)(fe,{path:"/messages",element:(0,ti.jsx)(Qb,{})}),(0,ti.jsx)(fe,{path:"/friends",element:(0,ti.jsx)(Ew,{})}),(0,ti.jsx)(fe,{path:"/reels",element:(0,ti.jsx)(lk,{})}),(0,ti.jsx)(fe,{path:"/music",element:(0,ti.jsx)(kk,{})}),(0,ti.jsx)(fe,{path:"/trending",element:(0,ti.jsx)(Uk,{})}),(0,ti.jsx)(fe,{path:"/live",element:(0,ti.jsx)(eS,{})}),(0,ti.jsx)(fe,{path:"/feed",element:(0,ti.jsx)(ej,{})}),(0,ti.jsx)(fe,{path:"/saved",element:(0,ti.jsx)(ij,{})}),(0,ti.jsx)(fe,{path:"/liked",element:(0,ti.jsx)(lj,{})})]}),(0,ti.jsx)(Qm,{})]})]}),(0,ti.jsx)(zm,{isOpen:s,onClose:()=>l(!1),onRegister:e=>{console.log("User registered:",e)}})]},"app")})]}):(0,ti.jsxs)(Hr,{theme:t,children:[(0,ti.jsx)(Jm,{}),(0,ti.jsx)(Uy,{})]})};const v$=function(){return(0,ti.jsx)(Eh,{children:(0,ti.jsx)(af,{children:(0,ti.jsx)(cf,{children:(0,ti.jsx)(jh,{children:(0,ti.jsx)(tf,{children:(0,ti.jsx)(Fm,{children:(0,ti.jsx)(df,{children:(0,ti.jsx)(x$,{})})})})})})})})},b$=e=>{e&&e instanceof Function&&n.e(453).then(n.bind(n,453)).then(t=>{let{getCLS:n,getFID:r,getFCP:i,getLCP:o,getTTFB:a}=t;n(e),r(e),i(e),o(e),a(e)})};t.createRoot(document.getElementById("root")).render((0,ti.jsx)(e.StrictMode,{children:(0,ti.jsx)(v$,{})})),b$()})()})();
//# sourceMappingURL=main.d07af3e0.js.map